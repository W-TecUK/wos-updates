"""satshelf: the W-OS 4 shelf, native GTK + cairo (no web). One transparent window along the bottom edge, three parts:
LEFT   the ring and your essentials (basic apps, pinned, always there);
MIDDLE a capsule of the apps that are open right now;
RIGHT  live pills (music, update, ...), which never move when an app opens.
The style (a preference) is how a newly opened app reaches the middle: "join" grows a capsule at the centre, "morph" sends
the icon across on an arc. Both move on one spring (see satshelf_layout.py). All solid colour, no blur; icons upright.
The window's input region is only the visible capsules, so the rest of the bottom edge is click-through.
Preference file: ~/.config/wos/shelf.json ({"style": "join"|"morph"}), changes live.
"""
import json
import os
import sys
import time

import cairo
import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("Pango", "1.0")
gi.require_version("PangoCairo", "1.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk, Pango, PangoCairo  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import satshelf_layout as L  # noqa: E402
import satperf  # noqa: E402
from satglass import Glass, read_mode  # noqa: E402

try:
    gi.require_version("Wnck", "3.0")
    from gi.repository import Wnck  # noqa: E402
except (ValueError, ImportError):
    Wnck = None

CONFIG = os.path.join(os.path.expanduser("~"), ".config", "wos", "shelf.json")
FILL, EDGE, TRACK, YELLOW = (0x14 / 255,) * 3, (0x3A / 255,) * 3, (0x44 / 255,) * 3, (1.0, 0xC9 / 255, 0x33 / 255)
MARK = "/usr/share/wos/satisfaction/icons/wos-mark-dark.svg"
STYLES = ("join", "morph")
HOVER_OPEN_MS, IDLE_CLOSE_MS = 250, 2000


def read_style():
    try:
        with open(CONFIG, encoding="utf-8") as f:
            s = json.load(f).get("style")
            return s if s in STYLES else "join"
    except (OSError, ValueError, AttributeError):
        return "join"


def _read_all():
    try:
        with open(CONFIG, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_all(d):
    os.makedirs(os.path.dirname(CONFIG), exist_ok=True)
    tmp = CONFIG + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, CONFIG)


def write_style(style):
    if style not in STYLES:
        raise ValueError(style)
    d = _read_all()
    d["style"] = style
    _write_all(d)


def read_background():
    """Does the dock sit on a panel? Off by default: the icons float on the desktop (needs a see-through window; without one the panel stays)."""
    return _read_all().get("background") is True


def write_background(on):
    d = _read_all()
    d["background"] = bool(on)
    _write_all(d)


def rounded(cr, x, y, w, h, radii):
    tl, tr, br, bl = [min(r, w / 2, h / 2) for r in radii]
    cr.new_sub_path()
    cr.arc(x + w - tr, y + tr, tr, -1.5708, 0)
    cr.arc(x + w - br, y + h - br, br, 0, 1.5708)
    cr.arc(x + bl, y + h - bl, bl, 1.5708, 3.1416)
    cr.arc(x + tl, y + tl, tl, 3.1416, 4.7124)
    cr.close_path()


class Shelf:
    def __init__(self, launch, on_all_apps=None, pinned=None, geo=None, glass=None):
        self.launch, self.on_all_apps = launch, on_all_apps
        self.style = read_style()
        self.background = read_background()
        self.reduce_motion = satperf.cheap()          # flat mode snaps instead of animating
        self.pills = []
        self.running = []                          # [{"id", "klass", "pixbuf", "window"}] from the window list
        self.essentials = [{"id": did, "icon": icon, "running": False, "window": None} for did, icon in (pinned or [])]
        self.active = []                           # [{"key", "item", "e": Spring, "from": (x, y) | None}]
        self.press = None                          # (essential index, started at)
        self.last_tick = None
        self.icon_cache = {}
        self.frame = None
        self.pointer = None

        display = Gdk.Display.get_default()
        mon = display.get_primary_monitor() or display.get_monitor(0)
        self.geo = geo or mon.get_geometry()
        self.ui = 1.0
        self.scale = max(0.8, min(1.25, self.geo.width / 1920.0))
        self.glass = glass or Glass(self.geo.width, self.geo.height)
        self.strip_h = int((L.CAP_H + L.BOTTOM + L.ARC + 12) * self.scale)

        self.win = Gtk.Window()
        self.win.set_decorated(False)
        self.win.set_skip_taskbar_hint(True)
        self.win.set_skip_pager_hint(True)
        self.win.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.win.set_accept_focus(False)
        self.win.set_keep_above(True)
        self.win.set_app_paintable(True)
        self.alpha = satperf.use_alpha(self.win.get_screen())
        if self.alpha:
            self.win.set_visual(self.win.get_screen().get_rgba_visual())
        self.area = Gtk.DrawingArea()
        self.area.add_events(Gdk.EventMask.POINTER_MOTION_MASK | Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK | Gdk.EventMask.LEAVE_NOTIFY_MASK)
        self.area.connect("draw", self._draw)
        self.area.connect("motion-notify-event", self._motion)
        self.area.connect("leave-notify-event", lambda *_: setattr(self, "pointer", None))
        self.area.connect("button-release-event", self._click)
        self.win.add(self.area)
        self.win.set_default_size(self.geo.width, self.strip_h)
        self.win.move(self.geo.x, self.geo.y + self.geo.height - self.strip_h)
        self.win.resize(self.geo.width, self.strip_h)
        self.win.connect("realize", lambda *_: self._update_input())

        self._watch_config()
        self._watch_windows()

    # ---------- state ----------
    def show(self):
        self.win.show_all()
        self._update_input()
        self._kick()

    def set_style(self, style):
        if style in STYLES:
            self.style = style
            self._kick()

    def _refresh_theme(self):
        """Follow Settings: dark or light (and "auto" by the clock) for the panels, without a restart."""
        try:
            if self.glass.set_mode(read_mode()):
                self._kick()
        except Exception as e:                               # a theme glitch must never take the dock down
            print("wos-dock: theme: %s" % e, file=sys.stderr)

    def set_background(self, on):
        if on != self.background:
            self.background = on
            self._kick()

    def set_pill(self, pid, icon, title, state="", progress=None, app=None):
        """Show or update a live pill. Pills appear only while something is live; remove_pill when it ends."""
        pill = {"id": pid, "icon": icon, "title": title, "state": state, "progress": progress, "app": app}
        pill["natural_w"] = self._pill_natural_w(pill)
        for i, old in enumerate(self.pills):
            if old["id"] == pid:
                self.pills[i] = pill
                break
        else:
            self.pills.append(pill)
        self._kick()

    def remove_pill(self, pid):
        self.pills = [p for p in self.pills if p["id"] != pid]
        self._kick()

    def _pill_natural_w(self, pill):
        lay = self.area.create_pango_layout(pill["title"])
        lay.set_font_description(Pango.FontDescription("Syne Bold 10.5"))
        w = lay.get_pixel_size()[0]
        lay2 = self.area.create_pango_layout(pill["state"])
        lay2.set_font_description(Pango.FontDescription("Syne 9"))
        w = max(w, lay2.get_pixel_size()[0], 90 if pill.get("progress") is not None else 0)
        return 10 + 46 + 12 + w + 20

    @staticmethod
    def _match(item_id, klass):
        a, b = item_id.replace(".desktop", "").lower(), (klass or "").lower()
        return bool(b) and (a == b or a in b or b in a)

    # ---------- windows ----------
    def _watch_windows(self):
        self.wscreen = None
        if Wnck is None:
            return
        self.wscreen = Wnck.Screen.get_default()
        self.wscreen.force_update()
        for sig in ("window-opened", "window-closed", "active-window-changed"):
            self.wscreen.connect(sig, lambda *a: GLib.idle_add(self._windows_changed))
        self._windows_changed()

    def _windows_changed(self):
        if self.wscreen is None:
            return False
        running, seen = [], set()
        for w in self.wscreen.get_windows():
            if w.get_window_type() != Wnck.WindowType.NORMAL or w.is_skip_tasklist():
                continue
            klass = w.get_class_group_name() or w.get_name() or ""
            if klass.lower() in seen:
                continue                                      # one icon per app
            seen.add(klass.lower())
            running.append({"id": klass, "klass": klass, "pixbuf": w.get_icon(), "window": w})
        self.set_running(running)
        return False

    def set_running(self, running):
        """running: [{"id", "klass", "pixbuf", "window"}]. Updates the dashes and the middle capsule (with entry animation)."""
        self.running = running
        for it in self.essentials:
            hit = next((r for r in running if self._match(it["id"], r["klass"]) or self._match(it.get("icon") or "", r["klass"])), None)
            it["running"], it["window"] = hit is not None, hit["window"] if hit else None
        keys = [r["klass"].lower() for r in running]
        for a in self.active:                                # closed apps shrink away, then are dropped
            if a["key"] not in keys:
                a["e"].target = 0.0
                if self.reduce_motion:
                    a["e"].value, a["e"].velocity = 0.0, 0.0
        for r in running:
            key = r["klass"].lower()
            cur = next((a for a in self.active if a["key"] == key), None)
            if cur:
                cur["e"].target = 1.0
                cur["item"]["window"] = r["window"]
                continue
            ess = next((i for i, it in enumerate(self.essentials) if it["running"] and it["window"] is r["window"]), None)
            item = next((dict(it) for it in self.essentials if it["window"] is r["window"]), None) or \
                {"id": r["id"], "icon": None, "pixbuf": r.get("pixbuf"), "window": r["window"]}
            src = None
            if self.frame and ess is not None and ess < len(self.frame["icons"]):
                ic = self.frame["icons"][ess]
                src = (ic["x"] + ic["size"] / 2, ic["y"] + ic["size"] / 2)
            sp = L.Spring(1.0 if self.reduce_motion else 0.0)
            sp.target = 1.0
            self.active.append({"key": key, "item": item, "e": sp, "from": src})
        self._kick()

    # ---------- animation ----------
    def _kick(self):
        if self.last_tick is None:
            self.last_tick = time.monotonic()
            self.area.add_tick_callback(self._tick)
        self.area.queue_draw()

    def _tick(self, widget, clock):
        now = time.monotonic()
        dt, self.last_tick = now - self.last_tick, now
        busy = False
        for a in self.active:
            a["e"].step(dt)
            busy = busy or not a["e"].settled
        self.active = [a for a in self.active if not (a["e"].target == 0.0 and a["e"].settled)]
        if self.press is not None:
            if now - self.press[1] > 0.15:
                self.press = None
            else:
                busy = True
        self.area.queue_draw()
        self._update_input()
        if not busy:
            self.last_tick = None
            return False
        return True

    # ---------- drawing ----------
    def _icon(self, it, size):
        size = max(8, int(round(size)))
        key = (it.get("icon") or it["id"], size, id(it.get("pixbuf")))
        if key in self.icon_cache:
            return self.icon_cache[key]
        pb = None
        theme = Gtk.IconTheme.get_default()
        name = it.get("icon") or it["id"]
        try:
            if name and name.startswith("/"):
                pb = GdkPixbuf.Pixbuf.new_from_file_at_size(name, size, size)
            elif name and theme.has_icon(name):
                pb = theme.load_icon(name, size, 0)
        except GLib.Error:
            pb = None
        if pb is None and it.get("pixbuf") is not None:
            pb = it["pixbuf"].scale_simple(size, size, GdkPixbuf.InterpType.BILINEAR)
        if pb is None:
            try:
                pb = theme.load_icon("application-x-executable", size, 0)
            except GLib.Error:
                pb = None
        self.icon_cache[key] = pb
        return pb

    def _frame(self):
        press = None
        if self.press is not None:
            press = (self.press[0], 1.0)
        active = [{"item": a["item"], "e": a["e"].value, "from": a["from"]} for a in self.active]
        self.frame = L.frame(self.style, self.geo.width, self.geo.height, self.essentials, active, self._visible_pills(),
                             self.scale, self.reduce_motion, press)
        return self.frame

    def _visible_pills(self):
        """A pill whose app is itself open stays out: that app is already in the middle capsule. Now Playing is the exception, it always shows."""
        running = [(r.get("klass") or "").lower() for r in self.running]
        return [p for p in self.pills if not (p.get("app") and p["id"] != "music" and any(p["app"].lower() in k or k in p["app"].lower() for k in running if k))]

    def _dash(self, cr, cx, y):
        return                                       # no yellow line under running apps (Will, 18 Nov); the middle capsule already shows what is open
        s = self.scale
        cr.save()
        cr.translate(cx, y)
        cr.rotate(-0.2443)
        rounded(cr, -8 * s, -2 * s, 16 * s, 4 * s, (2 * s,) * 4)
        look = self.glass.look
        cr.set_source_rgb(*look["dash"])
        if look["dash_outline"]:
            cr.fill_preserve(); cr.set_source_rgba(*look["dash_outline"]); cr.set_line_width(1); cr.stroke()
        else:
            cr.fill()
        cr.restore()

    def _icon_shadow(self, cr, x, y, size):
        """No panel under the icons: a soft shadow under each one keeps it readable on a light wallpaper (stacked rounded rects, no blur filter)."""
        s = self.scale
        for i, a in ((3, 0.05), (2, 0.07), (1, 0.09)):
            g = i * 2.0 * s
            rounded(cr, x - g + 1 * s, y - g + 4 * s, size + 2 * g - 2 * s, size + 2 * g, (size * 0.24 + g,) * 4)
            cr.set_source_rgba(0, 0, 0, a)
            cr.fill()

    def _draw(self, widget, cr):
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)
        f = self._frame()
        top = self.geo.height - self.strip_h
        cr.translate(0, -top)
        s = self.scale

        x, y, w, h = f["capsule"]                                       # left: ring + essentials
        panel = self.background or not self.alpha       # no see-through window: the panel stays, or the icons would sit on black
        if panel:
            self.glass.paint(cr, x, y, w, h, L.capsule_radii(h), tag="left")
        rx, ry, rs = f["ring"]
        self._draw_ring(cr, rx, ry, rs)
        for ic in f["icons"]:
            pb = self._icon(ic["item"], ic["size"])
            if not panel:
                self._icon_shadow(cr, ic["x"], ic["y"], ic["size"])
            if ic["ring"]:                                              # 3 px yellow tail-corner ring while pressed
                rounded(cr, ic["x"] - 4 * s, ic["y"] - 4 * s, ic["size"] + 8 * s, ic["size"] + 8 * s, (14 * s, 14 * s, 14 * s, 5 * s))
                cr.set_source_rgb(*YELLOW); cr.set_line_width(3 * s); cr.stroke()
            if pb is not None:
                Gdk.cairo_set_source_pixbuf(cr, pb, ic["x"], ic["y"])
                cr.paint()
            if ic["running"]:
                self._dash(cr, ic["x"] + ic["size"] / 2, ic["y"] + ic["size"] + 10 * s)

        if f["mid"]:                                                    # middle: open apps
            x, y, w, h = f["mid"]
            if panel:
                self.glass.paint(cr, x, y, w, h, L.capsule_radii(h), tag="mid")
            for ic in f["mid_icons"]:
                pb = self._icon(ic["item"], ic["size"])
                if pb is not None and ic["alpha"] > 0.01:
                    Gdk.cairo_set_source_pixbuf(cr, pb, ic["x"], ic["y"])
                    cr.paint_with_alpha(min(1.0, ic["alpha"]))
                if ic["running"]:
                    self._dash(cr, ic["x"] + ic["size"] / 2, ic["y"] + ic["size"] + 8 * s)

        for p in f["pills"]:                                            # right: live pills
            self._draw_pill(cr, p)
        key = tuple(tuple(int(v) for v in r) for r in self._hit_rects())    # the clickable/visible shape follows what was just drawn
        if key != getattr(self, "_shape_key", None):
            self._shape_key = key
            GLib.idle_add(self._update_input)
        if self.glass.settling:                                         # a tint change is still easing: keep drawing
            self.glass.settling = False
            GLib.idle_add(self._kick)
        return True

    def _draw_grid(self, *a):
        pass

    def _draw_ring(self, cr, x, y, size):
        cr.save()
        cr.arc(x + size / 2, y + size / 2, size / 2 - 2 * self.scale, 0, 6.2832)
        cr.set_source_rgb(1, 1, 1); cr.fill_preserve()
        cr.set_source_rgb(*YELLOW); cr.set_line_width(4 * self.scale); cr.stroke()
        cr.restore()
        pb = self._icon({"id": "mark", "icon": MARK}, size * 0.47)
        if pb is not None:
            Gdk.cairo_set_source_pixbuf(cr, pb, x + (size - pb.get_width()) / 2, y + (size - pb.get_height()) / 2)
            cr.paint()

    def _draw_pill(self, cr, p):
        pill, x, y, w, h = p["pill"], p["x"], p["y"], p["w"], p["h"]
        s = self.scale
        if p["bg_alpha"] > 0.01:
            self.glass.paint(cr, x, y, w, h, L.pill_radii(h), alpha=p["bg_alpha"], tag="pill:" + p["pill"]["id"])
        icon_size = 46 * s
        ix = x + (10 * s if w > 100 * s else (w - icon_size) / 2)
        pb = self._icon({"id": pill["icon"], "icon": pill["icon"]}, icon_size)
        if pb is not None:
            Gdk.cairo_set_source_pixbuf(cr, pb, ix, y + (h - icon_size) / 2)
            cr.paint()
        if p["text_alpha"] > 0.02 and w > 120 * s:
            cr.save()
            cr.rectangle(x, y, w, h); cr.clip()
            tx = x + (10 + 46 + 12) * s
            for text, font, a, ty in ((pill["title"], "Syne Bold %d" % round(10.5 * s / self.ui), 1.0, y + h * 0.22), (pill["state"], "Syne %d" % round(9 * s / self.ui), 0.75, y + h * 0.52)):
                if not text:
                    continue
                lay = self.area.create_pango_layout(text)
                lay.set_font_description(Pango.FontDescription(font))
                cr.move_to(tx, ty if pill.get("progress") is None else ty - 4 * s)
                tc = self.glass.text if a >= 1.0 else self.glass.look["muted"][:3]
                cr.set_source_rgba(tc[0], tc[1], tc[2], (1.0 if a >= 1.0 else self.glass.look["muted"][3]) * p["text_alpha"])
                PangoCairo.show_layout(cr, lay)
            if pill.get("progress") is not None:
                bx, by, bw = tx, y + h - 18 * s, 90 * s
                rounded(cr, bx, by, bw, 4 * s, (2 * s,) * 4); cr.set_source_rgba(*TRACK, p["text_alpha"]); cr.fill()
                rounded(cr, bx, by, bw * max(0.0, min(1.0, pill["progress"])), 4 * s, (2 * s,) * 4); cr.set_source_rgba(*YELLOW, p["text_alpha"]); cr.fill()
            cr.restore()

    # ---------- input ----------
    def _hit_rects(self):
        """Rectangles (window coordinates) that should receive the pointer: left capsule, middle capsule, pills."""
        f = self.frame or self._frame()
        top = self.geo.height - self.strip_h
        rects = [f["capsule"]] + ([f["mid"]] if f["mid"] else []) + [(p["x"], p["y"], p["w"], p["h"]) for p in f["pills"]]
        return [(x, y - top, w, h) for (x, y, w, h) in rects if y - top + h > 0]

    def _update_input(self):
        gw = self.win.get_window()
        if gw is None:
            return False
        region = cairo.Region()
        for (x, y, w, h) in self._hit_rects():
            region.union(cairo.RectangleInt(int(x), int(max(0, y)), int(w) + 1, int(h) + 1))
        gw.input_shape_combine_region(region, 0, 0)
        if not self.alpha:                                   # no see-through window: cut the window to the capsules
            shape = cairo.Region()
            for (x, y, w, h) in self._hit_rects():
                shape.union(satperf.rounded_region(x, max(0, y), w, h, min(w, h) / 2.0))
            gw.shape_combine_region(shape, 0, 0)
        return False

    def _target_at(self, ex, ey):
        f = self.frame
        if f is None:
            return None
        ex_, ey_ = ex, ey + self.geo.height - self.strip_h
        rx, ry, rs = f["ring"]
        if rx <= ex_ <= rx + rs and ry <= ey_ <= ry + rs:
            return ("ring", None, None)
        for i, ic in enumerate(f["icons"]):
            if ic["x"] <= ex_ <= ic["x"] + ic["size"] and ic["y"] <= ey_ <= ic["y"] + ic["size"]:
                return ("essential", ic["item"], i)
        for ic in f["mid_icons"]:
            if ic["alpha"] > 0.5 and ic["x"] <= ex_ <= ic["x"] + ic["size"] and ic["y"] <= ey_ <= ic["y"] + ic["size"]:
                return ("active", ic["item"], None)
        for p in f["pills"]:
            if p["x"] <= ex_ <= p["x"] + p["w"] and p["y"] <= ey_ <= p["y"] + p["h"]:
                return ("pill", p["pill"], None)
        return None

    def _motion(self, w, ev):
        self.pointer = (ev.x, ev.y)
        tgt = bool(self._target_at(ev.x, ev.y))
        if tgt != getattr(self, "_hand", None):                  # only touch the cursor when it changes
            self._hand = tgt
            self.area.get_window().set_cursor(Gdk.Cursor.new_from_name(self.area.get_display(), "pointer" if tgt else "default"))

    def _click(self, w, ev):
        tgt = self._target_at(ev.x, ev.y)
        if not tgt:
            return
        kind, obj, idx = tgt
        if kind == "ring":
            if ev.button == 3 and self.on_orbit:
                self.on_orbit()                          # right-click: the favourites fan
            elif self.on_all_apps:
                self.on_all_apps()                       # click: Index
        elif kind in ("essential", "active"):
            if obj.get("window") is not None:
                obj["window"].activate(int(time.time()))
            else:
                if kind == "essential":
                    self.press = (idx, time.monotonic())     # a 150 ms press with a yellow ring, then the app opens
                self.launch(obj["id"])
            self._kick()
        elif kind == "pill" and self.on_pill:
            self.on_pill(obj)

    on_pill = None
    on_orbit = None

    # ---------- preference file ----------
    def _watch_config(self):
        os.makedirs(os.path.dirname(CONFIG), exist_ok=True)
        self.monitor = Gio.File.new_for_path(os.path.dirname(CONFIG)).monitor_directory(Gio.FileMonitorFlags.NONE, None)
        self.monitor.connect("changed", lambda *a: (self.set_style(read_style()), self.set_background(read_background()), self._refresh_theme()))
        GLib.timeout_add_seconds(60, lambda: (self._refresh_theme(), True)[1])      # "auto" flips at 19:00 and 07:00
