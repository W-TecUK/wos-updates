"use strict";
/* Notepad: a list of notes on the left, the note you are writing on the right. Saves as you type.
   Signed in with a W-Account, notes also sync with W-Life so they follow you to every device. They always save on this
   computer first, so writing never waits for the network. What to sync is decided in notesync.js (tested). */

boot(async () => {
  const root = $("#root");
  const S = window.NoteSync;
  const errText = e => (e && e.message) || "Something went wrong";
  let notes = await wos.data.get("notes", null);
  if (!notes) {
    notes = [{ id: uid(), title: "Welcome to Notepad", body: "Write anything. It saves as you type.\n\nPin a note to keep it at the top.", updated: Date.now(), pinned: true, welcome: true }];
    await wos.data.set("notes", notes);
  }
  let life = { signed_in: false }; try { life = await wos.call("life.status"); } catch (e) { /* older image */ }
  let syncOn = (await wos.data.get("syncOn", null)), pending = (await wos.data.get("pending", [])) || [];
  let current = notes[0].id, query = "", status = "", syncing = false, again = false;
  const persist = () => Promise.all([wos.data.set("notes", notes), wos.data.set("pending", pending)]);
  const save = debounce(() => persist(), 300);
  const get = id => notes.find(n => n.id === id);

  const list = h("div.list");
  const search = h("input.field", { placeholder: "Search", oninput: e => { query = e.target.value.toLowerCase(); drawList(); } });
  const addBtn = h("button.btn.small", { onclick: add }, h("span", { html: icon("plus", 14) }), "New");
  const side = h("aside.side", { style: "display:flex;flex-direction:column;padding:12px;gap:10px" },
    h("div", { style: "display:flex;gap:8px;align-items:center" }, h("div.search", { style: "flex:1" }, h("span", { html: icon("search") }), search), addBtn),
    h("div.card", { style: "flex:1;overflow:auto" }, list));
  const title = h("input.field", { placeholder: "Title", style: "border:0;background:none;font-size:22px;font-weight:800;padding:0;height:auto;border-radius:0", oninput: e => edit("title", e.target.value) });
  const text = h("textarea.field", { placeholder: "Start writing…", style: "flex:1;border:0;background:none;font-size:15px;line-height:1.65;padding:0;border-radius:0", oninput: e => edit("body", e.target.value) });
  const meta = h("div.small.muted"); const count = h("div.small.muted"); const chip = h("span.chip");
  const pin = h("button.icon-btn", { title: "Pin", onclick: () => { const n = get(current); n.pinned = !n.pinned; n.dirty = true; n.updated = Date.now(); save(); draw(); syncSoon(); } });
  const del = h("button.icon-btn", { title: "Delete note", html: icon("trash"), onclick: remove });
  const bar = h("div.bar", meta, chip, h("div.grow"), count, pin, del);
  const bannerEl = h("div");
  const editor = h("div", { style: "display:flex;flex-direction:column;flex:1;padding:22px 30px;gap:12px;min-height:0" }, title, text);
  root.append(h("div.app", side, h("div.main", bar, bannerEl, editor)));

  function edit(field, value) { const n = get(current); n[field] = value; n.updated = Date.now(); n.dirty = true; delete n.welcome; save(); drawList(); stats(); syncSoon(); }
  function add() { const n = { id: uid(), title: "", body: "", updated: Date.now(), pinned: false, rid: null, dirty: true, stamp: null }; notes.unshift(n); current = n.id; save(); draw(); title.focus(); }
  async function remove() {
    const n = get(current); if (!n) return;
    if (!await confirmBox("Delete this note?", `“${n.title || "Untitled"}” will be deleted for good${n.rid ? ", on your other devices too" : ""}.`, "Delete", true)) return;
    if (n.rid && !pending.includes(String(n.rid))) pending.push(String(n.rid));
    notes = notes.filter(x => x.id !== n.id); if (!notes.length) notes.push({ id: uid(), title: "", body: "", updated: Date.now(), pinned: false, rid: null, dirty: false, stamp: null });
    current = notes[0].id; save(); draw(); syncSoon();
  }
  function stats() { const n = get(current); const words = (n.body.trim().match(/\S+/g) || []).length; count.textContent = `${words} word${words === 1 ? "" : "s"}`; meta.textContent = "Edited " + new Date(n.updated).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }); }
  function drawList() {
    list.innerHTML = "";
    const shown = [...notes].filter(n => !query || (n.title + " " + n.body).toLowerCase().includes(query)).sort((a, b) => (b.pinned - a.pinned) || b.updated - a.updated);
    if (!shown.length) list.append(h("div.row.muted", "No notes"));
    shown.forEach(n => list.append(h("button.row" + (n.id === current ? ".on" : ""), { onclick: () => { current = n.id; draw(); } },
      h("div.grow", h("div.t", (n.pinned ? "★ " : "") + (n.title || "Untitled")), h("div.s", (n.body.split("\n")[0] || "No text").slice(0, 60))))));
  }
  function paintChip() {
    chip.textContent = !life.signed_in ? "On this computer" : !syncOn ? "Not syncing" : status || "Synced";
    chip.style.color = status.startsWith("Offline") || status.startsWith("Could not") ? "#d98a00" : "";
    bannerEl.innerHTML = "";
    if (life.signed_in && syncOn === null) bannerEl.append(h("div.card", { style: "margin:0 22px;padding:12px 16px;display:flex;align-items:center;gap:12px" }, h("div", { style: "flex:1" }, h("b", "Sync your notes with your W-Account?"), h("div.small.muted", "They will be kept on W-Life and appear on your other devices. They stay on this computer too.")),
      h("button.btn.small.ghost", { onclick: () => { syncOn = false; wos.data.set("syncOn", false); paintChip(); } }, "Not now"), h("button.btn.small", { onclick: () => { syncOn = true; wos.data.set("syncOn", true); paintChip(); sync(); } }, "Sync notes")));
    else if (life.signed_in && syncOn === false) bannerEl.append(h("div", { style: "margin:0 22px;font-size:12px" }, h("a", { href: "#", style: "color:var(--accent)", onclick: e => { e.preventDefault(); syncOn = true; wos.data.set("syncOn", true); paintChip(); sync(); } }, "Turn on sync")));
  }
  function draw() {
    const n = get(current);
    title.value = n.title; text.value = n.body; pin.innerHTML = icon("star"); pin.style.color = n.pinned ? "#ff9f0a" : "";
    drawList(); stats(); paintChip();
  }

  // ---------- sync with W-Life ----------
  async function life_(method, path, body) {
    const r = await wos.call("life.request", { method, path, body });
    if (!r.ok) { const e = new Error(r.message); e.offline = !!r.offline; throw e; }
    return r.data;
  }
  const syncSoon = debounce(() => sync(), 2500);
  async function sync() {
    if (!life.signed_in || !syncOn) return;
    if (syncing) { again = true; return; }
    syncing = true; status = "Syncing…"; paintChip();
    try {
      let remote = await life_("GET", "/api/v1/notes");
      const p = S.plan(notes.filter(n => !n.welcome), remote, pending);       // the starter note stays on this computer
      for (const id of p.deleteRemote) await life_("DELETE", "/api/v1/notes/" + encodeURIComponent(id));
      pending = pending.filter(id => !p.deleteRemote.includes(id) && !p.dropPending.includes(id));
      p.removeLocal.forEach(id => { notes = notes.filter(n => n.id !== id); });
      if (!notes.length) notes.push({ id: uid(), title: "", body: "", updated: Date.now(), pinned: false, rid: null, dirty: false, stamp: null });
      const stampOf = rid => (remote.find(r => String(r.id) === String(rid)) || {}).updated_at || null;
      const apply = (n, row) => { n.title = row.title || ""; n.body = row.body || ""; n.pinned = !!row.pinned; n.updated = Date.parse(row.updated_at) || Date.now(); n.dirty = false; };
      for (const c of p.conflicts) {                       // both changed: keep ours, save theirs as a separate note
        const row = await life_("GET", "/api/v1/notes/" + encodeURIComponent(c.rid));
        notes.unshift({ id: uid(), title: (row.title || "Untitled") + " (from another device)", body: row.body || "", pinned: false, updated: Date.now(), rid: null, dirty: true, stamp: null });
      }
      for (const x of p.pull) { const n = get(x.id), row = await life_("GET", "/api/v1/notes/" + encodeURIComponent(x.rid)); if (n && !n.dirty) { apply(n, row); n.stamp = stampOf(x.rid) || row.updated_at; } }
      for (const rid of p.pullNew) { const row = await life_("GET", "/api/v1/notes/" + encodeURIComponent(rid)); const n = { id: uid(), rid: String(rid), stamp: stampOf(rid) || row.updated_at }; apply(n, row); notes.push(n); }
      const pushed = [];
      for (const x of p.push) {
        const n = get(x.id); if (!n) continue;
        const seen = n.updated, body = { title: n.title, body: n.body, pinned: !!n.pinned };
        if (x.create || !n.rid) { const r = await life_("POST", "/api/v1/notes", { title: body.title, body: body.body }); n.rid = String(r.id); if (n.pinned) await life_("PUT", "/api/v1/notes/" + encodeURIComponent(n.rid), body); }
        else await life_("PUT", "/api/v1/notes/" + encodeURIComponent(n.rid), body);
        if (n.updated === seen) n.dirty = false;
        pushed.push(n);
      }
      if (pushed.length || p.pullNew.length) { remote = await life_("GET", "/api/v1/notes"); pushed.forEach(n => { n.stamp = stampOf(n.rid); }); }
      if (!get(current)) current = notes[0].id;
      status = "Synced · " + new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
    } catch (e) {
      status = e.offline ? "Offline: changes sync when you reconnect" : "Could not sync: " + errText(e);
    }
    await persist();
    syncing = false; draw();
    if (again) { again = false; syncSoon(); }
  }

  document.addEventListener("keydown", e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "n") { e.preventDefault(); add(); } });
  draw();
  if (life.signed_in && syncOn) sync();
  setInterval(() => { if (!document.hidden) sync(); }, 60000);
});
