"""Calendar reminders: tell the person a few minutes before an event starts, even with the Calendar closed. Pure functions, tested anywhere.

Events are the Calendar app's own shape: {id, title, location, start, end, allDay}, times in milliseconds since 1970.
"""
import datetime

LEAD_MINUTES = 10
MAX_TITLE = 80


def from_api(row):
    """A W-Life calendar row (title, location, start_at, end_at, all_day, id) -> the app's event, or None if it cannot be read."""
    try:
        start = datetime.datetime.fromisoformat(str(row["start_at"]).replace("Z", "+00:00")).timestamp() * 1000
        end = datetime.datetime.fromisoformat(str(row["end_at"]).replace("Z", "+00:00")).timestamp() * 1000
    except (KeyError, ValueError, TypeError):
        return None
    return {"id": "r" + str(row.get("id", "")), "title": str(row.get("title") or "")[:MAX_TITLE], "location": str(row.get("location") or "")[:MAX_TITLE],
            "start": int(start), "end": int(end), "allDay": bool(row.get("all_day"))}


def clean_local(raw):
    out = []
    for e in raw if isinstance(raw, list) else []:
        if isinstance(e, dict) and isinstance(e.get("start"), (int, float)) and isinstance(e.get("end"), (int, float)):
            out.append({"id": "l" + str(e.get("id", "")), "title": str(e.get("title") or "")[:MAX_TITLE], "location": str(e.get("location") or "")[:MAX_TITLE],
                        "start": int(e["start"]), "end": int(e["end"]), "allDay": bool(e.get("allDay"))})
    return out


def due(events, now_ms, fired, lead_minutes=LEAD_MINUTES):
    """Events that start within the next `lead_minutes` (or have only just started) and have not been announced.

    fired: dict of announced keys, updated here and pruned of anything long past. Returns [(key, title, body)]."""
    out = []
    window = lead_minutes * 60000
    for k in [k for k, ts in fired.items() if ts < now_ms - 6 * 3600000]:
        del fired[k]
    seen = set()
    for e in events:
        if e["allDay"] or not e["title"]:
            continue
        key = "%s@%d" % (e["id"], e["start"] // 60000)
        dup = (e["title"], e["start"])                          # the same event can arrive from both the account and this computer
        if dup in seen or key in fired:
            continue
        seen.add(dup)
        if now_ms - 2 * 60000 <= e["start"] <= now_ms + window:
            fired[key] = e["start"]
            mins = round((e["start"] - now_ms) / 60000)
            when = "Starting now" if mins <= 0 else "In %d minute%s" % (mins, "" if mins == 1 else "s")
            out.append((key, e["title"], when + (" · " + e["location"] if e["location"] else "")))
    return out
