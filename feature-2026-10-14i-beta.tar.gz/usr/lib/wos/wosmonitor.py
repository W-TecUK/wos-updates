"""System Monitor helpers: read /proc into plain numbers, and decide what may be force-quit.

Pure functions over text (so they are tested on any machine); only `snapshot` and `read_proc` touch /proc.
"""
import os
import re

# Things that end the session or the machine if killed. Matched against the process name and command line.
PROTECTED_NAMES = {"systemd", "init", "xorg", "xwayland", "lightdm", "xfwm4", "dbus-daemon", "pipewire", "wireplumber",
                   "pulseaudio", "networkmanager", "sudo", "login"}
PROTECTED_CMD = ("libexec/wos/shell", "libexec/wos/desktop-session", "libexec/wos/wos-updated", "libexec/wos/wos-priv")


def parse_stat(text):
    """/proc/<pid>/stat -> (name, state, cpu_ticks, rss_pages) or None. The name may contain spaces and brackets."""
    try:
        head, _, tail = text.rpartition(")")
        name = head.split("(", 1)[1]
        f = tail.split()
        return name, f[0], int(f[11]) + int(f[12]), int(f[21])
    except (IndexError, ValueError):
        return None


def parse_meminfo(text):
    """-> {total_kb, available_kb, swap_total_kb, swap_free_kb}"""
    vals = {}
    for line in text.splitlines():
        m = re.match(r"(\w+):\s+(\d+)", line)
        if m:
            vals[m.group(1)] = int(m.group(2))
    return {"total_kb": vals.get("MemTotal", 0), "available_kb": vals.get("MemAvailable", vals.get("MemFree", 0)),
            "swap_total_kb": vals.get("SwapTotal", 0), "swap_free_kb": vals.get("SwapFree", 0)}


def parse_cpu_total(text):
    """First line of /proc/stat -> (busy, total) jiffies."""
    first = text.splitlines()[0].split()
    nums = [int(x) for x in first[1:9]]
    idle = nums[3] + (nums[4] if len(nums) > 4 else 0)
    total = sum(nums)
    return total - idle, total


def percent(prev, cur):
    """CPU percent between two (busy, total) samples."""
    if not prev or cur[1] <= prev[1]:
        return 0.0
    return round(100.0 * (cur[0] - prev[0]) / (cur[1] - prev[1]), 1)


def process_cpu(prev_ticks, cur_ticks, prev_total, cur_total, cores):
    """Per-process CPU percent (100 = one full core), from tick counts and total jiffies of all cores."""
    if prev_ticks is None or cur_total <= prev_total:
        return 0.0
    return round(100.0 * cores * (cur_ticks - prev_ticks) / (cur_total - prev_total), 1)


def friendly_name(name, cmdline):
    """A readable name: the program in the command line when the kernel's 15-character name is cut off."""
    parts = [p for p in cmdline.split("\0") if p]
    if parts:
        base = os.path.basename(parts[0])
        if base in ("python3", "python", "sh", "bash", "node") and len(parts) > 1 and not parts[1].startswith("-"):
            script = os.path.basename(parts[1]) or base
            if script == "app" and len(parts) > 2:      # W-OS apps run as `app <id>`
                return "W-OS " + parts[2].title()
            if "/libexec/wos/" in parts[1]:             # W-OS's own helpers: "W-OS Shell", "W-OS Notify Watch"
                return "W-OS " + script.replace("wos-", "", 1).replace("-", " ").title()
            base = script
        if base and (len(name) >= 15 or base.lower().startswith(name.lower())):
            return base
    return name


def protected(pid, name, cmdline, self_pid=None):
    """Why this process must not be killed from here, or "" when it may be."""
    if pid <= 1 or pid == self_pid:
        return "This is part of the system."
    if not cmdline:
        return "This is part of the system."
    if name.lower() in PROTECTED_NAMES or any(p in cmdline for p in PROTECTED_CMD):
        return "Quitting this would end your session."
    return ""


def read(path):
    try:
        with open(path, "rb") as f:
            return f.read().decode("utf-8", "replace")
    except OSError:
        return ""


def read_proc(root="/proc", uid=None):
    """[{pid, name, state, ticks, rss_kb, cmd}] for the person's own processes (uid) or all of them."""
    out = []
    page = os.sysconf("SC_PAGE_SIZE") // 1024 if hasattr(os, "sysconf") else 4
    try:
        entries = os.listdir(root)
    except OSError:
        return out
    for e in entries:
        if not e.isdigit():
            continue
        p = os.path.join(root, e)
        try:
            if uid is not None and os.stat(p).st_uid != uid:
                continue
        except OSError:
            continue
        st = parse_stat(read(os.path.join(p, "stat")))
        if not st:
            continue
        cmd = read(os.path.join(p, "cmdline"))
        out.append({"pid": int(e), "name": friendly_name(st[0], cmd), "state": st[1], "ticks": st[2], "rss_kb": st[3] * page, "cmd": cmd})
    return out
