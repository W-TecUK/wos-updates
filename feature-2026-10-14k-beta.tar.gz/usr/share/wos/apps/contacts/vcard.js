"use strict";
/* vCard (.vcf) reading and writing for Contacts: the format phones, Apple, Google and Microsoft all import and export.
   No screen in here so it can be tested (os/tests/vcard.test.js). A person is {name, phone, email, address, notes}. */
(function (root) {
  const unescapeV = s => s.replace(/\\([nN,;\\])/g, (_, c) => (c === "n" || c === "N") ? "\n" : c);
  const escapeV = s => String(s || "").replace(/\\/g, "\\\\").replace(/\r?\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");
  // split on a separator that is not escaped with a backslash
  const splitUnescaped = (s, sep) => { const out = []; let cur = ""; for (let i = 0; i < s.length; i++) { if (s[i] === "\\" && i + 1 < s.length) { cur += s[i] + s[i + 1]; i++; } else if (s[i] === sep) { out.push(cur); cur = ""; } else cur += s[i]; } out.push(cur); return out; };

  function decodeQP(s) { return s.replace(/=\r?\n/g, "").replace(/=([0-9A-F]{2})/gi, (_, h) => String.fromCharCode(parseInt(h, 16))); }

  function parse(text) {
    const lines = String(text || "").replace(/\r\n?/g, "\n").replace(/\n[ \t]/g, "").split("\n");        // unfold continued lines
    const people = []; let card = null;
    for (const raw of lines) {
      const line = raw.trim();
      if (/^BEGIN:VCARD$/i.test(line)) { card = { fn: "", n: "", tel: "", email: "", adr: "", note: "" }; continue; }
      if (/^END:VCARD$/i.test(line)) {
        if (card) {
          const name = card.fn || card.n;
          if (name || card.tel || card.email) people.push({ name: name.trim(), phone: card.tel.trim(), email: card.email.trim(), address: card.adr.trim(), notes: card.note.trim() });
        }
        card = null; continue;
      }
      if (!card || !line.includes(":")) continue;
      const i = line.indexOf(":"), head = line.slice(0, i), value = line.slice(i + 1);
      const parts = head.split(";"), prop = parts[0].replace(/^.*\./, "").toUpperCase();         // "item1.EMAIL" -> EMAIL
      const qp = parts.some(p => /ENCODING=QUOTED-PRINTABLE/i.test(p));
      const val = qp ? decodeQP(value) : value;
      if (prop === "FN" && !card.fn) card.fn = unescapeV(val);
      else if (prop === "N" && !card.n) { const [fam = "", given = "", more = "", prefix = "", suffix = ""] = splitUnescaped(val, ";").map(unescapeV); card.n = [prefix, given, more, fam, suffix].filter(Boolean).join(" "); }
      else if (prop === "TEL" && !card.tel) card.tel = unescapeV(val);
      else if (prop === "EMAIL" && !card.email) card.email = unescapeV(val);
      else if (prop === "ADR" && !card.adr) card.adr = splitUnescaped(val, ";").map(unescapeV).filter(Boolean).join(", ");
      else if (prop === "NOTE" && !card.note) card.note = unescapeV(val);
    }
    return people;
  }

  function fold(line) { const out = []; while (line.length > 75) { out.push(line.slice(0, 75)); line = " " + line.slice(75); } out.push(line); return out.join("\r\n"); }

  function serialize(people) {
    return people.filter(p => p.name || p.phone || p.email).map(p => {
      const words = (p.name || "").trim().split(/\s+/).filter(Boolean), family = words.length > 1 ? words[words.length - 1] : "", given = words.length > 1 ? words.slice(0, -1).join(" ") : (words[0] || "");
      const rows = ["BEGIN:VCARD", "VERSION:3.0", "FN:" + escapeV(p.name || p.email || p.phone), `N:${escapeV(family)};${escapeV(given)};;;`];
      if (p.phone) rows.push("TEL;TYPE=CELL:" + escapeV(p.phone));
      if (p.email) rows.push("EMAIL;TYPE=INTERNET:" + escapeV(p.email));
      if (p.address) rows.push("ADR;TYPE=HOME:;;" + escapeV(p.address) + ";;;;");
      if (p.notes) rows.push("NOTE:" + escapeV(p.notes));
      rows.push("END:VCARD");
      return rows.map(fold).join("\r\n");
    }).join("\r\n") + "\r\n";
  }

  /* People from `incoming` that are not already in `existing` (same name, phone and email). */
  function newOnes(existing, incoming) {
    const key = p => [p.name, p.phone, p.email].map(x => String(x || "").trim().toLowerCase()).join("|");
    const have = new Set(existing.map(key)); const out = [];
    for (const p of incoming) { const k = key(p); if (!have.has(k)) { have.add(k); out.push(p); } }
    return out;
  }

  const api = { parse, serialize, newOnes };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.VCard = api;
})(typeof window !== "undefined" ? window : globalThis);
