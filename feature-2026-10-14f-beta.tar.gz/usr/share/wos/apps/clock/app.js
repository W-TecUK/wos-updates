"use strict";
/* Clock: world clocks, alarms, a stopwatch and timers. Alarms and timers are saved for the system, so they
   still ring when this window is closed. */

boot(async info => {
  const root = $("#root");
  let tab = (await wos.data.get("tab", "world")) || "world";
  let zones = (await wos.data.get("zones", null)) || ["Europe/London", "America/New_York", "Asia/Tokyo"];
  let clock = await wos.call("clock.get");
  const errText = e => (e && e.message) || "Something went wrong";
  const content = h("div", { style: "flex:1;min-height:0;overflow:auto;padding:0 24px 24px" });
  const seg = h("div.seg");
  root.append(h("div", { style: "display:flex;flex-direction:column;height:100%" }, h("div", { style: "padding:18px 24px 14px;display:flex;justify-content:center" }, seg), content));

  const ZONES = ["Europe/London", "Europe/Dublin", "Europe/Paris", "Europe/Berlin", "Europe/Madrid", "Europe/Rome", "Europe/Athens", "Europe/Istanbul", "Europe/Moscow", "Africa/Cairo", "Africa/Lagos", "Africa/Johannesburg",
    "Asia/Dubai", "Asia/Karachi", "Asia/Kolkata", "Asia/Dhaka", "Asia/Bangkok", "Asia/Singapore", "Asia/Hong_Kong", "Asia/Shanghai", "Asia/Seoul", "Asia/Tokyo", "Australia/Perth", "Australia/Sydney", "Pacific/Auckland",
    "Pacific/Honolulu", "America/Anchorage", "America/Los_Angeles", "America/Denver", "America/Chicago", "America/New_York", "America/Toronto", "America/Sao_Paulo", "America/Buenos_Aires", "America/Mexico_City"];
  const city = z => z.split("/").pop().replace(/_/g, " ");
  const timeIn = (z, d = new Date()) => d.toLocaleTimeString("en-GB", { timeZone: z, hour: "2-digit", minute: "2-digit" });
  const dayIn = (z, d = new Date()) => d.toLocaleDateString("en-GB", { timeZone: z, weekday: "short", day: "numeric", month: "short" });
  const offsetHours = z => { const d = new Date(); const t = new Date(d.toLocaleString("en-US", { timeZone: z })); const l = new Date(d.toLocaleString("en-US")); return Math.round((t - l) / 36e5 * 2) / 2; };
  const pad = n => String(n).padStart(2, "0");
  let timers = [];                     // intervals to clear when the tab changes
  const later = (fn, ms) => { const t = setInterval(fn, ms); timers.push(t); return t; };

  const saveClock = async () => { try { clock = await wos.call("clock.set", { data: clock }); } catch (e) { toast(errText(e)); } };

  function paintSeg() {
    seg.innerHTML = "";
    [["world", "World"], ["alarms", "Alarms"], ["stopwatch", "Stopwatch"], ["timer", "Timer"]].forEach(([k, l]) => seg.append(h("button" + (tab === k ? ".on" : ""), { onclick: () => { tab = k; wos.data.set("tab", k); draw(); } }, l)));
  }
  function draw() { timers.forEach(clearInterval); timers = []; paintSeg(); content.innerHTML = ""; views[tab](); }

  const views = {
    world() {
      const local = Intl.DateTimeFormat().resolvedOptions().timeZone;
      const list = h("div.card");
      const paint = () => {
        list.innerHTML = "";
        [local, ...zones.filter(z => z !== local)].forEach(z => {
          const off = offsetHours(z) - offsetHours(local);
          list.append(h("div.row", { style: "cursor:default;min-height:64px" }, h("div.grow", h("div.t", { style: "font-size:16px" }, z === local ? "Here · " + city(z) : city(z)),
            h("div.s", dayIn(z) + (z === local ? "" : off === 0 ? " · same time" : ` · ${Math.abs(off)} h ${off > 0 ? "ahead" : "behind"}`))),
            h("span.time", { "data-z": z, style: "font-size:30px;font-weight:800;font-variant-numeric:tabular-nums" }, timeIn(z)),
            z === local ? null : h("button.icon-btn", { title: "Remove", html: icon("x", 14), onclick: () => { zones = zones.filter(x => x !== z); wos.data.set("zones", zones); paint(); } })));
        });
      };
      paint();
      const dd = dropdown(ZONES.filter(z => z !== local).map(z => [z, city(z)]), { value: "", width: 220, onChange: v => { if (v && !zones.includes(v)) { zones.push(v); wos.data.set("zones", zones); paint(); } } });
      content.append(list, h("div", { style: "margin-top:14px;display:flex;align-items:center;gap:10px" }, h("span.muted", "Add a city"), dd));
      later(() => list.querySelectorAll(".time").forEach(el => { el.textContent = timeIn(el.dataset.z); }), 5000);
    },

    alarms() {
      const next = (() => { let best = null; const now = new Date();
        clock.alarms.filter(a => a.on).forEach(a => { for (let add = 0; add < 8; add++) { const d = new Date(now); d.setDate(d.getDate() + add); const [hh, mm] = a.time.split(":"); d.setHours(+hh, +mm, 0, 0);
          if (d <= now || (a.days.length && !a.days.includes((d.getDay() + 6) % 7))) continue; if (!best || d < best) best = d; break; } });
        return best; })();
      const mins = next ? Math.round((next - new Date()) / 60000) : 0;
      const list = h("div.card");
      if (!clock.alarms.length) list.append(h("div.muted", { style: "padding:28px;text-align:center" }, "No alarms yet."));
      [...clock.alarms].sort((a, b) => a.time.localeCompare(b.time)).forEach(a => {
        const sw = h("button.switch" + (a.on ? ".on" : ""), { onclick: async () => { a.on = !a.on; await saveClock(); draw(); } });
        list.append(h("div.row", { style: "cursor:default;min-height:68px" }, h("div.grow", { style: "cursor:pointer", onclick: () => editAlarm(a) },
          h("div", { style: "font-size:34px;font-weight:800;font-variant-numeric:tabular-nums;" + (a.on ? "" : "color:var(--muted)") }, a.time),
          h("div.s", (a.label || "Alarm") + " · " + daysText(a.days))), sw));
      });
      content.append(h("div", { style: "display:flex;align-items:center;margin-bottom:14px" }, h("div.muted", { style: "flex:1" }, next ? `Next alarm in ${mins >= 60 ? Math.floor(mins / 60) + " h " : ""}${mins % 60} min` : "No alarm is on"),
        h("button.btn.small", { onclick: () => editAlarm(null) }, h("span", { html: icon("plus", 14) }), "Add alarm")), list);
    },

    stopwatch() {
      let start = null, elapsed = 0, laps = [];
      const big = h("div", { style: "font-size:64px;font-weight:800;font-variant-numeric:tabular-nums;text-align:center;margin:30px 0 18px" });
      const lapList = h("div.card", { style: "margin-top:20px" });
      const go = h("button.btn", { onclick: toggle }, "Start"), lap = h("button.btn.ghost", { onclick: lapNow, disabled: true }, "Lap");
      const fmt = ms => `${pad(Math.floor(ms / 60000))}:${pad(Math.floor(ms / 1000) % 60)}.${pad(Math.floor(ms / 10) % 100)}`;
      const now = () => elapsed + (start ? Date.now() - start : 0);
      const paint = () => { big.textContent = fmt(now()); };
      function toggle() { if (start) { elapsed = now(); start = null; go.textContent = elapsed ? "Resume" : "Start"; lap.textContent = "Reset"; } else { start = Date.now(); go.textContent = "Stop"; lap.textContent = "Lap"; lap.disabled = false; } }
      function lapNow() {
        if (!start) { elapsed = 0; laps = []; lap.disabled = true; lap.textContent = "Lap"; go.textContent = "Start"; lapList.innerHTML = ""; paint(); return; }
        const t = now(), prev = laps.length ? laps[0].total : 0; laps.unshift({ n: laps.length + 1, total: t, split: t - prev });
        lapList.innerHTML = ""; laps.forEach(l => lapList.append(h("div.row", { style: "cursor:default;min-height:40px;font-variant-numeric:tabular-nums" }, h("span.muted", "Lap " + l.n), h("div.grow", { style: "text-align:right" }, fmt(l.split)), h("span.muted", fmt(l.total)))));
      }
      paint();
      content.append(big, h("div", { style: "display:flex;gap:12px;justify-content:center" }, lap, go), lapList);
      later(paint, 50);
    },

    timer() {
      const active = clock.timers.filter(t => !t.done);
      const hh = h("input.field", { type: "number", min: 0, max: 99, value: 0, style: "width:80px;text-align:center;font-size:24px;height:52px" });
      const mm = h("input.field", { type: "number", min: 0, max: 59, value: 5, style: "width:80px;text-align:center;font-size:24px;height:52px" });
      const ss = h("input.field", { type: "number", min: 0, max: 59, value: 0, style: "width:80px;text-align:center;font-size:24px;height:52px" });
      const label = h("input.field", { placeholder: "Label (optional)", style: "width:240px" });
      const mk = async secs => { clock.timers.push({ id: uid(), end: Date.now() / 1000 + secs, label: label.value, done: false }); await saveClock(); draw(); };
      const preset = (m) => h("button.btn.ghost.small", { onclick: () => mk(m * 60) }, m + " min");
      content.append(h("div", { style: "display:flex;flex-direction:column;align-items:center;gap:14px;margin:10px 0 26px" },
        h("div", { style: "display:flex;gap:8px;align-items:center" }, hh, h("span.muted", "h"), mm, h("span.muted", "min"), ss, h("span.muted", "s")), label,
        h("button.btn", { onclick: () => { const s = (+hh.value || 0) * 3600 + (+mm.value || 0) * 60 + (+ss.value || 0); if (s < 1) { toast("Set a time first"); return; } mk(Math.min(s, 99 * 3600)); } }, "Start timer"),
        h("div", { style: "display:flex;gap:8px" }, preset(1), preset(5), preset(10), preset(30))));
      const list = h("div.card");
      const paint = async () => {
        list.innerHTML = "";
        const nowS = Date.now() / 1000;
        const live = clock.timers.filter(t => !t.done);
        let changed = false;
        live.forEach(t => { if (t.end <= nowS - 15) { t.done = true; changed = true; } });   // the system rings it within 10 s; only then tidy it away });
        if (changed) { await saveClock(); }
        clock.timers.filter(t => !t.done).forEach(t => {
          const left = Math.max(0, Math.ceil(t.end - nowS));
          list.append(h("div.row", { style: "cursor:default;min-height:64px" }, h("div.grow", h("div", { style: "font-size:30px;font-weight:800;font-variant-numeric:tabular-nums" }, `${pad(Math.floor(left / 3600))}:${pad(Math.floor(left / 60) % 60)}:${pad(left % 60)}`), h("div.s", t.label || "Timer")),
            h("button.btn.ghost.small", { onclick: async () => { clock.timers = clock.timers.filter(x => x.id !== t.id); await saveClock(); draw(); } }, "Cancel")));
        });
        if (!list.children.length) list.append(h("div.muted", { style: "padding:22px;text-align:center" }, "No timers running."));
      };
      paint();
      content.append(list);
      later(paint, 500);
      void active;
    },
  };

  const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  function daysText(d) { return !d.length || d.length === 7 ? "Every day" : d.join() === "0,1,2,3,4" ? "Weekdays" : d.join() === "5,6" ? "Weekends" : d.map(x => DAYS[x]).join(" "); }

  function editAlarm(existing) {
    const a = existing ? { ...existing, days: [...existing.days] } : { id: uid(), time: "07:30", label: "", days: [], on: true };
    const tp = timePicker({ value: a.time, onChange: v => { a.time = v; } });
    const label = h("input.field", { placeholder: "Label", value: a.label });
    const chips = h("div", { style: "display:flex;gap:6px;flex-wrap:wrap" });
    const paint = () => { chips.innerHTML = ""; DAYS.forEach((d, i) => chips.append(h("button.btn.small" + (a.days.includes(i) ? "" : ".ghost"), { type: "button", onclick: () => { a.days = a.days.includes(i) ? a.days.filter(x => x !== i) : [...a.days, i].sort(); paint(); } }, d))); };
    paint();
    const done = () => back.remove();
    const back = h("div.modal-back", h("div.modal", h("h2", existing ? "Edit alarm" : "New alarm"), h("div.form-row", tp), h("div.form-row", label), h("div.form-row", h("span.label", "Repeat"), chips),
      h("div.small.muted", "With no days chosen, the alarm rings every day."),
      h("div.actions", existing ? h("button.btn.ghost", { onclick: async () => { clock.alarms = clock.alarms.filter(x => x.id !== a.id); await saveClock(); done(); draw(); } }, "Delete") : null, h("button.btn.ghost", { onclick: done }, "Cancel"),
        h("button.btn", { onclick: async () => { a.time = tp.value; a.label = label.value; a.on = true; const i = clock.alarms.findIndex(x => x.id === a.id); if (i >= 0) clock.alarms[i] = a; else clock.alarms.push(a); await saveClock(); done(); draw(); } }, "Save"))));
    document.body.append(back);
  }

  draw();
});
