"use strict";

/* ---------- Placeholder data: used only for the static preview (no daemon) ---------- */
const PREVIEW = {
  languages: [{ code: "en_GB", name: "English (GB)" }, { code: "en_US", name: "English (US)" }, { code: "es_ES", name: "Español" }],
  regions: [["GB", "United Kingdom"], ["CA", "Canada"], ["ES", "Spain"], ["FR", "France"], ["DE", "Germany"],
            ["IT", "Italy"], ["NL", "Netherlands"], ["PT", "Portugal"], ["PL", "Poland"], ["SE", "Sweden"]]
    .map(([code, name]) => ({ code, name })),
  network: { online: true, wired: false, wifi: [
    { ssid: "Home-5G", security: "Secured" }, { ssid: "BT-Hub6-4XK2", security: "Secured" }, { ssid: "Guest", security: "Open" }] },
};
const ACCESSIBILITY = ["acc_overlay", "acc_zoom", "acc_scale", "acc_speak", "acc_auracast", "acc_colour"];
const USERS = { main: "Alex Holmes", others: ["Natalie", "William", "Laura"] };
const DOCK_APPS = 12;

const WGPSL_EN = `
# William Graves Proprietary Software License (The WGPSL)

Copyright (c) 2026 William Graves Corporation Ltd, trading as Will Graves Co

---

## Software License Agreement for William Graves Operating Services (W-OS) 4 "Windermere"

Version: Penguin 4ALPHA

PLEASE READ THIS SOFTWARE LICENSE AGREEMENT CAREFULLY BEFORE INSTALLING OR USING W-OS. BY INSTALLING, DOWNLOADING, OR USING W-OS, YOU AGREE TO BE BOUND BY THE TERMS OF THIS LICENSE. IF YOU DO NOT AGREE, DO NOT INSTALL OR USE W-OS.

---

### 1. Definitions

- **W-OS** or **the Software** means William Graves Operating Services 4 ("Windermere"), the operating system developed by William Graves Corporation Ltd (trading as Will Graves Co, brand William Graves Technology), including its updates and documentation.
- **PEKS** means the Persistent Entry Key Service used to activate and license the Software.

### 2. Licence

We give you a personal, non-exclusive, non-transferable, revocable licence to install and use the W-OS components that we own ("Our Components", such as the W-OS desktop, apps, setup and update services) on computers that you own or control, for your own use, and for testing where you are a tester.

### 3. What you may not do with Our Components

- Sell, rent, lend, sublicense or share copies of Our Components, or give access to them to other people, without our written permission.
- Remove or change our copyright, trade mark or licence notices.
- Use our names, logos and marks ("W-OS", "William Graves Technology", "Will Graves Co") to suggest that your product or service comes from us or is approved by us.
- Reverse engineer or copy Our Components, except so far as the law allows despite this restriction.

### 4. Open-source software

W-OS also contains software written by others, such as Debian and the Linux kernel, under their own licences (listed in Settings, About, Open source notices). This licence does not restrict your rights under those licences. Where a licence gives you the right to the source code, we will provide it on request. You have full control of your own computer, including a terminal and administrator access; nothing in this licence stops you from inspecting or changing the open-source parts of your own system.

### 5. Activation and updates

W-OS may check with our servers to confirm your licence (through PEKS) and to fetch updates. These checks are limited to what is described in our Privacy notice. If your computer cannot reach our servers, it keeps working: we will never delete your data, lock you out of your own files or stop your computer from starting. Long periods offline may pause new app installs and non-security updates until you reconnect. Security updates continue to be offered. The tester build does not require activation.

### 6. Ownership

Our Components, and all rights in them, belong to William Graves Corporation Ltd or its licensors. This licence gives you the right to use them, not ownership. Your files and data always belong to you.

### 7. No warranty

So far as the law allows, W-OS is provided "as is" and "as available", without promises about how well it works, and we exclude all warranties and conditions that would otherwise be implied.

### 8. Our responsibility

Nothing in this licence limits or excludes liability that cannot legally be limited, including for death or personal injury caused by our negligence, or for fraud. Subject to that, and so far as the law allows, we are not responsible for loss of data, loss of profit, or any indirect or consequential loss arising from your use of W-OS, and our total responsibility to you under this licence is limited to £100, or the price you paid for W-OS in the last 2 years, whichever is greater.

### 9. Ending

This licence ends if you break it, or if we withdraw it by telling you. You can end it at any time by removing W-OS. When it ends you must stop using Our Components. Sections 3, 6, 7, 8 and 10 continue afterwards.

### 10. The law

This licence is governed by the law of England and Wales, and the courts of England have non-exclusive jurisdiction. If you live outside England, you may have rights in your own country that this cannot remove.

### 11. Contact

William Graves Corporation Ltd, company number 16414831, 14 Blunham Road, Biggleswade, England SG18 8BY. support@willgraves.co.uk

Where you are a tester, the Tester agreement comes first for the test period.

Version 1.0, approved by William Graves for William Graves Corporation Ltd, September 2026.
`;

const DISCLOSURE_EN = `
# Responsible Disclosure

We welcome reports of security vulnerabilities in W-OS. Please email them privately to support@willgraves.co.uk. We will acknowledge your report within 5 working days and keep you updated. Please give us reasonable time (we ask for 90 days) to fix the problem before you publish it, do not access other people's data, do not damage or disrupt other people's systems, and only test on computers you own or have permission to test. We will not take legal action against good-faith research that follows these rules.

---

### Not for military or unethical government use

Findings and access gained through this programme must not be used for military purposes or for unethical government practices, and we will not work with anyone who intends to.

---

Version 1.0, approved by William Graves for William Graves Corporation Ltd, September 2026.
`;

const CREDITS_EN = `
# Credits

W-OS is built on the work of many people and organisations.

- **Debian**: the foundation W-OS is built on.
- **Anthropic**: available as an optional default AI model.
- **Samsung**: works on the drivers and other software for much of the hardware W-OS runs on.
- **William Graves Corporation Ltd**: makes W-OS, trading as Will Graves Co.
- **Microsoft**
- **Sajowi Group**
- **The Generated Project**: for Jenny AI.
`;

/* Each document can have a version per language. Anything missing falls back to
   English and says so. Add a translation by adding its language code here. */
const TESTER_EN = `
# W-OS 4 "Windermere" (Penguin 4ALPHA): Tester agreement

This is an agreement between you and **William Graves Corporation Ltd**, a company registered in England and Wales, company number 16414831, registered office 14 Blunham Road, Biggleswade, England SG18 8BY, trading as Will Graves Co ("we", "us"). It covers your use of the pre-release software called W-OS 4 "Windermere" (Penguin 4ALPHA) (the "Software"). By pressing Continue in setup you accept it. If you do not accept it, do not use the Software.

**1. What this is.** The Software is an early test version. It is given to you so you can try it and tell us what works and what does not.

**2. It can go wrong.** The Software may contain faults. It may stop working, behave unexpectedly, or lose or damage data, including the contents of any disk you install it on. Installing W-OS erases the whole disk you choose. **Back up anything you care about before you start.** Do not use the Software for work, banking, health, safety or anything else where a failure would cause harm.

**3. Your licence.** We give you a personal, non-exclusive, non-transferable licence to use the Software for testing, under the WGPSL (shown in Legal). If this agreement and the WGPSL disagree about testing, this agreement comes first for the test period.

**4. Confidentiality.** The Software, its screens and anything you learn about unreleased features are confidential. Please do not share the installer, copies of the Software, screenshots or recordings publicly without our written permission. This does not stop you using your own computer, or talking about your own experience in general terms.

**5. Feedback.** You are not obliged to send feedback. If you do, we may use it to improve the Software and our products without paying you or crediting you, and you confirm you have the right to send it. Please do not put anything private, such as passwords, banking details or other people's personal information, in feedback.

**6. Your information.** How we handle personal information is explained in our Privacy notice (shown in Legal). In short: the Software sends nothing about you unless you turn sharing on, or press Send in the feedback app.

**7. No warranty.** The Software is provided "as is" and "as available", without promises about how well it works. So far as the law allows, we exclude all warranties and conditions that would otherwise be implied.

**8. Our responsibility.** Nothing in this agreement limits or excludes liability that cannot legally be limited, including for death or personal injury caused by our negligence, or for fraud. Subject to that, and so far as the law allows, we are not responsible for loss of data, loss of profit, or any indirect or consequential loss arising from your use of the Software, and our total responsibility to you for anything else arising from this agreement is limited to £100, or the price paid for this product in the last 2 years, whichever is greater at time of dispute.

**9. Third-party software.** The Software includes open-source software from others, each under its own licence, listed under Settings, About, Open source notices. Those licences apply to that software. If you want the source code for any of it, contact us and we will provide it as those licences require.

**10. Ending.** You can stop at any time by removing the Software. We can end your access, or stop the test, at any time. Sections 4 to 8 and 11 continue afterwards. When requested, you agree to end all use of our software requested, and if required display proof and evidence of your discontinued use.

**11. The law.** This agreement is governed by the law of England and Wales. The courts of England have non-exclusive jurisdiction. If you live in Scotland or Northern Ireland, or outside the UK, you may still have rights in your own country that this cannot remove.

**12. Age.** You must be 13 or over, or have a parent or guardian agree for you. 

**13. Contact.** support@willgraves.co.uk

Version 1.0, approved by William Graves for William Graves Corporation Ltd, September 2026.
`;

const PRIVACY_EN = `
# W-OS Privacy notice (tester build)

**Who we are.** William Graves Corporation Ltd ("we"), trading as Will Graves Co, a company registered in England and Wales, company number 16414831, registered office 14 Blunham Road, Biggleswade, England SG18 8BY. We decide how the information described here is used, which makes us the "controller" under the UK GDPR and the Data Protection Act 2018. Contact: support@willgraves.co.uk.

**The short version.** W-OS sends nothing about you unless you switch on sharing or press Send in the feedback app. Your files, mail, calendar, notes and contacts stay on your computer.

## What we may receive, and why

- **Feedback you write.** Your message, your name or email if you include them, and, if you leave "Include system details" on, your computer model, W-OS version and similar. Only when you press Send. Used to fix problems and improve W-OS. Legal basis: your consent.
- **Crash and usage information.** Only if you switch on "Share crash and usage information". It is off unless you choose it. Used to find and fix faults. Legal basis: your consent. You can switch it off at any time in Settings.
- **Your IP address and W-OS version.** When your computer checks for updates from our update server. Used to deliver updates and keep W-OS secure. Legal basis: legitimate interests (delivering and securing the software).
- **Your W-Account.** If you choose to sign in with a W-Account, your email and password are sent to sign you in, and your computer keeps your account name and email. Legal basis: it is needed to give you the service you asked for.
- **Tester details.** Your name and email, if you signed up to test or we contact you about the test. Used to run the test and contact you about it. Legal basis: legitimate interests.

## What we do not do

We do not sell your information. We do not use it for advertising. We do not read your files, mail or messages.

## Who else sees it

Only people and companies that help us run W-OS and the test, such as our email and hosting providers, who may handle it for us under contract and only on our instructions. If your information is sent outside the UK, we make sure UK law allows it, for example by using a country the UK treats as adequate or approved safeguards.

## How long we keep it

- Feedback: for 12 months after the test ends, or until we have dealt with it, whichever is sooner.
- Update-server records: 30 days.
- Tester contact details: until the test ends, plus 6 months.

After that we delete it.

## Your rights

Under UK law you can ask to see the information we hold about you, have it corrected or deleted, restrict or object to its use, receive it in a portable form, and withdraw consent at any time (this does not affect anything done before). Email support@willgraves.co.uk. We reply within one month. If you are unhappy, you can complain to the Information Commissioner's Office (ico.org.uk, 0303 123 1113).

## Children

You must be 13 or over to use W-OS, or have a parent or guardian agree for you.

## Changes

We will update this notice if what the software does changes, and tell you before an update that changes it.

Version 1.0, approved by William Graves for William Graves Corporation Ltd, September 2026.
`;

const LEGAL_DOCS = [
  { id: "tester", title: { en: "Tester agreement", es: "Acuerdo de prueba" }, text: { en: TESTER_EN } },
  { id: "wgpsl", title: { en: "WGPSL (licence)", es: "WGPSL (licencia)" }, text: { en: WGPSL_EN } },
  { id: "privacy", title: { en: "Privacy notice", es: "Aviso de privacidad" }, text: { en: PRIVACY_EN } },
  { id: "disclosure", title: { en: "Responsible Disclosure", es: "Divulgación responsable" }, text: { en: DISCLOSURE_EN } },
  { id: "credits", title: { en: "Credits", es: "Créditos" }, text: { en: CREDITS_EN } },
];


/* ---------- Helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const t = key => I18N.t(key);
const state = { language: "en_GB", region: "GB", network: null, accessibility: new Set(), gender: null };
let locales = PREVIEW;
let networkInfo = null;
let installable = false;          // the live image can install itself; an installed system cannot
let installInfo = null;

/* wos-setupd answers on the same origin when running for real. Without it the
   page is a static preview: same screens, placeholder data, nothing is saved. */
const TOKEN = new URLSearchParams(location.search).get("t") || "";
let live = false;
let dev = false;

async function api(path, body) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 60000);
  try {
    const r = await fetch(path, {
      method: body ? "POST" : "GET",
      headers: { "X-WOS-Token": TOKEN, ...(body ? { "Content-Type": "application/json" } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: ctl.signal,
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || `Request failed (${r.status})`);
    return data;
  } finally {
    clearTimeout(timer);
  }
}

/* ---------- Flow ---------- */
const nav = $("#nav");
const btnBack = $("#btn-back");
const btnNext = $("#btn-next");
let current = null;

function showError(message) {
  let el = $(".err", current);
  if (!el) { el = document.createElement("p"); el.className = "err"; current.appendChild(el); }
  el.textContent = message ? I18N.error(message) : "";
}

function setBusy(on) {
  btnNext.disabled = btnBack.disabled = on;
  nav.classList.toggle("busy", on);
}

function go(name) {
  const el = $(`[data-screen="${name}"]`);
  if (!el) return;
  $$(".screen").forEach(s => s.classList.remove("active"));
  el.classList.add("active");
  current = el;
  showError("");
  nav.hidden = el.hasAttribute("data-nonav");
  btnBack.style.visibility = el.dataset.prev ? "visible" : "hidden";
  if (!live && location.hash !== "#" + name) history.replaceState(null, "", "#" + name);
  if (name === "network") loadNetwork();
  if (name === "setup") runSetup();
  if (name === "desktop") tickClock();
  const focusable = $("input[type=password], input[type=email], input[type=text]", el);
  if (focusable) focusable.focus();
}

/* Work to do when leaving a screen. Only runs against the real daemon. */
const commits = {
  async region() {
    await api("/api/locale", { language: state.language, region: state.region });
  },
  async network() {
    const net = state.network;
    if (!net || !net.ssid) return;            // wired, or skipped: offline setup is fine
    const password = net.security === "Secured" ? $("#net-pass").value : "";
    await api("/api/network/connect", { ssid: net.ssid, password });
  },
  async accessibility() {
    await api("/api/accessibility", { options: [...state.accessibility] });
  },
  async privacy() {
    await api("/api/privacy", { share: $("#share-telemetry").checked });
  },
  async signin() {
    const [email, password] = $$("#signin-form input").map(i => i.value);
    await api("/api/account", { mode: "waccount", email, password });
  },
  async local() {
    const [name, password, confirm] = $$("#local-form input").map(i => i.value);
    if (password !== confirm) throw new Error(t("pw_mismatch"));
    await api("/api/account", { mode: "local", name, password });
  },
};

async function advance() {
  if (!current?.dataset.next) return;
  const name = current.dataset.screen;
  showError("");
  setBusy(true);
  if (name === "network" && live && state.network?.ssid) showError(t("connecting"));
  try {
    if (live && commits[name]) await commits[name]();
    go(name === "language" && installable ? "install" : current.dataset.next);
  } catch (e) {
    showError(e.message);
  } finally {
    setBusy(false);
  }
}
btnNext.addEventListener("click", advance);
btnBack.addEventListener("click", () => current?.dataset.prev && go(current.dataset.prev));

/* ---------- Lists ---------- */
/* items: [{ label, tag, value }] */
function renderList(name, items, key, { preselect = true, selected } = {}) {
  const ul = $(`[data-list="${name}"]`);
  ul.innerHTML = "";
  items.forEach((item, i) => {
    const li = document.createElement("li");
    li.innerHTML = `<span></span><small></small>`;
    $("span", li).textContent = item.label;
    $("small", li).textContent = item.tag || "";
    li.addEventListener("click", () => select(ul, li, key, item.value));
    ul.appendChild(li);
    const isSel = selected !== undefined ? item.value === selected : (i === 0 && preselect);
    if (isSel) select(ul, li, key, item.value, false);
  });
  if (!ul._keys) {
    ul._keys = true;
    ul.tabIndex = 0;
    ul.addEventListener("keydown", e => {
      const lis = $$("li", ul);
      let i = lis.findIndex(l => l.classList.contains("sel"));
      if (e.key === "ArrowDown") i = Math.min(lis.length - 1, i + 1);
      else if (e.key === "ArrowUp") i = Math.max(0, i - 1);
      else return;
      e.preventDefault();
      lis[i].click();
      lis[i].scrollIntoView({ block: "nearest" });
    });
  }
}

function select(ul, li, key, value, notify = true) {
  $$("li", ul).forEach(l => l.classList.remove("sel"));
  li.classList.add("sel");
  state[key] = value;
  if (key === "network") {
    const needsPass = live && value?.security === "Secured";
    $("#net-pass").hidden = !needsPass;
    ul.classList.toggle("short", needsPass);
    if (needsPass) $("#net-pass").focus();
  }
  if (key === "language" && notify) { I18N.setLanguage(value); refreshTexts(); }
}

function renderLanguages() {
  renderList("language", locales.languages.map((l, i) => ({ label: l.name, value: l.code, tag: i === 0 ? t("default_tag") : "" })),
    "language", { selected: state.language });
}

function renderRegions() {
  renderList("region", locales.regions.map((r, i) => ({ label: I18N.regionName(r.code, r.name), value: r.code, tag: i === 0 ? t("default_tag") : "" })),
    "region", { selected: state.region });
}

async function loadNetwork() {
  networkInfo = live ? await api("/api/network").catch(() => ({ online: false, wired: false, wifi: [] })) : PREVIEW.network;
  state.network = null;
  $("#net-pass").hidden = true;
  $("#net-pass").value = "";
  renderNetworks();
}

function renderNetworks() {
  if (!networkInfo) return;
  const info = networkInfo;
  const items = info.wifi.map(n => ({ label: n.ssid, tag: n.active ? t("connected") : t(n.security === "Secured" ? "secured" : "open"), value: n }));
  if (!items.length) {
    items.push(info.wired
      ? { label: t("wired"), tag: t("connected"), value: null }
      : { label: t("no_networks"), tag: "", value: null });
  }
  renderList("network", items, "network", { preselect: info.wired && !info.wifi.length, selected: state.network });
}

/* Everything the language can change, redrawn in place (selections are kept). */
function renderAccessibility() {
  const pills = $('[data-pills="accessibility"]');
  pills.innerHTML = "";
  ACCESSIBILITY.forEach(key => {
    const label = document.createElement("label");
    label.innerHTML = `<input type="checkbox"><span></span>`;
    $("span", label).textContent = t(key);
    const box = $("input", label);
    box.checked = state.accessibility.has(key);
    box.addEventListener("change", () => box.checked ? state.accessibility.add(key) : state.accessibility.delete(key));
    pills.appendChild(label);
  });
}

function refreshTexts() {
  I18N.apply();
  renderLanguages();
  renderRegions();
  renderNetworks();
  renderAccessibility();
  if (typeof buildLegalPickers === "function") buildLegalPickers();
}

/* Gender options behave like radios; the choice flavours gendered languages. */
$$('[data-group="gender"] input').forEach(box => box.addEventListener("change", () => {
  $$('[data-group="gender"] input').forEach(o => { if (o !== box) o.checked = false; });
  state.gender = box.checked ? box.value : null;
  I18N.setGender(state.gender);
  I18N.apply();
}));

/* ---------- Legal (tiny markdown renderer, enough for the licence text) ---------- */
function md(src) {
  const esc = s => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const inline = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/`(.+?)`/g, "<code>$1</code>");
  let html = "", list = false;
  for (const raw of src.trim().split("\n")) {
    const line = raw.trimEnd();
    const li = line.match(/^- (.*)/);
    if (list && !li) { html += "</ul>"; list = false; }
    if (li) { if (!list) { html += "<ul>"; list = true; } html += `<li>${inline(li[1])}</li>`; }
    else if (/^---+$/.test(line)) html += "<hr>";
    else if (/^### /.test(line)) html += `<h4>${inline(line.slice(4))}</h4>`;
    else if (/^## /.test(line)) html += `<h3>${inline(line.slice(3))}</h3>`;
    else if (/^# /.test(line)) html += `<h2>${inline(line.slice(2))}</h2>`;
    else if (line) html += `<p>${inline(line)}</p>`;
  }
  return html + (list ? "</ul>" : "");
}

function renderLegal() {
  const doc = LEGAL_DOCS.find(d => d.id === $("#legal-pick").value) || LEGAL_DOCS[0];
  const lang = I18N.lang.startsWith("es") ? "es" : "en";
  const text = doc.text[lang] || doc.text.en;
  const fallback = !doc.text[lang] && lang !== "en";
  $("#legal-doc").innerHTML = (fallback ? `<p class="note">${esc(t("legal_fallback"))}</p>` : "") + md(text);
  $("#legal-doc").scrollTop = 0;
}
function buildLegalPickers() {
  const ui = I18N.lang.startsWith("es") ? "es" : "en";
  const pick = $("#legal-pick");
  const keepDoc = pick.value;
  pick.innerHTML = LEGAL_DOCS.map(d => `<option value="${d.id}">${esc(d.title[ui] || d.title.en)}</option>`).join("");
  pick.value = keepDoc || LEGAL_DOCS[0].id;
  renderLegal();
}
const esc = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
$("#legal-pick").addEventListener("change", renderLegal);
buildLegalPickers();


/* ---------- Sign in / skip -> setup ---------- */
$("#signin-form").addEventListener("submit", e => { e.preventDefault(); advance(); });
$("#local-form").addEventListener("submit", e => { e.preventDefault(); advance(); });
$("#skip-link").addEventListener("click", e => { e.preventDefault(); go("local"); });

async function runSetup() {
  const status = $("#setup-status");
  const steps = ["step_loading", "step_activate", "step_account", "step_finish"];
  for (const key of steps) {
    if (current?.dataset.screen !== "setup") return;
    status.textContent = t(key);
    await new Promise(r => setTimeout(r, 1000));
  }
  if (!live) return go("lock");
  try {
    await api("/api/finish", {});
    if (dev) go("lock");                       // dev preview: carry on to the remaining mockups
    else status.textContent = t("step_start");
  } catch (e) {
    status.textContent = t("step_error") + I18N.error(e.message);
  }
}

/* ---------- Lock screen (static preview until the greeter is built) ---------- */
$("#lock-name").textContent = USERS.main;
const row = $("#other-users");
USERS.others.forEach(name => {
  const u = document.createElement("div");
  u.className = "u";
  u.innerHTML = `<div class="avatar small"></div>`;
  u.appendChild(document.createTextNode(name));
  u.addEventListener("click", () => { $("#lock-name").textContent = name; $("#lock-form input").focus(); });
  row.appendChild(u);
});
$("#lock-form").addEventListener("submit", e => {
  e.preventDefault();
  const input = $("#lock-form input");
  if (!input.value) { const lock = $(".lock"); lock.classList.remove("shake"); void lock.offsetWidth; lock.classList.add("shake"); return; }
  input.value = "";
  go("desktop");
});
$("#power-btn").addEventListener("click", () => go("language"));

/* ---------- Desktop (static preview until the shell is built) ---------- */
const dock = $("#dock");
for (let i = 0; i < DOCK_APPS; i++) {
  const a = document.createElement("div");
  a.className = "app";
  a.innerHTML = `<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6L5.6 18.4"/></svg>`;
  dock.appendChild(a);
}
const DAYS = { en: ["Sun", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat"], es: ["dom", "lun", "mar", "mié", "jue", "vie", "sáb"] };
const MONTHS = { en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"],
                 es: ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sept", "oct", "nov", "dic"] };
function tickClock() {
  const d = new Date(), l = I18N.lang.startsWith("es") ? "es" : "en";
  const hm = d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  $("#clock").textContent = `${hm}  ${DAYS[l][d.getDay()]} ${d.getDate()} ${MONTHS[l][d.getMonth()]}`;
}
setInterval(tickClock, 15000);

/* ---------- Installing W-OS to a disk ---------- */
async function loadDisks() {
  installInfo = await api("/api/install/info").catch(() => ({ live: false, disks: [] }));
  const disks = installInfo.disks || [];
  renderList("disk", disks.map(d => ({ label: `${d.model}  ·  ${d.size_gb} GB`, tag: [d.bus, d.removable ? "USB" : ""].filter(Boolean).join(" "), value: d.path })),
    "disk", { preselect: false });
  state.disk = null;
  $("#disk-empty").hidden = disks.length > 0;
  $("#disk-go").disabled = true;
  $("#disk-warn").hidden = true;
  $("#disk-go").textContent = t("disk_erase");
  confirming = false;
}
let confirming = false;
$("#choose-install").addEventListener("click", () => { go("disk"); loadDisks(); });
$("#choose-try").addEventListener("click", () => go("region"));
$("#install-back").addEventListener("click", e => { e.preventDefault(); go("language"); });
$("#disk-back").addEventListener("click", () => go("install"));
document.addEventListener("click", e => {
  if (current?.dataset.screen === "disk" && e.target.closest('[data-list="disk"] li')) {
    $("#disk-go").disabled = !state.disk; confirming = false; $("#disk-warn").hidden = true; $("#disk-go").textContent = t("disk_erase");
  }
});
$("#disk-go").addEventListener("click", async () => {
  if (!state.disk) return;
  if (!confirming) {                       // the erase needs a second, deliberate click
    confirming = true;
    $("#disk-warn").textContent = t("disk_warn").replace("{disk}", state.disk);
    $("#disk-warn").hidden = false;
    $("#disk-go").textContent = t("disk_confirm");
    return;
  }
  try {
    await api("/api/install/start", { disk: state.disk });
  } catch (e) { $("#disk-warn").textContent = I18N.error(e.message); $("#disk-warn").hidden = false; return; }
  $("#install-err").textContent = ""; $("#install-fail-back").hidden = true;
  go("installing");
  const poll = setInterval(async () => {
    let st; try { st = await api("/api/install/status"); } catch { return; }
    if (st.error) { clearInterval(poll); $("#install-err").textContent = st.error; $("#install-fail-back").hidden = false; return; }
    $("#install-step").textContent = st.step || "";
    $("#install-bar").style.width = Math.max(2, st.pct || 0) + "%";
    if (st.pct === 100) { clearInterval(poll); go("installed"); }
  }, 1000);
});
$("#install-fail-back").addEventListener("click", () => go("disk"));
$("#install-restart").addEventListener("click", () => { api("/api/install/restart", {}).catch(() => {}); $("#install-restart").disabled = true; });

/* ---------- Keyboard + start ---------- */
document.addEventListener("keydown", e => {
  if (e.key === "Enter" && current && !["INPUT", "BUTTON", "A"].includes(document.activeElement.tagName)) btnNext.click();
  if (e.key === "Escape" && current?.dataset.prev) btnBack.click();
});

(async () => {
  try {
    const s = await api("/api/state");
    live = true;
    dev = !!s.dev;
    locales = await api("/api/locales");
    try { installable = !!(await api("/api/install/info")).live; } catch { installable = false; }
  } catch {
    live = false;
    locales = PREVIEW;
  }
  state.language = locales.languages[0].code;
  state.region = locales.regions[0].code;
  I18N.setLanguage(state.language);
  refreshTexts();
  go(live ? "language" : (location.hash || "#language").slice(1));
})();
