"""Transfer: bring a person's files and bookmarks over from a Windows PC, a Mac or any old drive.

What it does: finds a user's folders on a mounted drive or a folder the person points at (Windows C:\\Users\\name or a Mac
/Users/name, or the same copied to a USB stick), lists what is there, then copies the chosen parts into this account's
home. It never deletes anything on the source, never overwrites a file in the home folder (a clash gets a suffix), skips
system litter and links, and checks every copied size.

What it cannot do, and says so (see CANNOT_IMPORT): installed programs, saved Wi-Fi passwords, the Windows Credential
Manager, the Mac Keychain, iMessage and app licences. Browser passwords are only taken from the browser's own CSV export.

Standard library only.
"""
import html
import json
import os
import plistlib
import re
import shutil
import sqlite3

# Folder names to look for on each system, and where they land in the home folder.
FOLDERS = {
    "documents": {"label": "Documents", "dest": "Documents", "names": ("Documents", "My Documents")},
    "desktop": {"label": "Desktop", "dest": "Desktop", "names": ("Desktop",)},
    "downloads": {"label": "Downloads", "dest": "Downloads", "names": ("Downloads",)},
    "pictures": {"label": "Photos", "dest": "Pictures", "names": ("Pictures", "My Pictures")},
    "music": {"label": "Music", "dest": "Music", "names": ("Music", "My Music")},
    "videos": {"label": "Videos", "dest": "Videos", "names": ("Videos", "My Videos", "Movies")},
}
SKIP_USERS = {"public", "default", "default user", "all users", "defaultuser0", "shared", "guest"}
SKIP_FILES = {"thumbs.db", "desktop.ini", ".ds_store", "ehthumbs.db", ".localized", "icon\r"}
SKIP_DIRS = {"$recycle.bin", ".trashes", ".spotlight-v100", ".fseventsd", "system volume information", "appdata", "node_modules"}
CANNOT_IMPORT = (
    "Installed programs (Windows and Mac apps do not run natively on W-OS)",
    "Saved Wi-Fi passwords",
    "Windows Credential Manager and the Mac Keychain",
    "iMessage and app licences",
    "Browser passwords that are only stored on the disk (export them from the browser as a CSV file instead)",
)
# Browser bookmark files, relative to a user folder.
BOOKMARK_SOURCES = (
    ("Chrome", "chrome-json", ("AppData/Local/Google/Chrome/User Data/Default/Bookmarks", "Library/Application Support/Google/Chrome/Default/Bookmarks")),
    ("Edge", "chrome-json", ("AppData/Local/Microsoft/Edge/User Data/Default/Bookmarks", "Library/Application Support/Microsoft Edge/Default/Bookmarks")),
    ("Safari", "safari-plist", ("Library/Safari/Bookmarks.plist",)),
)


FIREFOX_ROOTS = {"menu": "Bookmarks menu", "toolbar": "Bookmarks toolbar", "unfiled": "Other bookmarks", "mobile": "Mobile bookmarks"}


class TransferError(Exception):
    """Message safe to show to the person."""


# ---------- finding sources ----------

def _is_dir(p):
    return os.path.isdir(p) and not os.path.islink(p)


def find_profiles(root):
    """User folders under a drive or folder: <root>/Users/<name> (Windows and Mac), or the folder itself when it already
    has Documents/Pictures in it. Returns [{"name", "path", "system"}], system being "windows", "mac" or "folder"."""
    out = []
    users = os.path.join(root, "Users")
    if _is_dir(users):
        for name in sorted(os.listdir(users)):
            path = os.path.join(users, name)
            if name.lower() in SKIP_USERS or name.startswith(".") or not _is_dir(path):
                continue
            if _looks_like_profile(path):
                system = "mac" if _is_dir(os.path.join(path, "Library")) else "windows"
                out.append({"name": name, "path": path, "system": system})
    if not out and _looks_like_profile(root):
        out.append({"name": os.path.basename(os.path.normpath(root)) or "Folder", "path": root, "system": "folder"})
    return out


def _looks_like_profile(path):
    try:
        names = {n.lower() for n in os.listdir(path)}
    except OSError:
        return False
    wanted = {n.lower() for f in FOLDERS.values() for n in f["names"]}
    return len(names & wanted) >= 1


def find_drives(media_roots=("/media", "/run/media", "/mnt")):
    """Mounted places that hold at least one user profile. Returns [{"path", "profiles"}]."""
    out = []
    candidates = []
    for base in media_roots:
        if not _is_dir(base):
            continue
        for name in sorted(os.listdir(base)):
            sub = os.path.join(base, name)
            if not _is_dir(sub):
                continue
            candidates.append(sub)
            for inner in sorted(os.listdir(sub)) if os.access(sub, os.R_OK) else []:      # /run/media/<user>/<drive>
                p = os.path.join(sub, inner)
                if _is_dir(p):
                    candidates.append(p)
    for path in candidates:
        profiles = find_profiles(path)
        if profiles:
            out.append({"path": path, "profiles": profiles})
    return out


# ---------- scanning ----------

def _walk_files(folder):
    """Yields (path, size) for the files worth copying under folder."""
    for dirpath, dirnames, filenames in os.walk(folder, followlinks=False):
        dirnames[:] = [d for d in dirnames if d.lower() not in SKIP_DIRS and not os.path.islink(os.path.join(dirpath, d))]
        for f in filenames:
            if f.lower() in SKIP_FILES or f.startswith("~$"):
                continue
            p = os.path.join(dirpath, f)
            if os.path.islink(p):
                continue
            try:
                yield p, os.path.getsize(p)
            except OSError:
                continue


def scan_profile(profile_path):
    """What is in one user folder: {"folders": {key: {...}}, "bookmarks": [...], "bookmark_files": [...] }."""
    folders = {}
    for key, spec in FOLDERS.items():
        for name in spec["names"]:
            p = os.path.join(profile_path, name)
            if _is_dir(p):
                count = total = 0
                for _path, size in _walk_files(p):
                    count += 1
                    total += size
                if count:
                    folders[key] = {"label": spec["label"], "path": p, "files": count, "bytes": total}
                break
    marks = []
    for browser, kind, rels in BOOKMARK_SOURCES:
        for rel in rels:
            p = os.path.join(profile_path, *rel.split("/"))
            if os.path.isfile(p):
                try:
                    n = len(parse_bookmarks(p, kind))
                except TransferError:
                    continue
                marks.append({"browser": browser, "kind": kind, "path": p, "count": n})
    marks += _firefox_sources(profile_path)
    exported = _exported_html_bookmarks(profile_path)
    return {"folders": folders, "bookmarks": marks + exported}


def _firefox_sources(profile_path):
    out = []
    for rel in ("AppData/Roaming/Mozilla/Firefox/Profiles", "Library/Application Support/Firefox/Profiles"):
        base = os.path.join(profile_path, *rel.split("/"))
        if not _is_dir(base):
            continue
        for prof in sorted(os.listdir(base)):
            db = os.path.join(base, prof, "places.sqlite")
            if os.path.isfile(db):
                try:
                    n = len(parse_bookmarks(db, "firefox-places"))
                except TransferError:
                    continue
                out.append({"browser": "Firefox", "kind": "firefox-places", "path": db, "count": n})
    return out


def _exported_html_bookmarks(profile_path):
    out = []
    for key in ("documents", "downloads", "desktop"):
        for name in FOLDERS[key]["names"]:
            d = os.path.join(profile_path, name)
            if not _is_dir(d):
                continue
            try:
                entries = os.listdir(d)
            except OSError:
                continue
            for f in entries:
                if re.match(r"(?i).*bookmarks.*\.html?$", f):
                    p = os.path.join(d, f)
                    try:
                        n = len(parse_bookmarks(p, "netscape-html"))
                    except TransferError:
                        continue
                    if n:
                        out.append({"browser": "Exported file", "kind": "netscape-html", "path": p, "count": n})
    return out


# ---------- bookmarks ----------

def parse_bookmarks(path, kind):
    """Returns [(folder_path_list, title, url)]. Raises TransferError if the file cannot be read."""
    try:
        if kind == "chrome-json":
            with open(path, encoding="utf-8") as f:
                roots = json.load(f).get("roots", {})
            out = []
            for key in ("bookmark_bar", "other", "synced"):
                if isinstance(roots.get(key), dict):
                    _chrome_walk(roots[key], [roots[key].get("name") or key], out)
            return out
        if kind == "safari-plist":
            with open(path, "rb") as f:
                tree = plistlib.load(f)
            out = []
            _safari_walk(tree, [], out)
            return out
        if kind == "firefox-places":
            return _firefox_bookmarks(path)
        if kind == "netscape-html":
            with open(path, encoding="utf-8", errors="replace") as f:
                return _netscape_parse(f.read())
    except (OSError, ValueError, plistlib.InvalidFileException, sqlite3.Error, AttributeError, TypeError) as e:
        raise TransferError("Could not read the bookmarks file: %s" % os.path.basename(path)) from e
    raise TransferError("Unknown bookmarks format")


def _chrome_walk(node, trail, out):
    for child in node.get("children", []):
        if child.get("type") == "folder":
            _chrome_walk(child, trail + [child.get("name", "")], out)
        elif child.get("type") == "url" and _safe_url(child.get("url", "")):
            out.append((trail, child.get("name") or child["url"], child["url"]))


def _safari_walk(node, trail, out):
    if node.get("WebBookmarkType") == "WebBookmarkTypeLeaf":
        url = node.get("URLString", "")
        if _safe_url(url):
            title = (node.get("URIDictionary") or {}).get("title") or url
            out.append((trail, title, url))
        return
    name = node.get("Title") or ""
    sub = trail if node.get("WebBookmarkType") == "WebBookmarkTypeProxy" or name in ("com.apple.ReadingList",) else trail + ([name] if name else [])
    if name == "com.apple.ReadingList":
        return
    for child in node.get("Children", []):
        _safari_walk(child, sub, out)


def _firefox_bookmarks(db_path):
    con = sqlite3.connect("file:%s?mode=ro&immutable=1" % db_path, uri=True)
    try:
        rows = con.execute(
            "SELECT b.id, b.parent, b.type, b.title, p.url FROM moz_bookmarks b LEFT JOIN moz_places p ON p.id = b.fk").fetchall()
    finally:
        con.close()
    folders = {r[0]: (r[1], r[3] or "") for r in rows if r[2] == 2}
    out = []
    for _id, parent, typ, title, url in rows:
        if typ == 1 and url and _safe_url(url):
            trail, pid, guard = [], parent, 0
            while pid in folders and guard < 30:
                pp, name = folders[pid]
                if name and pp in folders:      # skip the invisible root folder
                    trail.insert(0, FIREFOX_ROOTS.get(name, name) if folders.get(pp, (None, "x"))[1] == "" else name)
                pid, guard = pp, guard + 1
            out.append((trail, title or url, url))
    return out


def _netscape_parse(text):
    out, trail = [], []
    for m in re.finditer(r"(?is)<h3[^>]*>(.*?)</h3>|<a\s[^>]*href=\"([^\"]*)\"[^>]*>(.*?)</a>|(</dl>)", text):
        if m.group(1) is not None:
            trail.append(html.unescape(re.sub(r"<[^>]+>", "", m.group(1))).strip())
        elif m.group(2) is not None:
            url = html.unescape(m.group(2))
            if _safe_url(url):
                out.append((list(trail), html.unescape(re.sub(r"<[^>]+>", "", m.group(3))).strip() or url, url))
        elif m.group(4) and trail:
            trail.pop()
    return out


def _safe_url(url):
    return url.lower().startswith(("http://", "https://", "ftp://"))


def bookmarks_to_html(items):
    """The standard bookmarks file every browser can import. Folders become nested lists."""
    tree = {"children": {}, "links": []}
    for trail, title, url in items:
        node = tree
        for name in trail:
            node = node["children"].setdefault(name, {"children": {}, "links": []})
        node["links"].append((title, url))

    def render(node, depth):
        pad = "    " * depth
        lines = []
        for name, child in node["children"].items():
            lines.append("%s<DT><H3>%s</H3>" % (pad, html.escape(name)))
            lines.append("%s<DL><p>" % pad)
            lines += render(child, depth + 1)
            lines.append("%s</DL><p>" % pad)
        for title, url in node["links"]:
            lines.append('%s<DT><A HREF="%s">%s</A>' % (pad, html.escape(url, quote=True), html.escape(title)))
        return lines

    head = ('<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">\n'
            "<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n")
    return head + "\n".join(render(tree, 1)) + "\n</DL><p>\n"


# ---------- copying ----------

def plan_copy(profile_path, scan, wanted, home):
    """The list of (source file, destination file) for the chosen folders. `wanted` is a set of folder keys."""
    ops = []
    for key in sorted(wanted):
        info = scan["folders"].get(key)
        if not info:
            continue
        dest_root = os.path.join(home, FOLDERS[key]["dest"])
        for src, size in _walk_files(info["path"]):
            rel = os.path.relpath(src, info["path"])
            ops.append((src, _contained(dest_root, rel), size))
    return ops


def _contained(root, rel):
    """root/rel, refusing anything that would land outside root."""
    dest = os.path.normpath(os.path.join(root, rel))
    if os.path.commonpath([os.path.abspath(root), os.path.abspath(dest)]) != os.path.abspath(root):
        raise TransferError("A file path tried to leave the destination folder")
    return dest


def _free_name(path):
    """path, or 'name (from old PC).ext', then '(from old PC 2)' ... when it already exists."""
    if not os.path.lexists(path):
        return path
    base, ext = os.path.splitext(path)
    n = 1
    while True:
        cand = "%s (from old computer%s)%s" % (base, "" if n == 1 else " %d" % n, ext)
        if not os.path.lexists(cand):
            return cand
        n += 1


def run_copy(ops, progress=None, cancelled=None, min_free=200 * 1024 * 1024):
    """Copies the files. Never overwrites. Returns a report dict. progress(done_files, total_files, done_bytes, total_bytes)."""
    total_bytes = sum(s for _a, _b, s in ops)
    if ops:
        probe = os.path.dirname(ops[0][1])
        while probe and not os.path.isdir(probe):
            probe = os.path.dirname(probe)
        free = shutil.disk_usage(probe or "/").free
        if free < total_bytes + min_free:
            raise TransferError("Not enough space: %d MB needed, %d MB free" % (total_bytes // 2**20, free // 2**20))
    done_files = done_bytes = 0
    report = {"copied": 0, "bytes": 0, "renamed": 0, "failed": [], "cancelled": False}
    for src, dest, size in ops:
        if cancelled and cancelled():
            report["cancelled"] = True
            break
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            final = _free_name(dest)
            part = final + ".part"
            shutil.copyfile(src, part)
            if os.path.getsize(part) != size:
                os.remove(part)
                raise OSError("size changed while copying")
            os.replace(part, final)
            try:
                shutil.copystat(src, final)
            except OSError:
                pass
            report["copied"] += 1
            report["bytes"] += size
            if final != dest:
                report["renamed"] += 1
        except OSError as e:
            report["failed"].append({"file": src, "why": str(e)})
        done_files += 1
        done_bytes += size
        if progress:
            progress(done_files, len(ops), done_bytes, total_bytes)
    return report


def import_bookmarks(sources, out_path):
    """Merges the chosen bookmark sources into one HTML file at out_path (to import into Firefox). Returns how many."""
    items, seen = [], set()
    for src in sources:
        for trail, title, url in parse_bookmarks(src["path"], src["kind"]):
            key = (tuple(trail), url)
            if key not in seen:
                seen.add(key)
                items.append((trail, title, url))
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(bookmarks_to_html(items))
    return len(items)
