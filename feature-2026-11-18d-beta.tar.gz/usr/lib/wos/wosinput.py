"""Mouse, trackpad and keyboard choices: cleaning what was saved and turning it into the commands that apply it. Pure, so it is tested anywhere."""
import re

DELAYS = (200, 300, 400, 600, 800)            # ms before a held key starts repeating
RATES = (10, 15, 25, 35, 50)                   # repeats per second
LAYOUTS = (("gb", "English (UK)"), ("us", "English (US)"), ("ie", "Irish"), ("es", "Spanish"), ("latam", "Spanish (Latin America)"), ("fr", "French"),
           ("de", "German"), ("it", "Italian"), ("pt", "Portuguese"), ("br", "Portuguese (Brazil)"), ("nl", "Dutch"), ("be", "Belgian"), ("ch", "Swiss"),
           ("se", "Swedish"), ("no", "Norwegian"), ("dk", "Danish"), ("fi", "Finnish"), ("pl", "Polish"), ("cz", "Czech"), ("gr", "Greek"), ("tr", "Turkish"), ("ru", "Russian"))
LAYOUT_CODES = tuple(c for c, _ in LAYOUTS)


def clean_input(raw):
    raw = raw if isinstance(raw, dict) else {}
    try:
        speed = max(-100, min(100, int(raw.get("speed", 0))))
    except (TypeError, ValueError):
        speed = 0
    delay = raw.get("repeat_delay")
    rate = raw.get("repeat_rate")
    layout = raw.get("layout")
    return {"tap": bool(raw.get("tap", True)), "natural": bool(raw.get("natural", True)), "speed": speed,
            "repeat_delay": delay if delay in DELAYS else 400, "repeat_rate": rate if rate in RATES else 25,
            "layout": layout if layout in LAYOUT_CODES else None}


def merge(old, changes):
    """Apply a partial update from the page onto what was saved; unknown keys are ignored."""
    out = clean_input(old)
    for k in ("tap", "natural", "speed", "repeat_delay", "repeat_rate", "layout"):
        if k in (changes or {}):
            out[k] = changes[k]
    return clean_input(out)


def accel(speed):
    """libinput's pointer acceleration, -1 (slowest) to 1 (fastest), from the -100..100 slider."""
    return round(max(-100, min(100, speed)) / 100.0, 2)


def repeat_command(d):
    c = clean_input(d)
    return ["xset", "r", "rate", str(c["repeat_delay"]), str(c["repeat_rate"])]


def layout_command(d):
    c = clean_input(d)
    return ["setxkbmap", c["layout"]] if c["layout"] else None


def valid_layout(code):
    return bool(re.fullmatch(r"[a-z]{2,5}", str(code))) and code in LAYOUT_CODES
