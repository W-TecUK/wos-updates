"use strict";

/* Shared by the wallpaper, top bar and dock pages. Inside the shell each page
   talks to the native process over the WebKit bridge; opened in a plain
   browser (see preview.html) it runs against a mock so the design can be
   worked on without booting anything. */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const surface = document.body.dataset.surface;
const bridge = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.wos;

/* The real shell renders in software (no GPU compositing), where backdrop-filter leaves stale pixels
   behind when a pill changes size. So inside the shell the blur is always off and the denser fill
   is used; only a normal browser (the design preview) gets the frosted look. */
if (bridge || !(CSS.supports("backdrop-filter", "blur(1px)") || CSS.supports("-webkit-backdrop-filter", "blur(1px)"))) {
  document.documentElement.classList.add("noblur");
}

function post(msg) {
  if (bridge) bridge.postMessage(JSON.stringify(msg));
  else mockHost(msg);
}
const handlers = {};
window.wos = { receive(m) { const h = handlers[m.type]; if (h) h(m); } };

const t = key => (typeof I18N !== "undefined" ? I18N.t(key) : key);

handlers.init = m => {
  if (typeof I18N !== "undefined") { if (m.lang) I18N.setLanguage(m.lang); I18N.apply(); }
  if (surface === "bar") { tickClock(); if (m.avail) applyAvail(m.avail); }
};

/* ---------- Top bar ---------- */
const DAYS = { en: ["Sun", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat"], es: ["dom", "lun", "mar", "mié", "jue", "vie", "sáb"] };
const MONTHS = { en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"],
                 es: ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sept", "oct", "nov", "dic"] };

/* Choices from Settings > Desktop & Dock, pushed by the shell whenever they change. */
window.__desktop = { wallpaper: "default", dock: "medium", clock24: true, seconds: false, date: true, battery: true };

function tickClock() {
  const d = new Date(), l = typeof I18N !== "undefined" && I18N.lang.startsWith("es") ? "es" : "en", p = window.__desktop;
  const opts = { hour: "2-digit", minute: "2-digit", hour12: !p.clock24 };
  if (p.seconds) opts.second = "2-digit";
  let hm = d.toLocaleTimeString("en-GB", opts);
  if (!p.clock24) hm = hm.replace(/\b(am|pm)\b/i, x => x.toUpperCase()).replace(/^0/, "");
  $("#clock").textContent = p.date ? `${hm}  ${DAYS[l][d.getDay()]} ${d.getDate()} ${MONTHS[l][d.getMonth()]}` : hm;
}

function showBatteryPct() {
  const el = document.getElementById("battery-pct");
  if (!el) return;
  const b = window.__battery;
  el.textContent = b && window.__desktop.battery ? b.pct + "%" : "";
}

handlers["desktop-prefs"] = m => {
  window.__desktop = Object.assign(window.__desktop, m.prefs || {});
  const p = window.__desktop, root = document.documentElement;
  let wall = "";
  if (p.wallpaper && p.wallpaper.startsWith("builtin:")) wall = `url("../../wallpapers/${p.wallpaper.slice(8).replace(/[^a-z0-9_-]/g, "")}.svg")`;
  else if (p.wallpaper && p.wallpaper.startsWith("file:")) wall = `url("file://${encodeURI(p.wallpaper.slice(5))}")`;
  if (wall) root.style.setProperty("--wall", wall); else root.style.removeProperty("--wall");
  root.dataset.dock = p.dock || "medium";
  if (surface === "bar") { tickClock(); showBatteryPct(); }
  if (surface === "dock" && window.__relayoutDock) requestAnimationFrame(() => requestAnimationFrame(window.__relayoutDock));
};

function initBar() {
  const wg = $("#wg"), menu = $("#menu"), appmenu = $("#appmenu");
  let confirming = null, openKind = null, info = { app: "" };
  const fmt = (key, app) => t(key).replace("{app}", app);

  /* One place decides whether the bar window has to be tall (a menu is showing). */
  function closeAll() {
    menu.hidden = true; appmenu.hidden = true; openKind = null; confirming = null;
    const pnl = $("#panel"); if (pnl) { pnl.hidden = true; $("#tray").classList.remove("open"); }
    wg.classList.remove("open");
    $$(".mbtn").forEach(b => b.classList.remove("open"));
    $$("button", menu).forEach(b => b.classList.remove("confirm"));
    post({ type: "bar-open", open: false });
  }
  function opened() { post({ type: "bar-open", open: true }); }
  /* One question, asked everywhere: is anything dropped down? (menus and the status panel) */
  const anyOpen = () => !menu.hidden || !appmenu.hidden || !$("#panel").hidden;

  /* ---- the WG (system) menu */
  wg.addEventListener("click", e => {
    e.stopPropagation();
    const wasOpen = !menu.hidden;
    closeAll();
    if (!wasOpen) { menu.hidden = false; wg.classList.add("open"); opened(); }
  });
  $$("button", menu).forEach(b => b.addEventListener("click", e => {
    e.stopPropagation();
    if (b.disabled) return;
    if (b.dataset.menu === "force-quit") { post({ type: "menu-action", action: "force-quit-list" }); return; }
    if (b.dataset.menu) { closeAll(); post({ type: "menu-action", action: b.dataset.menu }); return; }
    if (b.dataset.confirm && confirming !== b) {       // destructive actions need a second click
      $$("button", menu).forEach(x => x.classList.remove("confirm"));
      confirming = b; b.classList.add("confirm");
      return;
    }
    closeAll();
    post({ type: "power", action: b.dataset.action });
  }));

  /* ---- Terminally Close (Force Quit): pick an open app, click twice to kill it */
  handlers["force-quit-apps"] = m => {
    appmenu.innerHTML = "";
    const head = document.createElement("div");
    head.className = "head"; head.textContent = t("fq_title"); appmenu.appendChild(head);
    let armed = null;
    if (!m.apps.length) {
      const none = document.createElement("button");
      none.textContent = t("fq_none"); none.disabled = true; appmenu.appendChild(none);
    }
    m.apps.forEach(a => {
      const b = document.createElement("button");
      b.textContent = a.name;
      b.addEventListener("click", e => {
        e.stopPropagation();
        if (armed !== b) {
          $$("button", appmenu).forEach(x => { x.classList.remove("confirm"); if (x._name) x.textContent = x._name; });
          armed = b; b.classList.add("confirm"); b.textContent = fmt("fq_confirm", a.name);
          return;
        }
        closeAll();
        post({ type: "menu-action", action: "force-quit", pid: a.pid });
      });
      b._name = a.name;
      appmenu.appendChild(b);
    });
    menu.hidden = true; wg.classList.remove("open");
    appmenu.style.left = "20px"; appmenu.hidden = false; openKind = "fq";
    opened();
  };

  /* ---- the app menus: Name, View, Help */
  function itemsFor(kind) {
    const app = info.app, st = info.state || {};
    if (kind === "app") return [
      { label: t("menu_preferences"), action: "prefs", disabled: !info.prefs },
      { sep: true },
      { label: fmt("menu_hide", app), action: "hide" },
      { label: fmt("menu_quit", app), action: "quit" },
    ];
    if (kind === "view") return [
      { label: st.fullscreen ? t("menu_exit_fullscreen") : t("menu_fullscreen"), action: "fullscreen" },
      { label: st.maximized ? t("menu_restore") : t("menu_maximise"), action: "maximize" },
      { label: t("menu_minimise"), action: "minimize" },
      { label: t("menu_above"), action: "above", checked: !!st.above },
      { sep: true },
      { label: t("menu_accessibility"), action: "accessibility" },
      { label: t("menu_fonts"), action: "fonts" },
    ];
    const help = info.help || [];
    return help.length ? help.map((title, i) => ({ label: title, action: "help", arg: i }))
                       : [{ label: t("menu_no_help"), disabled: true }];
  }

  function openAppMenu(btn) {
    const kind = btn.dataset.kind;
    const wasOpen = openKind === kind;
    closeAll();
    if (wasOpen || (kind !== "app" && !info.app)) return;
    if (kind === "app" && !info.app) return;          // the desktop itself has no app menu
    appmenu.innerHTML = "";
    itemsFor(kind).forEach(it => {
      if (it.sep) { appmenu.appendChild(document.createElement("hr")); return; }
      const b = document.createElement("button");
      b.innerHTML = `<span class="check">${it.checked ? "✓" : ""}</span>`;
      const lab = document.createElement("span"); lab.textContent = it.label; b.appendChild(lab);
      b.disabled = !!it.disabled;
      b.addEventListener("click", e => { e.stopPropagation(); closeAll(); if (it.action) post({ type: "app-action", action: it.action, arg: it.arg }); });
      appmenu.appendChild(b);
    });
    appmenu.style.left = Math.max(8, btn.getBoundingClientRect().left) + "px";
    appmenu.hidden = false; openKind = kind; btn.classList.add("open");
    opened();
  }
  $$(".mbtn").forEach(b => b.addEventListener("click", e => { e.stopPropagation(); openAppMenu(b); }));

  document.addEventListener("click", () => { if (anyOpen()) closeAll(); });
  /* The native side says when focus moved elsewhere (another window, the launcher): never stay open. */
  handlers["close-menus"] = () => { if (anyOpen()) closeAll(); };
  /* Open a menu from outside (the control socket): used for keyboard access and testing. */
  handlers["open-menu"] = m => {
    closeAll();
    const target = m.which === "wg-menu" ? wg : m.which === "view-menu" ? $("#m-view") : $("#m-app");
    if (target) target.click();
  };
  window.addEventListener("blur", () => { if (anyOpen()) closeAll(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeAll(); });

  /* ---- the status panel behind the Wi-Fi and battery icons */
  const panel = $("#panel"), tray = $("#tray");
  const nets = $("#panel-nets");
  tray.addEventListener("click", e => {
    e.stopPropagation();
    const wasOpen = !panel.hidden;
    closeAll();
    if (!wasOpen) { panel.hidden = false; tray.classList.add("open"); opened(); post({ type: "panel-open" }); }
  });
  panel.addEventListener("click", e => e.stopPropagation());
  $("#panel-volume").addEventListener("input", e => { $("#panel-volume-n").textContent = e.target.value + "%"; post({ type: "panel-action", what: "volume", value: +e.target.value }); });
  $("#panel-bright").addEventListener("input", e => { $("#panel-bright-n").textContent = e.target.value + "%"; post({ type: "panel-action", what: "brightness", value: +e.target.value }); });
  $("#panel-wifi-radio").addEventListener("click", e => { const on = !e.target.classList.contains("on"); e.target.classList.toggle("on", on); e.target.textContent = on ? "On" : "Off"; post({ type: "panel-action", what: "wifi-radio", on }); });
  handlers.panel = m => {
    $("#panel-volume").value = m.volume ?? 50; $("#panel-volume-n").textContent = (m.volume ?? 50) + "%";
    $("#panel-bright-row").hidden = m.brightness == null;
    if (m.brightness != null) { $("#panel-bright").value = m.brightness; $("#panel-bright-n").textContent = m.brightness + "%"; }
    const r = $("#panel-wifi-radio"); r.classList.toggle("on", !!m.wifi_on); r.textContent = m.wifi_on ? "On" : "Off";
    nets.innerHTML = "";
    if (!m.networks.length) nets.insertAdjacentHTML("beforeend", `<button disabled><span>${m.wifi_on ? "No networks found" : "Wi-Fi is off"}</span></button>`);
    m.networks.forEach(n => {
      const b = document.createElement("button");
      b.innerHTML = `<span class="check">${n.active ? "\u2713" : ""}</span><span></span><span class="sig">${n.secure ? "Secured" : "Open"}</span>`;
      b.children[1].textContent = n.ssid;
      b.addEventListener("click", e => {
        e.stopPropagation();
        if (n.active) return;
        if (!n.secure) { post({ type: "panel-action", what: "connect", ssid: n.ssid }); closeAll(); return; }
        const box = document.createElement("input"); box.type = "password"; box.placeholder = "Password for " + n.ssid; box.className = "netpass";
        b.after(box); box.focus();
        box.addEventListener("keydown", k => { if (k.key === "Enter" && box.value) { post({ type: "panel-action", what: "connect", ssid: n.ssid, password: box.value }); closeAll(); } });
      });
      nets.appendChild(b);
    });
  };

  handlers.active = m => {
    info = m;
    $("#m-app").textContent = m.app || t("desktop_name");
    $("#m-view").hidden = $("#m-help").hidden = !m.app;   // every app has all three; the bare desktop has none
  };
  handlers.status = m => {
    const wifi = $("#wifi");
    wifi.classList.toggle("off", !m.wifi);
    wifi.setAttribute("title", m.wifi ? m.wifi.name : "");
    const bat = $("#battery");
    bat.hidden = !m.battery;
    if (m.battery) {
      $("#battery-fill").setAttribute("width", Math.max(1, Math.round(15 * m.battery.pct / 100)));
      $("#battery-fill").style.fill = m.battery.charging ? "#7ee787" : m.battery.pct <= 15 ? "#ff7b72" : "currentColor";
    }
    window.__battery = m.battery || null;
    showBatteryPct();
  };
  $("#m-app").textContent = t("desktop_name");
  setInterval(tickClock, 15000);
}

function applyAvail(avail) {
  const store = $("#menu-store");
  if (store && avail.store === false) {
    store.disabled = true;
    store.textContent = `${t("menu_store")} \u2014 ${t("coming_soon")}`;
  }
}

/* ---------- About windows (About This Device / About This W-OS) ---------- */
function initAbout() {
  const activation = a => {
    if (!a || !a.available) return t("act_none");
    const key = { activated: "act_activated", unactivated: "act_unactivated", grace_expired: "act_grace", limited_mode: "act_limited" }[a.lifecycle];
    return key ? t(key) : (a.lifecycle || "?");
  };
  handlers.about = m => {
    const d = m.data;
    let title, sub, fine = "", rows;
    if (m.kind === "device") {
      title = t("about_device"); sub = d.model || d.name;
      rows = [[t("dev_name"), d.name], [t("dev_model"), d.model || "\u2014"],
              [t("dev_cpu"), d.cpu ? d.cpu + (d.cores ? ` (${d.cores})` : "") : "\u2014"],
              [t("dev_mem"), d.memory_gb ? d.memory_gb + " GB" : "\u2014"], [t("dev_storage"), d.storage_gb + " GB"],
              [t("dev_id"), d.device_id || "\u2014"], [t("dev_activation"), activation(d.activation)]];
    } else {
      title = d.name; sub = "";
      rows = [[t("os_nickname"), d.nickname], [t("os_version"), d.version], [t("os_licence"), d.licence]];
      fine = d.copyright;
    }
    $("#about-title").textContent = title;
    $("#about-sub").textContent = sub;
    $("#about-fine").textContent = fine;
    const list = $("#about-rows");
    list.innerHTML = "";
    rows.forEach(([k, v]) => {
      const row = document.createElement("div");
      row.innerHTML = "<dt></dt><dd></dd>";
      $("dt", row).textContent = k; $("dd", row).textContent = v;
      list.appendChild(row);
    });
  };
  $("#about-close").addEventListener("click", () => post({ type: "close-about" }));
  document.addEventListener("keydown", e => { if (e.key === "Escape") post({ type: "close-about" }); });
}

/* ---------- Dock ---------- */
const FALLBACK_ICON = `<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6L5.6 18.4"/></svg>`;

/* Our own icons are full-bleed tiles; other apps' icons (Firefox and so on) keep the pale tile behind them. */
const OWN_ICON = /\/wos-[a-z-]+\.svg$/;
const LAUNCHER_ICON = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 128' width='100%' height='100%'><defs><linearGradient id='glauncher' x1='0.15' y1='0' x2='0.55' y2='1'><stop offset='0' stop-color='#9d8bff'/><stop offset='1' stop-color='#4f3ff0'/></linearGradient><radialGradient id='hlauncher' cx='0.22' cy='0.12' r='0.85'><stop offset='0' stop-color='#fff' stop-opacity='.24'/><stop offset='.6' stop-color='#fff' stop-opacity='0'/></radialGradient><linearGradient id='rlauncher' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#fff' stop-opacity='.42'/><stop offset='.35' stop-color='#fff' stop-opacity='0'/><stop offset='.75' stop-color='#000' stop-opacity='0'/><stop offset='1' stop-color='#000' stop-opacity='.22'/></linearGradient><clipPath id='clauncher'><path d='M128.00,64.00 L127.98,80.72 L127.94,86.06 L127.86,89.93 L127.75,93.08 L127.61,95.77 L127.44,98.15 L127.23,100.28 L127.00,102.22 L126.73,104.01 L126.43,105.67 L126.09,107.21 L125.73,108.66 L125.33,110.02 L124.89,111.30 L124.42,112.50 L123.92,113.64 L123.38,114.72 L122.80,115.74 L122.18,116.71 L121.53,117.63 L120.83,118.50 L120.10,119.32 L119.32,120.10 L118.50,120.83 L117.63,121.53 L116.71,122.18 L115.74,122.80 L114.72,123.38 L113.64,123.92 L112.50,124.42 L111.30,124.89 L110.02,125.33 L108.66,125.73 L107.21,126.09 L105.67,126.43 L104.01,126.73 L102.22,127.00 L100.28,127.23 L98.15,127.44 L95.77,127.61 L93.08,127.75 L89.93,127.86 L86.06,127.94 L80.72,127.98 L64.00,128.00 L47.28,127.98 L41.94,127.94 L38.07,127.86 L34.92,127.75 L32.23,127.61 L29.85,127.44 L27.72,127.23 L25.78,127.00 L23.99,126.73 L22.33,126.43 L20.79,126.09 L19.34,125.73 L17.98,125.33 L16.70,124.89 L15.50,124.42 L14.36,123.92 L13.28,123.38 L12.26,122.80 L11.29,122.18 L10.37,121.53 L9.50,120.83 L8.68,120.10 L7.90,119.32 L7.17,118.50 L6.47,117.63 L5.82,116.71 L5.20,115.74 L4.62,114.72 L4.08,113.64 L3.58,112.50 L3.11,111.30 L2.67,110.02 L2.27,108.66 L1.91,107.21 L1.57,105.67 L1.27,104.01 L1.00,102.22 L0.77,100.28 L0.56,98.15 L0.39,95.77 L0.25,93.08 L0.14,89.93 L0.06,86.06 L0.02,80.72 L0.00,64.00 L0.02,47.28 L0.06,41.94 L0.14,38.07 L0.25,34.92 L0.39,32.23 L0.56,29.85 L0.77,27.72 L1.00,25.78 L1.27,23.99 L1.57,22.33 L1.91,20.79 L2.27,19.34 L2.67,17.98 L3.11,16.70 L3.58,15.50 L4.08,14.36 L4.62,13.28 L5.20,12.26 L5.82,11.29 L6.47,10.37 L7.17,9.50 L7.90,8.68 L8.68,7.90 L9.50,7.17 L10.37,6.47 L11.29,5.82 L12.26,5.20 L13.28,4.62 L14.36,4.08 L15.50,3.58 L16.70,3.11 L17.98,2.67 L19.34,2.27 L20.79,1.91 L22.33,1.57 L23.99,1.27 L25.78,1.00 L27.72,0.77 L29.85,0.56 L32.23,0.39 L34.92,0.25 L38.07,0.14 L41.94,0.06 L47.28,0.02 L64.00,0.00 L80.72,0.02 L86.06,0.06 L89.93,0.14 L93.08,0.25 L95.77,0.39 L98.15,0.56 L100.28,0.77 L102.22,1.00 L104.01,1.27 L105.67,1.57 L107.21,1.91 L108.66,2.27 L110.02,2.67 L111.30,3.11 L112.50,3.58 L113.64,4.08 L114.72,4.62 L115.74,5.20 L116.71,5.82 L117.63,6.47 L118.50,7.17 L119.32,7.90 L120.10,8.68 L120.83,9.50 L121.53,10.37 L122.18,11.29 L122.80,12.26 L123.38,13.28 L123.92,14.36 L124.42,15.50 L124.89,16.70 L125.33,17.98 L125.73,19.34 L126.09,20.79 L126.43,22.33 L126.73,23.99 L127.00,25.78 L127.23,27.72 L127.44,29.85 L127.61,32.23 L127.75,34.92 L127.86,38.07 L127.94,41.94 L127.98,47.28Z'/></clipPath></defs><g clip-path='url(#clauncher)'><rect width='100%' height='100%' fill='url(#glauncher)'/><rect width='100%' height='100%' fill='url(#hlauncher)'/><path d='M128.00,64.00 L127.98,80.72 L127.94,86.06 L127.86,89.93 L127.75,93.08 L127.61,95.77 L127.44,98.15 L127.23,100.28 L127.00,102.22 L126.73,104.01 L126.43,105.67 L126.09,107.21 L125.73,108.66 L125.33,110.02 L124.89,111.30 L124.42,112.50 L123.92,113.64 L123.38,114.72 L122.80,115.74 L122.18,116.71 L121.53,117.63 L120.83,118.50 L120.10,119.32 L119.32,120.10 L118.50,120.83 L117.63,121.53 L116.71,122.18 L115.74,122.80 L114.72,123.38 L113.64,123.92 L112.50,124.42 L111.30,124.89 L110.02,125.33 L108.66,125.73 L107.21,126.09 L105.67,126.43 L104.01,126.73 L102.22,127.00 L100.28,127.23 L98.15,127.44 L95.77,127.61 L93.08,127.75 L89.93,127.86 L86.06,127.94 L80.72,127.98 L64.00,128.00 L47.28,127.98 L41.94,127.94 L38.07,127.86 L34.92,127.75 L32.23,127.61 L29.85,127.44 L27.72,127.23 L25.78,127.00 L23.99,126.73 L22.33,126.43 L20.79,126.09 L19.34,125.73 L17.98,125.33 L16.70,124.89 L15.50,124.42 L14.36,123.92 L13.28,123.38 L12.26,122.80 L11.29,122.18 L10.37,121.53 L9.50,120.83 L8.68,120.10 L7.90,119.32 L7.17,118.50 L6.47,117.63 L5.82,116.71 L5.20,115.74 L4.62,114.72 L4.08,113.64 L3.58,112.50 L3.11,111.30 L2.67,110.02 L2.27,108.66 L1.91,107.21 L1.57,105.67 L1.27,104.01 L1.00,102.22 L0.77,100.28 L0.56,98.15 L0.39,95.77 L0.25,93.08 L0.14,89.93 L0.06,86.06 L0.02,80.72 L0.00,64.00 L0.02,47.28 L0.06,41.94 L0.14,38.07 L0.25,34.92 L0.39,32.23 L0.56,29.85 L0.77,27.72 L1.00,25.78 L1.27,23.99 L1.57,22.33 L1.91,20.79 L2.27,19.34 L2.67,17.98 L3.11,16.70 L3.58,15.50 L4.08,14.36 L4.62,13.28 L5.20,12.26 L5.82,11.29 L6.47,10.37 L7.17,9.50 L7.90,8.68 L8.68,7.90 L9.50,7.17 L10.37,6.47 L11.29,5.82 L12.26,5.20 L13.28,4.62 L14.36,4.08 L15.50,3.58 L16.70,3.11 L17.98,2.67 L19.34,2.27 L20.79,1.91 L22.33,1.57 L23.99,1.27 L25.78,1.00 L27.72,0.77 L29.85,0.56 L32.23,0.39 L34.92,0.25 L38.07,0.14 L41.94,0.06 L47.28,0.02 L64.00,0.00 L80.72,0.02 L86.06,0.06 L89.93,0.14 L93.08,0.25 L95.77,0.39 L98.15,0.56 L100.28,0.77 L102.22,1.00 L104.01,1.27 L105.67,1.57 L107.21,1.91 L108.66,2.27 L110.02,2.67 L111.30,3.11 L112.50,3.58 L113.64,4.08 L114.72,4.62 L115.74,5.20 L116.71,5.82 L117.63,6.47 L118.50,7.17 L119.32,7.90 L120.10,8.68 L120.83,9.50 L121.53,10.37 L122.18,11.29 L122.80,12.26 L123.38,13.28 L123.92,14.36 L124.42,15.50 L124.89,16.70 L125.33,17.98 L125.73,19.34 L126.09,20.79 L126.43,22.33 L126.73,23.99 L127.00,25.78 L127.23,27.72 L127.44,29.85 L127.61,32.23 L127.75,34.92 L127.86,38.07 L127.94,41.94 L127.98,47.28Z' fill='none' stroke='url(#rlauncher)' stroke-width='3'/></g><g transform='translate(0 3)' opacity='.18'><rect x='28' y='28' width='32' height='32' rx='9.5' fill='#000000' fill-opacity='1.0' /><rect x='68' y='28' width='32' height='32' rx='9.5' fill='#7fe3ff' fill-opacity='1.0' /><rect x='28' y='68' width='32' height='32' rx='9.5' fill='#ffd166' fill-opacity='1.0' /><rect x='68' y='68' width='32' height='32' rx='9.5' fill='#ff9ec9' fill-opacity='1.0' /></g><rect x='28' y='28' width='32' height='32' rx='9.5' fill='#ffffff' fill-opacity='1.0' /><rect x='68' y='28' width='32' height='32' rx='9.5' fill='#7fe3ff' fill-opacity='1.0' /><rect x='28' y='68' width='32' height='32' rx='9.5' fill='#ffd166' fill-opacity='1.0' /><rect x='68' y='68' width='32' height='32' rx='9.5' fill='#ff9ec9' fill-opacity='1.0' /></svg>`;

function initDock() {
  const dock = $("#dock");
  const next = {};

  function tile(item, onclick) {
    const el = document.createElement("div");
    el.className = "app";
    if (item.icon) { const img = document.createElement("img"); img.src = item.icon; img.alt = ""; el.appendChild(img); if (OWN_ICON.test(item.icon)) el.classList.add("filled"); }
    else { el.insertAdjacentHTML("beforeend", item.svg || FALLBACK_ICON); if (item.svg) el.classList.add("filled"); }
    const soon = item.available === false;          // in the dock layout but not built/installed yet
    const tip = document.createElement("span");
    tip.className = "tip"; tip.textContent = soon ? `${item.name} — ${t("coming_soon")}` : item.name; el.appendChild(tip);
    if (item.xids && item.xids.length) el.insertAdjacentHTML("beforeend", `<i class="dot"></i>`);
    if (soon) el.classList.add("soon");
    else el.addEventListener("click", onclick);
    return el;
  }

  function cycle(key, xids) {
    next[key] = ((next[key] ?? -1) + 1) % xids.length;
    post({ type: "activate", xid: xids[next[key]] });
  }

  handlers.state = m => {
    dock.innerHTML = "";
    // The app launcher and search come first, then a divider, then the pinned apps.
    dock.appendChild(tile({ name: t("launcher_name"), svg: LAUNCHER_ICON }, () => post({ type: "launcher-toggle" })));
    dock.insertAdjacentHTML("beforeend", `<div class="sep"></div>`);
    m.pinned.forEach(a => dock.appendChild(tile(a, () => a.xids.length ? cycle(a.id, a.xids) : post({ type: "launch", id: a.id }))));
    if (m.extra.length && m.pinned.length) dock.insertAdjacentHTML("beforeend", `<div class="sep"></div>`);
    m.extra.forEach(a => dock.appendChild(tile(a, () => cycle(a.name, a.xids))));
    requestAnimationFrame(reportLayout);
  };

  window.__relayoutDock = () => reportLayout();
  function reportLayout() {
    const r = dock.getBoundingClientRect();
    post({ type: "dock-layout", rect: { x: r.x, y: r.y, w: r.width, h: r.height } });
  }
  window.addEventListener("resize", () => requestAnimationFrame(reportLayout));
}

/* ---------- Launcher and search ---------- */
/* Drawn, not emoji: the system has no emoji font, so those show as empty boxes. */
const FOLDER_ICON = `<svg class="fi" viewBox="0 0 24 24" width="30" height="30"><path d="M3 7a2 2 0 0 1 2-2h4.2l2 2H19a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" fill="#5aa9ff"/></svg>`;
const FILE_ICON = `<svg class="fi" viewBox="0 0 24 24" width="30" height="30"><path d="M6 3h8l5 5v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z" fill="#e8ecf5"/><path d="M14 3v5h5" fill="#b6c0d8"/></svg>`;

function initLauncher() {
  const input = $("#lq"), grid = $("#lgrid"), results = $("#lresults"), all = $("#lall");
  let apps = [], files = [], query = "", picked = -1, timer = null;

  const tileFor = (app, onclick) => {
    const el = document.createElement("button");
    el.className = "ltile"; el.type = "button";
    if (app.icon) { const img = document.createElement("img"); img.src = app.icon; img.alt = ""; el.appendChild(img); if (OWN_ICON.test(app.icon)) el.classList.add("filled"); }
    else el.insertAdjacentHTML("beforeend", FALLBACK_ICON);
    const label = document.createElement("span"); label.textContent = app.name; el.appendChild(label);
    el.addEventListener("click", onclick);
    return el;
  };
  const launch = app => post({ type: "launcher-launch", id: app.id });
  const openFile = f => post({ type: "launcher-open", path: f.path });
  const close = () => post({ type: "launcher-close" });
  const matches = () => { const q = query.toLowerCase(); return apps.filter(a => a.name.toLowerCase().includes(q)); };

  function renderGrid() {
    grid.innerHTML = "";
    apps.forEach(a => grid.appendChild(tileFor(a, () => launch(a))));
  }

  /* Typing swaps the grid for a short list: matching apps, then matching files. */
  function renderResults() {
    const found = matches();
    results.innerHTML = "";
    const section = (title, rows) => {
      if (!rows.length) return;
      const h = document.createElement("h3"); h.textContent = title; results.appendChild(h);
      rows.forEach(r => results.appendChild(r));
    };
    const rows = [];
    const appRows = found.map(a => {
      const r = document.createElement("button"); r.type = "button"; r.className = "lrow";
      if (a.icon) { const img = document.createElement("img"); img.src = a.icon; img.alt = ""; r.appendChild(img); if (OWN_ICON.test(a.icon)) r.classList.add("filled"); }
      else r.insertAdjacentHTML("beforeend", FALLBACK_ICON);
      r.appendChild(document.createTextNode(a.name));
      r.addEventListener("click", () => launch(a)); r.act = () => launch(a); rows.push(r); return r;
    });
    const fileRows = files.map(f => {
      const r = document.createElement("button"); r.type = "button"; r.className = "lrow";
      r.insertAdjacentHTML("beforeend", f.dir ? FOLDER_ICON : FILE_ICON);
      r.appendChild(document.createTextNode(f.name));
      if (f.where) { const w = document.createElement("small"); w.textContent = f.where; r.appendChild(w); }
      r.addEventListener("click", () => openFile(f)); r.act = () => openFile(f); rows.push(r); return r;
    });
    section(t("launcher_apps"), appRows);
    section(t("launcher_files"), fileRows);
    if (!rows.length) { const p = document.createElement("p"); p.className = "none"; p.textContent = t("launcher_none"); results.appendChild(p); }
    results.rows = rows;
    picked = rows.length ? 0 : -1;
    paintPick();
  }

  function paintPick() {
    (results.rows || []).forEach((r, i) => r.classList.toggle("picked", i === picked));
    const r = (results.rows || [])[picked]; if (r) r.scrollIntoView({ block: "nearest" });
  }

  function update() {
    const typing = query.trim().length > 0;
    results.hidden = !typing; all.hidden = typing;
    if (typing) renderResults();
  }

  input.addEventListener("input", () => {
    query = input.value; files = [];
    update();
    clearTimeout(timer);
    if (query.trim().length >= 2) timer = setTimeout(() => post({ type: "launcher-search", q: query.trim() }), 160);
  });

  document.addEventListener("keydown", e => {
    const rows = results.rows || [];
    if (e.key === "Escape") { e.preventDefault(); if (query) { input.value = ""; query = ""; files = []; update(); } else close(); }
    else if (e.key === "ArrowDown" && !results.hidden && rows.length) { e.preventDefault(); picked = (picked + 1) % rows.length; paintPick(); }
    else if (e.key === "ArrowUp" && !results.hidden && rows.length) { e.preventDefault(); picked = (picked - 1 + rows.length) % rows.length; paintPick(); }
    else if (e.key === "Enter" && !results.hidden && rows[picked]) { e.preventDefault(); rows[picked].act(); }
  });
  /* A click on the empty backdrop closes it. */
  document.body.addEventListener("mousedown", e => { if (e.target === document.body || e.target.classList.contains("lbox") || e.target.id === "lgrid") close(); });

  handlers.init = m => {
    if (typeof I18N !== "undefined") { if (m.lang) I18N.setLanguage(m.lang); I18N.apply(); }
  };
  handlers.apps = m => { apps = m.apps || []; renderGrid(); if (query) update(); input.focus(); };
  handlers.results = m => { if (m.q === query.trim()) { files = m.files || []; if (query.trim()) renderResults(); } };
  input.focus();
}

/* ---------- Mock host (browser preview only) ---------- */
function mockHost(msg) {
  const later = f => setTimeout(f, 60);
  if (msg.type === "ready" && surface === "bar") later(() => {
    window.wos.receive({ type: "init", lang: "en_GB", avail: { settings: true, store: false } });
    window.wos.receive({ type: "active", app: "Firefox", prefs: true, help: ["Contact W-OS support"],
                         state: { fullscreen: false, maximized: false, above: false } });
    window.wos.receive({ type: "status", wifi: { kind: "wifi", name: "Home-5G" }, battery: { pct: 78, charging: false } });
  });
  if (msg.type === "ready" && surface === "dock") later(() => {
    const apps = [["Files", 1], ["Firefox", 1], ["W-Mail", 0], ["Photos", 0], ["W-Calendar", 0], ["Notepad", 0], ["Contacts", 0],
                  ["Spotify", 0], ["App Store", 0], ["Phone Sync", 0], ["Settings", 1], ["W-OS Alpha Feedback", 0]];
    window.wos.receive({ type: "state", extra: [], pinned: apps.map(([name, ready], i) =>
      ({ id: name + ".desktop", name, icon: "", available: !!ready, xids: i === 0 ? [1] : [] })) });
  });
  if (msg.type === "ready" && surface === "launcher") later(() => {
    window.wos.receive({ type: "init", lang: "en_GB" });
    const names = ["Files", "Firefox", "Terminal", "Settings", "Image Viewer", "Text Editor", "Calculator", "Screenshot", "Document Viewer", "Archive Manager", "Printers", "Volume Control"];
    window.wos.receive({ type: "apps", apps: names.map(n => ({ id: n + ".desktop", name: n, icon: "" })) });
  });
  if (msg.type === "launcher-search") later(() => window.wos.receive({ type: "results", q: msg.q, files: [
    { name: msg.q + " notes.txt", path: "/home/will/Documents/" + msg.q + " notes.txt", dir: false, where: "Documents" },
    { name: msg.q + " photos", path: "/home/will/Pictures/" + msg.q + " photos", dir: true, where: "Pictures" }] }));
  if (msg.type === "menu-action" && msg.action === "force-quit-list") later(() =>
    window.wos.receive({ type: "force-quit-apps", apps: [{ name: "Firefox", pid: 101 }, { name: "Files", pid: 102 }] }));
  if (msg.type === "menu-action" && msg.action.startsWith("about-")) parent.postMessage({ showAbout: msg.action.slice(6) }, "*");
  if (msg.type === "close-about") parent.postMessage({ closeAbout: true }, "*");
  if (msg.type === "ready" && surface === "about") later(() => {
    const kind = location.hash.slice(1) || "device";
    window.wos.receive({ type: "init", lang: "en_GB" });
    window.wos.receive({ type: "about", kind, data: kind === "device"
      ? { name: "wos3", model: "innotek GmbH VirtualBox", cpu: "Intel(R) Core(TM) Ultra 5 226V", cores: 2, memory_gb: 3, storage_gb: 19,
          device_id: "d27a8f7b7040", activation: { available: false } }
      : { name: "William Graves Operating Services (W-OS) 4", nickname: "Windermere", version: "Penguin 4ALPHA",
          licence: "William Graves Proprietary Software License (WGPSL)",
          copyright: "William Graves Corp. Ltd. (c) 2020-2026 William Graves Operating Services" } });
  });
  if (["power", "launch", "activate", "app-action", "menu-action"].includes(msg.type)) console.log("mock host:", msg);
}

if (surface === "bar") initBar();
if (surface === "dock") initDock();
if (surface === "about") initAbout();
if (surface === "launcher") initLauncher();
post({ type: "ready", surface });
