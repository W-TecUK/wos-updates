"use strict";
/* Weather logic and drawings with no network and no screen, so it can be tested (os/tests/weather.test.js).
   Temperatures arrive in Celsius and wind in km/h; units are applied only when showing. */
(function (root) {
  /* WMO weather codes -> words and which picture to draw. */
  function describe(code, isDay) {
    const day = isDay !== false;
    if (code === 0) return { label: day ? "Sunny" : "Clear", icon: day ? "sun" : "moon" };
    if (code === 1) return { label: day ? "Mostly sunny" : "Mostly clear", icon: day ? "partly" : "moon-cloud" };
    if (code === 2) return { label: "Partly cloudy", icon: day ? "partly" : "moon-cloud" };
    if (code === 3) return { label: "Overcast", icon: "cloud" };
    if (code === 45 || code === 48) return { label: "Fog", icon: "fog" };
    if (code >= 51 && code <= 57) return { label: "Drizzle", icon: "rain" };
    if (code >= 61 && code <= 67) return { label: code >= 65 ? "Heavy rain" : "Rain", icon: "rain" };
    if (code >= 71 && code <= 77) return { label: "Snow", icon: "snow" };
    if (code >= 80 && code <= 82) return { label: "Showers", icon: "rain" };
    if (code === 85 || code === 86) return { label: "Snow showers", icon: "snow" };
    if (code >= 95 && code <= 99) return { label: "Thunderstorm", icon: "storm" };
    return { label: "Unknown", icon: "cloud" };
  }

  const toF = c => c * 9 / 5 + 32, toMph = k => k * 0.621371;
  const temp = (c, unit) => c == null ? "–" : Math.round(unit === "f" ? toF(c) : c) + "°";
  const wind = (k, unit) => k == null ? "–" : unit === "f" ? Math.round(toMph(k)) + " mph" : Math.round(k) + " km/h";

  /* Drawn pictures, not emoji (this system has no emoji font). Simple shapes in a 48 px box. */
  const SUN = (cx, cy, r, c) => `<circle cx='${cx}' cy='${cy}' r='${r}' fill='${c}'/>` + Array.from({ length: 8 }, (_, i) => { const a = i * Math.PI / 4, x1 = cx + Math.cos(a) * (r + 4), y1 = cy + Math.sin(a) * (r + 4), x2 = cx + Math.cos(a) * (r + 8), y2 = cy + Math.sin(a) * (r + 8); return `<path d='M${x1.toFixed(1)} ${y1.toFixed(1)}L${x2.toFixed(1)} ${y2.toFixed(1)}' stroke='${c}' stroke-width='3' stroke-linecap='round'/>`; }).join("");
  const CLOUD = (fill, dx = 0, dy = 0) => `<path d='M${14 + dx} ${34 + dy}a8 8 0 0 1 1-16 11 11 0 0 1 21 3 7 7 0 0 1-1 13z' fill='${fill}'/>`;
  const MOON = "<path d='M30 10a14 14 0 1 0 8 25 11 11 0 0 1-8-25z' fill='#cfd6ff'/>";
  function iconSvg(kind, size) {
    const body = {
      sun: SUN(24, 24, 9, "#ffb800"),
      moon: MOON,
      partly: SUN(17, 17, 7, "#ffb800") + CLOUD("#e8ecf4", 4, 4),
      "moon-cloud": "<path d='M20 8a11 11 0 1 0 6 20 9 9 0 0 1-6-20z' fill='#cfd6ff'/>" + CLOUD("#dfe4f0", 4, 6),
      cloud: CLOUD("#dfe4f0", 0, 0),
      fog: CLOUD("#dfe4f0", 0, -4) + "<path d='M10 38h28M14 43h20' stroke='#aab2c5' stroke-width='3' stroke-linecap='round'/>",
      rain: CLOUD("#cdd5e6", 0, -4) + "<path d='M17 36l-2 6M25 36l-2 6M33 36l-2 6' stroke='#3d8bff' stroke-width='3' stroke-linecap='round'/>",
      snow: CLOUD("#dfe4f0", 0, -4) + "<g fill='#8fb8ff'><circle cx='16' cy='39' r='2.4'/><circle cx='24' cy='42' r='2.4'/><circle cx='32' cy='39' r='2.4'/></g>",
      storm: CLOUD("#b9c2d8", 0, -5) + "<path d='M26 30l-6 9h5l-3 8 9-11h-5l3-6z' fill='#ffc400'/>",
    }[kind] || CLOUD("#dfe4f0");
    return `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48' width='${size || 48}' height='${size || 48}'>${body}</svg>`;
  }

  /* "2026-10-14T21:00" -> a comparable number of the hour (local time of the place, as the server gives it). */
  const hourKey = s => String(s || "").slice(0, 13);
  function nextHours(fc, n) {
    const h = fc.hourly, cur = hourKey(fc.current.time);
    let i = h.time.findIndex(t => hourKey(t) >= cur); if (i < 0) i = 0;
    return h.time.slice(i, i + (n || 24)).map((t, k) => ({ time: t, hour: t.slice(11, 13), temp: h.temp[i + k], code: h.code[i + k], rain: h.rain[i + k] }));
  }
  const WEEK = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  function dayName(iso, index) {
    if (index === 0) return "Today"; if (index === 1) return "Tomorrow";
    const [y, m, d] = iso.split("-").map(Number); return WEEK[new Date(y, m - 1, d).getDay()];
  }
  function build(fc) {
    const c = fc.current, d = fc.daily;
    return {
      now: { temp: c.temp, feels: c.feels, humidity: c.humidity, wind: c.wind, ...describe(c.code, c.day), hi: d.max[0], lo: d.min[0], sunrise: (d.sunrise[0] || "").slice(11, 16), sunset: (d.sunset[0] || "").slice(11, 16) },
      hours: nextHours(fc, 24).map(x => ({ ...x, ...describe(x.code, +x.hour >= 7 && +x.hour < 19) })),
      days: d.time.map((t, i) => ({ name: dayName(t, i), hi: d.max[i], lo: d.min[i], rain: d.rain[i], ...describe(d.code[i], true) })),
    };
  }

  const api = { describe, temp, wind, iconSvg, nextHours, dayName, build, toF };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.Wx = api;
})(typeof window !== "undefined" ? window : globalThis);
