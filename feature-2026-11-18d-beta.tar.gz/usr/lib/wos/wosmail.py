"""Real email for the W-OS Mail app: IMAP to read, SMTP to send, standard library only.

Works with any provider that accepts a normal password or app password over TLS (W-Mail,
iCloud, Yahoo, Fastmail, your own server). Providers that insist on OAuth are not supported.
"""
import email
import email.policy
import email.utils
import imaplib
import json
import mimetypes
import os
import re
import smtplib
import ssl
import uuid
from email.header import decode_header, make_header
from email.message import EmailMessage

PRESETS = {
    "wmail": {"label": "W-Mail", "imap": ("mail.wmail.life", 993, "ssl"), "smtp": ("mail.wmail.life", 465, "ssl"),
              "help": "Your W-Mail address and password."},
    "icloud": {"label": "iCloud", "imap": ("imap.mail.me.com", 993, "ssl"), "smtp": ("smtp.mail.me.com", 587, "starttls"),
               "help": "Use an app-specific password from appleid.apple.com (Sign-In and Security)."},
    "yahoo": {"label": "Yahoo", "imap": ("imap.mail.yahoo.com", 993, "ssl"), "smtp": ("smtp.mail.yahoo.com", 465, "ssl"),
              "help": "Use an app password from your Yahoo account security page."},
    "fastmail": {"label": "Fastmail", "imap": ("imap.fastmail.com", 993, "ssl"), "smtp": ("smtp.fastmail.com", 465, "ssl"),
                 "help": "Use an app password from Fastmail settings."},
    "custom": {"label": "Other (IMAP)", "imap": ("", 993, "ssl"), "smtp": ("", 465, "ssl"),
               "help": "Enter the server details your provider gave you."},
}
SECURITY = ("ssl", "starttls", "none")
TIMEOUT = 25
MAX_BODY = 400000
MAX_SEND_BYTES = 25 * 1024 * 1024        # most providers refuse more than this in one message
MAX_SAVE_BYTES = 100 * 1024 * 1024
HOST_RE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$")
ADDR_RE = re.compile(r"^[^@\s<>\"',;]+@[^@\s<>\"',;]+\.[^@\s<>\"',;]+$")
LOCAL_HOSTS = ("localhost", "127.0.0.1")


class MailError(Exception):
    """Message safe to show to the person."""


def clean_header(value, limit=300):
    value = str(value or "")
    if "\r" in value or "\n" in value:
        raise MailError("That field cannot contain line breaks.")
    return value.strip()[:limit]


def parse_address(value):
    """A single plain address, or a MailError. Blocks header injection."""
    value = clean_header(value, 254)
    _, addr = email.utils.parseaddr(value)
    if not ADDR_RE.match(addr or ""):
        raise MailError("%r is not a valid email address." % value[:60])
    return addr


def parse_recipients(text):
    parts = [p for p in re.split(r"[;,]", clean_header(text, 2000)) if p.strip()]
    if not parts:
        raise MailError("Add at least one recipient.")
    if len(parts) > 50:
        raise MailError("Too many recipients.")
    return [parse_address(p) for p in parts]


def check_security(host, mode):
    if mode not in SECURITY:
        raise MailError("Unknown security setting.")
    if mode == "none" and host not in LOCAL_HOSTS:
        raise MailError("Unencrypted connections are only allowed to this computer.")


def normalise_account(data, existing_id=None):
    """Turn what the form sent into a stored account, or raise MailError."""
    preset = data.get("provider") if data.get("provider") in PRESETS else "custom"
    base = PRESETS[preset]
    address = parse_address(data.get("address"))
    password = str(data.get("password") or "")
    if not password:
        raise MailError("Enter the password.")
    out = {"id": existing_id or uuid.uuid4().hex[:10], "provider": preset, "address": address, "password": password,
           "name": clean_header(data.get("name") or "", 80), "login": clean_header(data.get("login") or address, 254)}
    for kind in ("imap", "smtp"):
        host = clean_header(data.get(kind + "_host") or base[kind][0], 253).lower()
        if not HOST_RE.match(host):
            raise MailError("Enter the %s server name." % kind.upper())
        try:
            port = int(data.get(kind + "_port") or base[kind][1])
        except (TypeError, ValueError):
            raise MailError("The %s port must be a number." % kind.upper())
        if not 1 <= port <= 65535:
            raise MailError("The %s port must be between 1 and 65535." % kind.upper())
        mode = data.get(kind + "_security") or base[kind][2]
        check_security(host, mode)
        out[kind] = {"host": host, "port": port, "security": mode}
    return out


def public_account(acct):
    """What the interface may see: never the password."""
    return {k: acct[k] for k in ("id", "provider", "address", "name") if k in acct}


# ---------- storage -------------------------------------------------------------------------
def load_accounts(path):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return [a for a in data if isinstance(a, dict) and a.get("id")]
    except (OSError, ValueError, TypeError):
        return []


def save_accounts(path, accounts):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(accounts, f)
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


# ---------- parsing -------------------------------------------------------------------------
def decode_text(value):
    try:
        return str(make_header(decode_header(value or "")))
    except Exception:
        return str(value or "")


def summarise(uid, raw_header, flags=""):
    msg = email.message_from_bytes(raw_header, policy=email.policy.compat32)
    name, addr = email.utils.parseaddr(decode_text(msg.get("From", "")))
    try:
        date = email.utils.parsedate_to_datetime(msg.get("Date", "")).timestamp()
    except Exception:
        date = 0
    return {"uid": str(uid), "from": name or addr or "Unknown", "addr": addr, "to": decode_text(msg.get("To", ""))[:300], "cc": decode_text(msg.get("Cc", ""))[:300],
            "subject": decode_text(msg.get("Subject", ""))[:300], "date": int(date * 1000), "read": "\\Seen" in flags, "flagged": "\\Flagged" in flags}


def html_to_text(html):
    html = re.sub(r"(?is)<(script|style|head).*?</\1>", "", html)
    html = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>|</h\d>|</li>", "\n", html)
    text = re.sub(r"<[^>]+>", "", html)
    import html as htmllib
    text = htmllib.unescape(text)
    return re.sub(r"\n{3,}", "\n\n", re.sub(r"[ \t]+", " ", text)).strip()


def body_text(raw):
    """Readable plain text of a message; no HTML, no remote content, attachments only listed."""
    msg = email.message_from_bytes(raw, policy=email.policy.default)
    part = msg.get_body(preferencelist=("plain",))
    text = ""
    if part is not None:
        text = part.get_content()
    else:
        part = msg.get_body(preferencelist=("html",))
        if part is not None:
            text = html_to_text(part.get_content())
    return {"body": str(text)[:MAX_BODY], "attachments": attachment_list(msg),
            "message_id": str(msg.get("Message-ID") or ""), "references": str(msg.get("References") or "")}


def safe_filename(name, fallback="attachment"):
    """A file name that cannot escape its folder or hide: no paths, no control characters, no leading dots."""
    name = os.path.basename(str(name or "").replace("\\", "/"))
    name = re.sub(r"[\x00-\x1f<>:\"|?*]", "_", name).strip().lstrip(".")
    return name[:120] or fallback


def attachment_list(msg):
    out = []
    for i, p in enumerate(msg.iter_attachments()):
        payload = p.get_payload(decode=True) if not p.is_multipart() else b""
        out.append({"index": i, "name": safe_filename(decode_text(p.get_filename()), "attachment-%d" % (i + 1)), "size": len(payload or b""), "type": p.get_content_type()})
        if len(out) >= 30:
            break
    return out


def extract_attachment(raw, index):
    """(file name, bytes) of the index-th attachment of a message."""
    msg = email.message_from_bytes(raw, policy=email.policy.default)
    for i, p in enumerate(msg.iter_attachments()):
        if i == index:
            data = p.get_payload(decode=True) or b""
            if len(data) > MAX_SAVE_BYTES:
                raise MailError("That attachment is too big to save here.")
            return safe_filename(decode_text(p.get_filename()), "attachment-%d" % (i + 1)), data
    raise MailError("That attachment is no longer there.")


def quote_folder(name):
    name = re.sub(r"[\x00-\x1f]", "", str(name or ""))
    if not name or len(name) > 200:
        raise MailError("That folder is not valid.")
    return '"%s"' % name.replace("\\", "\\\\").replace('"', '\\"')


def build_message(acct, to, subject, body, cc="", in_reply_to="", attachments=None, bcc=""):
    msg = EmailMessage()
    name = acct.get("name") or ""
    msg["From"] = email.utils.formataddr((name, acct["address"])) if name else acct["address"]
    recipients = parse_recipients(to)
    msg["To"] = ", ".join(recipients)
    extra = parse_recipients(cc) if cc.strip() else []
    if extra:
        msg["Cc"] = ", ".join(extra)
    hidden = parse_recipients(bcc) if str(bcc or "").strip() else []          # blind copies: delivered, never written in the headers
    msg["Subject"] = clean_header(subject, 300)
    msg["Date"] = email.utils.formatdate(localtime=True)
    msg["Message-ID"] = email.utils.make_msgid(domain=acct["address"].split("@")[1])
    if in_reply_to:
        msg["In-Reply-To"] = clean_header(in_reply_to, 500)
    msg.set_content(str(body or ""))
    total = 0
    for name, data in attachments or []:
        total += len(data)
        if total > MAX_SEND_BYTES:
            raise MailError("The attachments are too big to send (25 MB at most).")
        name = safe_filename(name)
        ctype = mimetypes.guess_type(name)[0] or "application/octet-stream"
        maintype, _, subtype = ctype.partition("/")
        msg.add_attachment(data, maintype=maintype, subtype=subtype or "octet-stream", filename=name)
    return msg, recipients + extra + hidden


# ---------- network -------------------------------------------------------------------------
def _context():
    return ssl.create_default_context()


def imap_open(acct):
    s = acct["imap"]
    check_security(s["host"], s["security"])
    try:
        if s["security"] == "ssl":
            conn = imaplib.IMAP4_SSL(s["host"], s["port"], ssl_context=_context(), timeout=TIMEOUT)
        else:
            conn = imaplib.IMAP4(s["host"], s["port"], timeout=TIMEOUT)
            if s["security"] == "starttls":
                conn.starttls(_context())
        conn.login(acct.get("login") or acct["address"], acct["password"])
        return conn
    except imaplib.IMAP4.error as exc:
        raise MailError("The server did not accept the address or password. " + _tail(exc))
    except ssl.SSLError as exc:
        raise MailError("The secure connection to %s failed (%s)." % (s["host"], getattr(exc, "reason", "TLS error")))
    except (OSError, EOFError) as exc:
        raise MailError("Could not reach %s: %s" % (s["host"], _tail(exc)))


def _tail(exc):
    text = " ".join(str(a.decode("utf-8", "replace") if isinstance(a, bytes) else a) for a in exc.args)
    return text.strip()[:160]


def smtp_open(acct):
    s = acct["smtp"]
    check_security(s["host"], s["security"])
    try:
        if s["security"] == "ssl":
            conn = smtplib.SMTP_SSL(s["host"], s["port"], timeout=TIMEOUT, context=_context())
        else:
            conn = smtplib.SMTP(s["host"], s["port"], timeout=TIMEOUT)
            conn.ehlo()
            if s["security"] == "starttls":
                conn.starttls(context=_context())
                conn.ehlo()
        conn.login(acct.get("login") or acct["address"], acct["password"])
        return conn
    except smtplib.SMTPAuthenticationError:
        raise MailError("The server did not accept the address or password for sending.")
    except ssl.SSLError as exc:
        raise MailError("The secure connection to %s failed (%s)." % (s["host"], getattr(exc, "reason", "TLS error")))
    except (OSError, smtplib.SMTPException) as exc:
        raise MailError("Could not reach %s: %s" % (s["host"], _tail(exc)))


def test_account(acct):
    conn = imap_open(acct)
    try:
        conn.logout()
    except Exception:
        pass
    out = smtp_open(acct)
    try:
        out.quit()
    except Exception:
        pass
    return True


SPECIAL = {"\\Sent": "sent", "\\Drafts": "drafts", "\\Trash": "bin", "\\Junk": "junk", "\\Archive": "archive"}


def parse_list_line(line):
    m = re.match(r'\((?P<flags>[^)]*)\)\s+(?P<sep>"[^"]*"|NIL)\s+(?P<name>.+)$', line.decode("utf-8", "replace") if isinstance(line, bytes) else line)
    if not m:
        return None
    name = m.group("name").strip()
    if name.startswith('"') and name.endswith('"'):
        name = name[1:-1].replace('\\"', '"')
    flags = m.group("flags").split()
    if "\\Noselect" in flags:
        return None
    return name, flags


def folder_role(name, flags):
    for f in flags:
        if f in SPECIAL:
            return SPECIAL[f]
    low = name.lower()
    if low == "inbox":
        return "inbox"
    for word, role in (("sent", "sent"), ("draft", "drafts"), ("trash", "bin"), ("deleted", "bin"), ("junk", "junk"), ("spam", "junk"), ("archive", "archive")):
        if word in low:
            return role
    return "other"


def list_folders(acct):
    conn = imap_open(acct)
    try:
        typ, data = conn.list()
        out = []
        for line in data or []:
            if not line:
                continue
            parsed = parse_list_line(line)
            if parsed and "&" not in parsed[0]:       # skip modified-UTF-7 names we cannot show
                out.append({"name": parsed[0], "role": folder_role(*parsed)})
        order = ["inbox", "drafts", "sent", "archive", "junk", "bin", "other"]
        out.sort(key=lambda f: (order.index(f["role"]), f["name"].lower()))
        return out
    finally:
        _quit(conn)


def _quit(conn):
    try:
        conn.logout()
    except Exception:
        pass


def _select(conn, folder, readonly=True):
    typ, _ = conn.select('"%s"' % folder.replace("\\", "\\\\").replace('"', '\\"'), readonly=readonly)
    if typ != "OK":
        raise MailError("Could not open that folder.")


def list_messages(acct, folder, limit=60):
    conn = imap_open(acct)
    try:
        _select(conn, folder)
        typ, data = conn.uid("SEARCH", None, "ALL")
        uids = (data[0] or b"").split()[-int(limit):]
        if not uids:
            return []
        typ, rows = conn.uid("FETCH", b",".join(uids).decode(), "(FLAGS BODY.PEEK[HEADER.FIELDS (FROM TO CC SUBJECT DATE)])")
        out = []
        for row in rows or []:
            if isinstance(row, tuple):
                meta = row[0].decode("utf-8", "replace")
                m = re.search(r"UID (\d+)", meta)
                flags = re.search(r"FLAGS \(([^)]*)\)", meta)
                if m:
                    out.append(summarise(m.group(1), row[1], flags.group(1) if flags else ""))
        out.sort(key=lambda x: x["date"], reverse=True)
        return out
    finally:
        _quit(conn)


def unseen(acct, folder="INBOX"):
    """UIDs of unread messages in a folder, oldest first."""
    conn = imap_open(acct)
    try:
        _select(conn, folder)
        typ, data = conn.uid("SEARCH", None, "UNSEEN")
        return sorted(int(u) for u in (data[0] or b"").split())
    finally:
        _quit(conn)


def summaries(acct, uids, folder="INBOX"):
    """Sender and subject of some messages, without marking them read."""
    if not uids:
        return []
    conn = imap_open(acct)
    try:
        _select(conn, folder)
        typ, rows = conn.uid("FETCH", ",".join(str(int(u)) for u in uids), "(BODY.PEEK[HEADER.FIELDS (FROM TO CC SUBJECT DATE)])")
        out = []
        for row in rows or []:
            if isinstance(row, tuple):
                m = re.search(r"UID (\d+)", row[0].decode("utf-8", "replace"))
                out.append(summarise(m.group(1) if m else 0, row[1], ""))
        return out
    finally:
        _quit(conn)


def new_since(baseline, uids):
    """What to announce: (unread messages newer than the last one announced, the new baseline).

    baseline None means this account has never been checked: remember where it stands and announce nothing, so adding an
    account does not announce the whole inbox."""
    top = max(uids) if uids else 0
    if baseline is None:
        return [], top
    return [u for u in uids if u > baseline], max(baseline, top)


def read_message(acct, folder, uid):
    uid = str(int(uid))
    conn = imap_open(acct)
    try:
        _select(conn, folder, readonly=False)
        typ, rows = conn.uid("FETCH", uid, "(BODY[])")
        raw = next((r[1] for r in rows or [] if isinstance(r, tuple)), None)
        if raw is None:
            raise MailError("That message is no longer there.")
        conn.uid("STORE", uid, "+FLAGS", "(\\Seen)")
        return body_text(raw)
    finally:
        _quit(conn)


def delete_message(acct, folder, uid, trash=None):
    uid = str(int(uid))
    conn = imap_open(acct)
    try:
        _select(conn, folder, readonly=False)
        if trash and trash != folder:
            typ, _ = conn.uid("COPY", uid, '"%s"' % trash.replace("\\", "\\\\").replace('"', '\\"'))
            if typ != "OK":
                raise MailError("Could not move the message to the bin.")
        conn.uid("STORE", uid, "+FLAGS", "(\\Deleted)")
        conn.expunge()
        return True
    finally:
        _quit(conn)


def set_read(acct, folder, uid, read):
    uid = str(int(uid))
    conn = imap_open(acct)
    try:
        _select(conn, folder, readonly=False)
        conn.uid("STORE", uid, "+FLAGS" if read else "-FLAGS", "(\\Seen)")
        return True
    finally:
        _quit(conn)


def set_flag(acct, folder, uid, flagged):
    uid = str(int(uid))
    conn = imap_open(acct)
    try:
        _select(conn, folder, readonly=False)
        conn.uid("STORE", uid, "+FLAGS" if flagged else "-FLAGS", "(\\Flagged)")
        return True
    finally:
        _quit(conn)


def move_message(acct, folder, uid, dest):
    """Move a message to another folder (archive, junk, anything): copy it, then remove the original."""
    uid = str(int(uid))
    if dest == folder:
        return True
    conn = imap_open(acct)
    try:
        _select(conn, folder, readonly=False)
        typ, _ = conn.uid("COPY", uid, quote_folder(dest))
        if typ != "OK":
            raise MailError("Could not move the message.")
        conn.uid("STORE", uid, "+FLAGS", "(\\Deleted)")
        conn.expunge()
        return True
    finally:
        _quit(conn)


def save_draft(acct, to, subject, body, cc="", bcc="", folder=None):
    """Keep an unfinished message in the Drafts folder on the server. Recipients may be missing or unfinished."""
    msg = EmailMessage()
    name = acct.get("name") or ""
    msg["From"] = email.utils.formataddr((name, acct["address"])) if name else acct["address"]
    for header, value in (("To", to), ("Cc", cc), ("Bcc", bcc)):
        clean = clean_header(value, 2000)
        if clean:
            msg[header] = clean
    msg["Subject"] = clean_header(subject, 300)
    msg["Date"] = email.utils.formatdate(localtime=True)
    msg.set_content(str(body or ""))
    target = folder or next((f["name"] for f in list_folders(acct) if f["role"] == "drafts"), None)
    if not target:
        raise MailError("This account has no Drafts folder.")
    conn = imap_open(acct)
    try:
        typ, _ = conn.append(quote_folder(target), "(\\Draft \\Seen)", None, msg.as_bytes())
        if typ != "OK":
            raise MailError("Could not save the draft.")
    finally:
        _quit(conn)
    return target


def read_attachment(acct, folder, uid, index):
    uid = str(int(uid))
    conn = imap_open(acct)
    try:
        _select(conn, folder, readonly=True)
        typ, rows = conn.uid("FETCH", uid, "(BODY.PEEK[])")
        raw = next((r[1] for r in rows or [] if isinstance(r, tuple)), None)
        if raw is None:
            raise MailError("That message is no longer there.")
        return extract_attachment(raw, int(index))
    finally:
        _quit(conn)


def send_message(acct, to, subject, body, cc="", in_reply_to="", attachments=None, bcc=""):
    msg, recipients = build_message(acct, to, subject, body, cc, in_reply_to, attachments, bcc)
    conn = smtp_open(acct)
    try:
        conn.send_message(msg, from_addr=acct["address"], to_addrs=recipients)
    except smtplib.SMTPRecipientsRefused:
        raise MailError("The server refused the recipient address.")
    except smtplib.SMTPException as exc:
        raise MailError("Could not send: " + _tail(exc))
    finally:
        try:
            conn.quit()
        except Exception:
            pass
    return msg.as_bytes()


def file_in_sent(acct, raw):
    """Best effort copy into the Sent folder (providers like iCloud do this themselves)."""
    if acct.get("provider") == "icloud":
        return False
    try:
        folders = list_folders(acct)
        sent = next((f["name"] for f in folders if f["role"] == "sent"), None)
        if not sent:
            return False
        conn = imap_open(acct)
        try:
            conn.append('"%s"' % sent, "(\\Seen)", None, raw)
        finally:
            _quit(conn)
        return True
    except MailError:
        return False
