"use strict";
// Compiled by satc (Satisfaction) -- do not edit by hand.

  let count = 0;
  async function increment() {
    count = (count + 1);
    render();
  }
  async function decrement() {
    count = (count - 1);
    render();
  }

function __satRender() {
  return h("div.sat-view", h("div.sat-text", String(`Satisfaction Counter`)), h("div.sat-text", String(`Count: ${count}`)), h("div.sat-hstack", h("button.sat-button", { onclick: async () => {
      decrement();
    } }, `-`), h("button.sat-button", { onclick: async () => {
      increment();
    } }, `+`)), h("div.sat-spacer"));
}

function render() {
  const root = document.getElementById("root");
  root.innerHTML = "";
  root.append(__satRender());
}
boot(async () => { render(); });
