"""satgtk: turns a .satUI view tree into real, native GTK3 widgets -- no WebKit, no HTML, no JS
anywhere in this path. This is W-OS-specific (tied to one desktop toolkit), which is exactly why
it lives here and not in satlang-lang: that repo stays host-agnostic, this file is one host's
choice of how to draw what satlang evaluates.

Beta only. Used by wos-sat-run (a single app) and satshell (the parallel, WebKit-free desktop
shell) alike -- both just call build() with a fresh handler dict and hand the result to a GTK
container.
"""
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib  # noqa: E402

from satlang import to_display_string  # noqa: E402

CSS_CLASS = {"View": "sat-view", "VStack": "sat-vstack", "HStack": "sat-hstack", "ZStack": "sat-zstack",
             "Text": "sat-text", "Button": "sat-button", "Spacer": "sat-spacer"}
# Leaf views that are one line of text. Title and Muted are the same label with a different CSS class.
TEXT_VIEWS = ("Text", "Title", "Muted")
ORIENTATION = {"View": Gtk.Orientation.VERTICAL, "VStack": Gtk.Orientation.VERTICAL, "HStack": Gtk.Orientation.HORIZONTAL,
               "Pill": Gtk.Orientation.HORIZONTAL, "DockPill": Gtk.Orientation.HORIZONTAL}


def _image(source, arg_nodes, interpreter, env, css_class):
    """Image("icon-name") draws a theme icon; Image("/abs/path.svg") draws a file. An optional second
    argument is the size in pixels (default 24). Native Gtk.Image, no web view."""
    size = 24
    if len(arg_nodes) > 1:
        size = int(interpreter.eval_expr(arg_nodes[1], env))
    if source and source.startswith("/"):
        try:
            from gi.repository import GdkPixbuf
            img = Gtk.Image.new_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_size(source, size, size))
        except GLib.Error:
            img = Gtk.Image.new_from_icon_name("image-missing", Gtk.IconSize.BUTTON)
    else:
        img = Gtk.Image.new_from_icon_name(source or "image-missing", Gtk.IconSize.BUTTON)
        img.set_pixel_size(size)
    img.get_style_context().add_class(css_class)
    return img


def build(node, interpreter, env, handlers, next_id):
    """Walks a .satUI AST against the CURRENT program state, same as satlang.render_view, but
    returns a live Gtk.Widget instead of a JSON-able dict. Runs on every render -- there is no
    compiled-once view, a Satisfaction program's UI is only ever evaluated fresh."""
    name, arg_nodes, block = node
    css_class = CSS_CLASS.get(name, "sat-" + name.lower())
    text = interpreter.eval_expr(arg_nodes[0], env) if arg_nodes else None
    text_str = to_display_string(text) if text is not None else None

    if name in TEXT_VIEWS:
        label = Gtk.Label(label=text_str or "")
        label.set_xalign(0)
        label.get_style_context().add_class(css_class)
        return label

    if name == "Image":
        return _image(text_str, arg_nodes, interpreter, env, css_class)

    if name in ("IconButton", "RingButton"):
        btn = Gtk.Button()
        btn.set_image(_image(text_str, arg_nodes, interpreter, env, "sat-icon"))
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.get_style_context().add_class(css_class)
        if block is not None and block[0] == "stmts":
            stmts, handler_env = block[1], env

            def on_icon_click(_widget, stmts=stmts, handler_env=handler_env):
                for s in stmts:
                    interpreter.exec_stmt(s, handler_env)

            btn.connect("clicked", on_icon_click)
        return btn

    if name == "Spacer":
        filler = Gtk.Box()
        filler.set_hexpand(True)
        filler.set_vexpand(True)
        filler.get_style_context().add_class(css_class)
        return filler

    if name == "Button":
        btn = Gtk.Button(label=text_str or "")
        btn.get_style_context().add_class(css_class)
        if block is not None and block[0] == "stmts":
            handler_id = "h%d" % next_id[0]
            next_id[0] += 1
            handlers[handler_id] = (block[1], env)
            stmts, handler_env = block[1], env

            def on_click(_widget, stmts=stmts, handler_env=handler_env):
                for s in stmts:
                    interpreter.exec_stmt(s, handler_env)

            btn.connect("clicked", on_click)
        return btn

    # a container: View, VStack, HStack, or ZStack
    box = Gtk.Box(orientation=ORIENTATION.get(name, Gtk.Orientation.VERTICAL), spacing=6 if name == "DockPill" else 10)
    if name == "Divider":
        box.set_valign(Gtk.Align.CENTER)
    if name in ("Pill", "DockPill"):
        box.set_halign(Gtk.Align.FILL)      # the pill fills its window, the content sits in the middle
        box.set_valign(Gtk.Align.FILL)
        box.set_homogeneous(False)
    box.get_style_context().add_class(css_class)
    if block is not None and block[0] == "views":
        for child_node in block[1]:
            child = build(child_node, interpreter, env, handlers, next_id)
            expand = child_node[0] == "Spacer"
            box.pack_start(child, expand, expand, 0)
    return box


def load_css():
    """A GTK CssProvider, not a browser stylesheet -- GTK's own CSS dialect, applied once at
    process start. See usr/share/wos/satisfaction/satgtk.css for the actual rules."""
    from gi.repository import Gdk
    provider = Gtk.CssProvider()
    try:
        provider.load_from_path("/usr/share/wos/satisfaction/satgtk.css")
    except GLib.Error as e:
        import sys
        print("satgtk: no stylesheet: %s" % e, file=sys.stderr)
        return
    Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
