"use strict";
/* Help: plain-language answers, grouped, with a search box that finds the right article as you type.
   The articles and the search are in topics.js (tested). */

boot(async info => {
  const root = $("#root");
  const H = window.HelpTopics;
  let query = "", current = (info.args || [])[0] && H.TOPICS.some(t => t.id === info.args[0]) ? info.args[0] : "welcome";

  const search = h("input.sidebar-search", { type: "search", placeholder: "Search Help", oninput: e => { query = e.target.value; const r = H.search(query, H.TOPICS); if (r.length && !r.some(t => t.id === current)) current = r[0].id; draw(); } });
  const nav = h("nav.nav"), article = h("div.body", { style: "max-width:680px;width:100%" });
  root.append(h("div.app.settings-app", h("aside.side", h("div.side-title", "Help"), search, nav), h("div.main", { style: "overflow:auto" }, h("div", { style: "padding:26px 30px;display:flex;justify-content:center" }, article))));

  function draw() {
    const found = H.search(query, H.TOPICS);
    nav.innerHTML = "";
    let group = null;
    found.forEach(t => {
      if (!query && t.group !== group) { group = t.group; nav.append(h("span.label", { style: "display:block;margin:16px 10px 6px" }, group)); }
      nav.append(h("button" + (t.id === current ? ".on" : ""), { style: "height:auto;min-height:34px;padding:7px 10px;line-height:1.25", onclick: () => { current = t.id; draw(); } }, t.title));
    });
    if (!found.length) nav.append(h("div.muted.small", { style: "padding:10px 12px" }, "Nothing matches. Try different words, like wifi, backup or password."));
    const t = H.TOPICS.find(x => x.id === current) || found[0];
    article.innerHTML = "";
    if (!t || !found.length) {
      article.append(h("div.panel", { style: "margin-top:20px" }, h("span.chip.gold.eyebrow", "Help"), h("h3", "No answer found"), h("p", "Try fewer or different words, or write to us from W-OS Alpha Feedback.")));
      return;
    }
    article.append(h("span.chip.gold", { style: "margin-bottom:10px" }, t.group), h("h1.dots", { style: "font-size:34px;margin:6px 0 16px" }, t.title));
    t.body.forEach(b => {
      if (typeof b === "string") article.append(h("p", { style: "line-height:1.65;margin:0 0 14px;user-select:text" }, b));
      else if (b.steps) article.append(h("ol", { style: "margin:0 0 16px;padding-left:22px;line-height:1.7;user-select:text" }, b.steps.map(s => h("li", { style: "margin-bottom:6px" }, s))));
      else if (b.tip) article.append(h("div.card", { style: "padding:14px 18px;margin:0 0 16px;border-left:4px solid var(--gold)" }, h("b", "Tip  "), b.tip));
    });
    const links = { welcome: ["Open Settings", "wos-settings.desktop"], files: ["Open Files", "wos-files.desktop"], backup: ["Open Settings", "wos-settings.desktop"], mail: ["Open Mail", "wos-mail.desktop"], apps: ["Open the App Store", "wos-store.desktop"], stuck: ["Open Monitor", "wos-monitor.desktop"] };
    if (links[t.id]) article.append(h("button.btn", { onclick: () => wos.call("sys.launch", { id: links[t.id][1] }).catch(e => toast(e.message)) }, links[t.id][0]));
  }
  draw();
});
