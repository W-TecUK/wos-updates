"""satshelf_layout: the maths of the W-OS 4 shelf, with no GTK in it so it can be tested.

Will's layout (18 Nov, designer's v9 SHELF-MOTION-SPEC): LEFT = essentials (ring + pinned basic apps, always there),
MIDDLE = a capsule of the open (active) apps, RIGHT = live pills, which never move when an app opens.
Two styles for how an opened app reaches the middle:
  join  - a small capsule forms at the centre and widens (30 to 100 px); the icon fades and scales in.
  morph - the icon travels from the left capsule on a 70 px arc to the centre, a capsule growing round it (60 to 100 px).
Every move uses one spring (stiffness 420, damping 26, about 7% overshoot). Sizes are for a 1920 wide screen; `s` scales them.
"""
BOTTOM = 24
CAP_H = 84          # open capsule height (join); morph grows 76 -> 84
RING = 60
RUN_ICON = 46
PIN_ICON = 52
RUN_PITCH = 60
PIN_PITCH = 66
PAD = 12
GAP_AFTER_RING = 14
PILL_H = 68
PILL_GAP = 10
PILL_OPEN_W = 150
PILL_ICON_ONLY_W = 68
MORPH_REST = 76
TAIL = 12
STIFFNESS = 420.0
DAMPING = 26.0


class Spring:
    """A damped spring that chases `target`. Step it with the frame time; stop ticking when `settled`."""

    def __init__(self, value=0.0, stiffness=STIFFNESS, damping=DAMPING):
        self.value = value
        self.target = value
        self.velocity = 0.0
        self.k = stiffness
        self.c = damping

    def step(self, dt):
        dt = min(dt, 0.05)
        n = max(1, int(dt / 0.004))
        h = dt / n
        for _ in range(n):
            self.velocity += (-self.k * (self.value - self.target) - self.c * self.velocity) * h
            self.value += self.velocity * h
        if self.settled:
            self.value, self.velocity = self.target, 0.0
        return self.value

    @property
    def settled(self):
        return abs(self.value - self.target) < 0.0005 and abs(self.velocity) < 0.005


def clamp(v, lo=0.0, hi=1.0):
    return lo if v < lo else hi if v > hi else v


def lerp(a, b, t):
    return a + (b - a) * t


def _pills_from_right(pills, widths, right, gap):
    xs, x = [], right
    for w in reversed(widths):
        x -= w
        xs.append(x)
        x -= gap
    return list(reversed(xs))


ESS_ICON = 46
ESS_PITCH = 60
MID_H = 68
MID_ICON = 46
MID_PITCH = 56
MID_PAD = 22
ARC = 70


def left_capsule(W, H, n_essentials, s=1.0):
    """(x, y, w, h) of the left capsule: ring plus the essentials."""
    w = s * (PAD * 2 + RING) + (s * GAP_AFTER_RING + n_essentials * s * ESS_PITCH if n_essentials else 0)
    return (s * BOTTOM, H - s * BOTTOM - s * CAP_H, w, s * CAP_H)


def frame(style, W, H, essentials, active, pills, s=1.0, reduce_motion=False, press=None):
    """Everything to draw. `essentials`: [{"id", "running"}]. `active`: [{"item", "e"}] with e the 0..1 entry progress
    of each open app. `press`: (essential index or None, 0..1) for the 'pressed' look of a just-clicked icon."""
    S = lambda v: v * s
    lx, ly, lw, lh = left_capsule(W, H, len(essentials), s)
    mid_y = lambda h: H - S(BOTTOM) - h
    ring = (lx + S(PAD), ly + (lh - S(RING)) / 2, S(RING))

    icons = []
    for i, it in enumerate(essentials):
        x = lx + S(PAD + RING + GAP_AFTER_RING) + i * S(ESS_PITCH) + (S(ESS_PITCH) - S(ESS_ICON)) / 2
        sz = S(ESS_ICON)
        pressed = press is not None and press[0] == i
        if pressed:
            sz *= 1 - 0.08 * clamp(press[1])
        icons.append({"item": it, "x": x + (S(ESS_ICON) - sz) / 2, "y": ly + lh / 2 - sz / 2, "size": sz, "alpha": 1.0,
                      "running": bool(it.get("running")), "ring": pressed and press[1] > 0})

    # ---- the middle capsule of active apps
    es = [clamp(a["e"], 0.0, 1.12) for a in active]
    if reduce_motion:
        es = [1.0 if e > 0.5 else 0.0 for e in es]
    total = sum(es)
    mid = None
    mid_icons = []
    if total > 0.01:
        t = clamp(total)
        base0, base1 = (30, 44) if style == "join" else (60, 44)
        w = S(lerp(base0, base1, t)) + total * S(MID_PITCH)
        x = (W - w) / 2
        h = S(MID_H)
        mid = (x, mid_y(h), w, h)
        start = x + (w - total * S(MID_PITCH)) / 2
        cum = 0.0
        for k, a in enumerate(active):
            e = es[k]
            cx = start + (cum + e / 2) * S(MID_PITCH)
            cy = mid_y(h) + h / 2
            cum += e
            sz = S(MID_ICON)
            alpha, scale, rise = 1.0, 1.0, 0.0
            if style == "join":
                alpha, scale = clamp(e * 1.5), 0.5 + 0.5 * clamp(e)
            else:                                        # morph: fly in from the left capsule on a 70 px arc
                src = a.get("from")                      # centre of the icon it came from, or the ring
                if src is None:
                    src = (ring[0] + ring[2] / 2, ring[1] + ring[2] / 2)
                f = clamp(e)
                cx, cy = lerp(src[0], cx, f), lerp(src[1], cy, f) - S(ARC) * 4 * f * (1 - f)
                alpha = clamp(e * 4)
            d = sz * scale
            mid_icons.append({"item": a["item"], "x": cx - d / 2, "y": cy - d / 2, "size": d, "alpha": alpha, "running": e > 0.95, "e": e})

    # ---- live pills: always on the right, never moved by an app opening
    natural = [S(pl["natural_w"]) for pl in pills]
    xs = _pills_from_right(pills, natural, W - S(BOTTOM), S(PILL_GAP))
    out_pills = [{"pill": pl, "x": x, "y": H - S(BOTTOM) - S(PILL_H), "w": w, "h": S(PILL_H), "bg_alpha": 1.0, "text_alpha": 1.0}
                 for pl, x, w in zip(pills, xs, natural)]
    return {"capsule": (lx, ly, lw, lh), "ring": ring, "icons": icons, "mid": mid, "mid_icons": mid_icons, "pills": out_pills}


def capsule_radii(h):
    """(top-left, top-right, bottom-right, bottom-left): round ends with a 12 px tail at the bottom-left."""
    return (h / 2, h / 2, h / 2, TAIL)


def pill_radii(h):
    return (h / 2, h / 2, TAIL, h / 2)
