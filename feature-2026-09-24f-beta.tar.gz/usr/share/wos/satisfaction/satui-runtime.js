"use strict";
/* The Satisfaction host page's own tiny renderer. It knows nothing about the language --
   satlang.py (the Python interpreter, running natively) evaluates .satUI into a plain JSON tree
   and this file's only job is turning that shape into DOM, and reporting clicks back by their
   opaque action id. All of Satisfaction's actual behaviour lives in satlang.py, not here. */

function h(tag, attrs, ...kids) {
  const [name, ...classes] = tag.split(".");
  const el = document.createElement(name || "div");
  if (classes.length) el.className = classes.join(" ");
  if (attrs && (attrs.nodeType || typeof attrs === "string" || Array.isArray(attrs))) { kids.unshift(attrs); attrs = null; }
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return el;
}

const bridge = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.sat;

function buildNode(node) {
  if (node.tag === "Button") {
    return h("button." + node.class, { onclick: () => { if (bridge) bridge.postMessage(JSON.stringify({ action: node.action })); } }, node.text || "");
  }
  if (node.children) return h("div." + node.class, node.children.map(buildNode));
  return h("div." + node.class, node.text != null ? String(node.text) : "");
}

window.__satRender = function (tree) {
  document.getElementById("sat-error").hidden = true;
  const root = document.getElementById("root");
  root.innerHTML = "";
  root.append(buildNode(tree));
};

window.__satError = function (message) {
  const box = document.getElementById("sat-error");
  box.hidden = false;
  box.textContent = message;
};

if (bridge) bridge.postMessage(JSON.stringify({ ready: true }));
