"""Accessibility choices: text size for W-OS apps, and, desktop-wide, the pointer size and the keyboard helpers.

Pure functions (tested anywhere). `commands` turns the person's choices into the xfconf-query calls wos-apply-prefs runs.
Text size is deliberately NOT applied through the screen's DPI: the desktop shell (bar, dock, widgets) is drawn by web views
that follow the DPI and its fixed layout breaks when it changes (found on the real image). W-OS apps zoom their own pages.
"""
TEXT_SCALES = (100, 115, 130, 150, 175, 200)         # percent
CURSOR_SIZES = (24, 32, 48, 64)                       # pixels
KEYBOARD_KEYS = ("sticky", "slow", "bounce")


def clean_prefs(raw):
    """Whatever was saved -> {text_scale, cursor_size, sticky, slow, bounce}. The old on/off 'Bigger text' counts as 115 %."""
    raw = raw if isinstance(raw, dict) else {}
    scale = raw.get("text_scale")
    if scale not in TEXT_SCALES:
        scale = 115 if raw.get("zoom") else 100
    size = raw.get("cursor_size")
    if size not in CURSOR_SIZES:
        size = CURSOR_SIZES[0]
    out = {"text_scale": scale, "cursor_size": size}
    for k in KEYBOARD_KEYS:
        out[k] = bool(raw.get(k))
    return out


def page_zoom(prefs):
    """The zoom factor W-OS apps apply to their own pages."""
    return clean_prefs(prefs)["text_scale"] / 100


def commands(prefs):
    p = clean_prefs(prefs)
    set_ = lambda channel, prop, kind, value: ["xfconf-query", "-c", channel, "-p", prop, "-n", "-t", kind, "-s", str(value)]      # noqa: E731
    out = [set_("xsettings", "/Gtk/CursorThemeSize", "int", p["cursor_size"])]
    for key, prop in (("sticky", "/StickyKeys"), ("slow", "/SlowKeys"), ("bounce", "/BounceKeys")):
        out.append(set_("accessibility", prop, "bool", "true" if p[key] else "false"))
    return out
