"use strict";
/* Phone Sync: pair an Android phone with this computer over the home network. While this window is open a small
   receiver listens (only for devices on a private network); close the window and it stops. The phone enters this
   computer's address and the six-digit code, then sends contacts, calendar events and photos. */

boot(async info => {
  const root = $("#root");
  let st = { running: false, addresses: [], code: "", phones: [], prefs: {}, last: {}, port: 8620 };
  const body = h("div.body", { style: "max-width:720px;margin:0 auto;width:100%" });
  root.append(h("div.app.no-side", h("div.main", body)));

  const setPref = async (key, value) => { try { await wos.call("phone.set_pref", { key, value }); } catch (e) { toast(e.message); } };
  const toggle = (label, sub, key) => {
    const sw = h("button.switch" + (st.prefs[key] ? ".on" : ""), { onclick: () => { st.prefs[key] = !st.prefs[key]; sw.classList.toggle("on", !!st.prefs[key]); setPref(key, !!st.prefs[key]); } });
    return h("div.row", { style: "cursor:default" }, h("div.grow", h("div.t", label), h("div.s", sub)), sw);
  };
  const when = t => new Date(t * 1000).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
  const lastLine = key => st.last[key] ? `Last: ${st.last[key].count} ${key === "photos" ? "photos" : "items"} from ${st.last[key].from}, ${when(st.last[key].time)}` : "Nothing received yet";

  function draw() {
    const code = st.code || "";
    const addr = st.addresses.length ? st.addresses.map(a => a + ":" + st.port).join("   ") : "Not connected to a network";
    body.innerHTML = "";
    body.append(h("h1.dots", { style: "font-size:40px;margin:4px 0 4px" }, "Phone Sync"),
      h("p.muted", { style: "margin:0 0 20px" }, "Bring your contacts, calendar and photos across from an Android phone."),
      h("div.card.pad", { style: "display:flex;gap:26px;align-items:center;flex-wrap:wrap" },
        h("div", { style: "flex:1;min-width:240px" },
          h("span.label", "Pairing code"),
          h("div.mono", { style: "font-size:34px;font-weight:700;letter-spacing:.18em;margin:6px 0 10px;user-select:text" }, code ? code.slice(0, 3) + " " + code.slice(3) : "…"),
          h("span.label", "This computer's address"),
          h("div.mono", { style: "font-size:18px;font-weight:700;margin:4px 0 12px;user-select:text" }, addr),
          h("ol.muted", { style: "padding-left:18px;margin:0 0 14px;line-height:1.7" },
            h("li", "Install W-OS Phone on your Android phone and join the same Wi-Fi."),
            h("li", "Open it, type the address and the code above."),
            h("li", "Press Pair, then Sync now.")),
          h("div", { style: "display:flex;align-items:center;gap:10px" },
            h("span", { html: '<i class="dot"></i>' }), h("span.small", st.running ? "Ready. Waiting for your phone…" : "Starting…"),
            h("button.btn.ghost.small", { style: "margin-left:auto", onclick: async () => { try { await wos.call("phone.new_code"); await refresh(); } catch (e) { toast(e.message); } } }, "New code")))),
      h("h2", { style: "margin:26px 0 10px;font-size:16px" }, "What this computer accepts"),
      h("div.card",
        toggle("Contacts", lastLine("contacts"), "contacts"),
        toggle("Calendar", lastLine("calendar"), "calendar"),
        toggle("Photos", lastLine("photos") + ". Saved in Pictures, in a folder called Phone.", "photos")),
      h("h2", { style: "margin:26px 0 10px;font-size:16px" }, "Paired phones"),
      h("div.card", st.phones.length ? st.phones.map((p, i) => h("div.row", { style: "cursor:default" },
        h("div.grow", h("div.t", p.name), h("div.s", "Paired " + when(p.added))),
        h("button.btn.ghost.small", { onclick: async () => { try { await wos.call("phone.forget", { index: i }); await refresh(); } catch (e) { toast(e.message); } } }, "Forget"))) :
        h("div.row.muted", { style: "cursor:default" }, "No phones yet")),
      h("p.small.muted", { style: "margin-top:14px" }, "Only devices on your own home network can reach this. It stops listening when you close this window."));
  }

  let editing = false;
  async function refresh() {
    try { st = await wos.call("phone.status"); } catch (e) { toast(e.message); }
    if (!editing) draw();
  }
  await refresh();
  setInterval(refresh, 4000);
});
