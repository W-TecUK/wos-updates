"use strict";
/* Settings: appearance (light/dark), network, sound, account, language, accessibility, updates, about. */

boot(async info => {
  const root = $("#root");
  let page = "appearance", theme = await wos.call("theme.get");
  const acc = await wos.call("prefs.get");

  // group, key, label, icon, colour, words the search also matches -- grouped and ordered the
  // way System Settings and Windows Settings both are (identity/personal first, then hardware
  // and connections, then the machine-wide stuff), not one flat alphabetical Linux-style list.
  const PAGES = [
    ["Personalization", "appearance", "Appearance", "paint", "#5e5ce6", "theme dark light accent colour highlight"],
    ["Personalization", "desktop", "Desktop & Dock", "image", "#0a84ff", "wallpaper background dock size clock menu bar battery"],
    ["Personalization", "displays", "Displays", "image", "#32ade6", "screen resolution scale brightness night light warm"],
    ["Personalization", "sound", "Sound", "sound", "#ff375f", "volume speaker output"],
    ["Personalization", "notifications", "Notifications", "bell", "#ff453a", "do not disturb focus alerts banners"],
    ["Network & devices", "network", "Network", "wifi", "#0a84ff", "wifi wi-fi internet"],
    ["Network & devices", "bluetooth", "Bluetooth", "phone", "#1d8cf8", "headphones devices"],
    ["Network & devices", "keyboard", "Keyboard & trackpad", "edit", "#8e8e93", "mouse touchpad typing scroll shortcuts hotkeys"],
    ["Network & devices", "printers", "Printers", "doc", "#8e8e93", "print scan"],
    ["Accounts & privacy", "users", "Users", "user", "#64a0ff", "accounts people login items startup apps"],
    ["Accounts & privacy", "account", "W-Account", "shield", "#0a84ff", "sign in email w-life"],
    ["Accounts & privacy", "privacy", "Privacy & Security", "lock", "#2c9fb8", "firewall data sharing telemetry crash usage"],
    ["System", "power", "Power", "battery", "#30b04f", "battery sleep lock screen energy"],
    ["System", "datetime", "Date & time", "clock", "#ff9f0a", "timezone clock 24 hour"],
    ["System", "language", "Language & region", "globe", "#0a84ff", "english spanish"],
    ["System", "defaults", "Default apps", "grid", "#bf5af2", "browser web"],
    ["System", "storage", "Storage", "disk", "#8e8e93", "disk space bin trash free"],
    ["System", "access", "Accessibility", "list", "#0a84ff", "zoom contrast motion speak"],
    ["System", "updates", "Updates", "refresh", "#8e8e93", "software version"],
    ["System", "about", "About", "gear", "#8e8e93", "name version device rename"],
  ];
  let query = "";
  { const want = (info.args || [])[0]; if (want && PAGES.some(p => p[1] === want)) page = want; }     // e.g. opened from the update notification
  const nav = h("nav.nav"); const body = h("div.body", { style: "max-width:680px;width:100%" });
  const searchBox = h("input.sidebar-search", { type: "search", placeholder: "Search", oninput: e => { query = e.target.value.trim().toLowerCase(); drawNav(); } });
  root.append(h("div.app.settings-app", h("aside.side", h("div.side-title", "Settings"), searchBox, nav), h("div.main", { style: "overflow:auto" }, h("div", { style: "padding:22px;display:flex;justify-content:center" }, body))));

  const section = (title, ...kids) => h("div", { style: "margin-bottom:26px" }, h("span.label", { style: "display:block;margin:0 4px 10px" }, title), ...kids);
  const rowOf = (label, sub, control) => h("div.row", { style: "cursor:default;min-height:56px" }, h("div.grow", h("div.t", label), sub ? h("div.s", sub) : null), control);
  const flag = (key) => { const s = h("button.switch" + (acc[key] ? ".on" : ""), { onclick: () => { acc[key] = !acc[key]; s.classList.toggle("on", acc[key]); wos.call("prefs.set", { key, value: acc[key] }); applyPrefs(acc); } }); return s; };

  const drawNav = () => {
    nav.innerHTML = "";
    const shown = PAGES.filter(([g, k, l, i, c, w]) => !query || (l + " " + w).toLowerCase().includes(query));
    let lastGroup = null;
    shown.forEach(([g, k, l, i, c]) => {
      if (g !== lastGroup) { nav.append(h("span.nav-group", g)); lastGroup = g; }
      nav.append(h("button" + (page === k ? ".on" : ""), { onclick: () => { page = k; draw(); } },
        h("span.tile-ico", { style: "background:" + c, html: icon(i, 15) }), l));
    });
    if (!shown.length) nav.append(h("div.muted.small", { style: "padding:10px 12px" }, "Nothing matches"));
  };
  const draw = async () => {
    drawNav();
    body.innerHTML = ""; body.append(h("h1.dots", { style: "font-size:36px;margin:0 0 20px" }, PAGES.find(p => p[1] === page)[2]));
    body.classList.remove("page-in"); void body.offsetWidth; body.classList.add("page-in");
    await views[page]();
  };
  const seg = (options, current, onpick) => {
    const box = h("div.seg");
    options.forEach(([v, label]) => box.append(h("button" + (current === v ? ".on" : ""), { onclick: () => { [...box.children].forEach(x => x.classList.remove("on")); box.children[options.findIndex(o => o[0] === v)].classList.add("on"); onpick(v); } }, label)));
    return box;
  };
  const switchOf = (on, onchange) => { const sw = h("button.switch" + (on ? ".on" : ""), { onclick: () => { const now = !sw.classList.contains("on"); sw.classList.toggle("on", now); onchange(now); } }); return sw; };
  const fmtBytes = n => n >= 1e9 ? (n / 1e9).toFixed(1) + " GB" : n >= 1e6 ? Math.round(n / 1e6) + " MB" : n >= 1e3 ? Math.round(n / 1e3) + " KB" : n + " bytes";

  const views = {
    async appearance() {
      const card = (mode, label, ic) => h("button.tile" + (theme === mode ? ".on" : ""), { style: "padding:16px", onclick: async () => { theme = mode; await wos.call("theme.set", { mode }); if (mode !== "auto") applyTheme(mode); else applyTheme(new Date().getHours() >= 19 || new Date().getHours() < 7 ? "dark" : "light"); draw(); } },
        h("div", { style: "height:64px;border-radius:12px;margin-bottom:10px;display:grid;place-items:center;" + (mode === "dark" ? "background:#0a0a0b;color:#f4f4f6" : mode === "light" ? "background:#f3f3f4;color:#0c0c0e" : "background:linear-gradient(90deg,#f3f3f4 50%,#0a0a0b 50%);color:#0a84ff"), html: icon(ic, 26) }),
        h("div", { style: "font-weight:800" }, label));
      body.append(section("Theme", h("div.grid", { style: "grid-template-columns:repeat(3,1fr)" }, card("light", "Light", "sun"), card("dark", "Dark", "moon"), card("auto", "Automatic", "refresh"))),
        h("p.muted.small", { style: "margin:-12px 4px 26px" }, "Automatic uses dark from 7 pm to 7 am."));
      const ACCENTS = [["blue", "#0a84ff", "Blue"], ["purple", "#a25be0", "Purple"], ["pink", "#f0559a", "Pink"], ["red", "#f5453a", "Red"], ["orange", "#f7821b", "Orange"], ["yellow", "#f5b800", "Yellow"], ["green", "#30b34f", "Green"], ["graphite", "#7d7d86", "Graphite"]];
      const swatches = h("div", { style: "display:flex;gap:12px;flex-wrap:wrap;padding:16px 18px" });
      const drawSwatches = () => { swatches.innerHTML = ""; ACCENTS.forEach(([k, c, n]) => swatches.append(h("button.swatch" + ((acc.accent || "blue") === k ? ".on" : ""), { title: n, style: "background:" + c,
        onclick: async () => { acc.accent = k; await wos.call("prefs.set", { key: "accent", value: k }); applyPrefs(acc); drawSwatches(); } }, (acc.accent || "blue") === k ? h("span", { html: icon("check", 15) }) : null))); };
      drawSwatches();
      body.append(section("Accent colour", h("div.card", swatches)), h("p.muted.small", { style: "margin:-12px 4px 0" }, "Used for buttons, selections and highlights in W-OS apps."));
    },
    async network() {
      const list = h("div.list", h("div.row.muted", { style: "cursor:default" }, "Looking for networks…")); const card = h("div.card", list);
      body.append(section("Wi-Fi", card), h("button.btn.ghost.small", { onclick: draw }, h("span", { html: icon("refresh", 14) }), "Scan again"));
      let nets = []; try { nets = await wos.call("sys.wifi.list"); } catch (e) { nets = []; }
      list.innerHTML = "";
      if (!nets.length) list.append(h("div.row.muted", { style: "cursor:default" }, "No Wi-Fi networks found. If this computer uses a cable, you are connected that way."));
      nets.forEach(n => list.append(h("button.row", { onclick: () => connect(n) }, h("span", { html: icon("wifi", 18) }), h("div.grow", h("div.t", n.ssid), h("div.s", n.active ? "Connected" : n.secure ? "Secured" : "Open")),
        n.active ? h("span", { html: '<i class="dot"></i>' }) : n.secure ? h("span", { html: icon("lock", 15), style: "color:var(--muted)" }) : null)));

      let net; try { net = await wos.call("sys.net.get"); } catch (e) { net = { connected: false }; }
      if (!net.connected) return;
      const address = h("input.field", { style: "width:220px", placeholder: "192.168.1.50", value: net.address || "" });
      const prefix = h("input.field", { style: "width:80px", placeholder: "24", value: net.prefix || "24" });
      const gateway = h("input.field", { style: "width:220px", placeholder: "192.168.1.1", value: net.gateway || "" });
      const dns = h("input.field", { style: "width:220px", placeholder: "1.1.1.1, 8.8.8.8", value: net.dns || "" });
      const mtu = h("input.field", { style: "width:120px", placeholder: "Automatic", value: net.mtu || "" });
      const manualRows = h("div", rowOf("IP address", "", address), rowOf("Subnet prefix", "e.g. 24 for 255.255.255.0", prefix), rowOf("Router (gateway)", "", gateway), rowOf("DNS servers", "Comma-separated", dns));
      const syncManual = () => { manualRows.style.display = method.value === "manual" ? "" : "none"; };
      const method = dropdown([["auto", "Automatic (DHCP)"], ["manual", "Manual"]], { value: net.method === "manual" ? "manual" : "auto", width: 160, onChange: syncManual });
      syncManual();
      const advSave = h("button.btn.small", {
        onclick: async () => {
          try {
            await wos.call("sys.net.set", { method: method.value, address: address.value.trim(), prefix: prefix.value.trim(), gateway: gateway.value.trim(), dns: dns.value.trim(), mtu: mtu.value.trim() });
            toast("Saved"); draw();
          } catch (e) { toast(e.message); }
        }
      }, "Apply");
      body.append(section("Advanced (" + net.name + ")", h("div.card",
        rowOf("Configure IPv4", "How this connection gets its address", method), manualRows,
        rowOf("MTU", "Maximum packet size. Leave blank for automatic", mtu)),
        h("div", { style: "margin-top:10px" }, advSave)));
    },
    async sound() {
      const v = await wos.call("sys.volume.get"); const out = h("span.mono", { style: "width:46px;text-align:right" }, v + "%");
      const range = h("input", { type: "range", min: 0, max: 100, value: v, style: "flex:1;accent-color:var(--ink)", oninput: e => { out.textContent = e.target.value + "%"; wos.call("sys.volume.set", { value: +e.target.value }); } });
      let outs = []; try { outs = await wos.call("sound.outputs"); } catch (e) { outs = []; }
      const defOut = outs.find(o => o.default);
      const outSel = dropdown(outs.map(o => [o.name, o.label || o.name]), { value: defOut && defOut.name, width: 220, onChange: name => wos.call("sound.output.set", { name }) });
      if (outs.length > 1) body.append(section("Play sound through", h("div.card", rowOf("Output", "", outSel))));
      body.append(section("Output", h("div.card", rowOf("Volume", "", h("div", { style: "display:flex;align-items:center;gap:12px;width:280px" }, h("span", { html: icon("sound", 18) }), range, out)))));
    },
    async account() {
      const a = await wos.call("account.get"); const isW = a.type === "waccount";
      const email = h("input.field", { placeholder: "Email", type: "email", style: "width:260px" }), pass = h("input.field", { placeholder: "Password", type: "password", style: "width:260px" });
      const inForm = h("div", { style: "display:flex;flex-direction:column;gap:8px;padding:14px" }, email, pass,
        h("div", h("button.btn.small", { onclick: async () => { try { toast("Signing in…"); await wos.call("account.signin", { email: email.value, password: pass.value }); toast("Signed in"); draw(); } catch (e) { toast(e.message); } } }, "Sign in")));
      body.append(section("You", h("div.card.pad", { style: "display:flex;align-items:center;gap:16px" }, h("div.avatar", { style: "width:56px;height:56px;font-size:20px" }, initials(a.name)),
        h("div", { style: "flex:1" }, h("div", { style: "font-weight:800;font-size:17px" }, a.name), h("div.small.muted", isW ? a.email : "Local account · stays on this device")), h("span.chip", isW ? "W-Account" : "Local"))),
        section("W-Account", h("div.card", isW ? rowOf("Signed in", "W-Mail and other W-Account features are available.", h("button.btn.ghost.small", { onclick: async () => { if (!await confirmBox("Sign out of W-Account?", "W-Mail will stop working until you sign in again.", "Sign out")) return; await wos.call("account.signout"); draw(); } }, "Sign out"))
          : h("div", h("div.row", { style: "cursor:default" }, h("div.grow", h("div.t", "Use a W-Account"), h("div.s", "One account for W-Mail and other W-OS services."))), inForm))));
    },
    async language() {
      body.append(section("Language", h("div.card", rowOf("Display language", "The language W-OS uses", h("span.chip", info.lang.replace("_", "-"))))),
        h("p.muted.small", "To change language or region, contact support: support@willgraves.co.uk. More languages are on the way."));
    },
    async bluetooth() {
      const st = await wos.call("bt.status");
      if (!st.available) { body.append(h("div.card.pad.muted", "No Bluetooth adapter was found on this computer.")); return; }
      const sw = h("button.switch" + (st.on ? ".on" : ""), { onclick: async () => { const on = !sw.classList.contains("on"); sw.classList.toggle("on", on); await wos.call("bt.power", { on }); draw(); } });
      const list = h("div.list", h("div.row.muted", { style: "cursor:default" }, st.on ? "Looking for devices…" : "Bluetooth is off"));
      body.append(section("Bluetooth", h("div.card", rowOf("Bluetooth", "Connect headphones, keyboards and more", sw))), section("Devices", h("div.card", list)),
        st.on ? h("button.btn.ghost.small", { onclick: draw }, h("span", { html: icon("refresh", 14) }), "Search again") : null);
      if (!st.on) return;
      const devs = await wos.call("bt.devices", { scan: true }); list.innerHTML = "";
      if (!devs.length) list.append(h("div.row.muted", { style: "cursor:default" }, "No devices found. Put your device in pairing mode."));
      devs.forEach(d => {
        const action = d.connected ? "disconnect" : d.paired ? "connect" : "pair";
        const label = d.connected ? "Disconnect" : d.paired ? "Connect" : "Pair";
        // Pairing especially can take up to 40 real seconds on the backend (Simple Secure
        // Pairing's own handshake) -- with no immediate feedback the button just sat there
        // looking unclicked for that whole time, which is exactly what looked like "nothing
        // happens". Show it's actually working straight away, not just once it resolves.
        const actionBtn = h("button.btn.ghost.small", { onclick: async () => {
          actionBtn.disabled = true;
          actionBtn.textContent = action === "pair" ? "Pairing…" : action === "connect" ? "Connecting…" : "Disconnecting…";
          try {
            const r = await wos.call("bt.action", { mac: d.mac, action });
            toast(r.ok ? "Done" : (r.message || "Could not do that"));
          } catch (e) { toast(e.message); }
          draw();
        } }, label);
        list.append(h("div.row", { style: "cursor:default" }, h("div.grow", h("div.t", d.name), h("div.s", d.connected ? "Connected" : d.paired ? "Paired" : "Not paired")),
          actionBtn,
          d.paired ? h("button.icon-btn", { title: "Forget", html: icon("trash"), onclick: async () => { await wos.call("bt.action", { mac: d.mac, action: "remove" }); draw(); } }) : null));
      });
    },
    async displays() {
      const list = await wos.call("displays.list");
      let night = { on: false, strength: 50 }; try { night = await wos.call("displays.nightlight.get"); } catch (e) { /* older image */ }
      const strengthOut = h("span.mono", { style: "width:40px;text-align:right" }, night.strength + "%");
      const strengthRange = h("input", { type: "range", min: 0, max: 100, value: night.strength, style: "flex:1;accent-color:var(--ink)",
        oninput: e => { strengthOut.textContent = e.target.value + "%"; }, onchange: e => wos.call("displays.nightlight.set", { strength: +e.target.value }).catch(er => toast(er.message)) });
      const nightSwitch = switchOf(night.on === true, async v => { try { await wos.call("displays.nightlight.set", { on: v }); } catch (e) { toast(e.message); } });
      body.append(section("Night Light", h("div.card",
          rowOf("Night Light", "Warms the screen so it's easier on the eyes", nightSwitch),
          rowOf("Strength", "", h("div", { style: "display:flex;align-items:center;gap:10px" }, strengthRange, strengthOut)))));
      if (!list.length) { body.append(h("div.card.pad.muted", "No displays were found.")); return; }
      list.forEach(d => {
        const modes = dropdown(d.modes.map(m => [m, m]), { value: d.current, width: 180 });
        const scale = dropdown([1, 1.25, 1.5, 2].map(x => [x, Math.round(x * 100) + "%"]), { value: 1, width: 120 });
        const apply = h("button.btn.small", { onclick: async () => { try { await wos.call("displays.set", { name: d.name, mode: modes.value, scale: +scale.value }); toast("Applied"); } catch (e) { toast(e.message); } } }, "Apply");
        body.append(section(d.name + (d.primary ? " (main)" : ""), h("div.card", rowOf("Resolution", "", modes), rowOf("Scale", "Make everything bigger or smaller", scale)), h("div", { style: "margin-top:10px" }, apply)));
      });
    },
    async power() {
      const p = await wos.call("power.get"); const bat = await wos.call("power.battery");
      const mk = (cur, choices) => dropdown(choices, { value: cur, width: 160, onChange: save });
      const lock = mk(p.lock_min, [[0, "Never"], [2, "2 minutes"], [5, "5 minutes"], [10, "10 minutes"], [30, "30 minutes"]]);
      const off = mk(p.off_min, [[0, "Never"], [5, "5 minutes"], [10, "10 minutes"], [15, "15 minutes"], [30, "30 minutes"], [60, "1 hour"]]);
      async function save() { await wos.call("power.set", { lock_min: +lock.value, off_min: +off.value }); toast("Saved"); }
      const lowPower = switchOf(p.low_power === true, async v => { if (v) toast("Turning on…"); try { await wos.call("power.set", { low_power: v }); toast(v ? "Low Power Mode on" : "Low Power Mode off"); } catch (e) { toast(e.message); } });
      body.append(bat ? section("Battery", h("div.card.pad", { style: "display:flex;gap:14px;align-items:center" }, h("div", { style: "font-size:28px;font-weight:800" }, bat.pct + "%"), h("div.muted", bat.status))) : null,
        section("Low Power Mode", h("div.card", rowOf("Low Power Mode", "Trims background activity to stretch the battery further", lowPower))),
        section("Screen", h("div.card", rowOf("Lock the screen after", "When nothing is touched", lock), rowOf("Turn the screen off after", "Saves power", off))),
        h("p.muted.small", "Closing the lid locks the computer and puts it to sleep."));
    },
    async keyboard() {
      const v = await wos.call("input.get");
      const sw = key => { const b = h("button.switch" + (v[key] ? ".on" : ""), { onclick: async () => { v[key] = !v[key]; b.classList.toggle("on", v[key]); await wos.call("input.set", { tap: v.tap, natural: v.natural }); } }); return b; };
      const layout = dropdown([["gb", "English (UK)"], ["us", "English (US)"], ["es", "Spanish"], ["fr", "French"], ["de", "German"]],
        { value: v.layout, width: 160, onChange: async c => { await wos.call("input.layout.set", { layout: c }); toast("Layout changed"); } });
      const shortcuts = [
        ["Super + Space", "Open Apps (the launcher and search)"],
        ["Super + Left / Right", "Snap the window to a half of the screen"],
        ["Super + Up / Down", "Maximise / restore the window"],
        ["Super + V", "Clipboard history"],
        ["Ctrl + Alt + L", "Lock the screen"],
        ["Alt + Tab", "Switch between open windows"],
        ["Alt + F4", "Close the window"],
        ["Alt + F9 / F10", "Hide / maximise the window"],
        ["Print", "Screenshot the whole screen"],
        ["Super + Shift + S", "Screenshot an area"],
      ];
      body.append(section("Keyboard", h("div.card", rowOf("Layout", "The letters on your keys", layout))),
        section("Trackpad", h("div.card", rowOf("Tap to click", "Tap the pad instead of pressing", sw("tap")), rowOf("Natural scrolling", "Content follows your fingers", sw("natural")))),
        section("Keyboard shortcuts", h("div.card", shortcuts.map(([keys, what]) =>
          h("div.row", { style: "cursor:default;min-height:44px" }, h("div.grow", what), h("kbd.shortcut", keys))))));
    },
    async printers() {
      const r = await wos.call("printers.list");
      body.append(section("Printers", h("div.card", h("div.list", r.printers.length ? r.printers.map(p => h("div.row", { style: "cursor:default" }, h("div.grow", h("div.t", p.name), h("div.s", p.state)), p.name === r.default ? h("span.chip", "Default") : null))
        : h("div.row.muted", { style: "cursor:default" }, "No printers yet.")))),
        h("p.muted.small", "Printers on your network appear here by themselves. Every app can also Save as PDF."));
    },
    async users() {
      const list = await wos.call("users.list");
      const ask = async why => askPassword(why, "Your password");
      const rows = list.map(u => h("div.row", { style: "cursor:default" }, h("div.avatar", initials(u.full)), h("div.grow", h("div.t", u.full + (u.me ? " (you)" : "")), h("div.s", (u.admin ? "Administrator" : "Standard") + " · " + u.name)),
        h("button.btn.ghost.small", { onclick: async () => { const me = await ask("Enter your password"); if (me === null) return; const pw = await askPassword("New password for " + u.name, "At least 8 characters"); if (!pw) return;
          try { await wos.call("users.passwd", { username: u.name, password: pw, me_password: me }); toast("Password changed"); } catch (e) { toast(e.message); } } }, "Change password"),
        u.me ? null : h("button.icon-btn", { title: "Remove", html: icon("trash"), onclick: async () => { if (!await confirmBox("Remove " + u.full + "?", "Their account and files will be deleted.", "Remove", true)) return; const me = await ask("Enter your password"); if (me === null) return;
          try { await wos.call("users.del", { username: u.name, me_password: me }); draw(); } catch (e) { toast(e.message); } } })));
      body.append(section("People who use this computer", h("div.card", h("div.list", rows))),
        h("button.btn", { onclick: async () => { const name = await prompt2("Full name"); if (!name) return; const uname = await prompt2("User name", name.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20), "letters and numbers"); if (!uname) return;
          const pw = await askPassword("Password for " + name, "At least 8 characters"); if (!pw) return; const me = await askPassword("Enter your password to confirm", "Your password"); if (me === null) return;
          try { await wos.call("users.add", { username: uname, name, password: pw, admin: false, me_password: me }); toast("Account created"); draw(); } catch (e) { toast(e.message); } } }, h("span", { html: icon("plus", 14) }), "Add a person"));
      let items = []; try { items = await wos.call("login_items.list"); } catch (e) { items = []; }
      const itemSwitch = it => switchOf(it.enabled, async v => { try { await wos.call("login_items.set", { id: it.id, enabled: v }); } catch (e) { toast(e.message); } } );
      body.append(section("Open at Login", h("div.card", items.length ? items.map(it => rowOf(it.name, "", itemSwitch(it)))
        : h("div.row.muted", { style: "cursor:default" }, "Nothing starts automatically for you yet."))));
    },
    async datetime() {
      const cur = await wos.call("sys.tz.get"); const zones = await wos.call("sys.tz.list");
      const sel = dropdown(zones.map(z => [z, z.replace(/_/g, " ")]), { value: cur.zone, width: 260,
        onChange: async z => { try { await wos.call("sys.tz.set", { zone: z }); toast("Time zone changed"); } catch (er) { toast(er.message); } } });
      body.append(section("Time", h("div.card", rowOf("Time zone", cur.synced ? "Clock is set from the internet" : "Waiting for the internet to set the clock", sel))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "Renaming this computer is in Settings → About."));
    },
    async access() {
      const d = await wos.call("desktop.get");
      const viz = switchOf(d.music_viz === true, async v => { try { await wos.call("desktop.set", { key: "music_viz", value: v }); } catch (e) { toast(e.message); } });
      body.append(section("Vision", h("div.card", rowOf("Bigger text", "Make text easier to read", flag("zoom")), rowOf("Higher contrast", "Stronger borders and text", flag("contrast")))),
        section("Motion and speech", h("div.card", rowOf("Reduce motion", "Fewer animations", flag("motion")), rowOf("Read aloud", "Speak text on screen", flag("speak")))),
        section("Music", h("div.card", rowOf("Music visualisation", "A glowing wave across the bottom of the screen that moves with whatever is playing", viz))),
        h("p.muted.small", "These apply to every W-OS app straight away. The desktop bar and dock will follow."));
    },
    async updates() {
      let st; try { st = await wos.call("updates.status"); } catch (e) { st = { version: info.version, history: [] }; }
      const box = h("div.card.pad", { style: "display:flex;align-items:center;gap:14px" });
      const list = h("div", { style: "margin-top:14px" });
      let checking = false;
      const paint = (found, note) => {
        box.innerHTML = "";
        const ok = !found || !found.length;
        box.append(h("span", { html: icon(checking ? "refresh" : ok ? "check" : "download", 26), style: "color:" + (checking ? "var(--muted)" : ok ? "var(--ok)" : "var(--accent)") }),
          h("div", { style: "flex:1" }, h("div", { style: "font-weight:800" }, checking ? "Checking for updates…" : ok ? "W-OS is up to date" : found.length + " update" + (found.length === 1 ? "" : "s") + " available"), h("div.small.muted", "Version " + (st.version || info.version) + (note ? " · " + note : ""))),
          h("button.btn.ghost.small", { onclick: () => check() }, "Check now"));
        list.innerHTML = "";
        (found || []).forEach(u => list.append(h("div.card", { style: "margin-bottom:10px" }, rowOf(u.id + " " + u.version, (u.kind === "security" ? "Security update" : "Update") + (u.notes ? " · " + u.notes : ""),
          u.action === "blocked" ? h("span.chip", "Needs activation") : h("button.btn.small", { onclick: () => install(u) }, "Install")))));
      };
      async function check(quiet) {
        checking = true; paint([], ""); if (quiet !== true) toast("Checking…");
        try { const r = await wos.call("updates.check"); checking = false; paint(r.available, r.note); }
        catch (e) { checking = false; paint([], "Could not check: " + e.message); }
      }
      async function install(u) {
        toast("Installing…");
        try { const r = await wos.call("updates.apply", { id: u.id }); st.probation = true; st.version = r.version; paint([], ""); if (r.restart_needed && await confirmBox("Restart to finish?", "The update is installed. Restart now, or later when it suits you.", "Restart now")) wos.call("sys.restart"); }
        catch (e) { toast(e.message); }
      }
      paint([], st.configured === false ? "No update service is configured yet" : "");
      if (st.configured !== false) check(true);            // look straight away: opening this page should not say "up to date" without asking
      const hist = (st.history || []).slice(0, 10);
      const notice = st.probation ? h("div.card", { style: "margin-bottom:12px" }, rowOf("Restart to finish the last update", "W-OS confirms an update after one restart. Then the next one can be installed.",
        h("button.btn.small", { onclick: async () => { if (await confirmBox("Restart now?", "Save your work first. W-OS restarts and finishes the update.", "Restart")) wos.call("sys.restart").catch(e => toast(e.message)); } }, "Restart"))) : null;
      const beta = st.beta_available ? switchOf(st.beta === true, async v => {
        if (v && !await confirmBox("Turn on Beta updates?", "Beta updates try new things before they reach everyone else. They can be rougher around the edges and are not meant for a computer you depend on.", "Turn on")) { draw(); return; }
        try { await wos.call("updates.set_beta", { on: v }); st.beta = v; toast(v ? "Beta updates on" : "Beta updates off"); check(true); } catch (e) { toast(e.message); draw(); }
      }) : null;
      body.append(section("W-OS", notice, box, list),
        beta ? section("Beta updates", h("div.card", rowOf("Beta updates", "Try new things early, on a separate track from the update everyone else gets", beta))) : null,
        // Developer/Satisfaction don't belong mixed into the everyday app grid alongside Mail
        // and Photos -- one clear entry point here instead, and only once Beta is actually on.
        st.beta === true ? section("Beta features", h("div.card",
          rowOf("Developer", "Write, run and install apps in Satisfaction, W-OS's own trial language", h("button.btn.ghost.small", { onclick: () => wos.call("sys.launch", { id: "wos-developer.desktop" }).catch(e => toast(e.message)) }, "Open")),
          rowOf("Satisfaction Counter", "A small demo app written in Satisfaction", h("button.btn.ghost.small", { onclick: () => wos.call("sys.launch", { id: "wos-satisfaction-demo.desktop" }).catch(e => toast(e.message)) }, "Open")))) : null,
        section("Recent updates", h("div.card", hist.length ? hist.map((x, i) => rowOf(x.id + " " + x.version, new Date(x.time * 1000).toLocaleString("en-GB") + " · " + x.result + (x.kind === "security" ? " · security" : ""),
          i === 0 && x.rollback_available ? h("button.btn.ghost.small", { onclick: async () => { if (!await confirmBox("Roll back this update?", "The previous version comes back after a restart.", "Roll back")) return; try { await wos.call("updates.rollback"); toast("Rolled back. Restart to finish."); draw(); } catch (e) { toast(e.message); } } }, "Roll back") : null))
          : h("div.row.muted", { style: "cursor:default" }, "Nothing installed yet"))),
        h("p.muted.small", "Security fixes for the system install by themselves. Other updates wait for you. Security updates cannot be rolled back."));
    },
    async desktop() {
      const d = await wos.call("desktop.get");
      const save = (k, v) => { d[k] = v; wos.call("desktop.set", { key: k, value: v }).catch(e => toast(e.message)); };
      let walls = []; try { walls = await wos.call("desktop.wallpapers"); } catch (e) { walls = []; }
      // Grouped by category, the way both macOS's and Windows' own wallpaper pickers show them --
      // not one flat grid. "Your Photos" (from the Pictures folder) always sorts last, since it's
      // personal content rather than part of the collection.
      const wallSections = h("div");
      const drawWalls = () => {
        wallSections.innerHTML = "";
        const order = [], byCat = new Map();
        walls.forEach(w => { const c = w.category || "Wallpapers"; if (!byCat.has(c)) { byCat.set(c, []); order.push(c); } byCat.get(c).push(w); });
        order.sort((a, b) => (a === "Your Photos" ? 1 : 0) - (b === "Your Photos" ? 1 : 0));
        order.forEach(cat => {
          const grid = h("div", { style: "display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:12px;padding:16px" });
          byCat.get(cat).forEach(w => grid.append(h("button.wall" + (d.wallpaper === w.id ? ".on" : ""), { title: w.name, onclick: () => { save("wallpaper", w.id); drawWalls(); } },
            h("div.wall-img", { style: `background-image:url("${w.uri}")` }), h("div.wall-name", w.name))));
          wallSections.append(section(cat, h("div.card", grid)));
        });
      };
      drawWalls();
      const cornerChoices = [["none", "—"], ["desktop", "Show Desktop"], ["lock", "Lock Screen"], ["launcher", "Open Apps"]];
      const cornerSel = key => dropdown(cornerChoices, { value: d[key] || "none", width: 160, onChange: v => save(key, v) });
      body.append(wallSections,
        section("Dock", h("div.card",
          rowOf("Size", "How big the icons in the dock are", seg([["small", "Small"], ["medium", "Medium"], ["large", "Large"]], d.dock, v => save("dock", v))),
          rowOf("Auto-hide in full screen", "Hide the menu bar and dock while an app is full screen", switchOf(d.autohide_fullscreen === true, v => save("autohide_fullscreen", v))))),
        section("Hot corners", h("div.card",
          rowOf("Top-left", "Drag the pointer into this corner of the screen", cornerSel("corner_tl")),
          rowOf("Top-right", "Drag the pointer into this corner of the screen", cornerSel("corner_tr")),
          rowOf("Bottom-left", "Drag the pointer into this corner of the screen", cornerSel("corner_bl")),
          rowOf("Bottom-right", "Drag the pointer into this corner of the screen", cornerSel("corner_br")))),
        section("Desktop", h("div.card",
          rowOf("Show files on the desktop", "Anything in your Desktop folder", switchOf(d.desk_icons !== false, v => save("desk_icons", v))),
          rowOf("Show the Bin on the desktop", "", switchOf(d.desk_bin !== false, v => save("desk_bin", v))),
          rowOf("Show widgets", "Clock, calendar, notes and more. Right-click the desktop to add or change them", switchOf(d.desk_widgets !== false, v => save("desk_widgets", v))))),
        section("Menu bar", h("div.card",
          rowOf("24-hour clock", "", switchOf(d.clock24, v => save("clock24", v))),
          rowOf("Show seconds", "", switchOf(d.seconds, v => save("seconds", v))),
          rowOf("Show the date", "", switchOf(d.date, v => save("date", v))),
          rowOf("Show battery percentage", "On laptops", switchOf(d.battery, v => save("battery", v))))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "Put your own pictures in the Pictures folder and they appear under Wallpaper."));
    },
    async notifications() {
      let dnd = false; try { dnd = await wos.call("dnd.get"); } catch (e) { /* not available */ }
      body.append(section("Focus", h("div.card", rowOf("Do Not Disturb", "Hide notification banners until you turn this off", switchOf(dnd, v => wos.call("dnd.set", { value: v }).catch(e => toast(e.message)))))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "W-OS apps only notify you about things you started, such as a finished download."));
    },
    async privacy() {
      let p = { share: false }; try { p = await wos.call("privacy.get"); } catch (e) { /* default */ }
      let fw = false; try { fw = await wos.call("firewall.status"); } catch (e) { /* unknown */ }
      body.append(section("Data", h("div.card",
          rowOf("Share crash and usage information", "Helps us fix problems. Nothing personal, no files, no browsing.", switchOf(!!p.share, v => wos.call("privacy.set", { value: v }).catch(e => toast(e.message)))),
          rowOf("Feedback you write", "Only sent when you press Send in the feedback app.", h("span.chip", "Always your choice")))),
        section("Security", h("div.card",
          rowOf("Firewall", "Blocks connections you did not ask for", h("span.chip", fw ? "On" : "Off")),
          rowOf("Screen lock", "Your password is needed to unlock. Set when it locks in Power.", h("button.btn.ghost.small", { onclick: () => { page = "power"; draw(); } }, "Open Power")),
          rowOf("App access", "W-OS apps can only reach your own folders, nothing else on the computer.", h("span.chip", "Home folder only")),
          rowOf("Location", "No app uses your location.", h("span.chip", "Not used")))));
    },
    async storage() {
      const u = await wos.call("storage.usage");
      const colours = ["#0a84ff", "#30b04f", "#ff9f0a", "#bf5af2", "#ff375f", "#5ac8fa", "#8e8e93"];
      const used = u.total - u.free; const parts = u.items.filter(i => i.bytes > 0);
      const other = Math.max(0, used - parts.reduce((t, i) => t + i.bytes, 0));
      const all = parts.concat(other > 0 ? [{ name: "System and apps", bytes: other }] : []);
      const bar = h("div.bar-stack", all.map((i, n) => h("div", { title: i.name, style: `width:${Math.max(0.5, i.bytes / u.total * 100)}%;background:${colours[n % colours.length]}` })));
      body.append(section("This computer", h("div.card.pad", h("div", { style: "display:flex;justify-content:space-between;margin-bottom:10px" }, h("span", { style: "font-weight:800" }, fmtBytes(used) + " used"), h("span.muted", fmtBytes(u.free) + " free of " + fmtBytes(u.total))), bar)),
        section("What is using it", h("div.card", all.map((i, n) => h("div.row", { style: "cursor:default;min-height:46px" }, h("span", { style: `width:12px;height:12px;border-radius:4px;background:${colours[n % colours.length]};flex:none` }), h("div.grow", h("div.t", i.name)), h("span.muted", fmtBytes(i.bytes)))))),
        u.bin > 0 ? section("Bin", h("div.card", rowOf("Empty the Bin", fmtBytes(u.bin) + " you deleted from Files", h("button.btn.ghost.small", { onclick: async () => { if (await confirmBox("Empty the Bin?", "Everything in it is removed for good.", "Empty Bin", true)) { await wos.call("files.bin.empty"); toast("Bin emptied"); draw(); } } }, "Empty Bin")))) : null);
    },
    async defaults() {
      const d = await wos.call("defaults.get");
      const sel = dropdown(d.options.map(o => [o.id, o.name]), { value: d.browser, width: 240,
        onChange: id => wos.call("defaults.set", { browser: id }).then(() => toast("Default browser changed")).catch(x => toast(x.message)) });
      body.append(section("Web", h("div.card", rowOf("Web browser", "Opens links from mail and other apps", sel))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "Install more browsers from the App Store and they appear here."));
    },
    async about() {
      const i = await wos.call("sys.info");
      const r = (a, b) => h("div.row", { style: "cursor:default" }, h("span.muted", { style: "width:140px" }, a), h("span", { style: "user-select:text;font-weight:700" }, String(b)));
      body.append(section("This device", h("div.card", r("Name", i.hostname), r("Model", i.device), r("Processor", i.cpu || "—"), r("Memory", i.memory_gb + " GB"), r("Storage", `${i.storage_gb} GB (${i.free_gb} GB free)`), r("Device ID", i.device_id))),
        section("Software", h("div.card", r("System", i.os), r("Release", `${i.nickname} · ${i.version}`), r("Version", i.build))),
        section("Computer name", h("div.card", h("div.row", { style: "cursor:default;min-height:56px" }, h("div.grow", h("div.t", "Name"), h("div.s", "Shown on your network and in Phone Sync")),
          (() => { const inp = h("input.field", { value: i.hostname, style: "width:190px" }); return h("div", { style: "display:flex;gap:8px;align-items:center" }, inp,
            h("button.btn.ghost.small", { onclick: async () => { try { await wos.call("sys.hostname.set", { name: inp.value.trim().toLowerCase() }); toast("Renamed. Applies after you restart."); } catch (e) { toast(e.message); } } }, "Rename")); })()))),
        h("div", { style: "margin-top:6px" }, h("button.btn.ghost.small", { onclick: showNotices }, "Open source notices")),
        h("p.muted.small", { style: "margin-top:14px" }, "William Graves Corp. Ltd. (c) 2020-2026 William Graves Operating Services"));
    },
  };

  async function showNotices() {
    const n = await wos.call("sys.notices");
    const rows = n.packages.slice(0, 1500).map(p => h("div.row", { style: "cursor:default;min-height:36px" }, h("div.grow", h("div.t", p.name), h("div.s", p.licence || "")), h("span.small.muted", p.version)));
    const close = () => back.remove();
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) close(); } }, h("div.modal", { style: "width:min(680px,94vw);max-height:84vh;display:flex;flex-direction:column" },
      h("h2", "Open source notices"), h("p.muted.small", { style: "white-space:pre-wrap;user-select:text" }, n.offer),
      h("div.card", { style: "overflow:auto;flex:1;margin-top:10px" }, h("div.list", rows)), h("div.actions", h("button.btn", { onclick: close }, "Close"))));
    document.body.append(back);
  }

  async function connect(n) {
    if (n.active) return;
    let password = "";
    if (n.secure) { password = await askPassword(`Password for ${n.ssid}`, "Wi-Fi password"); if (password === null) return; }
    toast("Connecting…"); const r = await wos.call("sys.wifi.connect", { ssid: n.ssid, password });
    toast(r.ok ? "Connected" : "Could not connect"); draw();
  }
  wos.on("theme", m => { theme = theme; });
  draw();
});
