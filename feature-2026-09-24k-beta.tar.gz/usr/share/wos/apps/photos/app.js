"use strict";
/* Photos: every picture in your home folder, newest first, grouped by month. Click for the viewer. */

boot(async () => {
  const root = $("#root");
  let photos = [], faves = new Set(await wos.data.get("faves", [])), only = false, at = -1, zoom = 1;
  const saveFaves = () => wos.data.set("faves", [...faves]);

  const seg = h("div.seg", h("button.on", { onclick: e => { only = false; tog(e); } }, "All"), h("button", { onclick: e => { only = true; tog(e); } }, "Favourites"));
  const count = h("span.small.muted");
  const bar = h("div.bar", h("h1", "Photos"), count, h("div.grow"), seg, h("button.btn.small.ghost", { onclick: load }, h("span", { html: icon("refresh", 14) }), "Refresh"));
  const body = h("div.body");
  root.append(h("div.app.no-side", h("div.main", bar, body)));
  function tog(e) { $$("button", seg).forEach(b => b.classList.remove("on")); e.target.classList.add("on"); draw(); }

  async function load() { body.innerHTML = ""; body.append(h("div.empty", "Looking for your pictures…")); try { photos = await wos.call("photos.list"); } catch (e) { toast(e.message); photos = []; } draw(); }
  const visible = () => photos.filter(p => !only || faves.has(p.path));

  function draw() {
    const list = visible(); count.textContent = `${list.length} picture${list.length === 1 ? "" : "s"}`; body.innerHTML = "";
    if (!list.length) {
      body.append(h("div.empty", h("div", h("div", { html: icon(only ? "star" : "image", 44), style: "color:var(--muted);margin-bottom:10px" }), h("p", only ? "Star a picture in the viewer and it shows up here." : "No pictures yet. Put images in your Pictures folder, or save some from the web."),
        h("button.btn", { onclick: () => wos.call("sys.launch", { id: "wos-files.desktop" }) }, "Open Files"))));
      return;
    }
    let month = ""; let grid = null;
    list.forEach((p, i) => {
      const m = new Date(p.mtime * 1000).toLocaleDateString("en-GB", { month: "long", year: "numeric" });
      if (m !== month) { month = m; body.append(h("div.label", { style: "margin:18px 2px 10px" }, m)); grid = h("div.grid", { style: "grid-template-columns:repeat(auto-fill,minmax(160px,1fr))" }); body.append(grid); }
      grid.append(h("div", { style: "position:relative;aspect-ratio:1;border-radius:14px;overflow:hidden;background:var(--panel-2);cursor:pointer", onclick: () => open(list, i) },
        h("img", { src: p.uri, loading: "lazy", style: "width:100%;height:100%;object-fit:cover" }),
        faves.has(p.path) ? h("span.dot", { style: "position:absolute;top:8px;right:8px" }) : null));
    });
  }

  function open(list, i) {
    at = i; zoom = 1;
    const img = h("img", { style: "max-width:100%;max-height:100%;object-fit:contain;transition:none" });
    const name = h("span.mono.small", { style: "color:#fff" }); const star = h("button.icon-btn", { style: "color:#fff", html: icon("star"), onclick: () => { const p = list[at]; faves.has(p.path) ? faves.delete(p.path) : faves.add(p.path); saveFaves(); show(); } });
    const btn = (ic, f, t) => h("button.icon-btn", { style: "color:#fff", title: t, html: icon(ic), onclick: f });
    const close = () => { view.remove(); document.removeEventListener("keydown", keys); draw(); };
    const view = h("div", { style: "position:fixed;inset:0;background:#000;z-index:30;display:flex;flex-direction:column" },
      h("div", { style: "display:flex;align-items:center;gap:6px;padding:10px 14px" }, btn("x", close, "Close"), name, h("div.grow", { style: "flex:1" }), btn("zoomout", () => { zoom = Math.max(.4, zoom - .25); fit(); }, "Zoom out"), btn("zoomin", () => { zoom = Math.min(4, zoom + .25); fit(); }, "Zoom in"), star, btn("trash", async () => {
        const p = list[at]; if (!await confirmBox("Move to Bin?", `“${p.name}” will go to the Bin.`, "Move to Bin", true)) return;
        try { await wos.call("fs.trash", { path: p.path }); photos = photos.filter(x => x.path !== p.path); list.splice(at, 1); if (!list.length) return close(); at = Math.min(at, list.length - 1); show(); } catch (e) { toast(e.message); } }, "Delete")),
      h("div", { style: "flex:1;min-height:0;display:flex;align-items:center;justify-content:center;overflow:auto;position:relative" }, img,
        h("button.icon-btn", { style: "position:absolute;left:10px;color:#fff;background:rgba(255,255,255,.12)", html: icon("back"), onclick: () => step(-1) }),
        h("button.icon-btn", { style: "position:absolute;right:10px;color:#fff;background:rgba(255,255,255,.12)", html: icon("forward"), onclick: () => step(1) })));
    const fit = () => { img.style.transform = `scale(${zoom})`; };
    const show = () => { const p = list[at]; img.src = p.uri; name.textContent = `${p.name}  ·  ${at + 1} / ${list.length}`; star.style.color = faves.has(p.path) ? "#ff9f0a" : "#fff"; zoom = 1; fit(); };
    const step = d => { at = (at + d + list.length) % list.length; show(); };
    const keys = e => { if (e.key === "Escape") close(); else if (e.key === "ArrowLeft") step(-1); else if (e.key === "ArrowRight") step(1); };
    document.addEventListener("keydown", keys); document.body.append(view); show();
  }
  load();
});
