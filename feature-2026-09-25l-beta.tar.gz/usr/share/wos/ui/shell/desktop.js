"use strict";

/* The desktop itself: files and folders on it, the Bin, and widgets. Runs on the desktop surface only.
   Files live in ~/Desktop; the shell (Python) does every file action, this page draws and asks. Where macOS or Windows can do
   something we cannot yet, the menu shows it with a "Soon" tag instead of hiding it. */

const DESK_TEXT = {
  en: {
    new_folder: "New Folder", new_text: "New Text Document", open: "Open", rename: "Rename", to_bin: "Move to Bin",
    get_info: "Get Info", compress: "Compress", sort_by: "Sort By", s_manual: "None (drag freely)", s_name: "Name", s_kind: "Kind", s_date: "Date Modified",
    clean_up: "Clean Up", change_wall: "Change Wallpaper…", edit_widgets: "Edit Widgets…", open_desktop: "Open Desktop in Files",
    open_bin: "Open Bin", empty_bin: "Empty Bin", empty_q: "Empty the Bin?", empty_note: "Everything in it will be deleted for good.", cancel: "Cancel",
    moved: "Moved to Bin", undo: "Undo", remove_w: "Remove Widget", small: "Small", medium: "Medium", large: "Large", soon: "Soon",
    stacks: "Use Stacks", spaces: "Desktops (Spaces)", drop_files: "Drop files from apps", widgets: "Widgets",
    widgets_sub: "Pick a widget to put it on your desktop. Drag it anywhere. Right-click it to change its size or remove it.", done: "Done",
    w_clock: "Clock", w_calendar: "Calendar", w_notes: "Notes", w_system: "Battery & Wi-Fi", w_weather: "Weather", w_music: "Music",
    d_clock: "The time, analogue or digital", d_calendar: "Today's date, the week or the month", d_notes: "A sticky note you can type in", d_system: "Battery and network at a glance",
    d_weather: "Current weather and the days ahead", d_music: "Play, pause and skip",
    coming_soon: "Coming soon", weather_note: "Needs your location. We will ask first.", music_note: "Controls for whatever is playing.", music_empty: "Nothing playing",
    plugged: "Plugged in", no_battery: "No battery", charging: "Charging", offline: "Not connected", wifi: "Wi-Fi", wired: "Wired", battery: "Battery",
    days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    dshort: ["S", "M", "T", "W", "T", "F", "S"],
    months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    note_ph: "Type a note…", bin: "Bin",
  },
  es: {
    new_folder: "Carpeta nueva", new_text: "Documento de texto nuevo", open: "Abrir", rename: "Cambiar nombre", to_bin: "Mover a la papelera",
    get_info: "Obtener información", compress: "Comprimir", sort_by: "Ordenar por", s_manual: "Ninguno (arrastrar libremente)", s_name: "Nombre", s_kind: "Tipo", s_date: "Fecha de modificación",
    clean_up: "Ordenar iconos", change_wall: "Cambiar fondo de pantalla…", edit_widgets: "Editar widgets…", open_desktop: "Abrir Escritorio en Archivos",
    open_bin: "Abrir papelera", empty_bin: "Vaciar papelera", empty_q: "¿Vaciar la papelera?", empty_note: "Todo lo que contiene se borrará para siempre.", cancel: "Cancelar",
    moved: "Movido a la papelera", undo: "Deshacer", remove_w: "Quitar widget", small: "Pequeño", medium: "Mediano", large: "Grande", soon: "Pronto",
    stacks: "Usar pilas", spaces: "Escritorios (Spaces)", drop_files: "Soltar archivos desde apps", widgets: "Widgets",
    widgets_sub: "Elige un widget para ponerlo en el escritorio. Arrástralo donde quieras. Haz clic derecho para cambiar su tamaño o quitarlo.", done: "Listo",
    w_clock: "Reloj", w_calendar: "Calendario", w_notes: "Notas", w_system: "Batería y Wi-Fi", w_weather: "El tiempo", w_music: "Música",
    d_clock: "La hora, analógica o digital", d_calendar: "La fecha de hoy, la semana o el mes", d_notes: "Una nota adhesiva donde escribir", d_system: "Batería y red de un vistazo",
    d_weather: "El tiempo actual y los próximos días", d_music: "Reproducir, pausar y saltar",
    coming_soon: "Próximamente", weather_note: "Necesita tu ubicación. Te preguntaremos antes.", music_note: "Controles de lo que se esté reproduciendo.", music_empty: "Nada suena ahora",
    plugged: "Conectado", no_battery: "Sin batería", charging: "Cargando", offline: "Sin conexión", wifi: "Wi-Fi", wired: "Cable", battery: "Batería",
    days: ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"],
    dshort: ["D", "L", "M", "X", "J", "V", "S"],
    months: ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"],
    note_ph: "Escribe una nota…", bin: "Papelera",
  },
};
const dk = key => { const l = (window.__lang || "en").startsWith("es") ? "es" : "en"; return DESK_TEXT[l][key] ?? DESK_TEXT.en[key] ?? key; };

const BIN = "\u0001bin";                 // the Bin's key in the layout; no real file is called this
const CELL_W = 100, CELL_H = 104, TOP = 56, BOTTOM_ROOM = 124;
const WSIZE = { s: [160, 160], m: [340, 160], l: [340, 340] };
const WIDGETS = {
  clock: { sizes: ["s", "m"], def: "s" }, calendar: { sizes: ["s", "m", "l"], def: "s" }, notes: { sizes: ["s", "m", "l"], def: "m" },
  system: { sizes: ["s", "m"], def: "m" }, weather: { sizes: ["s", "m", "l"], def: "s", soon: true }, music: { sizes: ["m"], def: "m" },
};

function initDesktop() {
  const root = document.body;
  const S = { items: [], layout: { icons: {}, widgets: [], sort: "manual" }, bin: 0, selected: new Set(), pendingRename: null, status: null };
  const layer = document.createElement("div"); layer.id = "deskicons"; root.appendChild(layer);
  const wlayer = document.createElement("div"); wlayer.id = "deskwidgets"; root.appendChild(wlayer);
  const prefs = () => window.__desktop || {};
  const showIcons = () => prefs().desk_icons !== false;
  const showBin = () => prefs().desk_bin !== false;
  const showWidgets = () => prefs().desk_widgets !== false;

  /* ---------- geometry ---------- */
  const W = () => window.innerWidth, H = () => window.innerHeight;
  const cols = () => Math.max(1, Math.floor(W() / CELL_W));
  const rows = () => Math.max(1, Math.floor((H() - TOP - BOTTOM_ROOM) / CELL_H));
  const posOf = cell => ({ x: W() - (cell.c + 1) * CELL_W, y: TOP + cell.r * CELL_H });
  const cellAt = (x, y) => ({ c: Math.max(0, Math.min(cols() - 1, Math.round((W() - x - CELL_W) / CELL_W))), r: Math.max(0, Math.min(rows() - 1, Math.round((y - TOP) / CELL_H))) });
  const key = cell => cell.c + "," + cell.r;

  function entries() {
    const list = showIcons() ? S.items.map(i => ({ ...i, key: i.name })) : [];
    if (showBin()) list.push({ key: BIN, name: dk("bin"), bin: true });
    return list;
  }

  function freeCell(taken, from) {
    const start = from || { c: 0, r: 0 };
    let best = null, bestD = 1e9;
    for (let c = 0; c < cols(); c++) for (let r = 0; r < rows(); r++) {
      if (taken.has(c + "," + r)) continue;
      const d = Math.abs(c - start.c) * 3 + Math.abs(r - start.r) + (from ? 0 : c * 1000 + r);
      if (d < bestD) { bestD = d; best = { c, r }; }
    }
    return best || { c: cols() - 1, r: rows() - 1 };
  }

  /* Every icon gets a cell. Ones already placed keep it; new ones take the first free cell (the Bin prefers the bottom right). */
  function placeAll() {
    const list = entries(), icons = S.layout.icons, taken = new Set(), placed = {};
    list.forEach(e => { const c = icons[e.key]; if (c && c.c < cols() && c.r < rows() && !taken.has(key(c))) { taken.add(key(c)); placed[e.key] = c; } });
    let dirty = false;
    const bin = list.find(e => e.bin);
    if (bin && !placed[BIN]) { placed[BIN] = freeCell(taken, { c: 0, r: rows() - 1 }); taken.add(key(placed[BIN])); dirty = true; }
    list.forEach(e => { if (!placed[e.key]) { placed[e.key] = freeCell(taken); taken.add(key(placed[e.key])); dirty = true; } });
    Object.keys(icons).forEach(k => { if (!placed[k] && !S.items.some(i => i.name === k) && k !== BIN) { delete icons[k]; } });
    list.forEach(e => { if (!icons[e.key] || icons[e.key].c !== placed[e.key].c || icons[e.key].r !== placed[e.key].r) icons[e.key] = placed[e.key]; });
    if (dirty) saveLayout();
  }

  let saveTimer = null;
  function saveLayout() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => post({ type: "desk-layout", layout: { icons: S.layout.icons, widgets: S.layout.widgets, sort: S.layout.sort } }), 300);
  }

  /* ---------- icon art ---------- */
  const FOLDER = `<svg viewBox="0 0 64 56" width="64" height="56"><path d="M4 10C4 6 7 3 11 3H24c2 0 3.500 1 5 2.500L32 9h21c4 0 7 3 7 7v28c0 4-3 7-7 7H11c-4 0-7-3-7-7z" fill="#7cc4ff"/><rect x="4" y="16" width="56" height="35" rx="7" fill="#3a8dff"/><rect x="4" y="16" width="56" height="12" rx="6" fill="#fff" fill-opacity=".16"/></svg>`;
  const BINSVG = full => `<svg viewBox="0 0 64 64" width="60" height="60"><path d="M12 18h40l-3.500 36c-.3 3-2.700 5-5.700 5H21.200c-3 0-5.400-2-5.700-5z" fill="#d9dee9" fill-opacity=".92"/><path d="M12 18h40l-1 10H13z" fill="#fff" fill-opacity=".35"/><rect x="9" y="12" width="46" height="7" rx="3.500" fill="#f4f6fb"/><rect x="26" y="7" width="12" height="6" rx="3" fill="#f4f6fb"/><path d="M25 30v20M32 30v20M39 30v20" stroke="#8b93a6" stroke-width="3" stroke-linecap="round"/>${full ? `<path d="M17 12l6-7 7 6 6-8 8 9z" fill="#fff"/>` : ""}</svg>`;
  function fileArt(it) {
    const ext = (it.name.includes(".") ? it.name.split(".").pop() : "").toUpperCase().slice(0, 4);
    const mime = it.mime || "";
    if (mime.startsWith("image/") && !mime.includes("svg") && it.path) return `<img class="thumb" src="file://${encodeURI(it.path)}" alt="" draggable="false">`;
    const tone = mime === "application/pdf" ? "#ff5147" : mime.startsWith("audio/") ? "#ff375f" : mime.startsWith("video/") ? "#8e5cf7" : mime.startsWith("text/") ? "#5b8def" : "#98a1b5";
    return `<svg viewBox="0 0 48 60" width="50" height="62"><path d="M6 6c0-2 2-4 4-4h20l12 12v40c0 2-2 4-4 4H10c-2 0-4-2-4-4z" fill="#fff"/><path d="M30 2l12 12H34c-2.500 0-4-1.500-4-4z" fill="${tone}" fill-opacity=".38"/><rect x="6" y="40" width="36" height="14" rx="3" fill="${tone}"/><text x="24" y="51" text-anchor="middle" font-family="sans-serif" font-size="9" font-weight="700" fill="#fff">${(ext || "FILE").replace(/[<&>]/g, "")}</text></svg>`;
  }

  /* ---------- drawing ---------- */
  function iconEl(e) {
    const el = document.createElement("div");
    el.className = "dicon" + (S.selected.has(e.key) ? " sel" : "") + (e.dir ? " isdir" : "") + (e.bin ? " isbin" : "");
    el.dataset.key = e.key;
    const cell = S.layout.icons[e.key], p = posOf(cell);
    el.style.left = p.x + "px"; el.style.top = p.y + "px";
    const art = document.createElement("div"); art.className = "art";
    art.innerHTML = e.bin ? BINSVG(S.bin > 0) : e.dir ? FOLDER : fileArt(e);
    const label = document.createElement("div"); label.className = "label"; label.textContent = e.name;
    el.append(art, label);
    return el;
  }

  function render() {
    const editing = document.querySelector(".dicon input");
    if (editing) return;                                 // do not redraw under someone who is typing a name
    placeAll();
    layer.innerHTML = "";
    layer.hidden = false;
    entries().forEach(e => layer.appendChild(iconEl(e)));
    renderWidgets();
  }

  /* ---------- selection, dragging, marquee ---------- */
  const iconAt = target => target.closest && target.closest(".dicon");
  let drag = null, marquee = null;

  function paintSel() { $$(".dicon", layer).forEach(el => el.classList.toggle("sel", S.selected.has(el.dataset.key))); }

  document.addEventListener("mousedown", ev => {
    if (ev.button !== 0) return;
    closeMenu();
    if (ev.target.closest(".widget, .gallery, .dlg, .toast")) return;
    const el = iconAt(ev.target);
    if (el) {
      const k = el.dataset.key;
      if (ev.ctrlKey || ev.metaKey) { S.selected.has(k) ? S.selected.delete(k) : S.selected.add(k); }
      else if (!S.selected.has(k)) { S.selected = new Set([k]); }
      paintSel();
      drag = { x: ev.clientX, y: ev.clientY, key: k, moving: false, els: [] };
    } else {
      if (!(ev.ctrlKey || ev.metaKey)) { S.selected = new Set(); paintSel(); }
      marquee = { x: ev.clientX, y: ev.clientY, box: null, base: new Set(S.selected) };
    }
  });

  document.addEventListener("mousemove", ev => {
    if (drag) {
      const dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
      if (!drag.moving && Math.hypot(dx, dy) > 5) {
        drag.moving = true;
        drag.els = $$(".dicon", layer).filter(el => S.selected.has(el.dataset.key)).map(el => ({ el, x: parseFloat(el.style.left), y: parseFloat(el.style.top) }));
        drag.els.forEach(d => d.el.classList.add("dragging"));
      }
      if (drag.moving) {
        drag.els.forEach(d => { d.el.style.left = d.x + dx + "px"; d.el.style.top = d.y + dy + "px"; });
        const over = dropTarget(ev);
        $$(".dicon.drop", layer).forEach(x => x.classList.remove("drop"));
        if (over) over.classList.add("drop");
      }
    } else if (marquee) {
      const x0 = Math.min(marquee.x, ev.clientX), y0 = Math.min(marquee.y, ev.clientY), w = Math.abs(ev.clientX - marquee.x), h = Math.abs(ev.clientY - marquee.y);
      if (!marquee.box && w + h > 6) { marquee.box = document.createElement("div"); marquee.box.id = "marquee"; root.appendChild(marquee.box); }
      if (marquee.box) {
        Object.assign(marquee.box.style, { left: x0 + "px", top: y0 + "px", width: w + "px", height: h + "px" });
        const sel = new Set(marquee.base);
        $$(".dicon", layer).forEach(el => {
          const r = el.getBoundingClientRect();
          if (r.right > x0 && r.left < x0 + w && r.bottom > y0 && r.top < y0 + h) sel.add(el.dataset.key);
        });
        S.selected = sel; paintSel();
      }
    }
  });

  function dropTarget(ev) {
    const under = document.elementsFromPoint(ev.clientX, ev.clientY).find(el => el.classList && el.classList.contains("dicon") && !S.selected.has(el.dataset.key));
    if (!under) return null;
    if (under.classList.contains("isdir") || under.classList.contains("isbin")) return under;
    return null;
  }

  document.addEventListener("mouseup", ev => {
    if (marquee) { if (marquee.box) marquee.box.remove(); marquee = null; }
    if (!drag) return;
    const d = drag; drag = null;
    if (!d.moving) return;
    $$(".dicon.drop", layer).forEach(x => x.classList.remove("drop"));
    const names = [...S.selected].filter(k => k !== BIN);
    const target = dropTarget(ev);
    if (target && names.length) {
      if (target.classList.contains("isbin")) return trashNames(names);
      post({ type: "desk-op", op: "move-into", folder: target.dataset.key, names });
      S.selected = new Set();
      return;
    }
    const taken = new Set(), moves = [];
    $$(".dicon", layer).forEach(el => { if (!S.selected.has(el.dataset.key)) taken.add(key(S.layout.icons[el.dataset.key])); });
    d.els.forEach(m => moves.push({ k: m.el.dataset.key, want: cellAt(parseFloat(m.el.style.left), parseFloat(m.el.style.top)) }));
    moves.forEach(m => { const c = taken.has(key(m.want)) ? freeCell(taken, m.want) : m.want; taken.add(key(c)); S.layout.icons[m.k] = c; });
    S.layout.sort = "manual";
    saveLayout(); render();
  });

  document.addEventListener("dblclick", ev => {
    const el = iconAt(ev.target);
    if (!el) return;
    openKey(el.dataset.key);
  });
  function openKey(k) { post({ type: "desk-op", op: k === BIN ? "open-bin" : "open", name: k }); }

  /* ---------- trash, rename, new ---------- */
  function trashNames(names) {
    names = names.filter(n => n !== BIN);
    if (!names.length) return;
    post({ type: "desk-op", op: "trash", names });
    S.selected = new Set();
  }
  function startRename(name) {
    const el = $$(".dicon", layer).find(e => e.dataset.key === name);
    if (!el || el.classList.contains("isbin")) return;
    const label = $(".label", el);
    const input = document.createElement("input");
    input.className = "rename"; input.value = name; input.spellcheck = false; input.maxLength = 200;
    label.replaceWith(input);
    input.focus();
    const dot = name.lastIndexOf(".");
    input.setSelectionRange(0, dot > 0 && !el.classList.contains("isdir") ? dot : name.length);
    let done = false;
    const finish = commit => {
      if (done) return; done = true;
      const to = input.value.trim();
      if (commit && to && to !== name) {
        if (S.layout.icons[name]) { S.layout.icons[to] = S.layout.icons[name]; delete S.layout.icons[name]; saveLayout(); }
        S.selected = new Set([to]);
        post({ type: "desk-op", op: "rename", name, to });
      }
      input.remove(); render();
    };
    input.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter") finish(true); else if (e.key === "Escape") finish(false); });
    input.addEventListener("blur", () => finish(true));
    input.addEventListener("mousedown", e => e.stopPropagation());
  }

  document.addEventListener("keydown", ev => {
    if (ev.target.closest && ev.target.closest("input, textarea")) return;
    const names = [...S.selected].filter(k => k !== BIN);
    if (ev.key === "F2" && names.length === 1) { ev.preventDefault(); startRename(names[0]); }
    else if (ev.key === "Delete" && names.length) { ev.preventDefault(); trashNames(names); }
    else if (ev.key === "Enter" && S.selected.size === 1) { ev.preventDefault(); openKey([...S.selected][0]); }
    else if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === "a") { ev.preventDefault(); S.selected = new Set(entries().map(e => e.key)); paintSel(); }
    else if (ev.key === "Escape") { S.selected = new Set(); paintSel(); closeMenu(); }
  });

  /* ---------- menus, dialogs, toast ---------- */
  let menuEl = null;
  function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }
  function buildMenu(items, sub) {
    const m = document.createElement("div"); m.className = "ctx" + (sub ? " sub" : "");
    items.forEach(it => {
      if (it.sep) { const s = document.createElement("hr"); m.appendChild(s); return; }
      const b = document.createElement("button");
      b.disabled = !!(it.disabled || it.soon);
      const check = document.createElement("span"); check.className = "ck"; check.textContent = it.check ? "✓" : "";
      const text = document.createElement("span"); text.className = "tx"; text.textContent = it.label;
      b.append(check, text);
      if (it.soon) { const tag = document.createElement("em"); tag.textContent = dk("soon"); b.appendChild(tag); }
      if (it.sub) {
        const arrow = document.createElement("span"); arrow.className = "ar"; arrow.textContent = "›"; b.appendChild(arrow);
        const inner = buildMenu(it.sub, true); b.appendChild(inner);
        b.addEventListener("mouseenter", () => { const r = b.getBoundingClientRect(); inner.style.top = "-6px"; inner.style.left = (r.right + 190 > W() ? "auto" : "100%"); inner.style.right = (r.right + 190 > W() ? "100%" : "auto"); });
      } else if (it.fn) b.addEventListener("click", e => { e.stopPropagation(); closeMenu(); it.fn(); });
      m.appendChild(b);
    });
    return m;
  }
  function openMenu(items, x, y) {
    closeMenu();
    menuEl = buildMenu(items);
    root.appendChild(menuEl);
    const r = menuEl.getBoundingClientRect();
    menuEl.style.left = Math.max(6, Math.min(x, W() - r.width - 6)) + "px";
    menuEl.style.top = Math.max(50, Math.min(y, H() - r.height - 10)) + "px";
  }

  function confirmBox(title, note, yes) {
    return new Promise(res => {
      const back = document.createElement("div"); back.className = "dlgback";
      const box = document.createElement("div"); box.className = "dlg";
      box.innerHTML = `<h3></h3><p></p><div class="btns"><button class="no"></button><button class="yes"></button></div>`;
      $("h3", box).textContent = title; $("p", box).textContent = note; $(".no", box).textContent = dk("cancel"); $(".yes", box).textContent = yes;
      const close = v => { back.remove(); res(v); };
      $(".no", box).onclick = () => close(false); $(".yes", box).onclick = () => close(true);
      back.appendChild(box); root.appendChild(back);
    });
  }

  let toastEl = null, toastTimer = null;
  function toast(text, undo) {
    if (toastEl) toastEl.remove();
    clearTimeout(toastTimer);
    toastEl = document.createElement("div"); toastEl.className = "toast";
    const span = document.createElement("span"); span.textContent = text; toastEl.appendChild(span);
    if (undo) { const b = document.createElement("button"); b.textContent = dk("undo"); b.onclick = () => { undo(); toastEl.remove(); toastEl = null; }; toastEl.appendChild(b); }
    root.appendChild(toastEl);
    toastTimer = setTimeout(() => { if (toastEl) { toastEl.remove(); toastEl = null; } }, 7000);
  }

  /* ---------- the desktop menu and the icon menu ---------- */
  function sortBy(mode) {
    const order = [...S.items];
    if (mode === "name") order.sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
    else if (mode === "kind") order.sort((a, b) => (b.dir - a.dir) || (a.mime || "").localeCompare(b.mime || "") || a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
    else if (mode === "date") order.sort((a, b) => b.mtime - a.mtime);
    const icons = {}, taken = new Set();
    if (showBin() && S.layout.icons[BIN]) { icons[BIN] = S.layout.icons[BIN]; taken.add(key(icons[BIN])); }
    order.forEach(i => { const c = freeCell(taken); taken.add(key(c)); icons[i.name] = c; });
    S.layout.icons = icons; S.layout.sort = mode; saveLayout(); render();
  }
  function cleanUp() {
    const ordered = $$(".dicon", layer).map(el => ({ k: el.dataset.key, c: S.layout.icons[el.dataset.key] })).filter(x => x.k !== BIN)
      .sort((a, b) => (a.c.c - b.c.c) || (a.c.r - b.c.r));
    const icons = {}, taken = new Set();
    if (showBin() && S.layout.icons[BIN]) { icons[BIN] = S.layout.icons[BIN]; taken.add(key(icons[BIN])); }
    ordered.forEach(x => { const c = freeCell(taken); taken.add(key(c)); icons[x.k] = c; });
    S.layout.icons = icons; saveLayout(); render();
  }
  async function emptyBin() {
    if (await confirmBox(dk("empty_q"), dk("empty_note"), dk("empty_bin"))) post({ type: "desk-op", op: "empty-bin" });
  }

  document.addEventListener("contextmenu", ev => {
    ev.preventDefault();
    const wEl = ev.target.closest && ev.target.closest(".widget");
    if (wEl) return widgetMenu(wEl, ev);
    if (ev.target.closest && ev.target.closest(".gallery, .dlg")) return;
    const el = iconAt(ev.target);
    if (el) {
      const k = el.dataset.key;
      if (!S.selected.has(k)) { S.selected = new Set([k]); paintSel(); }
      if (k === BIN) return openMenu([
        { label: dk("open_bin"), fn: () => openKey(BIN) },
        { label: dk("empty_bin"), fn: emptyBin, disabled: S.bin === 0 }], ev.clientX, ev.clientY);
      const names = [...S.selected].filter(x => x !== BIN);
      return openMenu([
        { label: dk("open"), fn: () => names.forEach(openKey) },
        { sep: true },
        { label: dk("rename"), fn: () => startRename(names[0]), disabled: names.length !== 1 },
        { label: dk("to_bin"), fn: () => trashNames(names) },
        { sep: true },
        { label: dk("get_info"), soon: true }, { label: dk("compress"), soon: true }], ev.clientX, ev.clientY);
    }
    const sort = S.layout.sort || "manual";
    openMenu([
      { label: dk("new_folder"), fn: () => post({ type: "desk-op", op: "new-folder" }) },
      { label: dk("new_text"), fn: () => post({ type: "desk-op", op: "new-text" }) },
      { sep: true },
      { label: dk("sort_by"), sub: [
        { label: dk("s_manual"), check: sort === "manual", fn: () => { S.layout.sort = "manual"; saveLayout(); } },
        { label: dk("s_name"), check: sort === "name", fn: () => sortBy("name") },
        { label: dk("s_kind"), check: sort === "kind", fn: () => sortBy("kind") },
        { label: dk("s_date"), check: sort === "date", fn: () => sortBy("date") }] },
      { label: dk("clean_up"), fn: cleanUp },
      { label: dk("stacks"), soon: true },
      { sep: true },
      { label: dk("edit_widgets"), fn: openGallery },
      { label: dk("change_wall"), fn: () => post({ type: "desk-op", op: "settings" }) },
      { label: dk("open_desktop"), fn: () => post({ type: "desk-op", op: "open-desktop" }) },
      { sep: true },
      { label: dk("spaces"), soon: true }, { label: dk("drop_files"), soon: true }], ev.clientX, ev.clientY);
  });
  window.addEventListener("blur", closeMenu);

  /* ---------- widgets ---------- */
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const pad = n => String(n).padStart(2, "0");
  const live = [];                                  // functions the clock tick calls

  function analog() {
    const wrap = el("div", "analog");
    let ticks = "";
    for (let i = 0; i < 12; i++) ticks += `<line x1="50" y1="${i % 3 ? 7 : 5}" x2="50" y2="${i % 3 ? 11 : 13}" transform="rotate(${i * 30} 50 50)" stroke="#2b2d36" stroke-width="${i % 3 ? 1.500 : 2.600}" stroke-linecap="round"/>`;
    wrap.innerHTML = `<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="47" fill="#f7f8fb"/>${ticks}
      <line class="hh" x1="50" y1="50" x2="50" y2="27" stroke="#1d1f27" stroke-width="4" stroke-linecap="round"/>
      <line class="mh" x1="50" y1="50" x2="50" y2="14" stroke="#1d1f27" stroke-width="2.800" stroke-linecap="round"/>
      <line class="sh" x1="50" y1="56" x2="50" y2="12" stroke="#ff453a" stroke-width="1.400" stroke-linecap="round"/><circle cx="50" cy="50" r="3" fill="#ff453a"/></svg>`;
    const run = () => {
      const d = new Date(), s = d.getSeconds(), m = d.getMinutes() + s / 60, h = (d.getHours() % 12) + m / 60;
      $(".hh", wrap).setAttribute("transform", `rotate(${h * 30} 50 50)`); $(".mh", wrap).setAttribute("transform", `rotate(${m * 6} 50 50)`); $(".sh", wrap).setAttribute("transform", `rotate(${s * 6} 50 50)`);
    };
    run(); live.push(run);
    return wrap;
  }

  function buildWidget(w, preview) {
    const box = el("div", "widget w-" + w.type + " sz-" + w.size);
    const [pw, ph] = WSIZE[w.size]; box.style.width = pw + "px"; box.style.height = ph + "px";
    const now = new Date();
    if (w.type === "clock") {
      if (w.size === "s") box.appendChild(analog());
      else {
        const t = el("div", "big"), d = el("div", "sub");
        const run = () => { const n = new Date(); t.textContent = pad(n.getHours()) + ":" + pad(n.getMinutes()); d.textContent = dk("days")[n.getDay()] + " " + n.getDate() + " " + dk("months")[n.getMonth()]; };
        box.append(t, d); run(); live.push(run);
      }
    } else if (w.type === "calendar") {
      box.classList.add("light");
      const build = () => {
        box.innerHTML = ""; const n = new Date();
        if (w.size === "s") {
          box.append(el("div", "wk", dk("days")[n.getDay()].toUpperCase()), el("div", "dn", String(n.getDate())), el("div", "mo", dk("months")[n.getMonth()]));
        } else {
          box.appendChild(el("div", "mh", dk("months")[n.getMonth()].toUpperCase() + " " + n.getFullYear()));
          const grid = el("div", "cal"); dk("dshort").forEach(d => grid.appendChild(el("span", "dow", d)));
          const first = new Date(n.getFullYear(), n.getMonth(), 1).getDay(), days = new Date(n.getFullYear(), n.getMonth() + 1, 0).getDate();
          if (w.size === "m") {
            for (let i = 0; i < 7; i++) { const dd = new Date(n); dd.setDate(n.getDate() - n.getDay() + i); grid.appendChild(el("span", "d" + (dd.getDate() === n.getDate() ? " today" : ""), String(dd.getDate()))); }
          } else {
            for (let i = 0; i < first; i++) grid.appendChild(el("span", "d"));
            for (let d = 1; d <= days; d++) grid.appendChild(el("span", "d" + (d === n.getDate() ? " today" : ""), String(d)));
          }
          box.appendChild(grid);
        }
      };
      build(); live.push(() => { if (new Date().getSeconds() === 0) build(); });
    } else if (w.type === "notes") {
      box.classList.add("note");
      box.appendChild(el("div", "grab"));
      const ta = document.createElement("textarea"); ta.placeholder = dk("note_ph"); ta.value = w.text || ""; ta.spellcheck = false; ta.maxLength = 4000;
      if (preview) ta.readOnly = true;
      ta.addEventListener("input", () => { w.text = ta.value; saveLayout(); });
      box.appendChild(ta);
    } else if (w.type === "system") {
      const build = () => {
        box.innerHTML = ""; const st = S.status || {}, b = st.battery;
        const pct = b ? b.pct : null;
        if (w.size === "s") {
          box.appendChild(el("div", "ring", `<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="38" fill="none" stroke="#ffffff" stroke-opacity=".18" stroke-width="10"/><circle cx="50" cy="50" r="38" fill="none" stroke="${pct !== null && pct < 20 && !b.charging ? "#ff453a" : "#30d158"}" stroke-width="10" stroke-linecap="round" stroke-dasharray="${(pct || 100) * 2.39} 239" transform="rotate(-90 50 50)"/></svg><b>${pct !== null ? pct + "%" : "AC"}</b>`));
        } else {
          box.appendChild(el("div", "row", `<span>${dk("battery")}</span><b>${pct !== null ? pct + "%" + (b.charging ? " · " + dk("charging") : "") : dk("plugged")}</b>`));
          box.appendChild(el("div", "bar", `<i style="width:${pct !== null ? pct : 100}%"></i>`));
          const net = st.wifi;
          box.appendChild(el("div", "row", `<span>${net && net.kind === "ethernet" ? dk("wired") : dk("wifi")}</span><b></b>`));
          $(".row:last-child b", box).textContent = net ? net.name : dk("offline");
        }
      };
      build(); w._refresh = build;
    } else if (w.type === "music") {
      box.classList.add("light");
      const build = () => {
        box.innerHTML = "";
        const m = S.status && S.status.music;
        if (!m) {
          const empty = el("div", "soonwrap");
          empty.append(el("div", "ico", "♪"), el("div", "t", dk("w_music")), el("div", "n", dk("music_empty")));
          box.appendChild(empty);
          return;
        }
        box.appendChild(el("div", "row", `<span></span>`));
        $(".row span", box).textContent = m.title || dk("w_music");
        const sub = el("div", "sub"); sub.textContent = m.artist || ""; box.appendChild(sub);
        const controls = el("div", "controls");
        const btn = (glyph, action) => { const b = document.createElement("button"); b.textContent = glyph; b.addEventListener("click", e => { e.stopPropagation(); post({ type: "music-action", action }); }); return b; };
        controls.append(btn("⏮", "previous"), btn(m.playing ? "⏸" : "▶", "play-pause"), btn("⏭", "next"));
        box.appendChild(controls);
      };
      build(); w._refresh = build;
    } else {
      const soon = el("div", "soonwrap");
      soon.append(el("div", "ico", "☀️"), el("div", "t", dk("w_" + w.type)), el("div", "tag", dk("coming_soon")));
      if (w.size !== "s") soon.appendChild(el("div", "n", dk(w.type + "_note")));
      box.appendChild(soon);
    }
    return box;
  }

  function renderWidgets() {
    live.length = 0;
    wlayer.innerHTML = "";
    if (!showWidgets()) return;
    S.layout.widgets.forEach(w => {
      const box = buildWidget(w);
      box.dataset.id = w.id;
      w.x = Math.max(0, Math.min(w.x, W() - 60)); w.y = Math.max(TOP - 6, Math.min(w.y, H() - 80));
      box.style.left = w.x + "px"; box.style.top = w.y + "px";
      wlayer.appendChild(box);
    });
  }
  setInterval(() => live.forEach(f => f()), 1000);

  /* Dragging a widget */
  let wdrag = null;
  document.addEventListener("mousedown", ev => {
    if (ev.button !== 0) return;
    const box = ev.target.closest && ev.target.closest("#deskwidgets .widget");
    if (!box || ev.target.closest("textarea")) return;
    const w = S.layout.widgets.find(x => x.id === box.dataset.id);
    if (!w) return;
    wdrag = { w, box, x: ev.clientX, y: ev.clientY, ox: w.x, oy: w.y };
    box.classList.add("lift");
  });
  document.addEventListener("mousemove", ev => {
    if (!wdrag) return;
    const nx = Math.max(0, Math.min(W() - 60, wdrag.ox + ev.clientX - wdrag.x)), ny = Math.max(TOP - 6, Math.min(H() - 80, wdrag.oy + ev.clientY - wdrag.y));
    wdrag.w.x = nx; wdrag.w.y = ny; wdrag.box.style.left = nx + "px"; wdrag.box.style.top = ny + "px";
  });
  document.addEventListener("mouseup", () => { if (wdrag) { wdrag.box.classList.remove("lift"); wdrag = null; saveLayout(); } });

  function widgetMenu(box, ev) {
    const w = S.layout.widgets.find(x => x.id === box.dataset.id);
    if (!w) return;
    const names = { s: dk("small"), m: dk("medium"), l: dk("large") };
    openMenu([
      ...WIDGETS[w.type].sizes.map(sz => ({ label: names[sz], check: w.size === sz, fn: () => { w.size = sz; saveLayout(); renderWidgets(); } })),
      { sep: true },
      { label: dk("remove_w"), fn: () => { S.layout.widgets = S.layout.widgets.filter(x => x !== w); saveLayout(); renderWidgets(); } },
      { label: dk("edit_widgets"), fn: openGallery }], ev.clientX, ev.clientY);
  }

  function addWidget(type, size) {
    const [pw, ph] = WSIZE[size];
    let x = 28, y = TOP + 10, tries = 0;
    const clash = () => S.layout.widgets.some(o => { const [ow, oh] = WSIZE[o.size]; return x < o.x + ow + 14 && x + pw + 14 > o.x && y < o.y + oh + 14 && y + ph + 14 > o.y; });
    while (clash() && tries++ < 200) { y += 20; if (y + ph > H() - BOTTOM_ROOM) { y = TOP + 10; x += 20; } }
    S.layout.widgets.push({ id: "w" + Date.now().toString(36), type, size, x, y, text: "" });
    saveLayout(); renderWidgets();
  }

  function openGallery() {
    closeMenu();
    if ($(".gallery")) return;
    const back = el("div", "dlgback"), g = el("div", "gallery");
    g.appendChild(el("h3", "", dk("widgets"))); g.appendChild(el("p", "", dk("widgets_sub")));
    const grid = el("div", "wgrid");
    const names = { s: dk("small"), m: dk("medium"), l: dk("large") };
    Object.entries(WIDGETS).forEach(([type, meta]) => {
      const card = el("div", "wcard" + (meta.soon ? " soon" : ""));
      const pv = el("div", "pv");
      const inner = buildWidget({ id: "pv", type, size: meta.def, text: "" }, true);
      inner.style.transform = "scale(.72)"; inner.style.transformOrigin = "top left";
      const [pw, ph] = WSIZE[meta.def]; pv.style.width = pw * .72 + "px"; pv.style.height = ph * .72 + "px"; pv.appendChild(inner);
      const info = el("div", "info"); info.append(el("b", "", dk("w_" + type)), el("span", "", meta.soon ? dk("coming_soon") : dk("d_" + type)));
      const sizes = el("div", "szs");
      meta.sizes.forEach(sz => { const b = el("button", "", names[sz]); b.disabled = !!meta.soon; b.onclick = () => addWidget(type, sz); sizes.appendChild(b); });
      card.append(pv, info, sizes); grid.appendChild(card);
    });
    const done = el("button", "done", dk("done")); done.onclick = () => { back.remove(); live.length = 0; renderWidgets(); };
    g.append(grid, done); back.appendChild(g); root.appendChild(back);
  }

  /* ---------- messages from the shell ---------- */
  handlers.desk = m => {
    S.items = m.items || [];
    const l = m.layout || {};
    S.layout = { icons: l.icons || {}, widgets: l.widgets || [], sort: l.sort || "manual" };
    S.bin = m.bin || 0;
    const names = new Set(S.items.map(i => i.name)); names.add(BIN);
    S.selected = new Set([...S.selected].filter(k => names.has(k)));
    if (S.pendingRename && names.has(S.pendingRename)) { const n = S.pendingRename; S.pendingRename = null; S.selected = new Set([n]); render(); startRename(n); return; }
    render();
  };
  handlers["desk-created"] = m => { S.pendingRename = m.name; };
  handlers["desk-bin"] = m => { S.bin = m.count || 0; const bin = $(".dicon.isbin .art", layer); if (bin) bin.innerHTML = BINSVG(S.bin > 0); };
  handlers["desk-trashed"] = m => {
    S.bin = m.bin || S.bin;
    toast(`${dk("moved")}${m.names.length > 1 ? " (" + m.names.length + ")" : ""}`, () => post({ type: "desk-op", op: "undo-trash", names: m.names }));
  };
  handlers["desk-error"] = m => toast(m.text);
  handlers.status = m => { S.status = m; S.layout.widgets.forEach(w => { if (w._refresh) w._refresh(); }); };
  const chained = handlers["desktop-prefs"];
  handlers["desktop-prefs"] = m => { chained(m); render(); };
  window.addEventListener("resize", () => { clearTimeout(window.__deskResize); window.__deskResize = setTimeout(render, 120); });
}

if (surface === "desktop") initDesktop();

/* ---------- mock host for the browser preview ---------- */
if (surface === "desktop" && !bridge) {
  const mock = { items: [
      { name: "Documents", dir: true, mime: "", mtime: 5, size: 0, path: "/home/will/Desktop/Documents" },
      { name: "Trip to Windermere", dir: true, mime: "", mtime: 9, size: 0, path: "/home/will/Desktop/Trip" },
      { name: "Budget.pdf", dir: false, mime: "application/pdf", mtime: 7, size: 1, path: "/home/will/Desktop/Budget.pdf" },
      { name: "Project notes.txt", dir: false, mime: "text/plain", mtime: 8, size: 1, path: "/home/will/Desktop/Project notes.txt" },
      { name: "Song.mp3", dir: false, mime: "audio/mpeg", mtime: 3, size: 1, path: "/home/will/Desktop/Song.mp3" }],
    layout: { icons: {}, sort: "manual", widgets: [
      { id: "a", type: "clock", size: "s", x: 28, y: 66, text: "" }, { id: "b", type: "calendar", size: "s", x: 208, y: 66, text: "" },
      { id: "c", type: "notes", size: "m", x: 28, y: 246, text: "Ship icons\nTest desktop widgets" }, { id: "d", type: "system", size: "m", x: 388, y: 66, text: "" }] }, bin: 2 };
  const push = () => window.wos.receive({ type: "desk", items: mock.items, layout: mock.layout, bin: mock.bin });
  window.__deskMock = msg => {
    if (msg.type === "ready") { setTimeout(() => { window.wos.receive({ type: "init", lang: "en_GB" }); push(); window.wos.receive({ type: "status", battery: { pct: 78, charging: false }, wifi: { kind: "wifi", name: "Home-5G" } }); }, 60); return true; }
    if (msg.type === "desk-layout") { mock.layout = msg.layout; return true; }
    if (msg.type === "desk-op") {
      const o = msg;
      if (o.op === "new-folder") { const n = "untitled folder"; mock.items.push({ name: n, dir: true, mime: "", mtime: 99, size: 0, path: "" }); window.wos.receive({ type: "desk-created", name: n }); }
      if (o.op === "new-text") { const n = "New Text Document.txt"; mock.items.push({ name: n, dir: false, mime: "text/plain", mtime: 99, size: 0, path: "" }); window.wos.receive({ type: "desk-created", name: n }); }
      if (o.op === "rename") mock.items.forEach(i => { if (i.name === o.name) i.name = o.to; });
      if (o.op === "trash") { mock.items = mock.items.filter(i => !o.names.includes(i.name)); mock.bin += o.names.length; window.wos.receive({ type: "desk-trashed", names: o.names, bin: mock.bin }); }
      if (o.op === "move-into") mock.items = mock.items.filter(i => !o.names.includes(i.name));
      if (o.op === "empty-bin") { mock.bin = 0; window.wos.receive({ type: "desk-bin", count: 0 }); }
      setTimeout(push, 150);
      return true;
    }
    return false;
  };
  const realMock = mockHost;
  mockHost = msg => { if (!(window.__deskMock && window.__deskMock(msg))) realMock(msg); };
  post({ type: "ready", surface });        // shell.js sent its own before this mock existed
}
