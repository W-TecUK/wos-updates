"""Decision and safety logic for the W-OS update handler (docs/UPDATES.md).

Everything here is pure: it takes facts (the manifest entry, device state,
probes of the machine) and returns decisions. Downloading, installing and
rebooting live in the daemon (wos-updated), which calls this. Keeping the rules
separate is what lets them be tested without touching a real system.
"""
import hashlib

import wosversion

# What to do with an available update.
SKIP = "skip"            # nothing to do (older, paused, not in this rollout yet)
BLOCKED = "blocked"      # not allowed right now (limited mode); say why
AUTO = "auto"            # install without asking
ASK = "ask"              # offer it and wait for a yes

HISTORY_LIMIT = 10
PROBATION_BOOTS = 2      # boots a new version gets to reach the desktop before it is reverted
MIN_BATTERY_PERCENT = 25   # unplugged and below this blocks; 25% itself is safe to update on
DISK_MARGIN_BYTES = 200 * 1024 * 1024


def kind_of(item):
    """'security' or 'feature'. Anything unrecognised counts as feature, so a
    typo on the server can never make something install without asking."""
    return "security" if item.get("kind") == "security" else "feature"


def in_rollout(item, device_id):
    """Staged rollout: the server sets rollout_percent (0-100, default 100).
    A device's place in the order is fixed by hashing, so the same devices go
    first every time and the share only ever grows as the percentage rises."""
    percent = item.get("rollout_percent", 100)
    if percent >= 100:
        return True
    if percent <= 0:
        return False
    digest = hashlib.sha256(("%s:%s" % (device_id, item.get("id", ""))).encode()).digest()
    return (int.from_bytes(digest[:4], "big") % 100) < percent


def decide(item, installed_version, lifecycle, device_id=""):
    """Returns (action, reason)."""
    try:
        if wosversion.compare(item["version"], installed_version) <= 0:
            return SKIP, "already up to date"
    except (KeyError, ValueError):
        return SKIP, "bad version in manifest"
    if item.get("paused"):
        return SKIP, "paused by the server"
    if not in_rollout(item, device_id):
        return SKIP, "not in this rollout yet"
    if kind_of(item) == "security":
        return AUTO, "security update"                 # always, even in limited mode
    if lifecycle == "limited_mode":
        return BLOCKED, "limited mode"
    return ASK, "feature update"


def preflight(item, probes, state):
    """Checks that must all pass before anything is applied. Returns a list of
    short reasons; an empty list means go. 'Not now' is a normal answer.

    probes: dict with signature_ok (bool), free_bytes (int),
            battery_percent (int or None for no battery), on_mains (bool)
    state:  the handler's saved state (pending update, probation)
    """
    problems = []
    if not probes.get("signature_ok"):
        problems.append("signature or checksum not verified")
    needed = 2 * int(item.get("size", 0)) + DISK_MARGIN_BYTES
    if probes.get("free_bytes", 0) < needed:
        problems.append("not enough free disk space")
    battery = probes.get("battery_percent")
    if battery is not None and battery < MIN_BATTERY_PERCENT and not probes.get("on_mains"):
        problems.append("battery too low")
    if state.get("pending"):
        problems.append("an earlier update is unfinished")
    if state.get("probation"):
        problems.append("the last update is still being checked")
    return problems


def can_roll_back(entry):
    """Manual rollback: never for security; otherwise only when the update's
    database entry says so. A missing flag means no."""
    if kind_of(entry) == "security":
        return False
    return entry.get("rollback_available") is True


def record(history, entry):
    """Newest first, capped at the last HISTORY_LIMIT."""
    return ([entry] + list(history))[:HISTORY_LIMIT]


# --- boot health check / automatic revert -------------------------------------
#
# After an update is applied the handler stores probation = {"version", "previous",
# "boots": 0}. Each boot calls on_boot_start (before the desktop) and, once the
# desktop has been up for a while, on_boot_healthy. A version that uses up its
# boots without ever being reported healthy is reverted to `previous`.

def begin_probation(state, new_version, previous_version):
    state = dict(state)
    state["probation"] = {"version": new_version, "previous": previous_version, "boots": 0}
    state.pop("pending", None)
    return state


def on_boot_start(state):
    """Returns (state, revert_to). revert_to is a version to go back to, or None."""
    probation = state.get("probation")
    if not probation:
        return state, None
    state = dict(state)
    probation = dict(probation)
    if probation["boots"] >= PROBATION_BOOTS:
        # It has already had its boots and never reported healthy: go back.
        state.pop("probation", None)
        return state, probation["previous"]
    probation["boots"] += 1
    state["probation"] = probation
    return state, None


def on_boot_healthy(state):
    """The desktop came up and stayed up: the update is good."""
    state = dict(state)
    state.pop("probation", None)
    return state
