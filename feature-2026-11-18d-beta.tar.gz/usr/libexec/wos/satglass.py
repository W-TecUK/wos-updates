"""satglass: the modern-OS look for the shelf and the menu bar, drawn natively with cairo.

xfwm4's compositor makes windows see-through but cannot blur what is behind them. We know what is behind the chrome (the
wallpaper), so we blur a copy of it once and paint the right piece behind each capsule: a real frosted-glass effect with no
compositor blur. Each surface gets, in order:
  1. a soft drop shadow (stacked rounded rects, no filter needed),
  2. the blurred wallpaper, clipped to the shape,
  3. a navy tint so white text and icons always read,
  4. a faint top-to-bottom sheen (light above, deeper below) for depth,
  5. a 1 px edge: bright on top, softer below, plus a dark hairline outside it.
If the wallpaper cannot be read it falls back to a solid navy fill, so nothing ever turns see-through or unreadable.
The look is data (GLASS below) so the designer can tune it without touching code.
"""
import os
import subprocess

import cairo
import satperf
import gi

gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf  # noqa: E402

DEFAULT_WALLPAPER = "/usr/share/backgrounds/wos3/default.png"
# Designer's v9 GLASS-SPEC.md. Dark and light each have their own numbers.
DARK = {
    "tint": (22 / 255, 22 / 255, 26 / 255), "tint_alpha": 0.62, "tint_max": 0.90, "saturation": 1.15,       # neutral charcoal (Will, 18 Nov: not blue)
    "sheen": 0.10, "sheen_end": 0.55, "edge_top": 0.28, "edge_side": 0.08, "outline": (0.0, 0.0, 0.0, 0.55),
    "shadow": (0, 0, 0, 0.35), "contact": (0, 0, 0, 0.25),
    "text": (1.0, 1.0, 1.0), "muted": (1.0, 1.0, 1.0, 0.75), "dash": (1.0, 0xC9 / 255, 0x33 / 255), "dash_outline": None,
    "solid": (0x1C / 255, 0x1C / 255, 0x1E / 255), "solid_edge": (0x3A / 255, 0x3A / 255, 0x3D / 255),
}
LIGHT = {
    "tint": (246 / 255, 246 / 255, 248 / 255), "tint_alpha": 0.66, "tint_max": 0.80, "saturation": 1.2,
    "sheen": 0.55, "sheen_end": 0.55, "edge_top": 0.90, "edge_side": 0.35, "outline": (0, 0, 0, 0.14),
    "shadow": (0, 0, 0, 0.18), "contact": (0, 0, 0, 0.14),
    "text": (10 / 255, 26 / 255, 60 / 255), "muted": (10 / 255, 26 / 255, 60 / 255, 0.78), "dash": (0xE5 / 255, 0xA8 / 255, 0.0),
    "dash_outline": (12 / 255, 42 / 255, 102 / 255, 0.25),
    "solid": (0.965, 0.965, 0.97), "solid_edge": (0, 0, 0, 0.18),
}
BLUR_DOWN = 14             # the wallpaper is shrunk this many times then enlarged: about a 28 px blur at 1920 wide
MIN_CONTRAST = 7.0         # text on glass must reach this against the brightest (dark mode) or darkest (light mode) wallpaper under it
PREF_DIR = os.path.join(os.path.expanduser("~"), ".config", "wos")


def read_mode():
    """"dark" (default) or "light", from ~/.config/wos/theme."""
    try:
        with open(os.path.join(PREF_DIR, "theme"), encoding="utf-8") as f:
            return "light" if f.read().strip().lower() == "light" else "dark"
    except OSError:
        return "dark"


def reduce_transparency():
    """True when the person turned Reduce Transparency on (a file ~/.config/wos/reduce-transparency)."""
    return os.path.exists(os.path.join(PREF_DIR, "reduce-transparency"))


def _lin(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def luminance(rgb):
    r, g, b = [_lin(v) for v in rgb]
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = luminance(a), luminance(b)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)


def adaptive_alpha(look, wall_rgb, floor=None):
    """The smallest tint opacity (never below the designer's) that keeps text at MIN_CONTRAST over this wallpaper colour,
    counting the light sheen at the top of the capsule. Bright wallpaper under dark glass, or dark wallpaper under light
    glass, is what pushes it up."""
    lo = floor if floor is not None else look["tint_alpha"]
    tint, text = look["tint"], look["text"]
    for i in range(0, 101):
        a = lo + (look["tint_max"] - lo) * i / 100.0
        base = [a * t + (1 - a) * w for t, w in zip(tint, wall_rgb)]
        top = [look["sheen"] * 1.0 + (1 - look["sheen"]) * v for v in base]      # sheen is white
        if contrast(text, base) >= MIN_CONTRAST and contrast(text, top) >= MIN_CONTRAST * 0.8:
            return a
    return look["tint_max"]


def wallpaper_path():
    """The wallpaper xfdesktop is showing, else the W-OS default."""
    try:
        out = subprocess.run(["xfconf-query", "-c", "xfce4-desktop", "-p", "/backdrop/screen0/monitor0/workspace0/last-image"],
                             capture_output=True, text=True, timeout=2).stdout.strip()
        if out and os.path.isfile(out):
            return out
    except (OSError, subprocess.SubprocessError):
        pass
    return DEFAULT_WALLPAPER


def round_path(cr, x, y, w, h, radii):
    tl, tr, br, bl = [max(0.0, min(r, w / 2, h / 2)) for r in radii]
    cr.new_sub_path()
    cr.arc(x + w - tr, y + tr, tr, -1.5708, 0)
    cr.arc(x + w - br, y + h - br, br, 0, 1.5708)
    cr.arc(x + bl, y + h - bl, bl, 1.5708, 3.1416)
    cr.arc(x + tl, y + tl, tl, 3.1416, 4.7124)
    cr.close_path()


def saturate(surface, amount):
    """Boost colour saturation of a (small) surface in place: the blurred copy gets richer, as frosted glass does."""
    if abs(amount - 1.0) < 0.01:
        return surface
    surface.flush()
    data = surface.get_data()
    for i in range(0, len(data) - 3, 4):
        b, g, r = data[i], data[i + 1], data[i + 2]
        grey = 0.299 * r + 0.587 * g + 0.114 * b
        data[i] = max(0, min(255, int(grey + (b - grey) * amount)))
        data[i + 1] = max(0, min(255, int(grey + (g - grey) * amount)))
        data[i + 2] = max(0, min(255, int(grey + (r - grey) * amount)))
    surface.mark_dirty()
    return surface


def blur_surface(src, factor, saturation=1.0):
    """A cheap, smooth blur: shrink a lot, then enlarge with bilinear filtering (twice, for smoother falloff)."""
    w, h = src.get_width(), src.get_height()
    out = src
    for f in (factor / 2.0, factor):
        sw, sh = max(2, int(w / f)), max(2, int(h / f))
        small = cairo.ImageSurface(cairo.FORMAT_ARGB32, sw, sh)
        c = cairo.Context(small)
        c.scale(sw / float(out.get_width()), sh / float(out.get_height()))
        c.set_source_surface(out, 0, 0)
        c.get_source().set_filter(cairo.FILTER_BILINEAR)
        c.paint()
        if f == factor:
            saturate(small, saturation)
        big = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
        c = cairo.Context(big)
        c.scale(w / float(sw), h / float(sh))
        c.set_source_surface(small, 0, 0)
        c.get_source().set_filter(cairo.FILTER_BILINEAR)
        c.paint()
        out = big
    return out


class Glass:
    cheap = False
    def __init__(self, width, height, ox=0, oy=0, mode=None):
        """width/height: the monitor; ox/oy: its top-left in screen coordinates. Everything is painted in monitor coordinates."""
        self.w, self.h, self.ox, self.oy = width, height, ox, oy
        self.mode = mode or read_mode()
        self.look = LIGHT if self.mode == "light" else DARK
        self.solid = reduce_transparency()
        self.cheap = satperf.cheap()
        self.path = None
        self.wall = None          # the sharp wallpaper, monitor-sized (to read brightness under each capsule)
        self.blurred = None
        self._cur = {}            # per-capsule tint opacity, eased toward its target
        self._stamp = {}
        self.settling = False
        self.refresh(force=True)

    def set_mode(self, mode, solid=None):
        """Switch dark/light or Reduce Transparency. Returns True when something changed."""
        solid = self.solid if solid is None else solid
        if mode == self.mode and solid == self.solid:
            return False
        self.mode, self.solid = mode, solid
        self.look = LIGHT if mode == "light" else DARK
        self.refresh(force=True)
        return True

    @property
    def text(self):
        return self.look["text"]

    def refresh(self, force=False):
        """Re-read the wallpaper if it changed. Returns True when the picture was rebuilt."""
        path = wallpaper_path()
        if path == self.path and not force:
            return False
        self.path = path
        self.blurred = self.wall = None
        self._cur.clear()
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(path)
            cover = max(self.w / float(pb.get_width()), self.h / float(pb.get_height()))      # xfdesktop "zoomed"
            surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, self.w, self.h)
            c = cairo.Context(surf)
            c.translate((self.w - pb.get_width() * cover) / 2, (self.h - pb.get_height() * cover) / 2)
            c.scale(cover, cover)
            Gdk.cairo_set_source_pixbuf(c, pb, 0, 0)
            c.paint()
            self.wall = surf                     # the sharp wallpaper, for the desktop surface
            if not self.solid and not self.cheap:        # cheap mode never builds the blurred copy
                self.blurred = blur_surface(surf, BLUR_DOWN, self.look["saturation"])
        except Exception as e:      # an unreadable or odd image must never break the shell
            print("satglass: no wallpaper blur (%s)" % e)
        return True

    def _wall_rgb(self, x, y, w, h):
        """The brightest (dark mode) or darkest (light mode) of a few samples of the blurred wallpaper under a rectangle."""
        surf = self.blurred
        data, stride = surf.get_data(), surf.get_stride()
        best = None
        for fx in (0.1, 0.5, 0.9):
            for fy in (0.15, 0.5, 0.85):
                px = int(max(0, min(self.w - 1, x + w * fx)))
                py = int(max(0, min(self.h - 1, y + h * fy)))
                o = py * stride + px * 4
                rgb = (data[o + 2] / 255.0, data[o + 1] / 255.0, data[o] / 255.0)
                lum = luminance(rgb)
                if best is None or (lum > best[0] if self.mode == "dark" else lum < best[0]):
                    best = (lum, rgb)
        return best[1]

    def backdrop(self, cr, dim=0.5):
        """The wallpaper dimmed, for full-screen windows when there is no compositor to see through."""
        if self.wall is not None:
            cr.set_source_surface(self.wall, 0, 0)
            cr.paint()
        else:
            cr.set_source_rgb(0.06, 0.16, 0.45)
            cr.paint()
        cr.set_source_rgba(0, 0, 0, dim)
        cr.paint()

    def shadow(self, cr, x, y, w, h, radii, alpha=1.0):
        """0 14 40 and a contact 0 2 6, drawn as stacked rounded rects (no blur filter needed)."""
        lk = self.look
        for (drop, spread, rgba, n) in ((14, 20, lk["shadow"], 12), (2, 3, lk["contact"], 3)):
            for i in range(n, 0, -1):
                grow = spread * i / n
                round_path(cr, x - grow, y - grow + drop, w + 2 * grow, h + 2 * grow, [r + grow for r in radii])
                cr.set_source_rgba(rgba[0], rgba[1], rgba[2], rgba[3] * alpha * (0.95 / n) * (1 - 0.55 * i / n) * 1.6)
                cr.fill()

    def paint(self, cr, x, y, w, h, radii, alpha=1.0, shadow=True, tint_floor=None, tag=None):
        """Paint one frosted capsule at (x, y, w, h) in monitor coordinates. `alpha` fades the whole thing (0..1).
        `tint_floor` raises the minimum tint opacity (the Index panel carries more text: 0.70)."""
        if alpha <= 0.01 or w < 2 or h < 2:
            return
        lk = self.look
        if self.cheap:                       # one flat rounded rectangle and a hairline edge: nothing else
            round_path(cr, x, y, w, h, radii)
            cr.set_source_rgb(*lk["solid"])
            cr.fill_preserve()
            cr.set_source_rgba(*(tuple(lk["solid_edge"]) + (1.0,))[:4])
            cr.set_line_width(1)
            cr.stroke()
            return
        cr.push_group()
        if shadow:
            self.shadow(cr, x, y, w, h, radii)
        cr.save()
        round_path(cr, x, y, w, h, radii)
        cr.clip()
        if self.blurred is not None and not self.solid:
            cr.set_source_surface(self.blurred, 0, 0)
            cr.paint()
            a = adaptive_alpha(lk, self._wall_rgb(x, y, w, h), tint_floor)
            if tag is not None:                      # ease tint changes over about 200 ms so nothing flickers while a capsule slides
                import time
                now = time.monotonic()
                cur = self._cur.get(tag, a)
                dt = min(0.1, now - self._stamp.get(tag, now))
                cur += (a - cur) * min(1.0, dt / 0.07)
                self._stamp[tag] = now
                if abs(cur - a) > 0.004:
                    self.settling = True
                else:
                    cur = a
                self._cur[tag] = cur
                a = cur
            cr.set_source_rgba(*lk["tint"], a)
        else:
            cr.set_source_rgb(*lk["solid"])
        cr.paint()
        if self.blurred is not None and not self.solid:
            sheen = cairo.LinearGradient(0, y, 0, y + h)
            sheen.add_color_stop_rgba(0.0, 1, 1, 1, lk["sheen"])
            sheen.add_color_stop_rgba(lk["sheen_end"], 1, 1, 1, 0.0)
            cr.set_source(sheen)
            cr.paint()
        cr.restore()
        edge = cairo.LinearGradient(0, y, 0, y + h)
        if self.blurred is not None and not self.solid:
            edge.add_color_stop_rgba(0.0, 1, 1, 1, lk["edge_top"])
            edge.add_color_stop_rgba(0.35, 1, 1, 1, lk["edge_side"])
            edge.add_color_stop_rgba(1.0, 1, 1, 1, lk["edge_side"])
        else:
            edge.add_color_stop_rgba(0.0, *(tuple(lk["solid_edge"]) + (1.0,))[:4])
            edge.add_color_stop_rgba(1.0, *(tuple(lk["solid_edge"]) + (1.0,))[:4])
        round_path(cr, x + 0.5, y + 0.5, w - 1, h - 1, [max(0, r - 0.5) for r in radii])
        cr.set_source(edge)
        cr.set_line_width(1)
        cr.stroke()
        round_path(cr, x - 0.5, y - 0.5, w + 1, h + 1, [r + 0.5 for r in radii])
        cr.set_source_rgba(*lk["outline"])
        cr.set_line_width(1)
        cr.stroke()
        cr.pop_group_to_source()
        cr.paint_with_alpha(alpha)
