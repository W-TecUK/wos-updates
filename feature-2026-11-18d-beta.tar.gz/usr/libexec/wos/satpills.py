"""satpills: the live things on the right of the shelf, from the real sources.
- Music: any MPRIS player (Firefox, Spotify, VLC, ...) that is playing or paused. Click the pill to play/pause.
- Update: a W-OS update that is installed and waiting for a restart (from the updater's own state file).
The updater does not report download progress, so there is no progress bar yet. Pills appear only while live."""
import json
import os

STATE_FILE = "/var/lib/wos/updates.json"
MPRIS = "org.mpris.MediaPlayer2"


def _name_from_url(url):
    from urllib.parse import unquote, urlparse
    try:
        base = os.path.splitext(os.path.basename(unquote(urlparse(url).path)))[0]
    except ValueError:
        return ""
    return base.replace("_", " ").strip()


def music_pill(props, app_name=None):
    """props: the player's Player-interface properties as plain Python. None when nothing is playing.
    The title is the track (or the file name for a video), the second line is the app and the artist."""
    status = props.get("PlaybackStatus")
    if status not in ("Playing", "Paused"):
        return None
    meta = props.get("Metadata") or {}
    title = meta.get("xesam:title") or (_name_from_url(meta.get("xesam:url") or "") if meta.get("xesam:url") else "") or app_name or "Music"
    artists = meta.get("xesam:artist") or []
    if isinstance(artists, str):
        artists = [artists]
    paused = status == "Paused"
    if app_name:
        parts = [app_name] + ([", ".join(artists)] if artists else [])
        state = ("Paused · " if paused else "") + " · ".join(parts)
    else:
        state = "%s%s" % ("Paused" if paused else "Playing", " · " + ", ".join(artists) if artists else "")
    return {"id": "music", "icon": "audio-x-generic", "title": title[:40], "state": state[:48], "progress": None}


def update_pill(state):
    pending = (state or {}).get("pending")
    if not pending:
        return None
    return {"id": "update", "icon": "system-software-update", "title": "W-OS update", "state": "Restart to finish", "progress": None}


def read_state(path=STATE_FILE):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


class PillSources:
    """Polls the sources every few seconds and keeps the shelf's pills in step."""

    def __init__(self, shelf, state_file=STATE_FILE, interval_ms=5000):
        from gi.repository import Gio, GLib
        self.Gio, self.GLib = Gio, GLib
        self.shelf, self.state_file = shelf, state_file
        self.player = None
        self.status, self.names, self.started, self._pending = {}, {}, {}, None
        try:
            self.bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        except GLib.Error:
            self.bus = None
        shelf.on_pill = self.clicked
        self._watch()
        self.poll()
        GLib.timeout_add(interval_ms, self.poll)

    def _call(self, name, iface, method, params, reply):
        return self.bus.call_sync(name, "/org/mpris/MediaPlayer2", iface, method, params, reply, self.Gio.DBusCallFlags.NONE, 120, None)

    def _players(self):
        if self.bus is None:
            return []
        try:
            names = self.bus.call_sync("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "ListNames", None,
                                       self.GLib.VariantType("(as)"), self.Gio.DBusCallFlags.NONE, 120, None).unpack()[0]
        except self.GLib.Error:
            return []
        return [n for n in names if n.startswith(MPRIS + ".")]

    def _watch(self):
        """Players announce every change (new track, play, pause) as a D-Bus signal, and many send the track details a moment
        after the play signal. Re-read soon after any of them, so the pill is not up to 5 seconds late or missing its title."""
        if self.bus is None:
            return
        Gio = self.Gio
        self.bus.signal_subscribe(None, "org.freedesktop.DBus.Properties", "PropertiesChanged", "/org/mpris/MediaPlayer2", None,
                                  Gio.DBusSignalFlags.NONE, lambda *a: self._soon())
        self.bus.signal_subscribe("org.freedesktop.DBus", "org.freedesktop.DBus", "NameOwnerChanged", "/org/freedesktop/DBus", None,
                                  Gio.DBusSignalFlags.NONE, lambda *a: self._soon())

    def _soon(self):
        if self._pending is None:
            self._pending = self.GLib.timeout_add(150, self._soon_run)

    def _soon_run(self):
        self._pending = None
        self.poll()
        return False

    def _app_name(self, name):
        if name not in self.names:
            try:
                root = self._call(name, "org.freedesktop.DBus.Properties", "GetAll", self.GLib.Variant("(s)", (MPRIS,)),
                                  self.GLib.VariantType("(a{sv})")).unpack()[0]
                self.names[name] = (root.get("Identity") or "", (root.get("DesktopEntry") or root.get("Identity") or "").lower() or None)
            except self.GLib.Error:
                return ("", None)
        return self.names[name]

    def _app_icon(self, entry):
        """The player's own icon, taken from its launcher file; None when it has none (the generic music icon is used)."""
        if not entry:
            return None
        try:
            info = self.Gio.DesktopAppInfo.new(entry if entry.endswith(".desktop") else entry + ".desktop")
            icon = info.get_icon() if info else None
            return icon.to_string() if icon else None
        except (TypeError, self.GLib.Error):
            return None

    def current_music(self):
        """The player that most recently started playing wins; if none is playing, the one that played last."""
        import time
        found = []
        gone = set(self.status) - set(self._players())
        for name in gone:
            self.status.pop(name, None); self.names.pop(name, None); self.started.pop(name, None)
        for name in self._players():
            try:
                v = self._call(name, "org.freedesktop.DBus.Properties", "GetAll", self.GLib.Variant("(s)", (MPRIS + ".Player",)),
                               self.GLib.VariantType("(a{sv})")).unpack()[0]
            except self.GLib.Error:
                continue
            st = v.get("PlaybackStatus")
            if st == "Playing" and self.status.get(name) != "Playing":
                self.started[name] = time.monotonic()
            self.status[name] = st
            ident, entry = self._app_name(name)
            pill = music_pill(v, ident or None)
            if pill:
                pill["app"] = entry
                pill["icon"] = self._app_icon(entry) or pill["icon"]
                found.append((st == "Playing", self.started.get(name, 0), name, pill))
        if not found:
            return None
        found.sort(key=lambda f: (f[0], f[1]))
        _, _, self.player, pill = found[-1]
        return pill

    def poll(self):
        for pid, pill in (("music", self.current_music()), ("update", update_pill(read_state(self.state_file)))):
            cur = next((p for p in self.shelf.pills if p["id"] == pid), None)
            if pill is None:
                if cur:
                    self.shelf.remove_pill(pid)
            elif not cur or any(cur.get(k) != pill[k] for k in ("title", "state", "icon")):
                self.shelf.set_pill(pill["id"], pill["icon"], pill["title"], pill["state"], pill["progress"], pill.get("app"))
        return True

    def clicked(self, pill):
        if pill["id"] == "update":                      # a waiting update: ask, then restart
            import subprocess
            try:
                subprocess.Popen(["/usr/libexec/wos/wos-update-restart"])
            except OSError:
                pass
            return
        if pill["id"] == "music" and self.player and self.bus:
            try:
                self._call(self.player, MPRIS + ".Player", "PlayPause", None, None)
            except self.GLib.Error:
                pass
