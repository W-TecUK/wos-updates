"""Satisfaction v0.2: a small W-OS-native language with its OWN interpreter -- not a translator
into some other language's runtime. This file is the whole language: a tokenizer, a recursive-
descent parser, and a tree-walking evaluator, all in plain Python (the language every other part
of W-OS is already written in), with no other runtime underneath it.

Vendored, not developed here: the language itself lives at
https://github.com/W-TecUK/satisfaction-lang (own tests, own CLI, own examples), currently at
commit 3d240b8. This copy is exactly that file, unmodified -- update it by pulling the upstream
repo's newer satlang.py, not by editing this one in place.

Deliberately easier than Swift, not a smaller Swift: no optionals, no generics, no protocols, no
type annotations at all. A value is a number, a string, a boolean, nil, a list, or a function.
Errors are always "line N: what went wrong", in plain English, because the person hitting one is
learning, not debugging a stranger's code.

  .satif  logic: let/var, func, if/else, while, for ... in ..., return, the usual operators,
          Swift-style string interpolation ("Count: \\(count)"), list literals [1, 2, 3].
  .satUI  a declarative view tree (View/VStack/HStack/Text/Button/Spacer), evaluated against the
          live program state every time it's asked to render -- not compiled once and thrown away.
"""
import re


class SatError(Exception):
    def __init__(self, line, message):
        super().__init__("Line %s: %s" % (line if line is not None else "?", message))
        self.line, self.message = line, message


# ---------------------------------------------------------------- lexer
KEYWORDS = {"let", "var", "func", "if", "else", "while", "for", "in", "return", "true", "false", "nil"}
TOKEN_RE = re.compile(r"""
    (?P<newline>\n)
  | (?P<ws>[^\S\n]+)
  | (?P<comment>//[^\n]*)
  | (?P<string>"(?:\\.|[^"\\])*")
  | (?P<number>\d+(?:\.\d+)?)
  | (?P<ident>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<op>==|!=|<=|>=|&&|\|\||[-+*/=<>!(){}\[\],.])
""", re.VERBOSE)


class Token:
    __slots__ = ("kind", "value", "line")

    def __init__(self, kind, value, line):
        self.kind, self.value, self.line = kind, value, line

    def __repr__(self):
        return "%s(%r)@%s" % (self.kind, self.value, self.line)


def lex(source):
    tokens, pos, line = [], 0, 1
    while pos < len(source):
        m = TOKEN_RE.match(source, pos)
        if not m:
            raise SatError(line, "I don't understand %r here." % source[pos:pos + 12])
        pos = m.end()
        kind = m.lastgroup
        if kind == "newline":
            line += 1
            continue
        if kind in ("ws", "comment"):
            continue
        text = m.group()
        if kind == "ident" and text in KEYWORDS:
            tokens.append(Token(text, text, line))
        else:
            tokens.append(Token(kind, text, line))
    tokens.append(Token("eof", "", line))
    return tokens


# ---------------------------------------------------------------- string interpolation
def parse_string_literal(raw, line):
    """"Hi \\(name)" is Swift's own interpolation syntax, kept exactly. Returns a list of parts:
    plain strings and ("expr", ExprAST) pieces, evaluated and joined at run time."""
    body = raw[1:-1]
    parts, i = [], 0
    while i < len(body):
        m = re.match(r"\\\(", body[i:])
        if m:
            depth, j = 1, i + 2
            while j < len(body) and depth:
                if body[j] == "(":
                    depth += 1
                elif body[j] == ")":
                    depth -= 1
                j += 1
            inner = body[i + 2:j - 1]
            parts.append(("expr", Parser(lex(inner)).expr()))
            i = j
            continue
        m = re.match(r"\\[nt\\\"]", body[i:])
        if m:
            parts.append(("text", {"\\n": "\n", "\\t": "\t", "\\\\": "\\", "\\\"": "\""}[m.group()]))
            i += 2
            continue
        parts.append(("text", body[i]))
        i += 1
    # merge consecutive plain-text parts
    merged = []
    for kind, value in parts:
        if kind == "text" and merged and merged[-1][0] == "text":
            merged[-1] = ("text", merged[-1][1] + value)
        else:
            merged.append((kind, value))
    return merged


# ---------------------------------------------------------------- parser (shared grammar)
class Parser:
    def __init__(self, tokens):
        self.tokens, self.i = tokens, 0

    def peek(self):
        return self.tokens[self.i]

    def at(self, kind, value=None):
        t = self.tokens[self.i]
        return t.kind == kind and (value is None or t.value == value)

    def eat(self, kind=None, value=None):
        t = self.tokens[self.i]
        if kind and t.kind != kind:
            raise SatError(t.line, "expected %r but found %r." % (kind, t.value))
        if value and t.value != value:
            raise SatError(t.line, "expected %r but found %r." % (value, t.value))
        self.i += 1
        return t

    # ---- statements
    def block(self):
        self.eat("op", "{")
        stmts = []
        while not self.at("op", "}"):
            stmts.append(self.statement())
        self.eat("op", "}")
        return stmts

    def statement(self):
        t = self.peek()
        if t.kind in ("let", "var"):
            self.eat()
            name = self.eat("ident").value
            self.eat("op", "=")
            value = self.expr()
            return ("decl", name, value, t.line)
        if t.kind == "func":
            self.eat()
            name = self.eat("ident").value
            self.eat("op", "(")
            params = []
            while not self.at("op", ")"):
                params.append(self.eat("ident").value)
                if self.at("op", ","):
                    self.eat()
            self.eat("op", ")")
            return ("func", name, params, self.block(), t.line)
        if t.kind == "if":
            self.eat()
            self.eat("op", "(")
            cond = self.expr()
            self.eat("op", ")")
            then = self.block()
            otherwise = None
            if self.at("else"):
                self.eat()
                otherwise = [self.statement()] if self.at("if") else self.block()
            return ("if", cond, then, otherwise, t.line)
        if t.kind == "while":
            self.eat()
            self.eat("op", "(")
            cond = self.expr()
            self.eat("op", ")")
            return ("while", cond, self.block(), t.line)
        if t.kind == "for":
            self.eat()
            name = self.eat("ident").value
            self.eat("in")
            iterable = self.expr()
            return ("for", name, iterable, self.block(), t.line)
        if t.kind == "return":
            self.eat()
            value = None
            if not self.at("op", "}"):
                value = self.expr()
            return ("return", value, t.line)
        expr = self.expr()
        return ("expr", expr, t.line)

    # ---- expressions (precedence climbing)
    def expr(self):
        return self.assignment()

    def assignment(self):
        left = self.logic_or()
        if self.at("op", "="):
            self.eat()
            return ("assign", left, self.assignment(), left[-1] if isinstance(left, tuple) else 0)
        return left

    def _binary(self, next_level, ops):
        left = next_level()
        while self.at("op") and self.peek().value in ops:
            line = self.peek().line
            op = self.eat().value
            left = ("bin", op, left, next_level(), line)
        return left

    def logic_or(self):
        return self._binary(self.logic_and, ("||",))

    def logic_and(self):
        return self._binary(self.equality, ("&&",))

    def equality(self):
        return self._binary(self.comparison, ("==", "!="))

    def comparison(self):
        return self._binary(self.additive, ("<", "<=", ">", ">="))

    def additive(self):
        return self._binary(self.multiplicative, ("+", "-"))

    def multiplicative(self):
        return self._binary(self.unary, ("*", "/"))

    def unary(self):
        if self.at("op") and self.peek().value in ("!", "-"):
            line = self.peek().line
            op = self.eat().value
            return ("unary", op, self.unary(), line)
        return self.call_or_primary()

    def call_or_primary(self):
        node = self.primary()
        while True:
            if self.at("op", "("):
                line = self.eat().line
                args = []
                while not self.at("op", ")"):
                    args.append(self.expr())
                    if self.at("op", ","):
                        self.eat()
                self.eat("op", ")")
                node = ("call", node, args, line)
            elif self.at("op", "."):
                self.eat()
                name = self.eat("ident").value
                node = ("member", node, name, node[-1])
            elif self.at("op", "["):
                line = self.eat().line
                index = self.expr()
                self.eat("op", "]")
                node = ("index", node, index, line)
            else:
                return node

    def primary(self):
        t = self.peek()
        if t.kind == "number":
            self.eat()
            return ("num", float(t.value) if "." in t.value else int(t.value), t.line)
        if t.kind == "string":
            self.eat()
            return ("str", parse_string_literal(t.value, t.line), t.line)
        if t.kind in ("true", "false"):
            self.eat()
            return ("bool", t.kind == "true", t.line)
        if t.kind == "nil":
            self.eat()
            return ("nil", None, t.line)
        if t.kind == "ident":
            self.eat()
            return ("ident", t.value, t.line)
        if t.kind == "op" and t.value == "[":
            self.eat()
            items = []
            while not self.at("op", "]"):
                items.append(self.expr())
                if self.at("op", ","):
                    self.eat()
            self.eat("op", "]")
            return ("list", items, t.line)
        if t.kind == "op" and t.value == "(":
            self.eat()
            e = self.expr()
            self.eat("op", ")")
            return e
        raise SatError(t.line, "I didn't expect %r here." % t.value)


# ---------------------------------------------------------------- interpreter
class ReturnSignal(Exception):
    def __init__(self, value):
        self.value = value


class SatFunction:
    def __init__(self, name, params, body, closure):
        self.name, self.params, self.body, self.closure = name, params, body, closure


class Environment:
    def __init__(self, parent=None):
        self.vars, self.parent = {}, parent

    def define(self, name, value):
        self.vars[name] = value

    def get(self, name, line):
        env = self
        while env is not None:
            if name in env.vars:
                return env.vars[name]
            env = env.parent
        raise SatError(line, "I don't know what \"%s\" is. Did you spell it right, or forget a `let`?" % name)

    def set(self, name, value, line):
        env = self
        while env is not None:
            if name in env.vars:
                env.vars[name] = value
                return
            env = env.parent
        raise SatError(line, "I can't change \"%s\" because it was never declared with `let` or `var`." % name)


def truthy(v):
    return bool(v) and v != 0


def sat_type_name(v):
    if v is None:
        return "nil"
    if isinstance(v, bool):
        return "a true/false value"
    if isinstance(v, (int, float)):
        return "a number"
    if isinstance(v, str):
        return "text"
    if isinstance(v, list):
        return "a list"
    if isinstance(v, SatFunction):
        return "a function"
    return type(v).__name__


def to_display_string(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    if isinstance(v, list):
        return "[" + ", ".join(to_display_string(x) for x in v) + "]"
    return str(v)


class Interpreter:
    def __init__(self, builtins=None):
        self.globals = Environment()
        for name, fn in (builtins or {}).items():
            self.globals.define(name, fn)

    def run(self, statements):
        for s in statements:
            self.exec_stmt(s, self.globals)

    # ---- statements
    def exec_stmt(self, node, env):
        kind = node[0]
        if kind == "decl":
            _, name, value_node, line = node
            env.define(name, self.eval_expr(value_node, env))
        elif kind == "func":
            _, name, params, body, line = node
            env.define(name, SatFunction(name, params, body, env))
        elif kind == "if":
            _, cond, then, otherwise, line = node
            if truthy(self.eval_expr(cond, env)):
                self.exec_block(then, env)
            elif otherwise is not None:
                self.exec_block(otherwise, env)
        elif kind == "while":
            _, cond, body, line = node
            guard = 0
            while truthy(self.eval_expr(cond, env)):
                self.exec_block(body, env)
                guard += 1
                if guard > 1_000_000:
                    raise SatError(line, "This `while` looped a million times without stopping -- check the condition ever becomes false.")
        elif kind == "for":
            _, name, iterable_node, body, line = node
            value = self.eval_expr(iterable_node, env)
            if not isinstance(value, list):
                raise SatError(line, "`for %s in ...` needs a list, but got %s." % (name, sat_type_name(value)))
            for item in value:
                loop_env = Environment(env)
                loop_env.define(name, item)
                self.exec_block(body, loop_env)
        elif kind == "return":
            _, value_node, line = node
            raise ReturnSignal(self.eval_expr(value_node, env) if value_node is not None else None)
        elif kind == "expr":
            self.eval_expr(node[1], env)
        else:
            raise SatError(node[-1], "internal: don't know how to run %r" % (kind,))

    def exec_block(self, statements, parent_env):
        env = Environment(parent_env)
        for s in statements:
            self.exec_stmt(s, env)

    # ---- expressions
    def eval_expr(self, node, env):
        kind = node[0]
        if kind == "num" or kind == "bool" or kind == "nil":
            return node[1]
        if kind == "str":
            out = []
            for part_kind, part in node[1]:
                out.append(part if part_kind == "text" else to_display_string(self.eval_expr(part, env)))
            return "".join(out)
        if kind == "list":
            return [self.eval_expr(e, env) for e in node[1]]
        if kind == "ident":
            return env.get(node[1], node[2])
        if kind == "assign":
            target, value_node, line = node[1], node[2], node[3]
            value = self.eval_expr(value_node, env)
            if target[0] == "ident":
                env.set(target[1], value, line)
            elif target[0] == "index":
                lst = self.eval_expr(target[1], env)
                idx = self.eval_expr(target[2], env)
                if not isinstance(lst, list) or not isinstance(idx, int):
                    raise SatError(line, "That's not something I can put a value into like a list slot.")
                lst[idx] = value
            else:
                raise SatError(line, "I can't assign to that -- only a name or a list slot.")
            return value
        if kind == "unary":
            _, op, operand_node, line = node
            v = self.eval_expr(operand_node, env)
            if op == "-":
                if not isinstance(v, (int, float)):
                    raise SatError(line, "Can't put a minus sign in front of %s -- that's only for numbers." % sat_type_name(v))
                return -v
            return not truthy(v)
        if kind == "bin":
            _, op, left_node, right_node, line = node
            left = self.eval_expr(left_node, env)
            if op == "&&":
                return left if not truthy(left) else self.eval_expr(right_node, env)
            if op == "||":
                return left if truthy(left) else self.eval_expr(right_node, env)
            right = self.eval_expr(right_node, env)
            return self.apply_binary(op, left, right, line)
        if kind == "index":
            _, coll_node, index_node, line = node
            coll = self.eval_expr(coll_node, env)
            index = self.eval_expr(index_node, env)
            if not isinstance(coll, list):
                raise SatError(line, "Only a list can be indexed with [ ], but this is %s." % sat_type_name(coll))
            if not isinstance(index, int) or index < 0 or index >= len(coll):
                raise SatError(line, "That list doesn't have an item at position %s." % to_display_string(index))
            return coll[index]
        if kind == "member":
            raise SatError(node[-1], "Satisfaction doesn't have . properties yet.")
        if kind == "call":
            return self.eval_call(node, env)
        raise SatError(node[-1], "internal: don't know how to evaluate %r" % (kind,))

    def apply_binary(self, op, left, right, line):
        if op == "+":
            if isinstance(left, str) or isinstance(right, str):
                return to_display_string(left) + to_display_string(right)
            if isinstance(left, list) and isinstance(right, list):
                return left + right
            if isinstance(left, (int, float)) and isinstance(right, (int, float)):
                return left + right
            raise SatError(line, "Can't add %s and %s together." % (sat_type_name(left), sat_type_name(right)))
        if op in ("-", "*", "/"):
            if not (isinstance(left, (int, float)) and isinstance(right, (int, float))):
                raise SatError(line, "Both sides of `%s` need to be numbers -- got %s and %s." % (op, sat_type_name(left), sat_type_name(right)))
            if op == "/" and right == 0:
                raise SatError(line, "Can't divide by zero.")
            return {"-": lambda a, b: a - b, "*": lambda a, b: a * b, "/": lambda a, b: a / b}[op](left, right)
        if op == "==":
            return left == right
        if op == "!=":
            return left != right
        if op in ("<", "<=", ">", ">="):
            if not (isinstance(left, (int, float)) and isinstance(right, (int, float))):
                raise SatError(line, "Can only compare numbers with `%s`, not %s and %s." % (op, sat_type_name(left), sat_type_name(right)))
            return {"<": left < right, "<=": left <= right, ">": left > right, ">=": left >= right}[op]
        raise SatError(line, "internal: unknown operator %r" % op)

    def invoke(self, fn, args, name="that function"):
        """Calls a SatFunction with already-evaluated Python argument values. Shared by eval_call
        (a call written in the program) and call_by_name (a host driving a function directly --
        a clock tick, a timer, anything that isn't a click)."""
        if len(args) != len(fn.params):
            raise SatError(None, "%s needs %d value(s), but got %d." % (name, len(fn.params), len(args)))
        call_env = Environment(fn.closure)
        for p, a in zip(fn.params, args):
            call_env.define(p, a)
        try:
            for s in fn.body:
                self.exec_stmt(s, call_env)
        except ReturnSignal as r:
            return r.value
        return None

    def call_by_name(self, name, args=()):
        """For a host that needs to run a Satisfaction function directly, not from a click --
        a periodic clock tick, a timer, a notification callback. Raises SatError if there's no
        such function."""
        fn = self.globals.vars.get(name)
        if not isinstance(fn, SatFunction):
            raise SatError(None, "There's no function called \"%s\" to run." % name)
        return self.invoke(fn, list(args), name)

    def eval_call(self, node, env):
        _, callee_node, arg_nodes, line = node
        args = [self.eval_expr(a, env) for a in arg_nodes]
        if callee_node[0] != "ident":
            raise SatError(line, "That's not something I can call like a function.")
        name = callee_node[1]
        fn = env.get(name, line)
        if callable(fn) and not isinstance(fn, SatFunction):
            try:
                return fn(*args)
            except SatError:
                raise
            except Exception as e:
                raise SatError(line, "%s ran into a problem: %s" % (name, e))
        if isinstance(fn, SatFunction):
            try:
                return self.invoke(fn, args, name)
            except SatError as e:
                raise SatError(line, e.message) if e.line is None else e
        raise SatError(line, "\"%s\" is %s, not something I can call." % (name, sat_type_name(fn)))


# ---------------------------------------------------------------- .satUI: view tree, evaluated live
CSS_CLASS = {"View": "sat-view", "VStack": "sat-vstack", "HStack": "sat-hstack", "ZStack": "sat-zstack",
             "Text": "sat-text", "Button": "sat-button", "Spacer": "sat-spacer"}


class UIParser(Parser):
    def view(self):
        name = self.eat("ident").value
        args = []
        if self.at("op", "("):
            self.eat()
            while not self.at("op", ")"):
                args.append(self.expr())
                if self.at("op", ","):
                    self.eat()
            self.eat("op", ")")
        block = None
        if self.at("op", "{"):
            self.eat()
            if name == "Button":
                block = ("stmts", [])
                while not self.at("op", "}"):
                    block[1].append(self.statement())
            else:
                block = ("views", [])
                while not self.at("op", "}"):
                    block[1].append(self.view())
            self.eat("op", "}")
        return (name, args, block)


def parse_satui(source):
    return UIParser(lex(source)).view()


def parse_satif(source):
    p = Parser(lex(source))
    stmts = []
    while not p.at("eof"):
        stmts.append(p.statement())
    return stmts


def render_view(node, interpreter, env, next_handler_id, handlers):
    """Walks a .satUI AST against the CURRENT program state and produces a plain JSON-able tree.
    Runs on every render, not once at compile time -- so `Text("Count: \\(count)")` always shows
    the real, live value of count."""
    name, arg_nodes, block = node
    text = interpreter.eval_expr(arg_nodes[0], env) if arg_nodes else None
    out = {"tag": name, "class": CSS_CLASS.get(name, "sat-" + name.lower()), "text": to_display_string(text) if text is not None else None}
    if block is None:
        return out
    if block[0] == "stmts":
        handler_id = "h%d" % next_handler_id[0]
        next_handler_id[0] += 1
        handlers[handler_id] = (block[1], env)
        out["action"] = handler_id
        return out
    out["children"] = [render_view(v, interpreter, env, next_handler_id, handlers) for v in block[1]]
    return out
