"use strict";
/* App Store: discover apps, see what is installed, check for updates.
   The catalogue below is a placeholder list until the App Store service exists; installing is not
   wired up yet, so "Get" says so instead of pretending. */

boot(async info => {
  const root = $("#root");
  let tab = "discover", installed = [], catalogue = [], busy = new Set(), progress = new Map();
  const load = async () => { try { installed = await wos.call("sys.apps"); } catch (e) { installed = []; } try { catalogue = await wos.call("store.catalogue"); } catch (e) { catalogue = []; } };
  await load();
  wos.on("store-progress", m => { progress.set(m.key, m); draw(); });
  const has = c => c.installed;
  const appIcon = c => c.icon
    ? h("img", { src: "../../store/icons/" + c.icon + ".svg", width: 52, height: 52, style: "border-radius:14px;flex:none;display:block" })
    : h("div", { style: "width:52px;height:52px;border-radius:14px;background:var(--panel-2);display:grid;place-items:center;flex:none", html: icon(c.glyph || "grid", 26) });
  const badge = c => c.kind === "web" ? "Web app" : c.kind === "flatpak" ? "App" : c.kind === "wine" ? "Experimental" : "";

  const nav = h("nav.nav"); const body = h("div.body");
  const side = h("aside.side", h("span.label", { style: "margin-top:0" }, "App Store"), nav);
  root.append(h("div.app", side, h("div.main", body)));

  function drawNav() {
    nav.innerHTML = "";
    [["discover", "Discover", "bag"], ["installed", "Installed", "grid"], ["updates", "Updates", "refresh"]].forEach(([k, l, i]) =>
      nav.append(h("button" + (tab === k ? ".on" : ""), { onclick: () => { tab = k; draw(); } }, h("span", { html: icon(i) }), l)));
  }
  const getBtn = c => {
    const key = c.package || c.id;
    if (busy.has(key)) {
      const p = progress.get(key);
      return h("div", { style: "display:flex;flex-direction:column;gap:4px;min-width:120px" },
        h("div.small.muted", p ? p.note : "Working…"),
        h("div", { style: "height:4px;border-radius:999px;background:var(--panel-2);overflow:hidden" },
          h("div", { style: `height:100%;border-radius:999px;background:var(--accent);width:${p ? p.pct : 8}%;transition:width .25s ease` })));
    }
    if (c.installed) return h("button.btn.ghost.small", { onclick: () => act(c, "store.remove", "Removed") }, "Remove");
    return h("button.btn.small", { onclick: () => act(c, "store.install", "Installed") }, "Get");
  };
  function showDetails(c) {
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) back.remove(); } },
      h("div.modal", { style: "max-width:420px" },
        h("div", { style: "display:flex;gap:16px;align-items:center;margin-bottom:14px" }, appIcon(c),
          h("div", h("h2", { style: "margin:0" }, c.name), h("div.small.muted", [c.by, badge(c)].filter(Boolean).join("  ·  ")))),
        h("p.muted", c.blurb || ""),
        c.note ? h("p.small.muted", c.note) : null,
        h("div.actions", h("button.btn.ghost", { onclick: () => back.remove() }, "Close"),
          h("button.btn" + (c.installed ? ".ghost" : ""), {
            onclick: async () => { back.remove(); await act(c, c.installed ? "store.remove" : "store.install", c.installed ? "Removed" : "Installed"); }
          }, c.installed ? "Remove" : "Get"))));
    document.body.append(back);
  }
  async function act(c, method, done) {
    const key = c.package || c.id;
    busy.add(key); progress.delete(key); draw();
    try { await wos.call(method, c.kind === "web" || c.kind === "flatpak" || c.kind === "wine" ? { id: c.id } : { package: c.package }); toast(c.name + ": " + done); } catch (e) { toast(e.message); }
    busy.delete(key); progress.delete(key); await load(); draw();
  }

  function draw() {
    drawNav(); body.innerHTML = "";
    if (tab === "discover") {
      body.append(h("h1.dots", { style: "font-size:40px;margin:4px 0 4px" }, "Discover"), h("p.muted", { style: "margin:0 0 20px" }, "Apps picked for W-OS."));
      const order = ["Music", "Microsoft", "Developer", "Work", "Internet", "Video", "Creative", "Security"];
      const rank = c => { const i = order.indexOf(c); return i < 0 ? 99 : i; };
      const cats = [...new Set(catalogue.map(c => c.cat))].sort((x, y) => rank(x) - rank(y) || x.localeCompare(y));
      cats.forEach(cat => {
        body.append(h("div.label", { style: "margin:18px 0 10px" }, cat));
        const grid = h("div.grid", { style: "grid-template-columns:repeat(auto-fill,minmax(250px,1fr))" });
        catalogue.filter(c => c.cat === cat).forEach(c => grid.append(h("div.card.pad", { style: "display:flex;gap:14px;align-items:center" },
          h("div", { style: "display:flex;gap:14px;align-items:center;flex:1;min-width:0;cursor:pointer", onclick: () => showDetails(c) },
            appIcon(c),
            h("div", { style: "flex:1;min-width:0" }, h("div", { style: "font-weight:800" }, c.name), h("div.small.muted", c.blurb), h("div.small.muted", { style: "opacity:.7" }, [c.by, badge(c)].filter(Boolean).join("  ·  ")),
              c.note && !c.installed ? h("div.small.muted", { style: "opacity:.7" }, c.note) : "")),
          getBtn(c))));
        body.append(grid);
      });
    } else if (tab === "installed") {
      body.append(h("h1", { style: "margin:4px 0 16px" }, "Installed"), h("div.card", h("div.list", installed.map(a => h("div.row", { style: "cursor:default" },
        h("div.grow", h("div.t", a.name), h("div.s", a.description || "")), h("button.btn.ghost.small", { onclick: () => wos.call("sys.launch", { id: a.id }) }, "Open"))))));
    } else {
      body.append(h("h1", { style: "margin:4px 0 16px" }, "Updates"), h("div.card.pad", { style: "display:flex;align-items:center;gap:14px" },
        h("span", { html: icon("check", 26), style: "color:var(--ok)" }), h("div", { style: "flex:1" }, h("div", { style: "font-weight:800" }, "W-OS is up to date"), h("div.small.muted", `Version ${info.version}`)),
        h("button.btn.ghost.small", { onclick: async () => { toast("Checking…"); try { await wos.call("store.refresh"); toast("Up to date"); } catch (e) { toast(e.message); } } }, "Check now")));
    }
  }
  draw();
});
