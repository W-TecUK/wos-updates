"""Accessibility choices: text size for W-OS apps, and, desktop-wide, the pointer size and the keyboard helpers.

Pure functions (tested anywhere). `commands` turns the person's choices into the xfconf-query calls wos-apply-prefs runs.
Text size is deliberately NOT applied through the screen's DPI: the desktop shell (bar, dock, widgets) is drawn by web views
that follow the DPI and its fixed layout breaks when it changes (found on the real image). W-OS apps zoom their own pages.
"""
TEXT_SCALES = (100, 115, 130, 150, 175, 200)         # percent
CURSOR_SIZES = (24, 32, 48, 64)                       # pixels
KEYBOARD_KEYS = ("sticky", "slow", "bounce")
SYSTEM_KEYS = ("mono", "steady_cursor", "scrollbars")  # mono sound, a cursor that does not blink, scrollbars that stay visible
CLICK_SPEEDS = (400, 600, 800, 1000)                  # ms allowed between the two clicks of a double-click
SWITCHES = KEYBOARD_KEYS + SYSTEM_KEYS


def clean_prefs(raw):
    """Whatever was saved -> {text_scale, cursor_size, sticky, slow, bounce}. The old on/off 'Bigger text' counts as 115 %."""
    raw = raw if isinstance(raw, dict) else {}
    scale = raw.get("text_scale")
    if scale not in TEXT_SCALES:
        scale = 115 if raw.get("zoom") else 100
    size = raw.get("cursor_size")
    if size not in CURSOR_SIZES:
        size = CURSOR_SIZES[0]
    click = raw.get("click_speed")
    out = {"text_scale": scale, "cursor_size": size, "click_speed": click if click in CLICK_SPEEDS else CLICK_SPEEDS[0]}
    for k in SWITCHES:
        out[k] = bool(raw.get(k))
    return out


def page_zoom(prefs):
    """The zoom factor W-OS apps apply to their own pages."""
    return clean_prefs(prefs)["text_scale"] / 100


def commands(prefs):
    p = clean_prefs(prefs)
    set_ = lambda channel, prop, kind, value: ["xfconf-query", "-c", channel, "-p", prop, "-n", "-t", kind, "-s", str(value)]      # noqa: E731
    out = [set_("xsettings", "/Gtk/CursorThemeSize", "int", p["cursor_size"])]
    for key, prop in (("sticky", "/StickyKeys"), ("slow", "/SlowKeys"), ("bounce", "/BounceKeys")):
        out.append(set_("accessibility", prop, "bool", "true" if p[key] else "false"))
    out.append(set_("xsettings", "/Net/CursorBlink", "bool", "false" if p["steady_cursor"] else "true"))
    out.append(set_("xsettings", "/Gtk/OverlayScrolling", "bool", "false" if p["scrollbars"] else "true"))
    out.append(set_("xsettings", "/Net/DoubleClickTime", "int", p["click_speed"]))
    # "Reduce motion" (an older switch, read from the raw file) also turns off animations in GTK programs
    out.append(set_("xsettings", "/Gtk/EnableAnimations", "bool", "false" if (prefs or {}).get("motion") else "true"))
    return out


MONO_SINK = "wos_mono"


def mono_commands(prefs, default_sink=None):
    """Mono sound: a virtual sink that mixes left and right together, made the default. Off removes it. Needs pactl."""
    if clean_prefs(prefs)["mono"]:
        if not default_sink or default_sink == MONO_SINK:
            return []
        return [["pactl", "load-module", "module-remap-sink", "sink_name=" + MONO_SINK, "master=" + default_sink,
                 "channels=2", "channel_map=mono,mono", "remix=yes"], ["pactl", "set-default-sink", MONO_SINK]]
    return [["pactl", "unload-module", "module-remap-sink"]] if default_sink == MONO_SINK else []
