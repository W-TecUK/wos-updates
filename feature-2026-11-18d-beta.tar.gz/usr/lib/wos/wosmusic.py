"""W-OS Music: the parts that are not on screen. Library scan and tags, the play queue, and a small client for mpv (which plays
the sound: it is already in the image and handles every common format). No GTK in here, so it can be tested on its own."""
import json
import os
import re
import socket
import subprocess
import tempfile
import threading
import time

AUDIO_EXTS = (".mp3", ".flac", ".ogg", ".oga", ".opus", ".m4a", ".aac", ".wav", ".wma", ".mka")
CONF = os.path.join(os.path.expanduser("~"), ".config", "wos", "music.json")
SKIP_DIRS = {"node_modules", "__pycache__"}


def format_time(sec):
    if sec is None or sec < 0:
        return "–"
    sec = int(sec)
    return "%d:%02d" % (sec // 60, sec % 60)


# ---------------------------------------------------------------- settings
def load_conf(path=None):
    try:
        with open(path or CONF, encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            return d
    except (OSError, ValueError):
        pass
    return {}


def save_conf(data, path=None):
    path = path or CONF
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, path)
    except OSError:
        pass


def default_folders(conf, home=None):
    home = home or os.path.expanduser("~")
    folders = [f for f in conf.get("folders", []) if isinstance(f, str)]
    music = os.path.join(home, "Music")
    if music not in folders:
        folders.insert(0, music)
    return folders


# ---------------------------------------------------------------- tags and scan
def tags_from_name(path):
    """No tag reader? "Artist - Title.mp3" gives both; otherwise the file name is the title and the folder the album."""
    base = os.path.splitext(os.path.basename(path))[0]
    base = re.sub(r"^\d{1,3}[\s._-]+", "", base)             # a leading track number
    album = os.path.basename(os.path.dirname(path))
    m = re.match(r"^(.+?)\s+-\s+(.+)$", base)
    if m:
        return {"title": m.group(2).strip(), "artist": m.group(1).strip(), "album": album, "length": None}
    return {"title": base.strip() or os.path.basename(path), "artist": "", "album": album, "length": None}


def read_tags(path):
    """Title, artist, album and length. Uses mutagen when installed, else the file name."""
    info = tags_from_name(path)
    try:
        import mutagen
        f = mutagen.File(path, easy=True)
        if f is not None:
            def first(key):
                v = (f.tags or {}).get(key)
                return str(v[0]).strip() if v else ""
            info["title"] = first("title") or info["title"]
            info["artist"] = first("artist") or first("albumartist") or info["artist"]
            info["album"] = first("album") or info["album"]
            if getattr(f, "info", None) is not None and getattr(f.info, "length", None):
                info["length"] = float(f.info.length)
    except Exception:
        pass
    return info


def find_audio(folders):
    """Every audio file under the folders, sorted by folder then name. Hidden folders are skipped."""
    out = []
    for root in folders:
        for dirpath, dirs, files in os.walk(root):
            dirs[:] = sorted(d for d in dirs if not d.startswith(".") and d not in SKIP_DIRS)
            for name in sorted(files):
                if name.lower().endswith(AUDIO_EXTS) and not name.startswith("."):
                    out.append(os.path.join(dirpath, name))
    seen, uniq = set(), []
    for p in out:
        rp = os.path.realpath(p)
        if rp not in seen:
            seen.add(rp)
            uniq.append(p)
    return uniq


def scan(folders, on_batch, batch=40, stop=None, reader=read_tags):
    """Reads the library in batches (on_batch gets a list of track dicts). Meant for a background thread."""
    cur = []
    for path in find_audio(folders):
        if stop is not None and stop.is_set():
            return
        t = reader(path)
        t["path"] = path
        cur.append(t)
        if len(cur) >= batch:
            on_batch(cur)
            cur = []
    if cur:
        on_batch(cur)


def matches(track, query):
    q = query.strip().lower()
    if not q:
        return True
    hay = " ".join((track.get("title") or "", track.get("artist") or "", track.get("album") or "")).lower()
    return all(w in hay for w in q.split())


# ---------------------------------------------------------------- the queue
class Queue:
    """The tracks being played, in order, with shuffle and repeat ("off", "all", "one"). Holds paths; `index` is the current one."""

    def __init__(self):
        self.tracks = []
        self.index = -1
        self.shuffle = False
        self.repeat = "off"
        self._order = []
        self._pos = -1

    def set(self, tracks, start=0):
        self.tracks = list(tracks)
        self.index = start if 0 <= start < len(self.tracks) else -1
        self._rebuild()

    def _rebuild(self):
        import random
        self._order = list(range(len(self.tracks)))
        if self.shuffle and self._order:
            rest = [i for i in self._order if i != self.index]
            random.shuffle(rest)
            self._order = ([self.index] if self.index >= 0 else []) + rest
        self._pos = self._order.index(self.index) if self.index in self._order else -1

    def set_shuffle(self, on):
        self.shuffle = bool(on)
        self._rebuild()

    def current(self):
        return self.tracks[self.index] if 0 <= self.index < len(self.tracks) else None

    def next(self, auto=False):
        """The next track, or None at the end. `auto` is true when a song ended by itself (repeat "one" then stays on it)."""
        if not self.tracks:
            return None
        if auto and self.repeat == "one" and self.current():
            return self.current()
        if self._pos + 1 < len(self._order):
            self._pos += 1
        elif self.repeat == "all":
            self._rebuild() if self.shuffle else None
            self._pos = 0
        else:
            return None
        self.index = self._order[self._pos]
        return self.current()

    def prev(self):
        if not self.tracks:
            return None
        if self._pos > 0:
            self._pos -= 1
        elif self.repeat == "all":
            self._pos = len(self._order) - 1
        self.index = self._order[self._pos]
        return self.current()


# ---------------------------------------------------------------- mpv
class Mpv:
    """Plays through one background mpv (no window) and talks to it over its JSON socket.
    Callbacks run on the thread that reads the socket: hand them to the UI loop yourself (GLib.idle_add)."""

    def __init__(self, on_position=None, on_end=None, on_error=None, binary="mpv"):
        self.on_position, self.on_end, self.on_error = on_position, on_end, on_error
        self.binary = binary
        self.proc = None
        self.sock = None
        self._buf = b""
        self._id = 0
        self._lock = threading.Lock()
        self.path = None
        self.paused = True
        self.position = 0.0
        self.duration = None
        self.volume = 80

    def start(self):
        if self.proc and self.proc.poll() is None:
            return True
        d = tempfile.mkdtemp(prefix="wosmusic-")
        sockpath = os.path.join(d, "mpv.sock")
        try:
            self.proc = subprocess.Popen([self.binary, "--idle=yes", "--no-video", "--no-terminal", "--audio-display=no",
                                          "--really-quiet", "--input-ipc-server=" + sockpath, "--volume=%d" % self.volume],
                                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError as e:
            if self.on_error:
                self.on_error("Could not start the player (%s)" % e)
            return False
        for _ in range(60):
            if os.path.exists(sockpath):
                break
            time.sleep(0.05)
        try:
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.connect(sockpath)
        except OSError as e:
            if self.on_error:
                self.on_error("Could not talk to the player (%s)" % e)
            return False
        self.sock = s
        threading.Thread(target=self._read, daemon=True).start()
        for prop in ("time-pos", "duration", "pause"):
            self._send(["observe_property", self._next_id(), prop])
        return True

    def _next_id(self):
        self._id += 1
        return self._id

    def _send(self, cmd):
        if not self.sock:
            return
        try:
            with self._lock:
                self.sock.sendall((json.dumps({"command": cmd}) + "\n").encode("utf-8"))
        except OSError:
            pass

    def _read(self):
        while True:
            try:
                data = self.sock.recv(4096)
            except OSError:
                return
            if not data:
                return
            self._buf += data
            while b"\n" in self._buf:
                line, self._buf = self._buf.split(b"\n", 1)
                try:
                    self._event(json.loads(line.decode("utf-8", "ignore")))
                except ValueError:
                    pass

    def _event(self, ev):
        name = ev.get("event")
        if name == "property-change":
            p, v = ev.get("name"), ev.get("data")
            if p == "time-pos" and v is not None:
                self.position = float(v)
                if self.on_position:
                    self.on_position(self.position, self.duration)
            elif p == "duration":
                self.duration = float(v) if v is not None else None
                if self.on_position:
                    self.on_position(self.position, self.duration)
            elif p == "pause":
                self.paused = bool(v)
        elif name == "end-file":
            if self.on_end:
                self.on_end(ev.get("reason", "eof"))

    # ---- controls
    def play(self, path):
        if not self.start():
            return False
        self.path, self.position, self.duration, self.paused = path, 0.0, None, False
        self._send(["loadfile", path, "replace"])
        self._send(["set_property", "pause", False])
        return True

    def pause(self, on=True):
        self.paused = on
        self._send(["set_property", "pause", bool(on)])

    def toggle(self):
        self.pause(not self.paused)

    def stop(self):
        self.path = None
        self._send(["stop"])

    def seek(self, sec):
        self.position = float(sec)
        self._send(["seek", float(sec), "absolute"])

    def set_volume(self, v):
        self.volume = max(0, min(100, int(v)))
        self._send(["set_property", "volume", self.volume])

    def quit(self):
        self._send(["quit"])
        try:
            if self.proc:
                self.proc.wait(timeout=2)
        except Exception:
            try:
                self.proc.kill()
            except Exception:
                pass
