"use strict";

/* Lock / login screen. Inside the LightDM greeter the native side (greeter)
   answers over the WebKit script-message bridge; opened in a plain browser it
   uses a small mock so the design can be previewed. */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const bridge = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.wos;
const state = { users: [], selected: null, busy: false };

/* Two states, like a phone. A locked session first shows only the time and date; a key, a click or a nudge of the mouse
   brings up the password screen, which goes back to the clock after a quiet spell. Signing in at start-up goes straight to
   the password screen. */
let mode = "login", lockMode = false, idleTimer = null, nudge = 0;
function setMode(m) {
  mode = m;
  const el = $("#lock");
  el.classList.toggle("mode-clock", m === "clock");
  el.classList.toggle("mode-login", m === "login");
  if (m === "login") { $("#lock-form input").focus(); armIdle(); }
}
function armIdle() {
  clearTimeout(idleTimer);
  if (lockMode && !state.busy) idleTimer = setTimeout(() => { $("#lock-form input").value = ""; setMessage(""); $("#lock-form input").blur(); setMode("clock"); }, 25000);
}
function wake(e) {
  if (mode === "clock") { setMode("login"); return; }
  armIdle();
}
document.addEventListener("keydown", wake, true);
document.addEventListener("mousedown", wake, true);
document.addEventListener("touchstart", wake, true);
document.addEventListener("mousemove", e => { nudge += Math.abs(e.movementX || 0) + Math.abs(e.movementY || 0); if (nudge > 40) { nudge = 0; wake(e); } }, true);

function post(msg) {
  if (bridge) bridge.postMessage(JSON.stringify(msg));
  else mockHost(msg);
}

/* ---------- Rendering ---------- */
function setMessage(text) { $("#lock-msg").textContent = text || ""; }

function avatarFor(el, user) {
  el.style.backgroundImage = user && user.image ? `url("${user.image}")` : "";
  el.classList.toggle("photo", !!(user && user.image));
}

function render() {
  const cur = state.users.find(u => u.name === state.selected);
  $("#lock-name").textContent = cur ? cur.display : "";
  avatarFor($("#avatar"), cur);
  const others = state.users.filter(u => u.name !== state.selected);
  $("#others").hidden = others.length === 0;
  const row = $("#other-users");
  row.innerHTML = "";
  others.forEach(u => {
    const el = document.createElement("div");
    el.className = "u";
    el.tabIndex = 0;
    el.innerHTML = `<div class="avatar small"></div>`;
    avatarFor($(".avatar", el), u);
    el.appendChild(document.createTextNode(u.display));
    const pick = () => choose(u.name);
    el.addEventListener("click", pick);
    el.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") pick(); });
    row.appendChild(el);
  });
}

function choose(name) {
  if (state.busy) return;
  state.selected = name;
  setMessage("");
  $("#lock-form input").value = "";
  render();
  post({ type: "select", user: name });
  $("#lock-form input").focus();
}

function setBusy(on) {
  state.busy = on;
  $("#lock-form input").disabled = on;
  if (!on) $("#lock-form input").focus();
}

function failed(message) {
  setBusy(false);
  $("#lock-form input").value = "";
  setMessage(message || I18N.t("incorrect_password"));
  const who = $("#who");
  who.classList.remove("shake"); void who.offsetWidth; who.classList.add("shake");
  armIdle();
}

/* ---------- Clock and date ---------- */
const LDAYS = { en: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                es: ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"] };
const LMONTHS = { en: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                  es: ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"] };
function tickLock() {
  const d = new Date(), l = (typeof I18N !== "undefined" && I18N.lang.startsWith("es")) ? "es" : "en";
  $("#lock-time").textContent = String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
  $("#lock-date").textContent = l === "es" ? `${LDAYS.es[d.getDay()]}, ${d.getDate()} de ${LMONTHS.es[d.getMonth()]}`
                                            : `${LDAYS.en[d.getDay()]} ${d.getDate()} ${["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"][d.getMonth()]}`;
}
tickLock(); setInterval(tickLock, 10000);

/* ---------- Messages from the native side ---------- */
const handlers = {
  init(m) {
    if (m.lang) { I18N.setLanguage(m.lang); I18N.apply(); }
    tickLock();
    lockMode = !!m.lock;
    setMode(lockMode ? "clock" : "login");
    state.users = m.users || [];
    state.selected = m.selected || (state.users[0] && state.users[0].name) || null;
    render();
    if (state.selected) post({ type: "select", user: state.selected });
    $("#lock-form input").focus();
  },
  ok() { document.body.classList.add("leaving"); },      // login succeeded, session is starting
  fail(m) { failed(m.message && I18N.error(m.message)); },
  can(m) { $$("#power-menu button").forEach(b => { b.hidden = m[b.dataset.action] === false; }); },
};
window.wos = { receive(msg) { const h = handlers[msg.type]; if (h) h(msg); } };

/* ---------- Events ---------- */
$("#lock-form").addEventListener("submit", e => {
  e.preventDefault();
  const value = $("#lock-form input").value;
  if (!value || state.busy) return;
  setBusy(true);
  setMessage("");
  post({ type: "password", value });
});

$(".forgot").addEventListener("click", e => { e.preventDefault(); setMessage(I18N.t("forgot_help")); });

$("#power-btn").addEventListener("click", e => { e.stopPropagation(); $("#power-menu").hidden = !$("#power-menu").hidden; });
document.addEventListener("click", () => { $("#power-menu").hidden = true; });
$$("#power-menu button").forEach(b => b.addEventListener("click", () => post({ type: "power", action: b.dataset.action })));

/* ---------- Mock host (browser preview only) ---------- */
function mockHost(msg) {
  const mockUsers = [
    { name: "alex", display: "Alex Holmes" }, { name: "natalie", display: "Natalie" },
    { name: "william", display: "William" }, { name: "laura", display: "Laura" }];
  if (msg.type === "ready") setTimeout(() => window.wos.receive({ type: "init", lang: "en_GB", users: mockUsers, lock: location.hash === "#lock" }), 50);
  if (msg.type === "password") setTimeout(() => window.wos.receive(msg.value === "test" ? { type: "ok" } : { type: "fail" }), 500);
  if (msg.type === "power") console.log("power:", msg.action);
}

post({ type: "ready" });
