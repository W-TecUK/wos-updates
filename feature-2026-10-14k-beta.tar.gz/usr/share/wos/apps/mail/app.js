"use strict";
/* Mail: real email. Add W-Mail, iCloud, Yahoo, Fastmail or any IMAP account with its password
   (or app password). Messages stay on the mail server; this app reads and sends them live.
   Passwords are kept by the system (private file), never handed back to this page.
   Providers that only allow sign-in through a web page (OAuth) are not supported. */

boot(async info => {
  const root = $("#root");
  const ROLE_ICON = { inbox: "mail", drafts: "edit", sent: "send", archive: "folder", junk: "shield", bin: "trash", other: "folder" };
  const ROLE_LABEL = { inbox: "Inbox", drafts: "Drafts", sent: "Sent", archive: "Archive", junk: "Junk", bin: "Bin" };
  const errText = e => (e && e.message) || String(e || "Something went wrong");

  let accounts = [], presets = [], contacts = [];
  wos.call("mail.contacts").then(c => { contacts = c || []; }).catch(() => {});
  let state = (await wos.data.get("state", null)) || {};
  let acct = null, folders = [], folder = null, messages = [], current = null, detail = null, query = "", token = 0, busy = false;

  const nav = h("nav.nav"), list = h("div.list"), reader = h("div", { style: "flex:1;overflow:auto;padding:24px 30px;min-width:0" });
  const search = h("input.field", { placeholder: "Search", oninput: e => { query = e.target.value.toLowerCase(); drawList(); } });
  const accountBtn = h("button.btn.ghost", { style: "width:100%;justify-content:flex-start;margin-bottom:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap", onclick: accountMenu });
  const status = h("div.small.muted", { style: "padding:6px 4px;min-height:20px" });
  const side = h("aside.side", accountBtn,
    h("button.btn", { style: "width:100%;justify-content:center;margin-bottom:14px", onclick: () => compose() }, h("span", { html: icon("edit", 15) }), "Write"), nav, h("div", { style: "flex:1" }), status);
  const mid = h("div", { style: "width:320px;border-right:1px solid var(--line);display:flex;flex-direction:column;min-height:0" },
    h("div", { style: "padding:12px;display:flex;gap:8px;align-items:center" }, h("div.search", { style: "flex:1" }, h("span", { html: icon("search") }), search),
      h("button.icon-btn", { title: "Check for new mail", html: icon("refresh"), onclick: () => refresh() })), h("div", { style: "flex:1;overflow:auto" }, list));
  const main = h("div", { style: "display:grid;grid-template-columns:200px 320px 1fr;height:100%" }, side, mid, reader);

  const saveState = () => wos.data.set("state", state).catch(() => {});
  const setStatus = t => { status.textContent = t || ""; };

  // ---------- accounts ----------
  async function loadAccounts() {
    accounts = await wos.call("mail.accounts");
    presets = await wos.call("mail.presets");
  }
  function accountMenu(e) {
    const r = e.currentTarget.getBoundingClientRect();
    const items = accounts.map(a => ({ label: a.address, icon: a.id === acct.id ? "check" : "mail", onclick: () => { if (a.id !== acct.id) openAccount(a); } }));
    items.push("-", { label: "Add account…", icon: "plus", onclick: () => addAccount() },
      { label: "Remove this account…", icon: "trash", danger: true, onclick: () => removeAccount() });
    contextMenu(items, r.left, r.bottom + 4);
  }
  async function removeAccount() {
    if (!(await confirmBox("Remove " + acct.address + "?", "It is removed from this computer only. Your mail stays on the server.", "Remove"))) return;
    await wos.call("mail.remove", { account: acct.id }).catch(e => toast(errText(e)));
    await loadAccounts();
    acct = null;
    accounts.length ? openAccount(accounts[0]) : welcome();
  }
  function confirmBox(title, text, okLabel) {
    return new Promise(res => {
      const done = v => { back.remove(); res(v); };
      const back = h("div.modal-back", h("div.modal", h("h2", title), h("p.muted", text),
        h("div.actions", h("button.btn.ghost", { onclick: () => done(false) }, "Cancel"), h("button.btn", { onclick: () => done(true) }, okLabel))));
      document.body.append(back);
    });
  }

  function welcome() {
    root.innerHTML = "";
    const tiles = presets.map(p => h("button.btn.ghost", { style: "height:64px;justify-content:flex-start;gap:12px;padding:0 18px;font-size:15px", onclick: () => addAccount(p.id) },
      h("span", { html: icon(p.id === "custom" ? "gear" : "mail", 22) }), p.label));
    root.append(h("div.empty", { style: "height:100%" }, h("div", { style: "max-width:440px" },
      h("div", { html: icon("mail", 44), style: "color:var(--muted);margin-bottom:10px" }),
      h("h1", { style: "margin:0 0 6px" }, "Add your email"),
      h("p.muted", "Read and send mail from W-Mail, iCloud, Yahoo, Fastmail or any other provider that supports IMAP."),
      h("div", { style: "display:grid;gap:10px;margin-top:18px;text-align:left" }, tiles),
      h("p.small.muted", { style: "margin-top:16px" }, "Gmail and Outlook.com need a web sign-in that this app does not support yet."))));
  }

  function addAccount(providerId) {
    let provider = providerId || "wmail";
    const f = {};
    const field = (key, ph, type = "text") => (f[key] = h("input.field", { placeholder: ph, type, autocomplete: "off", spellcheck: false }));
    field("name", "Your name (shown to people you write to)");
    field("address", "Email address");
    field("password", "Password", "password");
    field("imap_host", "IMAP server, e.g. imap.example.com");
    field("imap_port", "993");
    field("smtp_host", "SMTP server, e.g. smtp.example.com");
    field("smtp_port", "465");
    f.name.value = info.full_name || "";
    Object.values(f).forEach(el => el.addEventListener("keydown", e => { if (e.key === "Enter") go(); }));
    let imapSec = "ssl", smtpSec = "ssl";
    const imapDd = dropdown([["ssl", "SSL/TLS"], ["starttls", "STARTTLS"]], { value: imapSec, onChange: v => { imapSec = v; } });
    const smtpDd = dropdown([["ssl", "SSL/TLS"], ["starttls", "STARTTLS"]], { value: smtpSec, onChange: v => { smtpSec = v; } });
    const help = h("p.small.muted", { style: "margin:0" });
    const custom = h("div", { style: "display:none" },
      h("div.form-row", h("div.small.muted", "Incoming (IMAP)"), h("div", { style: "display:flex;gap:8px" }, f.imap_host, h("div", { style: "width:84px" }, f.imap_port), imapDd)),
      h("div.form-row", h("div.small.muted", "Outgoing (SMTP)"), h("div", { style: "display:flex;gap:8px" }, f.smtp_host, h("div", { style: "width:84px" }, f.smtp_port), smtpDd)));
    const seg = h("div.seg", { style: "flex-wrap:wrap" });
    const paint = () => {
      seg.innerHTML = "";
      presets.forEach(p => seg.append(h("button" + (p.id === provider ? ".on" : ""), { type: "button", onclick: () => { provider = p.id; paint(); } }, p.label)));
      const p = presets.find(x => x.id === provider);
      help.textContent = p ? p.help : "";
      custom.style.display = provider === "custom" ? "block" : "none";
    };
    paint();
    const err = h("div.small", { style: "color:var(--danger,#d33);min-height:18px" });
    const connect = h("button.btn", { onclick: go }, "Connect");
    const cancel = h("button.btn.ghost", { onclick: () => back.remove() }, "Cancel");
    async function go() {
      err.textContent = "";
      if (!f.address.value.trim() || !f.password.value) { err.textContent = "Enter your email address and password."; return; }
      connect.disabled = true; connect.textContent = "Connecting…";
      try {
        const body = { provider, name: f.name.value, address: f.address.value.trim(), password: f.password.value };
        if (provider === "custom") Object.assign(body, { imap_host: f.imap_host.value.trim(), imap_port: f.imap_port.value, imap_security: imapSec,
          smtp_host: f.smtp_host.value.trim(), smtp_port: f.smtp_port.value, smtp_security: smtpSec });
        const added = await wos.call("mail.add", body);
        back.remove();
        await loadAccounts();
        openAccount(accounts.find(a => a.id === added.id) || accounts[accounts.length - 1]);
      } catch (e) {
        err.textContent = errText(e); connect.disabled = false; connect.textContent = "Connect";
      }
    }
    const back = h("div.modal-back", h("div.modal", { style: "width:min(520px,94vw);max-height:90vh;overflow:auto" }, h("h2", "Add an account"),
      h("div.form-row", seg), help, h("div.form-row", f.name), h("div.form-row", f.address), h("div.form-row", f.password), custom, err,
      h("div.actions", cancel, connect)));
    document.body.append(back);
    f.address.focus();
  }

  // ---------- reading ----------
  async function openAccount(a) {
    acct = a; state.account = a.id; folder = null; folders = []; messages = []; current = null; detail = null;
    if (!root.contains(main)) { root.innerHTML = ""; root.append(main); }
    accountBtn.textContent = a.address;
    drawNav(); drawList(); drawReader();
    setStatus("Connecting…");
    try {
      folders = await wos.call("mail.folders", { account: a.id });
      if (acct !== a) return;
      folder = (folders.find(f => f.name === state["folder:" + a.id]) || folders.find(f => f.role === "inbox") || folders[0] || {}).name;
      drawNav();
      await refresh();
    } catch (e) { if (acct === a) { setStatus(""); showError(errText(e)); } }
    saveState();
  }
  function showError(text) {
    list.innerHTML = "";
    list.append(h("div", { style: "padding:24px;text-align:center" }, h("p.muted", text), h("button.btn.small", { onclick: () => openAccount(acct) }, "Try again")));
  }
  async function refresh() {
    if (!acct || !folder || busy) return;
    const my = ++token, a = acct, fo = folder;
    busy = true; setStatus("Checking…");
    try {
      const got = await wos.call("mail.list", { account: a.id, folder: fo });
      if (my === token) { messages = got; setStatus("Updated " + new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })); drawNav(); drawList(); }
    } catch (e) { if (my === token) { setStatus(""); messages = []; drawList(); showError(errText(e)); } }
    finally { busy = false; }
  }
  const fmtSize = n => n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : n >= 1024 ? Math.round(n / 1024) + " KB" : n + " bytes";
  const roleOf = name => (folders.find(f => f.name === name) || {}).role || "other";
  const trashName = () => (folders.find(f => f.role === "bin") || {}).name;
  function drawNav() {
    nav.innerHTML = "";
    folders.forEach(f => {
      const unread = f.name === folder ? messages.filter(m => !m.read).length : 0;
      nav.append(h("button" + (folder === f.name ? ".on" : ""), { onclick: () => { if (folder === f.name) return; folder = f.name; state["folder:" + acct.id] = f.name; saveState(); current = null; detail = null; messages = []; query = ""; search.value = ""; drawNav(); drawList(); drawReader(); refresh(); } },
        h("span", { html: icon(ROLE_ICON[f.role] || "folder") }), h("span", { style: "flex:1;overflow:hidden;text-overflow:ellipsis" }, ROLE_LABEL[f.role] || f.name), unread ? h("span.badge", unread) : null));
    });
  }
  function drawList() {
    list.innerHTML = "";
    const sentLike = ["sent", "drafts"].includes(roleOf(folder));
    const shown = messages.filter(m => !query || (m.subject + m.from + m.addr).toLowerCase().includes(query));
    if (!shown.length && !busy) list.append(h("div.muted", { style: "padding:30px;text-align:center" }, query ? "No matches" : "Nothing in this folder"));
    shown.forEach(m => list.append(h("button.row" + (current === m.uid ? ".on" : ""), { onclick: () => openMessage(m) },
      m.read ? null : h("span.dot"), h("div.grow", h("div.t", sentLike ? (m.to || "No recipient") : m.from), h("div.s", m.subject || "(no subject)")),
      h("span.small.muted", new Date(m.date).toLocaleDateString("en-GB", { day: "numeric", month: "short" })))));
  }
  async function openMessage(m) {
    current = m.uid; detail = null; m.read = true; drawNav(); drawList(); drawReader("Loading…");
    const a = acct, fo = folder;
    try {
      const d = await wos.call("mail.read", { account: a.id, folder: fo, uid: m.uid });
      if (current === m.uid && acct === a && folder === fo) { detail = d; drawReader(); }
    } catch (e) { if (current === m.uid) drawReader(null, errText(e)); }
  }
  function drawReader(loading, error) {
    reader.innerHTML = "";
    const m = messages.find(x => x.uid === current);
    if (!m) { reader.append(h("div.empty", h("div", h("div", { html: icon("mail", 44), style: "color:var(--muted);margin-bottom:10px" }), h("p", "Select a message to read it.")))); return; }
    const role = roleOf(folder);
    reader.append(h("div", { style: "max-width:680px" },
      h("div", { style: "display:flex;align-items:center;gap:10px;margin-bottom:6px" }, h("h1", { style: "margin:0;font-size:22px;flex:1" }, m.subject || "(no subject)"),
        ["sent", "drafts"].includes(role) ? null : h("button.btn.ghost.small", { onclick: () => replyTo(m) }, "Reply"),
        h("button.icon-btn", { title: "Delete", html: icon("trash"), onclick: () => del(m) })),
      h("div.small.muted", { style: "margin-bottom:18px" }, ["sent", "drafts"].includes(role) ? "To " + (m.to || "—") : `${m.from} <${m.addr}>`, "  ·  ", new Date(m.date).toLocaleString("en-GB")),
      error ? h("p", { style: "color:var(--danger,#d33)" }, error) : null,
      loading ? h("p.muted", loading) : null,
      detail ? h("div", { style: "white-space:pre-wrap;line-height:1.65;user-select:text;overflow-wrap:anywhere" }, detail.body || "(This message has no text.)") : null,
      detail && detail.attachments.length ? h("div", { style: "margin-top:18px" }, h("div.label", { style: "margin-bottom:6px" }, detail.attachments.length === 1 ? "1 attachment" : detail.attachments.length + " attachments"),
        h("div.card", detail.attachments.map(at => h("div.row", { style: "cursor:default;min-height:44px" }, h("span", { html: icon("file", 16) }), h("div.grow", h("div.t", at.name), h("div.s", fmtSize(at.size))),
          h("button.btn.ghost.small", { onclick: async e => { const b = e.currentTarget; b.disabled = true; b.textContent = "Saving…"; try { const p = await wos.call("mail.save_attachment", { account: acct.id, folder, uid: m.uid, index: at.index }); toast("Saved to Downloads/" + p.split("/").pop()); } catch (er) { toast(errText(er)); } b.disabled = false; b.textContent = "Save"; } }, "Save"))))) : null));
  }
  function replyTo(m) {
    const quoted = detail ? "\n\n— " + m.from + " wrote:\n" + detail.body.split("\n").map(l => "> " + l).join("\n") : "";
    compose({ to: m.addr, subject: /^re:/i.test(m.subject) ? m.subject : "Re: " + m.subject, body: quoted, reply_to: detail ? detail.message_id : "" });
  }
  async function del(m) {
    const a = acct, fo = folder, trash = trashName();
    messages = messages.filter(x => x !== m); current = null; detail = null; drawNav(); drawList(); drawReader();
    try { await wos.call("mail.delete", { account: a.id, folder: fo, uid: m.uid, trash }); toast(trash && trash !== fo ? "Moved to Bin" : "Deleted"); }
    catch (e) { toast(errText(e)); refresh(); }
  }

  // ---------- writing ----------
  function compose(seed = {}) {
    const to = h("input.field", { placeholder: "To (separate several with commas)", value: seed.to || "", oninput: suggest, onblur: () => setTimeout(() => sugg.replaceChildren(), 150) });
    const sugg = h("div.card", { style: "position:absolute;left:0;right:0;top:40px;z-index:5;max-height:180px;overflow:auto" });
    function suggest() {
      const last = to.value.split(/[,;]/).pop().trim().toLowerCase(); sugg.replaceChildren();
      if (last.length < 2) return;
      contacts.filter(c => (c.name + " " + c.email).toLowerCase().includes(last)).slice(0, 6).forEach(c => sugg.append(h("button.row", { style: "min-height:40px", onmousedown: e => { e.preventDefault(); const head = to.value.split(/[,;]/).slice(0, -1).map(x => x.trim()).filter(Boolean); head.push(c.email); to.value = head.join(", ") + ", "; sugg.replaceChildren(); to.focus(); } }, h("div.grow", h("div.t", c.name || c.email), c.name ? h("div.s", c.email) : null))));
    }
    const subject = h("input.field", { placeholder: "Subject", value: seed.subject || "" });
    const body = h("textarea.field", { rows: 11, placeholder: "Write your message…" }, seed.body || "");
    const msg = h("div.small", { style: "color:var(--btn-danger,#d33);min-height:18px" });
    const cc = h("input.field", { placeholder: "Cc (optional)" });
    let files = [];
    const chips = h("div", { style: "display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px" });
    const paintFiles = () => { chips.innerHTML = ""; files.forEach(f => chips.append(h("span.chip", { style: "height:28px;gap:6px;padding:0 6px 0 12px" }, f.split("/").pop(), h("button.icon-btn", { style: "width:20px;height:20px", title: "Remove", html: icon("x", 12), onclick: () => { files = files.filter(x => x !== f); paintFiles(); } })))); };
    const attach = h("button.btn.ghost.small", { onclick: async () => { const p = await pickFile({ title: "Attach a file", start: info.home }); if (p && !files.includes(p)) { files.push(p); paintFiles(); } } }, h("span", { html: icon("plus", 14) }), "Attach a file");
    const send = h("button.btn", { onclick: go }, "Send");
    async function go() {
      msg.textContent = "";
      if (!to.value.trim()) { msg.textContent = "Add a recipient."; return; }
      send.disabled = true; send.textContent = "Sending…";
      try {
        await wos.call("mail.send", { account: acct.id, to: to.value, cc: cc.value, subject: subject.value, body: body.value, reply_to: seed.reply_to || "", attachments: files });
        back.remove(); toast("Sent");
        if (roleOf(folder) === "sent") refresh();
      } catch (e) { msg.textContent = errText(e); send.disabled = false; send.textContent = "Send"; }
    }
    const back = h("div.modal-back", h("div.modal", { style: "width:min(640px,94vw)" }, h("h2", "New message"),
      h("div.small.muted", { style: "margin-bottom:8px" }, "From " + acct.address),
      h("div.form-row", { style: "position:relative" }, to, sugg), h("div.form-row", cc), h("div.form-row", subject), h("div.form-row", body), chips, msg,
      h("div.actions", attach, h("div", { style: "flex:1" }), h("button.btn.ghost", { onclick: () => back.remove() }, "Discard"), send)));
    document.body.append(back); (seed.to ? body : to).focus();
  }

  await loadAccounts();
  if (!accounts.length) { welcome(); return; }
  openAccount(accounts.find(a => a.id === state.account) || accounts[0]);
  setInterval(() => { if (!document.hidden && !busy) refresh(); }, 120000);
});
