"use strict";
/* The Help app's articles and its search. Plain data and one pure function, so both are tested (os/tests/help.test.js).
   A topic is {id, group, title, words (extra search words), body: [paragraph | {steps: [...]} | {tip: "..."}]}. */
(function (root) {
  const T = [
    { id: "welcome", group: "Getting started", title: "Welcome to W-OS", words: "start begin new tour intro",
      body: ["W-OS is simple on purpose: the dock at the bottom holds your apps, the bar at the top shows what is open and the time, and one search box finds almost anything.",
        { steps: ["Open the launcher with the first icon in the dock, or press Super + Space (the key with the Windows or W logo).", "Type what you want: an app, a file, a sum like 12 * 7, or a question for the web.", "Press Enter to open the first result."] },
        { tip: "Settings has an Overview page with your computer's name, version, backup and account at a glance." }] },
    { id: "launcher", group: "Getting started", title: "Find and open apps and files", words: "search launcher spotlight calculator convert units super space",
      body: ["The launcher searches your apps and your files together. It also works as a calculator and a unit converter.",
        { steps: ["Press Super + Space.", "Type, for example: photos, tax return, 20% of 150, or 5 km in miles.", "Use the arrow keys to move through the results, Enter to open, Esc to close."] },
        "The last result is always a web search, so anything it cannot find on this computer can be looked up with one more Enter."] },
    { id: "account", group: "Getting started", title: "Sign in with a W-Account", words: "w-life account sync free license activation sign in",
      body: ["A W-Account (the same one as W-Life and W-Mail) unlocks all of W-OS for free and keeps your calendar and notes in step across your devices.",
        { steps: ["Open Settings, then W-Account.", "Enter your email and password and choose Sign in."] },
        "Without an account W-OS runs in limited mode: everything already on the computer keeps working and security updates still install, but new apps cannot be added from the Store. A product key tied to your computer also activates it (Settings > Activation)."] },
    { id: "files", group: "Everyday", title: "Your files, the Bin and Favourites", words: "files folder delete trash bin restore favourite recent usb drive eject zip",
      body: ["Files shows your Home folder and any USB drive you plug in. Click a folder to open it, double-click a file to open it in the right app.",
        { steps: ["Right-click a folder and choose Add to Favourites to keep it in the sidebar.", "Anything you delete goes to the Bin first. Open the Bin in the sidebar to bring it back.", "Recents lists the files you opened lately.", "Click the x beside a USB drive to eject it safely before unplugging."] },
        { tip: "Hold Ctrl while dragging to copy instead of move. Right-click a selection to compress it into a zip file." }] },
    { id: "backup", group: "Everyday", title: "Back up your files", words: "backup restore usb drive safe copy history time machine",
      body: ["Backup copies your files to a USB drive or other external disk, every day while it is plugged in. Each backup is a dated folder you can browse, and a backup only costs the space of what changed.",
        { steps: ["Plug in the drive.", "Open Settings, then Backup, choose the drive and turn on Back up automatically.", "To bring something back: Backup, Browse & restore beside a date, then Restore. It is copied to Restored from backup in your Home folder and never replaces your current files."] },
        "Caches and the Bin are not backed up. Keep the drive somewhere other than next to your computer."] },
    { id: "connect", group: "Everyday", title: "Wi-Fi, VPN, Bluetooth and printers", words: "wifi wi-fi network internet vpn bluetooth printer connect hotspot airplane",
      body: [{ steps: ["Wi-Fi: Settings > Network, choose a network and enter its password. Public Wi-Fi that needs a sign-in page opens it for you.", "VPN: Settings > Network > Add VPN and choose the profile file from your provider (.ovpn or WireGuard .conf).", "Bluetooth: Settings > Bluetooth, put the device in pairing mode and choose Pair.", "Printer: Settings > Printers > Add printer. Most printers from the last ten years are found by themselves."] },
        "Airplane mode in Settings > Network turns Wi-Fi and Bluetooth off together."] },
    { id: "mail", group: "Everyday", title: "Email, calendar, notes and contacts", words: "mail email icloud imap calendar notes contacts sync w-mail attachments draft",
      body: ["Mail reads and sends real email: add W-Mail, iCloud, Yahoo, Fastmail or any account that supports IMAP. For iCloud and Yahoo use an app-specific password from your account's security page. Gmail and Outlook.com need a web sign-in that W-OS does not support yet.",
        { steps: ["Open Mail and choose a provider, then enter your address and password.", "Write, attach files, save a draft, flag, move or archive messages from the toolbar.", "New mail is announced even when Mail is closed."] },
        "Calendar and Notepad sync with your W-Account when you are signed in, so they appear on your other devices. Contacts can import and export vCard (.vcf) files and complete addresses in Mail."] },
    { id: "apps", group: "Everyday", title: "Install apps", words: "store install app software windows exe wine remove",
      body: ["The App Store lists apps approved for W-OS. Choose Get to install and Remove to uninstall. Updates for everything arrive through Settings > Updates.",
        { steps: ["Open App Store and browse Discover.", "Choose Get on an app. A progress bar shows while it installs.", "Some Windows programs run through Windows App Support and are marked Experimental. Double-clicking a Windows .exe file offers to run it that way."] },
        { tip: "If Get does nothing and a message mentions limited mode, sign in with a W-Account or enter a product key in Settings > Activation." }] },
    { id: "shortcuts", group: "Shortcuts", title: "Keyboard shortcuts", words: "keys hotkeys keyboard super ctrl alt shortcut tile snap desktop lock screenshot",
      body: [{ steps: ["Super + Space: launcher and search", "Super + Left / Right: snap a window to half the screen; Super + Up / Down: maximise / restore", "Alt + Tab: switch windows; Alt + F4: close the window", "Ctrl + Alt + Left / Right: switch desktop; add Shift to take the window along", "Super + E: Files; Super + I: Settings; Ctrl + Shift + Esc: Monitor", "Super + L or Ctrl + Alt + L: lock the screen", "Super + V: clipboard history", "Print: screenshot of the whole screen; Super + Shift + S: screenshot of an area"] },
        "The full list is also in Settings > Keyboard & trackpad."] },
    { id: "personalise", group: "Make it yours", title: "Appearance, dock and desktops", words: "dark mode light mode theme dark light accent colour wallpaper dock size widgets desktops workspaces night light",
      body: [{ steps: ["Settings > Appearance: light, dark or automatic, and your accent colour.", "Settings > Desktop & Dock: wallpaper, the dock style (Default, Full, Bubbled or Bubbled condensed), size, and which widgets show.", "Desktops: press Ctrl + Alt + Right to move to another desktop, a quiet way to keep work and play apart.", "Settings > Displays: resolution, scale and Night Light, which warms the screen in the evening."] }] },
    { id: "access", group: "Make it yours", title: "Make text and the pointer bigger", words: "accessibility zoom large text contrast cursor pointer sticky keys motion read aloud",
      body: [{ steps: ["Settings > Accessibility > Text size makes text bigger in W-OS apps (in Firefox press Ctrl and +).", "Pointer size gives a bigger mouse pointer.", "Higher contrast, Reduce motion and Read aloud (select text, press Alt + R) are on the same page.", "Sticky Keys, Slow Keys and Bounce Keys help if holding or pressing keys precisely is hard."] }] },
    { id: "quiet", group: "Make it yours", title: "Notifications and quiet hours", words: "do not disturb focus notifications banners mute schedule sleep",
      body: [{ steps: ["Click the clock to see the notifications you have not read, grouped by app.", "Settings > Notifications: turn an app's banners off, or turn on Quiet hours to switch Do Not Disturb on by itself at night."] },
        "Muted apps still keep their notifications in the date panel, so nothing is lost."] },
    { id: "stuck", group: "If something goes wrong", title: "An app is frozen or slow", words: "freeze frozen stuck slow hang not responding force quit monitor memory",
      body: [{ steps: ["Press Ctrl + Shift + Esc to open Monitor.", "Choose the program in the list (the busy ones are at the top), then Quit. If it will not close, use Force quit.", "The Performance tab shows whether the processor, memory or disk is the bottleneck."] },
        "Anything you had not saved in a force-quit program is lost."] },
    { id: "network", group: "If something goes wrong", title: "No internet, sound or battery problems", words: "wifi not working no sound mic battery drain troubleshoot internet",
      body: [{ steps: ["No internet: Settings > Network. Turn Airplane mode off, rejoin the network, and try Scan again.", "No sound: Settings > Sound. Check the Output device and volume, and that the app is not muted in the Apps list.", "Microphone: Settings > Sound > Input shows the volume and mute for it.", "Battery draining: Settings > Power shows battery health; Low Power Mode trims background activity."] }] },
    { id: "updates", group: "If something goes wrong", title: "Updates and getting an update undone", words: "update upgrade restart rollback broke beta version",
      body: ["W-OS updates itself. Settings > Updates shows what is waiting and lets you check now.",
        { steps: ["If a new update causes trouble, open Settings > Updates and choose Roll back beside the newest update. The previous version comes back after a restart.", "You can opt in to Beta updates on the same page to try new things earlier."] }] },
    { id: "support", group: "If something goes wrong", title: "Reset a password and contact support", words: "forgot password reset support help contact feedback report problem",
      body: ["Forgot your W-Account password? Choose Forgot Password on the sign-in screen to reset it with W-Life. A local account's password can be changed from Settings > Users while you are signed in.",
        "To tell us about a problem or an idea, open W-OS Alpha Feedback from the launcher. Nothing is sent until you press Send."] },
  ];

  /* Rank topics for a search: title matches beat keyword matches beat body matches; every word typed must match somewhere. */
  function search(query, topics) {
    const words = String(query || "").toLowerCase().split(/\s+/).filter(Boolean);
    if (!words.length) return topics.slice();
    const scored = topics.map(t => {
      const title = t.title.toLowerCase(), kw = (t.words || "").toLowerCase(), group = t.group.toLowerCase();
      const body = t.body.map(b => typeof b === "string" ? b : (b.steps ? b.steps.join(" ") : b.tip || "")).join(" ").toLowerCase();
      let score = 0;
      for (const w of words) {
        const s = title.includes(w) ? 10 : kw.includes(w) ? 6 : group.includes(w) ? 3 : body.includes(w) ? 1 : 0;
        if (!s) return { t, score: 0 };
        score += s;
      }
      return { t, score };
    }).filter(x => x.score > 0);
    return scored.sort((a, b) => b.score - a.score || topics.indexOf(a.t) - topics.indexOf(b.t)).map(x => x.t);
  }

  const api = { TOPICS: T, search };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.HelpTopics = api;
})(typeof window !== "undefined" ? window : globalThis);
