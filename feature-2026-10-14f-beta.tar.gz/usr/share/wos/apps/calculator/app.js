"use strict";
/* Calculator: standard and scientific, keyboard friendly. The maths uses the same hand-written parser as the
   launcher (ui/shell/quick.js): nothing here evaluates text as code. */

boot(async () => {
  const root = $("#root");
  const Q = window.WQuick;
  let expr = "", result = "", justEvaluated = false, sci = (await wos.data.get("sci", false)) === true, history = (await wos.data.get("history", [])) || [], showHistory = false;

  const exprEl = h("div", { style: "min-height:22px;text-align:right;color:var(--muted);font-size:14px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;direction:rtl" });
  const outEl = h("div", { style: "text-align:right;font-weight:800;font-size:44px;line-height:1.15;overflow:hidden;white-space:nowrap;user-select:text;cursor:copy", title: "Click to copy", onclick: copy });
  const histEl = h("div", { style: "position:absolute;inset:0;background:var(--bg);z-index:5;padding:16px;overflow:auto;display:none" });
  const keys = h("div", { style: "display:grid;gap:8px;flex:1;min-height:0" });
  const wrap = h("div", { style: "position:relative;display:flex;flex-direction:column;height:100%;padding:14px;gap:10px" },
    h("div", { style: "display:flex;gap:8px;align-items:center" }, h("div.seg", ...[["Standard", false], ["Scientific", true]].map(([l, v]) => h("button" + (sci === v ? ".on" : ""), { onclick: () => { sci = v; wos.data.set("sci", v); build(); } }, l))),
      h("div", { style: "flex:1" }), h("button.icon-btn", { title: "History", html: icon("clock"), onclick: toggleHistory })),
    h("div", { style: "padding:6px 8px" }, exprEl, outEl), keys, histEl);
  root.append(wrap);

  const OPS = { "÷": "/", "×": "*", "−": "-" };
  const toExpr = s => s.replace(/[÷×−]/g, c => OPS[c]).replace(/√/g, "sqrt").replace(/π/g, "pi");

  function render() {
    exprEl.textContent = justEvaluated ? lastExpr + " =" : "";
    outEl.textContent = expr || "0";
    outEl.style.fontSize = (outEl.textContent.length > 12 ? 26 : outEl.textContent.length > 9 ? 34 : 44) + "px";
    outEl.style.color = result === "Error" ? "#ff453a" : "";
  }
  let lastExpr = "";

  function press(k) {
    if (result === "Error" && k !== "C") { expr = ""; result = ""; }
    if (k === "C") { expr = ""; result = ""; justEvaluated = false; }
    else if (k === "⌫") { expr = justEvaluated ? "" : expr.slice(0, -1); justEvaluated = false; }
    else if (k === "=") { evaluate(); }
    else if (k === "±") { expr = expr.startsWith("−") ? expr.slice(1) : expr ? "−" + expr : expr; }
    else if (k === "x²") { expr += "^2"; justEvaluated = false; }
    else {
      const isOp = "÷×−+^".includes(k);
      if (justEvaluated && !isOp && k !== "%") expr = "";
      justEvaluated = false;
      if (isOp && expr === "" && k !== "−") expr = "0";
      if (isOp && /[÷×−+^]$/.test(expr)) expr = expr.slice(0, -1);   // typing a second operator replaces the first
      expr += ["sin", "cos", "tan", "ln", "log", "√"].includes(k) ? k + "(" : k;
    }
    render();
  }

  function evaluate() {
    if (!expr) return;
    const open = (expr.match(/\(/g) || []).length - (expr.match(/\)/g) || []).length;
    const full = expr + ")".repeat(Math.max(0, open));
    const calc = Q.calculate(toExpr(full).replace(/(\d)\s*\(/g, "$1*("));
    lastExpr = full;
    if (!calc) { result = "Error"; expr = "Error"; justEvaluated = false; return; }
    result = calc.text;
    history.unshift({ expr: full, out: calc.text }); history = history.slice(0, 30); wos.data.set("history", history);
    expr = String(calc.value).length > 14 ? String(+calc.value.toPrecision(12)) : String(calc.value);
    if (expr.includes("e")) expr = calc.text;
    expr = expr.replace(/,/g, "").replace(/^-/, "−");
    justEvaluated = true;
  }

  function copy() {
    const text = (expr || "0").replace(/−/g, "-");
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => toast("Copied"), () => {});
  }

  function toggleHistory() {
    showHistory = !showHistory;
    histEl.style.display = showHistory ? "block" : "none";
    histEl.innerHTML = "";
    if (!showHistory) return;
    histEl.append(h("div", { style: "display:flex;align-items:center;margin-bottom:10px" }, h("h2", { style: "margin:0;flex:1;font-size:18px" }, "History"),
      history.length ? h("button.btn.ghost.small", { onclick: () => { history = []; wos.data.set("history", []); toggleHistory(); toggleHistory(); } }, "Clear") : null,
      h("button.icon-btn", { html: icon("x"), onclick: toggleHistory })));
    if (!history.length) histEl.append(h("p.muted", "Nothing yet."));
    history.forEach(x => histEl.append(h("button.row", { style: "flex-direction:column;align-items:flex-end;gap:2px", onclick: () => { expr = x.out.replace(/,/g, "").replace(/^-/, "−"); justEvaluated = false; toggleHistory(); render(); } },
      h("span.small.muted", x.expr + " ="), h("span", { style: "font-weight:800;font-size:20px" }, x.out))));
  }

  function build() {
    keys.innerHTML = "";
    wrap.querySelectorAll(".seg button").forEach((b, i) => b.classList.toggle("on", (i === 1) === sci));
    const std = [["C", "fn"], ["±", "fn"], ["%", "fn"], ["÷", "op"], ["7"], ["8"], ["9"], ["×", "op"], ["4"], ["5"], ["6"], ["−", "op"], ["1"], ["2"], ["3"], ["+", "op"], ["0", "", 1], [".", ""], ["=", "eq"]];
    const extra = [["(", "fn"], [")", "fn"], ["^", "fn"], ["⌫", "fn"], ["sin", "fn"], ["cos", "fn"], ["tan", "fn"], ["√", "fn"], ["ln", "fn"], ["log", "fn"], ["π", "fn"], ["x²", "fn"]];
    if (sci) {
      const grid = h("div", { style: "display:grid;grid-template-columns:repeat(4,1fr);gap:8px" });
      extra.forEach(([k]) => grid.append(btn(k, "fn", 0, true)));
      keys.append(grid);
    }
    const main = h("div", { style: "display:grid;grid-template-columns:repeat(4,1fr);gap:8px;flex:1" });
    std.forEach(([k, kind, wide]) => main.append(btn(k, kind || "", wide)));
    keys.append(main);
    keys.style.gridTemplateRows = sci ? "auto 1fr" : "1fr";
    render();
  }
  function btn(k, kind, wide, small) {
    const bg = kind === "eq" ? "var(--accent)" : kind === "op" ? "var(--panel-3)" : kind === "fn" ? "var(--panel-2)" : "var(--panel)";
    const color = kind === "eq" ? "var(--accent-ink)" : kind === "op" ? "var(--accent)" : "var(--ink)";
    return h("button", { style: `border:1px solid var(--line);border-radius:${small ? 12 : 16}px;background:${bg};color:${color};font-weight:700;font-size:${small ? 15 : 22}px;font-family:inherit;cursor:pointer;min-height:${small ? 40 : 52}px;${wide ? "grid-column:span 2;" : ""}`,
      onmousedown: e => e.preventDefault(), onclick: () => press(k) }, k);
  }

  document.addEventListener("keydown", e => {
    if (e.ctrlKey || e.metaKey) { if (e.key.toLowerCase() === "c" && !getSelection().toString()) { copy(); e.preventDefault(); } return; }
    const k = e.key;
    if (/^[0-9.()%]$/.test(k)) press(k);
    else if (k === "+") press("+");
    else if (k === "-") press("−");
    else if (k === "*" || k === "x") press("×");
    else if (k === "/") { press("÷"); e.preventDefault(); }
    else if (k === "^") press("^");
    else if (k === "Enter" || k === "=") { press("="); e.preventDefault(); }
    else if (k === "Backspace") press("⌫");
    else if (k === "Escape" || k === "Delete") press("C");
    else return;
  });
  build();
});
