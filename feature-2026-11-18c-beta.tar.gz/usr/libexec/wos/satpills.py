"""satpills: the live things on the right of the shelf, from the real sources.
- Music: any MPRIS player (Firefox, Spotify, VLC, ...) that is playing or paused. Click the pill to play/pause.
- Update: a W-OS update that is installed and waiting for a restart (from the updater's own state file).
The updater does not report download progress, so there is no progress bar yet. Pills appear only while live."""
import json
import os

STATE_FILE = "/var/lib/wos/updates.json"
MPRIS = "org.mpris.MediaPlayer2"


def music_pill(props):
    """props: the player's Player-interface properties as plain Python. None when nothing is playing."""
    status = props.get("PlaybackStatus")
    if status not in ("Playing", "Paused"):
        return None
    meta = props.get("Metadata") or {}
    title = meta.get("xesam:title") or "Music"
    artists = meta.get("xesam:artist") or []
    if isinstance(artists, str):
        artists = [artists]
    state = "%s%s" % ("Paused" if status == "Paused" else "Playing", " · " + ", ".join(artists) if artists else "")
    return {"id": "music", "icon": "audio-x-generic", "title": title[:40], "state": state[:48], "progress": None}


def update_pill(state):
    pending = (state or {}).get("pending")
    if not pending:
        return None
    return {"id": "update", "icon": "system-software-update", "title": "W-OS update", "state": "Restart to finish", "progress": None}


def read_state(path=STATE_FILE):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


class PillSources:
    """Polls the sources every few seconds and keeps the shelf's pills in step."""

    def __init__(self, shelf, state_file=STATE_FILE, interval_ms=5000):
        from gi.repository import Gio, GLib
        self.Gio, self.GLib = Gio, GLib
        self.shelf, self.state_file = shelf, state_file
        self.player = None
        try:
            self.bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        except GLib.Error:
            self.bus = None
        shelf.on_pill = self.clicked
        self.poll()
        GLib.timeout_add(interval_ms, self.poll)

    def _call(self, name, iface, method, params, reply):
        return self.bus.call_sync(name, "/org/mpris/MediaPlayer2", iface, method, params, reply, self.Gio.DBusCallFlags.NONE, 120, None)

    def _players(self):
        if self.bus is None:
            return []
        try:
            names = self.bus.call_sync("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "ListNames", None,
                                       self.GLib.VariantType("(as)"), self.Gio.DBusCallFlags.NONE, 120, None).unpack()[0]
        except self.GLib.Error:
            return []
        return [n for n in names if n.startswith(MPRIS + ".")]

    def current_music(self):
        best = None
        for name in self._players():
            try:
                v = self._call(name, "org.freedesktop.DBus.Properties", "GetAll", self.GLib.Variant("(s)", (MPRIS + ".Player",)),
                               self.GLib.VariantType("(a{sv})")).unpack()[0]
            except self.GLib.Error:
                continue
            pill = music_pill(v)
            if pill:
                try:
                    root = self._call(name, "org.freedesktop.DBus.Properties", "GetAll", self.GLib.Variant("(s)", (MPRIS,)),
                                      self.GLib.VariantType("(a{sv})")).unpack()[0]
                    pill["app"] = (root.get("DesktopEntry") or root.get("Identity") or "").lower() or None
                except self.GLib.Error:
                    pass
            if pill and (best is None or v.get("PlaybackStatus") == "Playing"):
                best, self.player = pill, name
        return best

    def poll(self):
        for pid, pill in (("music", self.current_music()), ("update", update_pill(read_state(self.state_file)))):
            cur = next((p for p in self.shelf.pills if p["id"] == pid), None)
            if pill is None:
                if cur:
                    self.shelf.remove_pill(pid)
            elif not cur or any(cur.get(k) != pill[k] for k in ("title", "state", "icon")):
                self.shelf.set_pill(pill["id"], pill["icon"], pill["title"], pill["state"], pill["progress"], pill.get("app"))
        return True

    def clicked(self, pill):
        if pill["id"] == "update":                      # a waiting update: ask, then restart
            import subprocess
            try:
                subprocess.Popen(["/usr/libexec/wos/wos-update-restart"])
            except OSError:
                pass
            return
        if pill["id"] == "music" and self.player and self.bus:
            try:
                self._call(self.player, MPRIS + ".Player", "PlayPause", None, None)
            except self.GLib.Error:
                pass
