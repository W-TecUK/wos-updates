"use strict";

/* Shared by the wallpaper, top bar and dock pages. Inside the shell each page
   talks to the native process over the WebKit bridge; opened in a plain
   browser (see preview.html) it runs against a mock so the design can be
   worked on without booting anything. */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const surface = document.body.dataset.surface;
const bridge = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.wos;

/* The real shell renders in software (no GPU compositing), where backdrop-filter leaves stale pixels
   behind when a pill changes size. So inside the shell the blur is always off and the denser fill
   is used; only a normal browser (the design preview) gets the frosted look. */
if (bridge || !(CSS.supports("backdrop-filter", "blur(1px)") || CSS.supports("-webkit-backdrop-filter", "blur(1px)"))) {
  document.documentElement.classList.add("noblur");
}

function post(msg) {
  if (bridge) bridge.postMessage(JSON.stringify(msg));
  else mockHost(msg);
}
const handlers = {};
window.wos = { receive(m) { const h = handlers[m.type]; if (h) h(m); } };

const t = key => (typeof I18N !== "undefined" ? I18N.t(key) : key);

handlers.init = m => {
  if (m.lang) window.__lang = m.lang;
  if (typeof I18N !== "undefined") { if (m.lang) I18N.setLanguage(m.lang); I18N.apply(); }
  if (surface === "bar") { tickClock(); if (m.avail) applyAvail(m.avail); }
};

/* ---------- Top bar ---------- */
const DAYS = { en: ["Sun", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat"], es: ["dom", "lun", "mar", "mié", "jue", "vie", "sáb"] };
const MONTHS = { en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"],
                 es: ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sept", "oct", "nov", "dic"] };

/* Choices from Settings > Desktop & Dock, pushed by the shell whenever they change. */
window.__desktop = { wallpaper: "default", dock: "medium", clock24: true, seconds: false, date: true, battery: true,
                     desk_icons: false, desk_bin: true, desk_widgets: true };

function tickClock() {
  const d = new Date(), l = typeof I18N !== "undefined" && I18N.lang.startsWith("es") ? "es" : "en", p = window.__desktop;
  const opts = { hour: "2-digit", minute: "2-digit", hour12: !p.clock24 };
  if (p.seconds) opts.second = "2-digit";
  let hm = d.toLocaleTimeString("en-GB", opts);
  if (!p.clock24) hm = hm.replace(/\b(am|pm)\b/i, x => x.toUpperCase()).replace(/^0/, "");
  $("#clock").textContent = p.date ? `${hm}  ${DAYS[l][d.getDay()]} ${d.getDate()} ${MONTHS[l][d.getMonth()]}` : hm;
}

function showBatteryPct() {
  const el = document.getElementById("battery-pct");
  if (!el) return;
  const b = window.__battery;
  el.textContent = b && window.__desktop.battery ? b.pct + "%" : "";
}

/* The clock re-renders every 15s normally (nothing on screen needs finer than that), but every 1s
   while "show seconds" is on -- otherwise the seconds digit only jumps every 15s instead of ticking. */
let clockTimer = null, clockAtSeconds = null;
function scheduleClockTick() {
  const wantSeconds = !!window.__desktop.seconds;
  if (clockTimer && clockAtSeconds === wantSeconds) return;
  clearInterval(clockTimer);
  clockAtSeconds = wantSeconds;
  clockTimer = setInterval(tickClock, wantSeconds ? 1000 : 15000);
}

handlers["desktop-prefs"] = m => {
  window.__desktop = Object.assign(window.__desktop, m.prefs || {});
  const p = window.__desktop, root = document.documentElement;
  let wall = "";
  if (p.wallpaper && p.wallpaper.startsWith("builtin:")) wall = `url("../../wallpapers/${p.wallpaper.slice(8).replace(/[^a-z0-9_-]/g, "")}.svg")`;
  else if (p.wallpaper && p.wallpaper.startsWith("file:")) wall = `url("file://${encodeURI(p.wallpaper.slice(5))}")`;
  if (wall) root.style.setProperty("--wall", wall); else root.style.removeProperty("--wall");
  root.dataset.dock = p.dock || "medium";
  root.dataset.dockstyle = p.dock_style || "default";
  root.dataset.dockalign = p.dock_align || "center";
  if (surface === "bar") { tickClock(); showBatteryPct(); scheduleClockTick(); }
  if (surface === "dock" && window.__relayoutDock) requestAnimationFrame(() => requestAnimationFrame(window.__relayoutDock));
};

function initBar() {
  const wg = $("#wg"), menu = $("#menu"), appmenu = $("#appmenu");
  let confirming = null, openKind = null, info = { app: "" };
  const fmt = (key, app) => t(key).replace("{app}", app);

  /* One place decides whether the bar window has to be tall (a menu is showing). */
  function closeAll() {
    menu.hidden = true; appmenu.hidden = true; openKind = null; confirming = null;
    const pnl = $("#panel"); if (pnl) { pnl.hidden = true; $("#tray").classList.remove("open"); }
    const dp = $("#datepanel"); if (dp) { dp.hidden = true; $("#clock").classList.remove("open"); stopDatePanelTick(); }
    wg.classList.remove("open");
    $$(".mbtn").forEach(b => b.classList.remove("open"));
    $$("button", menu).forEach(b => b.classList.remove("confirm"));
    post({ type: "bar-open", open: false });
  }
  function opened() { post({ type: "bar-open", open: true }); }
  /* One question, asked everywhere: is anything dropped down? (menus and the status panel) */
  const anyOpen = () => !menu.hidden || !appmenu.hidden || !$("#panel").hidden || !$("#datepanel").hidden;

  /* ---- the WG (system) menu */
  wg.addEventListener("click", e => {
    e.stopPropagation();
    const wasOpen = !menu.hidden;
    closeAll();
    if (!wasOpen) { menu.hidden = false; wg.classList.add("open"); opened(); }
  });
  $$("button", menu).forEach(b => b.addEventListener("click", e => {
    e.stopPropagation();
    if (b.disabled) return;
    if (b.dataset.menu === "force-quit") { post({ type: "menu-action", action: "force-quit-list" }); return; }
    if (b.dataset.menu) { closeAll(); post({ type: "menu-action", action: b.dataset.menu }); return; }
    if (b.dataset.confirm && confirming !== b) {       // destructive actions need a second click
      $$("button", menu).forEach(x => x.classList.remove("confirm"));
      confirming = b; b.classList.add("confirm");
      return;
    }
    closeAll();
    post({ type: "power", action: b.dataset.action });
  }));

  /* ---- Terminally Close (Force Quit): pick an open app, click twice to kill it */
  handlers["force-quit-apps"] = m => {
    appmenu.innerHTML = "";
    const head = document.createElement("div");
    head.className = "head"; head.textContent = t("fq_title"); appmenu.appendChild(head);
    let armed = null;
    if (!m.apps.length) {
      const none = document.createElement("button");
      none.textContent = t("fq_none"); none.disabled = true; appmenu.appendChild(none);
    }
    m.apps.forEach(a => {
      const b = document.createElement("button");
      b.textContent = a.name;
      b.addEventListener("click", e => {
        e.stopPropagation();
        if (armed !== b) {
          $$("button", appmenu).forEach(x => { x.classList.remove("confirm"); if (x._name) x.textContent = x._name; });
          armed = b; b.classList.add("confirm"); b.textContent = fmt("fq_confirm", a.name);
          return;
        }
        closeAll();
        post({ type: "menu-action", action: "force-quit", pid: a.pid });
      });
      b._name = a.name;
      appmenu.appendChild(b);
    });
    menu.hidden = true; wg.classList.remove("open");
    appmenu.style.left = "20px"; appmenu.hidden = false; openKind = "fq";
    opened();
  };

  /* ---- the app menus: Name, View, Help */
  function itemsFor(kind) {
    const app = info.app, st = info.state || {};
    if (kind === "app") return [
      { label: t("menu_preferences"), action: "prefs", disabled: !info.prefs },
      { sep: true },
      { label: fmt("menu_hide", app), action: "hide" },
      { label: fmt("menu_quit", app), action: "quit" },
    ];
    if (kind === "view") return [
      { label: st.fullscreen ? t("menu_exit_fullscreen") : t("menu_fullscreen"), action: "fullscreen" },
      { label: st.maximized ? t("menu_restore") : t("menu_maximise"), action: "maximize" },
      { label: t("menu_minimise"), action: "minimize" },
      { label: t("menu_above"), action: "above", checked: !!st.above },
      { sep: true },
      { label: t("menu_accessibility"), action: "accessibility" },
      { label: t("menu_fonts"), action: "fonts" },
    ];
    const help = info.help || [];
    return help.length ? help.map((title, i) => ({ label: title, action: "help", arg: i }))
                       : [{ label: t("menu_no_help"), disabled: true }];
  }

  function openAppMenu(btn) {
    const kind = btn.dataset.kind;
    const wasOpen = openKind === kind;
    closeAll();
    if (wasOpen || (kind !== "app" && !info.app)) return;
    if (kind === "app" && !info.app) return;          // the desktop itself has no app menu
    appmenu.innerHTML = "";
    itemsFor(kind).forEach(it => {
      if (it.sep) { appmenu.appendChild(document.createElement("hr")); return; }
      const b = document.createElement("button");
      b.innerHTML = `<span class="check">${it.checked ? "✓" : ""}</span>`;
      const lab = document.createElement("span"); lab.textContent = it.label; b.appendChild(lab);
      b.disabled = !!it.disabled;
      b.addEventListener("click", e => { e.stopPropagation(); closeAll(); if (it.action) post({ type: "app-action", action: it.action, arg: it.arg }); });
      appmenu.appendChild(b);
    });
    appmenu.style.left = Math.max(8, btn.getBoundingClientRect().left) + "px";
    appmenu.hidden = false; openKind = kind; btn.classList.add("open");
    opened();
  }
  $$(".mbtn").forEach(b => b.addEventListener("click", e => { e.stopPropagation(); openAppMenu(b); }));

  document.addEventListener("click", () => { if (anyOpen()) closeAll(); });
  /* The native side says when focus moved elsewhere (another window, the launcher): never stay open. */
  handlers["close-menus"] = () => { if (anyOpen()) closeAll(); };
  /* Open a menu from outside (the control socket): used for keyboard access and testing. */
  handlers["open-menu"] = m => {
    closeAll();
    const target = m.which === "wg-menu" ? wg : m.which === "view-menu" ? $("#m-view")
      : m.which === "panel" ? $("#tray") : m.which === "app-menu" ? $("#m-app") : null;
    if (target) target.click();
  };
  window.addEventListener("blur", () => { if (anyOpen()) closeAll(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeAll(); });

  /* ---- the status panel behind the Wi-Fi and battery icons */
  const panel = $("#panel"), tray = $("#tray");
  const nets = $("#panel-nets");
  tray.addEventListener("click", e => {
    e.stopPropagation();
    const wasOpen = !panel.hidden;
    closeAll();
    if (!wasOpen) { panel.hidden = false; tray.classList.add("open"); opened(); post({ type: "panel-open" }); }
  });
  panel.addEventListener("click", e => e.stopPropagation());
  $("#panel-volume").addEventListener("input", e => { $("#panel-volume-n").textContent = e.target.value + "%"; post({ type: "panel-action", what: "volume", value: +e.target.value }); });
  $("#panel-bright").addEventListener("input", e => { $("#panel-bright-n").textContent = e.target.value + "%"; post({ type: "panel-action", what: "brightness", value: +e.target.value }); });
  $("#panel-wifi-radio").addEventListener("click", e => { const on = !e.target.classList.contains("on"); e.target.classList.toggle("on", on); e.target.textContent = on ? "On" : "Off"; post({ type: "panel-action", what: "wifi-radio", on }); });
  $("#panel-bt-radio").addEventListener("click", e => { const on = !e.target.classList.contains("on"); e.target.classList.toggle("on", on); e.target.textContent = on ? "On" : "Off"; post({ type: "panel-action", what: "bt-radio", on }); });
  $("#panel-dnd").addEventListener("click", e => { const on = !e.target.classList.contains("on"); e.target.classList.toggle("on", on); e.target.textContent = on ? "On" : "Off"; post({ type: "panel-action", what: "dnd-toggle", on }); });
  $("#panel-night").addEventListener("click", e => { const on = !e.target.classList.contains("on"); e.target.classList.toggle("on", on); e.target.textContent = on ? "On" : "Off"; post({ type: "panel-action", what: "night-toggle", on }); });
  const btList = $("#panel-bt");
  handlers.panel = m => {
    $("#panel-volume").value = m.volume ?? 50; $("#panel-volume-n").textContent = (m.volume ?? 50) + "%";
    $("#panel-bright-row").hidden = m.brightness == null;
    if (m.brightness != null) { $("#panel-bright").value = m.brightness; $("#panel-bright-n").textContent = m.brightness + "%"; }
    const dndBtn = $("#panel-dnd"); dndBtn.classList.toggle("on", !!m.dnd); dndBtn.textContent = m.dnd ? "On" : "Off";
    const nightBtn = $("#panel-night"); nightBtn.classList.toggle("on", !!m.night); nightBtn.textContent = m.night ? "On" : "Off";
    const r = $("#panel-wifi-radio"); r.classList.toggle("on", !!m.wifi_on); r.textContent = m.wifi_on ? "On" : "Off";
    nets.innerHTML = "";
    if (!m.networks.length) nets.insertAdjacentHTML("beforeend", `<button disabled><span>${m.wifi_on ? "No networks found" : "Wi-Fi is off"}</span></button>`);
    m.networks.forEach(n => {
      const b = document.createElement("button");
      b.innerHTML = `<span class="check">${n.active ? "\u2713" : ""}</span><span></span><span class="sig">${n.secure ? "Secured" : "Open"}</span>`;
      b.children[1].textContent = n.ssid;
      b.addEventListener("click", e => {
        e.stopPropagation();
        if (n.active) return;
        if (!n.secure) { post({ type: "panel-action", what: "connect", ssid: n.ssid }); closeAll(); return; }
        const box = document.createElement("input"); box.type = "password"; box.placeholder = "Password for " + n.ssid; box.className = "netpass";
        b.after(box); box.focus();
        box.addEventListener("keydown", k => { if (k.key === "Enter" && box.value) { post({ type: "panel-action", what: "connect", ssid: n.ssid, password: box.value }); closeAll(); } });
      });
      nets.appendChild(b);
    });
    /* Clipboard history (Super+V), Windows' own convention. Hidden entirely once there's
       nothing to show yet, same as the other rows that depend on hardware/state being there. */
    const clip = $("#panel-clip"), clipList = $("#panel-clip-list");
    const hasClip = !!(m.clipboard && m.clipboard.length);
    clip.hidden = $("#panel-clip-sep").hidden = !hasClip;
    if (hasClip) {
      clipList.innerHTML = "";
      m.clipboard.forEach((c, i) => {
        const b = document.createElement("button");
        b.textContent = c.text.replace(/\s+/g, " ").trim();
        b.title = b.textContent;
        b.addEventListener("click", e => { e.stopPropagation(); post({ type: "panel-action", what: "clipboard-pick", index: i }); closeAll(); });
        clipList.appendChild(b);
      });
    }
    /* Bluetooth: no adapter at all (most virtual machines) hides the whole row, just like brightness does. */
    const btOk = !!m.bt_available;
    $("#panel-bt-row").hidden = $("#panel-bt-sep").hidden = !btOk;
    btList.hidden = !btOk;
    if (!btOk) return;
    const br = $("#panel-bt-radio"); br.classList.toggle("on", !!m.bt_on); br.textContent = m.bt_on ? "On" : "Off";
    btList.innerHTML = "";
    if (!m.bt_on) {
      btList.insertAdjacentHTML("beforeend", `<button disabled><span>Bluetooth is off</span></button>`);
    } else {
      if (!m.bt_devices.length) btList.insertAdjacentHTML("beforeend", `<button disabled><span>No paired devices</span></button>`);
      m.bt_devices.forEach(d => {
        const b = document.createElement("button");
        b.innerHTML = `<span class="check">${d.connected ? "\u2713" : ""}</span><span></span><span class="sig">${d.connected ? "Connected" : "Paired"}</span>`;
        b.children[1].textContent = d.name || d.mac;
        b.addEventListener("click", e => { e.stopPropagation(); post({ type: "panel-action", what: "bt-toggle", mac: d.mac, connected: d.connected }); closeAll(); });
        btList.appendChild(b);
      });
      const more = document.createElement("button");
      more.className = "more"; more.textContent = "Bluetooth Settings\u2026";
      more.addEventListener("click", e => { e.stopPropagation(); post({ type: "panel-action", what: "bt-settings" }); closeAll(); });
      btList.appendChild(more);
    }
  };

  /* ---- the date panel: click the clock for the time to the second, today's events and notifications */
  const clockBtn = $("#clock"), datepanel = $("#datepanel");
  let dpTimer = null;
  function stopDatePanelTick() { clearInterval(dpTimer); dpTimer = null; }
  function tickDatePanel() {
    const d = new Date(), l = typeof I18N !== "undefined" && I18N.lang.startsWith("es") ? "es-ES" : "en-GB", p = window.__desktop;
    $("#dp-time").textContent = d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: !p.clock24 });
    $("#dp-date").textContent = d.toLocaleDateString(l, { weekday: "long", day: "numeric", month: "long" });
  }
  clockBtn.addEventListener("click", e => {
    e.stopPropagation();
    const wasOpen = !datepanel.hidden;
    closeAll();
    if (!wasOpen) {
      datepanel.hidden = false; clockBtn.classList.add("open"); opened();
      tickDatePanel(); dpTimer = setInterval(tickDatePanel, 1000);
      post({ type: "date-panel-open" });
    }
  });
  datepanel.addEventListener("click", e => e.stopPropagation());
  $("#dp-clear").addEventListener("click", e => { e.stopPropagation(); post({ type: "date-panel-action", what: "clear-all" }); });
  handlers["date-panel"] = m => {
    const evs = $("#dp-events"); evs.innerHTML = "";
    if (!m.events.length) evs.insertAdjacentHTML("beforeend", `<button disabled><span>${t("dp_no_events")}</span></button>`);
    m.events.forEach(ev => {
      const b = document.createElement("button"); b.disabled = true;
      b.innerHTML = `<span class="dp-time-col">${ev.time || ""}</span><span></span>`;
      b.children[1].textContent = ev.title;
      evs.appendChild(b);
    });
    const notifs = $("#dp-notifs"); notifs.innerHTML = "";
    $("#dp-clear").hidden = !m.notifications.length;
    if (!m.notifications.length) notifs.insertAdjacentHTML("beforeend", `<button disabled><span>${t("dp_no_notifs")}</span></button>`);
    // Grouped by app, newest group first, like the other desktops' notification centres.
    const groups = new Map();
    m.notifications.forEach(n => { const k = n.app || "W-OS"; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(n); });
    const ago = ts => { const mins = Math.round((Date.now() / 1000 - ts) / 60); return mins < 1 ? "now" : mins < 60 ? mins + " min" : mins < 1440 ? Math.round(mins / 60) + " h" : Math.round(mins / 1440) + " d"; };
    groups.forEach((list, app) => {
      const head = document.createElement("div"); head.className = "dp-group";
      const name = document.createElement("span"); name.textContent = app + (list.length > 1 ? " · " + list.length : "");
      const clr = document.createElement("span"); clr.className = "dp-gclear"; clr.textContent = t("dp_clear");
      clr.addEventListener("click", e => { e.stopPropagation(); post({ type: "date-panel-action", what: "clear-app", app }); });
      head.append(name, clr); notifs.appendChild(head);
      list.forEach(n => {
        const b = document.createElement("button"); b.className = "dp-notif";
        const text = document.createElement("span"); text.className = "dp-notif-text";
        text.innerHTML = `<b></b><span class="s"></span>`;
        text.querySelector("b").textContent = n.title || n.app; text.querySelector(".s").textContent = (n.body || "") + (n.ts ? (n.body ? "  ·  " : "") + ago(n.ts) : "");
        const x = document.createElement("span"); x.className = "dp-notif-x"; x.textContent = "✕";
        b.append(text, x);
        b.addEventListener("click", e => { e.stopPropagation(); post({ type: "date-panel-action", what: "clear-notif", id: n.id }); });
        notifs.appendChild(b);
      });
    });
  };

  handlers.active = m => {
    info = m;
    $("#m-app").textContent = m.app || t("desktop_name");
    $("#m-view").hidden = $("#m-help").hidden = !m.app;   // every app has all three; the bare desktop has none
  };
  handlers.status = m => {
    const wifi = $("#wifi");
    wifi.classList.toggle("off", !m.wifi);
    wifi.setAttribute("title", m.wifi ? m.wifi.name : "");
    const bt = $("#bt");
    bt.hidden = !(m.bt && m.bt.available);      // no adapter (most virtual machines): no icon, same as brightness
    if (m.bt && m.bt.available) {
      bt.classList.toggle("off", !m.bt.on);
      bt.classList.toggle("connected", !!m.bt.connected);
    }
    const bat = $("#battery");
    bat.hidden = !m.battery;
    if (m.battery) {
      $("#battery-fill").setAttribute("width", Math.max(1, Math.round(15 * m.battery.pct / 100)));
      $("#battery-fill").style.fill = m.battery.charging ? "#7ee787" : m.battery.pct <= 15 ? "#ff7b72" : "currentColor";
    }
    window.__battery = m.battery || null;
    showBatteryPct();
  };
  $("#m-app").textContent = t("desktop_name");
  scheduleClockTick();
}

function applyAvail(avail) {
  const store = $("#menu-store");
  if (store && avail.store === false) {
    store.disabled = true;
    store.textContent = `${t("menu_store")} \u2014 ${t("coming_soon")}`;
  }
}

/* ---------- About windows (About This Device / About This W-OS) ---------- */
function initAbout() {
  const activation = a => {
    if (!a || !a.available) return t("act_none");
    const key = { activated: "act_activated", unactivated: "act_unactivated", grace_expired: "act_grace", limited_mode: "act_limited" }[a.lifecycle];
    return key ? t(key) : (a.lifecycle || "?");
  };
  handlers.about = m => {
    const d = m.data;
    let title, sub, fine = "", rows;
    if (m.kind === "device") {
      title = t("about_device"); sub = d.model || d.name;
      rows = [[t("dev_name"), d.name], [t("dev_model"), d.model || "\u2014"],
              [t("dev_cpu"), d.cpu ? d.cpu + (d.cores ? ` (${d.cores})` : "") : "\u2014"],
              [t("dev_mem"), d.memory_gb ? d.memory_gb + " GB" : "\u2014"], [t("dev_storage"), d.storage_gb + " GB"],
              [t("dev_id"), d.device_id || "\u2014"], [t("dev_activation"), activation(d.activation)]];
    } else {
      title = d.name; sub = "";
      rows = [[t("os_nickname"), d.nickname], [t("os_version"), d.version], [t("os_licence"), d.licence]];
      fine = d.copyright;
    }
    $("#about-title").textContent = title;
    $("#about-sub").textContent = sub;
    $("#about-fine").textContent = fine;
    const list = $("#about-rows");
    list.innerHTML = "";
    rows.forEach(([k, v]) => {
      const row = document.createElement("div");
      row.innerHTML = "<dt></dt><dd></dd>";
      $("dt", row).textContent = k; $("dd", row).textContent = v;
      list.appendChild(row);
    });
  };
  $("#about-close").addEventListener("click", () => post({ type: "close-about" }));
  document.addEventListener("keydown", e => { if (e.key === "Escape") post({ type: "close-about" }); });
}

/* ---------- Dock ---------- */
const FALLBACK_ICON = `<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6L5.6 18.4"/></svg>`;

/* Our own icons are full-bleed tiles; other apps' icons (Firefox and so on) keep the pale tile behind them. */
const OWN_ICON = /\/wos-[a-z-]+\.svg$/;
const LAUNCHER_ICON = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 128' width='100%' height='100%'><defs><linearGradient id='glauncherl' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#ffffff'/><stop offset='1' stop-color='#e8ebf2'/></linearGradient><linearGradient id='elauncherl' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#fff' stop-opacity='0'/><stop offset='.22' stop-color='#fff' stop-opacity='0'/></linearGradient><clipPath id='clauncherl'><path d='M36 0 H92 C117 0 128 11 128 36 V92 C128 117 117 128 92 128 H36 C11 128 0 117 0 92 V36 C0 11 11 0 36 0 Z'/></clipPath><filter id='slauncherl' x='-20%' y='-20%' width='140%' height='150%'><feGaussianBlur in='SourceAlpha' stdDeviation='3.2'/><feOffset dy='3.4'/><feComponentTransfer><feFuncA type='linear' slope='.2'/></feComponentTransfer><feMerge><feMergeNode/><feMergeNode in='SourceGraphic'/></feMerge></filter></defs><g clip-path='url(#clauncherl)'><rect width='100%' height='100%' fill='url(#glauncherl)'/><path d='M36 0 H92 C117 0 128 11 128 36 V92 C128 117 117 128 92 128 H36 C11 128 0 117 0 92 V36 C0 11 11 0 36 0 Z' fill='none' stroke='url(#elauncherl)' stroke-width='2'/></g><path d='M36 0 H92 C117 0 128 11 128 36 V92 C128 117 117 128 92 128 H36 C11 128 0 117 0 92 V36 C0 11 11 0 36 0 Z' fill='none' stroke='#000' stroke-opacity='.10'/><g filter='url(#slauncherl)'><circle cx='48' cy='48' r='24' fill='#2f8cff' fill-opacity='0.9'/><circle cx='80' cy='48' r='24' fill='#34c759' fill-opacity='0.8'/><circle cx='48' cy='80' r='24' fill='#ff9f0a' fill-opacity='0.8'/><circle cx='80' cy='80' r='24' fill='#ff375f' fill-opacity='0.7'/></g></svg>`;

/* The dock's Bin: a glass can, with paper showing when it is not empty. */
function binIcon(full) {
  return `<svg viewBox="0 0 128 128" width="100%" height="100%"><rect width="128" height="128" rx="28" fill="#e4e8f1"/><g transform="translate(20 18) scale(1.4)"><path d="M12 18h40l-3.500 36c-.3 3-2.700 5-5.700 5H21.200c-3 0-5.400-2-5.700-5z" fill="#c3cad9"/><rect x="9" y="12" width="46" height="7" rx="3.500" fill="#8d97ad"/><rect x="26" y="7" width="12" height="6" rx="3" fill="#8d97ad"/><path d="M25 30v20M32 30v20M39 30v20" stroke="#f4f6fb" stroke-width="3" stroke-linecap="round"/>${full ? `<path d="M17 12l6-8 7 7 6-9 8 10z" fill="#fff" stroke="#c3cad9" stroke-width="1"/>` : ""}</g></svg>`;
}

function initDock() {
  const dock = $("#dock");
  const dockmenu = $("#dockmenu");
  const next = {};

  function tile(item, onclick, oncontext) {
    const el = document.createElement("div");
    el.className = "app";
    if (item.icon) { const img = document.createElement("img"); img.src = item.icon; img.alt = ""; el.appendChild(img); if (OWN_ICON.test(item.icon)) el.classList.add("filled"); }
    else { el.insertAdjacentHTML("beforeend", item.svg || FALLBACK_ICON); if (item.svg) el.classList.add("filled"); }
    const soon = item.available === false;          // in the dock layout but not built/installed yet
    const tip = document.createElement("span");
    tip.className = "tip"; tip.textContent = soon ? `${item.name} — ${t("coming_soon")}` : item.name; el.appendChild(tip);
    if (item.xids && item.xids.length) el.insertAdjacentHTML("beforeend", `<i class="dot"></i>`);
    if (soon) el.classList.add("soon");
    else {
      el.addEventListener("click", onclick);
      if (oncontext) el.addEventListener("contextmenu", e => { e.preventDefault(); oncontext(e); });
    }
    return el;
  }

  function cycle(key, xids) {
    next[key] = ((next[key] ?? -1) + 1) % xids.length;
    post({ type: "activate", xid: xids[next[key]] });
  }

  let dockMenuOpen = false;
  function closeDockMenu() {
    dockmenu.hidden = true;
    if (dockMenuOpen) { dockMenuOpen = false; post({ type: "dock-open", open: false }); }
  }

  function openDockMenu(app, e) {
    dockmenu.innerHTML = "";
    const items = [{ label: t("dock_open"), action: "open" }];
    if (app.xids.length) items.push({ label: t("dock_quit"), action: "quit", xid: app.xids[0] });
    items.push({ sep: true }, { label: t("dock_remove"), action: "unpin" });
    items.forEach(it => {
      if (it.sep) { dockmenu.appendChild(document.createElement("hr")); return; }
      const b = document.createElement("button");
      b.textContent = it.label;
      b.addEventListener("click", ev => {
        ev.stopPropagation(); closeDockMenu();
        post({ type: "dock-context", action: it.action, id: app.id, xid: it.xid });
      });
      dockmenu.appendChild(b);
    });
    const width = 220;
    const show = () => {
      dockmenu.style.width = width + "px";
      dockmenu.style.left = Math.min(Math.max(4, e.clientX - width / 2), window.innerWidth - width - 4) + "px";
      dockmenu.style.top = "auto";
      dockmenu.style.bottom = "96px";
      dockmenu.hidden = false;
    };
    if (dockMenuOpen) { show(); return; }
    // dock-open makes the shell grow the dock's own window to full screen height (see shell's
    // on_message) -- that resize is asynchronous, so showing the menu right after posting it,
    // before the window has actually grown, meant it rendered against the OLD short window and
    // got clipped exactly like before that fix, just for a different reason. Wait for the
    // viewport to actually resize (with a timeout fallback in case it doesn't fire).
    dockMenuOpen = true;
    let shown = false;
    const onResize = () => { if (!shown) { shown = true; show(); } };
    window.addEventListener("resize", onResize, { once: true });
    setTimeout(() => { window.removeEventListener("resize", onResize); onResize(); }, 200);
    post({ type: "dock-open", open: true });
  }
  document.addEventListener("click", closeDockMenu);

  // Drag a pinned icon to reorder the dock, same gesture macOS's Dock and Windows' taskbar both
  // use. Reordered live (moving the dragged element as the pointer passes another icon) rather
  // than waiting for a drop -- the actual save-and-broadcast happens once, on dragend.
  let dragged = null;
  function makeDraggable(el, id) {
    el.draggable = true;
    el.dataset.appId = id;
    el.addEventListener("dragstart", () => { dragged = el; el.classList.add("dragging"); });
    el.addEventListener("dragend", () => {
      el.classList.remove("dragging");
      if (dragged) post({ type: "dock-reorder", order: [...dock.querySelectorAll(".app[data-app-id]")].map(x => x.dataset.appId) });
      dragged = null;
    });
    el.addEventListener("dragover", e => {
      e.preventDefault();
      if (!dragged || dragged === el) return;
      const rect = el.getBoundingClientRect();
      el.parentNode.insertBefore(dragged, (e.clientX - rect.left) < rect.width / 2 ? el : el.nextSibling);
    });
  }

  handlers.state = m => {
    dock.innerHTML = "";
    // The app launcher and search come first, then a divider, then the pinned apps.
    dock.appendChild(tile({ name: t("launcher_name"), svg: LAUNCHER_ICON }, () => post({ type: "launcher-toggle" })));
    dock.insertAdjacentHTML("beforeend", `<div class="sep"></div>`);
    m.pinned.forEach(a => {
      const el = tile(a, () => a.xids.length ? cycle(a.id, a.xids) : post({ type: "launch", id: a.id }), e => openDockMenu(a, e));
      makeDraggable(el, a.id);
      dock.appendChild(el);
    });
    if (m.extra.length && m.pinned.length) dock.insertAdjacentHTML("beforeend", `<div class="sep"></div>`);
    m.extra.forEach(a => dock.appendChild(tile(a, () => cycle(a.name, a.xids))));
    // The Bin sits at the far end, after a divider, and shows whether it holds anything.
    dock.insertAdjacentHTML("beforeend", `<div class="sep"></div>`);
    dock.appendChild(tile({ name: (window.__lang || "").startsWith("es") ? "Papelera" : "Bin", svg: binIcon(m.bin > 0) }, () => post({ type: "desk-op", op: "open-bin" })));
    requestAnimationFrame(reportLayout);
  };

  window.__relayoutDock = () => reportLayout();
  function reportLayout() {
    const r = dock.getBoundingClientRect();
    post({ type: "dock-layout", full: document.documentElement.dataset.dockstyle === "full", rect: { x: r.x, y: r.y, w: r.width, h: r.height } });
  }
  window.addEventListener("resize", () => requestAnimationFrame(reportLayout));
}

/* ---------- Launcher and search ---------- */
/* Drawn, not emoji: the system has no emoji font, so those show as empty boxes. */
const FOLDER_ICON = `<svg class="fi" viewBox="0 0 24 24" width="30" height="30"><path d="M3 7a2 2 0 0 1 2-2h4.2l2 2H19a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" fill="#5aa9ff"/></svg>`;
const FILE_ICON = `<svg class="fi" viewBox="0 0 24 24" width="30" height="30"><path d="M6 3h8l5 5v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z" fill="#e8ecf5"/><path d="M14 3v5h5" fill="#b6c0d8"/></svg>`;

function initLauncher() {
  const input = $("#lq"), grid = $("#lgrid"), results = $("#lresults"), all = $("#lall");
  let apps = [], files = [], query = "", picked = -1, timer = null;

  const tileFor = (app, onclick) => {
    const el = document.createElement("button");
    el.className = "ltile"; el.type = "button";
    if (app.icon) { const img = document.createElement("img"); img.src = app.icon; img.alt = ""; el.appendChild(img); if (OWN_ICON.test(app.icon)) el.classList.add("filled"); }
    else el.insertAdjacentHTML("beforeend", FALLBACK_ICON);
    const label = document.createElement("span"); label.textContent = app.name; el.appendChild(label);
    el.addEventListener("click", onclick);
    return el;
  };
  const launch = app => post({ type: "launcher-launch", id: app.id });
  const openFile = f => post({ type: "launcher-open", path: f.path });
  const close = () => post({ type: "launcher-close" });
  const matches = () => { const q = query.toLowerCase(); return apps.filter(a => a.name.toLowerCase().includes(q)); };

  function renderGrid() {
    grid.innerHTML = "";
    apps.forEach(a => grid.appendChild(tileFor(a, () => launch(a))));
  }

  /* Typing swaps the grid for a short list: matching apps, then matching files. */
  function renderResults() {
    const found = matches();
    results.innerHTML = "";
    const section = (title, rows) => {
      if (!rows.length) return;
      const h = document.createElement("h3"); h.textContent = title; results.appendChild(h);
      rows.forEach(r => results.appendChild(r));
    };
    const rows = [];
    // A calculator / unit answer comes first, so it is also what Enter picks.
    const ans = window.WQuick && query.trim().length >= 2 ? WQuick.quickAnswer(query) : null;
    const answerRows = ans ? [(() => {
      const r = document.createElement("button"); r.type = "button"; r.className = "lrow answer";
      const big = document.createElement("b"); big.textContent = ans.text; r.appendChild(big);
      const sm = document.createElement("small"); sm.textContent = ans.label + "  ·  " + t("launcher_copy"); r.appendChild(sm);
      r.act = () => post({ type: "launcher-copy", text: ans.copy }); r.addEventListener("click", r.act); rows.push(r); return r;
    })()] : [];
    const appRows = found.map(a => {
      const r = document.createElement("button"); r.type = "button"; r.className = "lrow";
      if (a.icon) { const img = document.createElement("img"); img.src = a.icon; img.alt = ""; r.appendChild(img); if (OWN_ICON.test(a.icon)) r.classList.add("filled"); }
      else r.insertAdjacentHTML("beforeend", FALLBACK_ICON);
      r.appendChild(document.createTextNode(a.name));
      r.addEventListener("click", () => launch(a)); r.act = () => launch(a); rows.push(r); return r;
    });
    const fileRows = files.map(f => {
      const r = document.createElement("button"); r.type = "button"; r.className = "lrow";
      r.insertAdjacentHTML("beforeend", f.dir ? FOLDER_ICON : FILE_ICON);
      r.appendChild(document.createTextNode(f.name));
      if (f.where) { const w = document.createElement("small"); w.textContent = f.where; r.appendChild(w); }
      r.addEventListener("click", () => openFile(f)); r.act = () => openFile(f); rows.push(r); return r;
    });
    // Last row: hand the words to the web, the way every other desktop's search box does.
    const webRows = query.trim().length >= 2 ? [(() => {
      const r = document.createElement("button"); r.type = "button"; r.className = "lrow";
      r.insertAdjacentHTML("beforeend", `<svg class="fi" viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="#5aa9ff" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.5 3.5 3.5 14.5 0 18M12 3c-3.5 3.5-3.5 14.5 0 18"/></svg>`);
      r.appendChild(document.createTextNode(t("launcher_web") + " \u201c" + query.trim() + "\u201d"));
      r.act = () => post({ type: "launcher-web", q: query.trim() }); r.addEventListener("click", r.act); rows.push(r); return r;
    })()] : [];
    section(t("launcher_answer"), answerRows);
    section(t("launcher_apps"), appRows);
    section(t("launcher_files"), fileRows);
    webRows.forEach(r => results.appendChild(r));
    if (!rows.length) { const p = document.createElement("p"); p.className = "none"; p.textContent = t("launcher_none"); results.appendChild(p); }
    results.rows = rows;
    picked = rows.length ? 0 : -1;
    paintPick();
  }

  function paintPick() {
    (results.rows || []).forEach((r, i) => r.classList.toggle("picked", i === picked));
    const r = (results.rows || [])[picked]; if (r) r.scrollIntoView({ block: "nearest" });
  }

  function update() {
    const typing = query.trim().length > 0;
    results.hidden = !typing; all.hidden = typing;
    if (typing) renderResults();
  }

  input.addEventListener("input", () => {
    query = input.value; files = [];
    update();
    clearTimeout(timer);
    if (query.trim().length >= 2) timer = setTimeout(() => post({ type: "launcher-search", q: query.trim() }), 160);
  });

  document.addEventListener("keydown", e => {
    const rows = results.rows || [];
    if (e.key === "Escape") { e.preventDefault(); if (query) { input.value = ""; query = ""; files = []; update(); } else close(); }
    else if (e.key === "ArrowDown" && !results.hidden && rows.length) { e.preventDefault(); picked = (picked + 1) % rows.length; paintPick(); }
    else if (e.key === "ArrowUp" && !results.hidden && rows.length) { e.preventDefault(); picked = (picked - 1 + rows.length) % rows.length; paintPick(); }
    else if (e.key === "Enter" && !results.hidden && rows[picked]) { e.preventDefault(); rows[picked].act(); }
  });
  /* A click on the empty backdrop closes it. */
  document.body.addEventListener("mousedown", e => { if (e.target === document.body || e.target.classList.contains("lbox") || e.target.id === "lgrid") close(); });

  handlers.init = m => {
    if (typeof I18N !== "undefined") { if (m.lang) I18N.setLanguage(m.lang); I18N.apply(); }
  };
  handlers.apps = m => { apps = m.apps || []; renderGrid(); if (query) update(); input.focus(); };
  handlers.results = m => { if (m.q === query.trim()) { files = m.files || []; if (query.trim()) renderResults(); } };
  input.focus();
}

/* ---------- Mock host (browser preview only) ---------- */
const mockNotifs = [{ id: "n1", app: "W-OS", title: "W-OS 1.0.143194176 is ready to install", body: "Brightness, and a Notification Centre.", ts: Date.now() / 1000 - 300 },
                    { id: "n2", app: "Firefox", title: "Download finished", body: "report.pdf", ts: Date.now() / 1000 - 600 },
                    { id: "n3", app: "Firefox", title: "Download finished", body: "photos.zip", ts: Date.now() / 1000 - 1900 },
                    { id: "n4", app: "Files", title: "Screenshot saved", body: "Screenshot 2026-09-22.png", ts: Date.now() / 1000 - 9000 }];
function mockHost(msg) {
  const later = f => setTimeout(f, 60);
  if (msg.type === "ready" && surface === "bar") later(() => {
    window.wos.receive({ type: "init", lang: "en_GB", avail: { settings: true, store: false } });
    window.wos.receive({ type: "active", app: "Firefox", prefs: true, help: ["Contact W-OS support"],
                         state: { fullscreen: false, maximized: false, above: false } });
    window.wos.receive({ type: "status", wifi: { kind: "wifi", name: "Home-5G" }, battery: { pct: 78, charging: false },
                         bt: { available: true, on: true, connected: true } });
  });
  if (msg.type === "panel-open" && surface === "bar") later(() => {
    window.wos.receive({ type: "panel", volume: 62, brightness: 80, wifi_on: true,
      networks: [{ ssid: "Home-5G", signal: 90, secure: true, active: true }, { ssid: "Cafe Wifi", signal: 40, secure: false, active: false }],
      bt_available: true, bt_on: true, bt_devices: [{ mac: "AA:BB:CC:DD:EE:01", name: "AirPods", connected: true },
                                                     { mac: "AA:BB:CC:DD:EE:02", name: "Keyboard", connected: false }] });
  });
  if (msg.type === "date-panel-open" || (msg.type === "date-panel-action" && surface === "bar")) later(() => {
    if (msg.type === "date-panel-action") {
      if (msg.what === "clear-all") mockNotifs.length = 0;
      else if (msg.what === "clear-app") { for (let i = mockNotifs.length - 1; i >= 0; i--) if (mockNotifs[i].app === msg.app) mockNotifs.splice(i, 1); }
      else { const i = mockNotifs.findIndex(n => n.id === msg.id); if (i > -1) mockNotifs.splice(i, 1); }
    }
    window.wos.receive({ type: "date-panel", events: [{ time: "09:30", title: "Stand-up" }, { time: "14:00", title: "Tester call" }], notifications: mockNotifs });
  });
  if (msg.type === "ready" && surface === "dock") later(() => {
    const apps = [["Files", 1], ["Firefox", 1], ["W-Mail", 0], ["Photos", 0], ["W-Calendar", 0], ["Notepad", 0], ["Contacts", 0],
                  ["Spotify", 0], ["App Store", 0], ["Phone Sync", 0], ["Settings", 1], ["W-OS Alpha Feedback", 0]];
    window.wos.receive({ type: "state", extra: [], pinned: apps.map(([name, ready], i) =>
      ({ id: name + ".desktop", name, icon: "", available: !!ready, xids: i === 0 ? [1] : [] })) });
  });
  if (msg.type === "ready" && surface === "launcher") later(() => {
    window.wos.receive({ type: "init", lang: "en_GB" });
    const names = ["Files", "Firefox", "Terminal", "Settings", "Image Viewer", "Text Editor", "Calculator", "Screenshot", "Document Viewer", "Archive Manager", "Printers", "Volume Control"];
    window.wos.receive({ type: "apps", apps: names.map(n => ({ id: n + ".desktop", name: n, icon: "" })) });
  });
  if (msg.type === "launcher-search") later(() => window.wos.receive({ type: "results", q: msg.q, files: [
    { name: msg.q + " notes.txt", path: "/home/will/Documents/" + msg.q + " notes.txt", dir: false, where: "Documents" },
    { name: msg.q + " photos", path: "/home/will/Pictures/" + msg.q + " photos", dir: true, where: "Pictures" }] }));
  if (msg.type === "menu-action" && msg.action === "force-quit-list") later(() =>
    window.wos.receive({ type: "force-quit-apps", apps: [{ name: "Firefox", pid: 101 }, { name: "Files", pid: 102 }] }));
  if (msg.type === "menu-action" && msg.action.startsWith("about-")) parent.postMessage({ showAbout: msg.action.slice(6) }, "*");
  if (msg.type === "close-about") parent.postMessage({ closeAbout: true }, "*");
  if (msg.type === "ready" && surface === "about") later(() => {
    const kind = location.hash.slice(1) || "device";
    window.wos.receive({ type: "init", lang: "en_GB" });
    window.wos.receive({ type: "about", kind, data: kind === "device"
      ? { name: "wos3", model: "innotek GmbH VirtualBox", cpu: "Intel(R) Core(TM) Ultra 5 226V", cores: 2, memory_gb: 3, storage_gb: 19,
          device_id: "d27a8f7b7040", activation: { available: false } }
      : { name: "William Graves Operating Services (W-OS) 4", nickname: "Windermere", version: "Penguin 4ALPHA",
          licence: "William Graves Proprietary Software License (WGPSL)",
          copyright: "William Graves Corp. Ltd. (c) 2020-2026 William Graves Operating Services" } });
  });
  if (["power", "launch", "activate", "app-action", "menu-action"].includes(msg.type)) console.log("mock host:", msg);
}

/* ---------- OSD: the popup on a hardware volume/brightness key press ---------- */
function initOsd() {
  const VOL_UP = `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9v6h4l5 4V5L8 9zM16 8a5 5 0 0 1 0 8"/></svg>`;
  const VOL_MUTE = `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9l5 6M21 9l-5 6"/></svg>`;
  const BRIGHT = `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/></svg>`;
  handlers.osd = m => {
    $("#osd-icon").innerHTML = m.kind === "brightness" ? BRIGHT : (m.muted ? VOL_MUTE : VOL_UP);
    $("#osd-fill").style.width = Math.max(0, Math.min(100, m.value)) + "%";
    $("#osd").classList.toggle("muted", !!m.muted);
  };
}

/* ---------- Music visualisation: one fluid, colour-shifting glowing wave driven by real audio levels ---------- */
function initViz() {
  const canvas = $("#viz-canvas");
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  function resize() { canvas.width = canvas.clientWidth * dpr; canvas.height = canvas.clientHeight * dpr; }
  resize();
  window.addEventListener("resize", resize);
  const bars = 32;
  let target = new Array(bars).fill(0);
  let current = new Array(bars).fill(0);
  let energy = 0.05;
  handlers.viz = m => { if (Array.isArray(m.levels) && m.levels.length) target = m.levels; };

  function wavePath(points, mid, amp, phase, t) {
    const w = canvas.width;
    const step = w / (points.length - 1);
    ctx.beginPath();
    ctx.moveTo(0, canvas.height);
    let prevX = 0, prevY = mid - points[0] * amp;
    ctx.lineTo(prevX, prevY);
    for (let i = 1; i < points.length; i++) {
      const x = i * step;
      const ripple = Math.sin(t * 0.03 + i * 0.6 + phase) * 4 * dpr;   // keeps it gently alive even in near-silence
      const y = mid - points[i] * amp + ripple;
      const cx = (prevX + x) / 2, cy = (prevY + y) / 2;
      ctx.quadraticCurveTo(prevX, prevY, cx, cy);
      prevX = x; prevY = y;
    }
    ctx.lineTo(w, prevY);
    ctx.lineTo(w, canvas.height);
    ctx.closePath();
  }

  let t = 0;
  const LAYERS = [
    { scale: 1.0, alpha: 0.30, phase: 0.0, hueShift: 0 },
    { scale: 0.72, alpha: 0.5, phase: 2.3, hueShift: 60 },
    { scale: 0.46, alpha: 0.85, phase: 4.6, hueShift: 120 },
  ];
  function frame() {
    t++;
    const w = canvas.width, h = canvas.height, mid = h * 0.7;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < bars; i++) current[i] += ((target[i] || 0) - current[i]) * 0.15;
    const peak = Math.max(0.05, ...current);
    energy += (peak - energy) * 0.06;
    const hue = (t * 0.5) % 360;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    LAYERS.forEach(layer => {
      wavePath(current, mid, layer.scale * (h * 0.55) * (0.35 + energy), layer.phase, t);
      const grad = ctx.createLinearGradient(0, 0, w, 0);
      const hueAt = off => (hue + layer.hueShift + off) % 360;
      grad.addColorStop(0, `hsla(${hueAt(0)},90%,65%,${layer.alpha})`);
      grad.addColorStop(0.5, `hsla(${hueAt(120)},90%,65%,${layer.alpha})`);
      grad.addColorStop(1, `hsla(${hueAt(240)},90%,65%,${layer.alpha})`);
      ctx.fillStyle = grad;
      ctx.shadowColor = `hsla(${hue},90%,65%,0.85)`;
      ctx.shadowBlur = 30 * dpr;
      ctx.fill();
    });
    ctx.restore();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

if (surface === "bar") initBar();
if (surface === "dock") initDock();
if (surface === "about") initAbout();
if (surface === "launcher") initLauncher();
if (surface === "osd") initOsd();
if (surface === "viz") initViz();
post({ type: "ready", surface });
