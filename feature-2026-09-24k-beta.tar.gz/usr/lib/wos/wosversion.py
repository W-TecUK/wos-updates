"""W-OS version numbers: MAJOR.MINOR.PATCH, where PATCH is not capped.

An update that does not declare a version gets the current version with its
third number increased by one (1.0.143194163 -> 1.0.143194164). Only a release
that says so bumps the minor (resets patch) or the major (resets both).
"""
import re

_PATTERN = re.compile(r"^v?(\d+)\.(\d+)\.(\d+)$")


def parse(text):
    m = _PATTERN.match(str(text).strip())
    if not m:
        raise ValueError("not a MAJOR.MINOR.PATCH version: %r" % (text,))
    return tuple(int(part) for part in m.groups())


def format_version(parts):
    return "%d.%d.%d" % tuple(parts)


def bump(current, level="patch"):
    major, minor, patch = parse(current)
    if level == "patch":
        return format_version((major, minor, patch + 1))
    if level == "minor":
        return format_version((major, minor + 1, 0))
    if level == "major":
        return format_version((major + 1, 0, 0))
    raise ValueError("unknown bump level: %r" % (level,))


def next_version(current, declared=None, level=None):
    """The version an update installs as.

    declared: a version the update names for itself. It must be newer than the
    current one (a downgrade is refused, not silently accepted).
    level: 'minor' or 'major' when the release asks for one.
    Neither given: the third number goes up by one.
    """
    if declared:
        if compare(declared, current) <= 0:
            raise ValueError("update version %s is not newer than %s" % (declared, current))
        return format_version(parse(declared))
    return bump(current, level or "patch")


def compare(a, b):
    pa, pb = parse(a), parse(b)
    return (pa > pb) - (pa < pb)
