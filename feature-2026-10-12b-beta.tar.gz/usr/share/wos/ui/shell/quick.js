"use strict";
/* Quick answers for the launcher's search box: type 12*7, 20% of 150, sqrt(2), or 5 km in miles and the
   answer is the first result. Pure functions, no DOM, so they can be tested on their own
   (os/tests/quick.test.js). Nothing here uses eval or Function: the expression is parsed by hand. */

(function (root) {
  const FUNCS = {
    sqrt: Math.sqrt, abs: Math.abs, round: Math.round, floor: Math.floor, ceil: Math.ceil,
    sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan,
    ln: Math.log, log: Math.log10, exp: Math.exp,
  };
  const CONSTS = { pi: Math.PI, e: Math.E };

  function tokenize(src) {
    const out = []; let i = 0;
    while (i < src.length) {
      const c = src[i];
      if (/\s/.test(c)) { i++; continue; }
      let m = /^(\d+\.?\d*|\.\d+)/.exec(src.slice(i));
      if (m) { out.push({ t: "num", v: parseFloat(m[1]) }); i += m[1].length; continue; }
      m = /^[a-z]+/.exec(src.slice(i));
      if (m) { out.push({ t: "id", v: m[0] }); i += m[0].length; continue; }
      if (src.startsWith("**", i)) { out.push({ t: "op", v: "^" }); i += 2; continue; }
      if ("+-*/^%()".includes(c)) { out.push({ t: "op", v: c }); i++; continue; }
      return null;
    }
    return out;
  }

  /* expr := term (('+'|'-') term)* ; term := power (('*'|'/') power)* ; power := unary ('^' power)? ;
     unary := ('-'|'+') unary | atom '%'? ; atom := number | const | func '(' expr ')' | '(' expr ')' */
  function parse(tokens) {
    let p = 0;
    const peek = () => tokens[p], next = () => tokens[p++];
    const isOp = v => peek() && peek().t === "op" && peek().v === v;
    function expr() {
      let v = term();
      while (isOp("+") || isOp("-")) {
        const op = next().v, right = term();
        if (right && right.pct !== undefined && op !== undefined) v = op === "+" ? v * (1 + right.pct) : v * (1 - right.pct);   // 150 + 10% -> 165
        else v = op === "+" ? v + num(right) : v - num(right);
      }
      return v;
    }
    const num = x => (x && x.pct !== undefined ? x.pct : x);
    function term() {
      let v = power();
      while (isOp("*") || isOp("/")) {
        const op = next().v, right = num(power());
        if (op === "/" && right === 0) throw new Error("div0");
        v = op === "*" ? num(v) * right : num(v) / right;
      }
      return v;
    }
    function power() {
      const base = unary();
      if (isOp("^")) { next(); return Math.pow(num(base), num(power())); }
      return base;
    }
    function unary() {
      if (isOp("-")) { next(); return -num(unary()); }
      if (isOp("+")) { next(); return num(unary()); }
      const v = atom();
      if (isOp("%")) { next(); return { pct: v / 100 }; }
      return v;
    }
    function atom() {
      const tk = next();
      if (!tk) throw new Error("end");
      if (tk.t === "num") return tk.v;
      if (tk.t === "id") {
        if (tk.v in CONSTS) return CONSTS[tk.v];
        if (tk.v in FUNCS) {
          if (!isOp("(")) throw new Error("fn");
          next(); const arg = num(expr());
          if (!isOp(")")) throw new Error("paren"); next();
          return FUNCS[tk.v](arg);
        }
        throw new Error("id");
      }
      if (tk.v === "(") { const v = expr(); if (!isOp(")")) throw new Error("paren"); next(); return v; }
      throw new Error("tok");
    }
    const v = expr();
    if (p !== tokens.length) throw new Error("trailing");
    return num(v);
  }

  function formatNumber(n) {
    if (!isFinite(n)) return null;
    const abs = Math.abs(n);
    if (abs !== 0 && (abs >= 1e15 || abs < 1e-9)) return n.toExponential(6).replace(/\.?0+e/, "e");
    return Number(n.toPrecision(12)).toLocaleString("en-GB", { maximumFractionDigits: abs >= 1 ? 6 : 10 });
  }

  /* "20% of 150" -> 30. Anything else goes through the expression parser. */
  function calculate(query) {
    let q = String(query).toLowerCase().trim().replace(/,(?=\d{3}\b)/g, "").replace(/[×]/g, "*").replace(/÷/g, "/");
    q = q.replace(/^=\s*/, "");
    q = q.replace(/(\d+(?:\.\d+)?)\s*%\s*of\s*(\S+)/g, "($1/100*$2)");
    q = q.replace(/(\d)\s*x\s*(?=[\d(.])/g, "$1*");
    if (!/\d/.test(q) && !/\b(pi|e)\b/.test(q)) return null;
    if (!/[-+*/^%()]|\b(sqrt|abs|round|floor|ceil|sin|cos|tan|asin|acos|atan|ln|log|exp)\b/.test(q.replace(/^[-+]/, ""))) return null;   // a bare number is not a question
    const tokens = tokenize(q);
    if (!tokens || !tokens.length) return null;
    try { const v = parse(tokens); const text = formatNumber(v); return text === null ? null : { value: v, text }; }
    catch (e) { return null; }
  }

  /* ---- unit conversion: "5 km in miles", "100 f to c", "2 lb to kg" */
  const U = {};
  const add = (kind, base, names) => names.forEach(([n, f]) => { U[n] = { kind, f, base }; });
  add("length", "m", [["m", 1], ["metre", 1], ["metres", 1], ["meter", 1], ["meters", 1], ["km", 1000], ["kilometre", 1000], ["kilometres", 1000], ["kilometer", 1000], ["kilometers", 1000],
    ["cm", 0.01], ["mm", 0.001], ["mi", 1609.344], ["mile", 1609.344], ["miles", 1609.344], ["yd", 0.9144], ["yard", 0.9144], ["yards", 0.9144],
    ["ft", 0.3048], ["foot", 0.3048], ["feet", 0.3048], ["in", 0.0254], ["inch", 0.0254], ["inches", 0.0254]]);
  add("mass", "kg", [["kg", 1], ["kilo", 1], ["kilos", 1], ["kilogram", 1], ["kilograms", 1], ["g", 0.001], ["gram", 0.001], ["grams", 0.001], ["mg", 1e-6],
    ["lb", 0.45359237], ["lbs", 0.45359237], ["pound", 0.45359237], ["pounds", 0.45359237], ["oz", 0.028349523125], ["ounce", 0.028349523125], ["ounces", 0.028349523125],
    ["st", 6.35029318], ["stone", 6.35029318]]);
  add("volume", "l", [["l", 1], ["litre", 1], ["litres", 1], ["liter", 1], ["liters", 1], ["ml", 0.001], ["gal", 3.785411784], ["gallon", 3.785411784], ["gallons", 3.785411784],
    ["pint", 0.56826125], ["pints", 0.56826125], ["cup", 0.2365882365], ["cups", 0.2365882365]]);
  add("speed", "m/s", [["m/s", 1], ["mph", 0.44704], ["kph", 1 / 3.6], ["km/h", 1 / 3.6], ["kmh", 1 / 3.6], ["knot", 0.514444], ["knots", 0.514444]]);
  add("data", "b", [["b", 1], ["kb", 1e3], ["mb", 1e6], ["gb", 1e9], ["tb", 1e12], ["byte", 1], ["bytes", 1], ["kib", 1024], ["mib", 1048576], ["gib", 1073741824]]);
  const TEMP = { c: "c", celsius: "c", "°c": "c", f: "f", fahrenheit: "f", "°f": "f", k: "k", kelvin: "k" };
  const toK = (v, u) => u === "c" ? v + 273.15 : u === "f" ? (v - 32) * 5 / 9 + 273.15 : v;
  const fromK = (v, u) => u === "c" ? v - 273.15 : u === "f" ? (v - 273.15) * 9 / 5 + 32 : v;
  const LABEL = { c: "°C", f: "°F", k: "K" };

  function convert(query) {
    const m = /^\s*(-?[\d,]*\.?\d+)\s*([a-z°\/]+)\s+(?:to|in|into|as)\s+([a-z°\/]+)\s*$/i.exec(String(query));
    if (!m) return null;
    const v = parseFloat(m[1].replace(/,/g, "")), from = m[2].toLowerCase(), to = m[3].toLowerCase();
    if (TEMP[from] && TEMP[to]) {
      const out = fromK(toK(v, TEMP[from]), TEMP[to]);
      return { text: `${formatNumber(Math.round(out * 1e6) / 1e6)} ${LABEL[TEMP[to]]}`, value: out, label: `${formatNumber(v)} ${LABEL[TEMP[from]]}` };
    }
    const a = U[from], b = U[to];
    if (!a || !b || a.kind !== b.kind) return null;
    const out = v * a.f / b.f;
    return { text: `${formatNumber(out)} ${m[3]}`, value: out, label: `${formatNumber(v)} ${m[2]}` };
  }

  /* One answer for the box, or null. kind says which, so the row can word its hint. */
  function quickAnswer(query) {
    const conv = convert(query);
    if (conv) return { kind: "convert", text: conv.text, copy: String(conv.value), label: conv.label };
    const calc = calculate(query);
    if (calc) return { kind: "calc", text: calc.text, copy: String(calc.value), label: String(query).trim() };
    return null;
  }

  const api = { quickAnswer, calculate, convert, formatNumber };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.WQuick = api;
})(typeof window !== "undefined" ? window : globalThis);
