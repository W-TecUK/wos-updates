"use strict";
/* W-OS Alpha Feedback: tell us what to fix. Saved on this device first, then sent by email. */

boot(async info => {
  const root = $("#root");
  let kind = "Bug", history = await wos.data.get("history", []);
  const KINDS = { Bug: "Something is broken", Idea: "I’d like…", Praise: "I like this" };

  const seg = h("div.seg", Object.keys(KINDS).map(k => h("button" + (k === kind ? ".on" : ""), { onclick: e => { kind = k; $$("button", seg).forEach(b => b.classList.remove("on")); e.target.classList.add("on"); hint.textContent = KINDS[k]; } }, k)));
  const hint = h("span.muted.small", KINDS[kind]);
  const msg = h("textarea.field", { rows: 8, placeholder: "What happened? What did you expect?" });
  const app = h("input.field", { placeholder: "Which app or screen? (optional)" });
  const email = h("input.field", { placeholder: "Your email, if we may reply (optional)", value: info.user && "" });
  const sys = h("button.switch.on", { onclick: () => sys.classList.toggle("on") });
  const sent = h("div");

  const send = async () => {
    if (!msg.value.trim()) { toast("Write a few words first"); return; }
    let extra = "";
    if (sys.classList.contains("on")) { const i = await wos.call("sys.info"); extra = `\n\n---\nW-OS ${i.version} (build ${i.build})\n${i.device}, ${i.cpu}, ${i.memory_gb} GB\nDevice ${i.device_id}`; }
    const entry = { id: uid(), kind, app: app.value, text: msg.value.trim(), email: email.value, date: Date.now() };
    history.unshift(entry); await wos.data.set("history", history);
    let r = { sent: false };
    try { r = await wos.call("feedback.send", { kind, text: entry.text, app: entry.app, email: entry.email, system: sys.classList.contains("on") ? await wos.call("sys.info") : null }); } catch (e) { r = { sent: false }; }
    if (!r.sent) {
      const body = `${entry.text}${entry.app ? "\n\nApp: " + entry.app : ""}${entry.email ? "\nReply to: " + entry.email : ""}${extra}`;
      await wos.call("sys.openUrl", { url: `mailto:feedback.wos@willgraves.co.uk?subject=${encodeURIComponent("[W-OS Alpha] " + kind)}&body=${encodeURIComponent(body)}` });
    }
    msg.value = ""; app.value = ""; toast(r.sent ? "Thank you. Your feedback was sent." : "Saved. Your email app has the message ready to send."); draw();
  };

  const body = h("div.body", { style: "max-width:560px;margin:0 auto;width:100%" },
    h("h1.dots", { style: "font-size:36px;margin:4px 0 4px" }, "Feedback"), h("p.muted", { style: "margin:0 0 18px" }, "This is an early version. What should we fix or add?"),
    h("div", { style: "display:flex;align-items:center;gap:12px;margin-bottom:12px" }, seg, hint),
    h("div.form-row", msg), h("div.form-row", app), h("div.form-row", email),
    h("div.row", { style: "cursor:default;padding:10px 0;border:0" }, h("div.grow", h("div.t", "Include system details"), h("div.s", "W-OS version and hardware, to help us reproduce it")), sys),
    h("button.btn", { onclick: send, style: "margin:6px 0 24px" }, h("span", { html: icon("send", 15) }), "Send"), sent);
  root.append(h("div.app.no-side", h("div.main", body)));

  function draw() {
    sent.innerHTML = "";
    if (!history.length) return;
    const rows = history.slice(0, 8).map(e => h("div.row", { style: "cursor:default" },
      h("span.chip", e.kind),
      h("div.grow", h("div.t", e.text.slice(0, 70)), h("div.s", new Date(e.date).toLocaleString("en-GB")))));
    sent.append(h("span.label", "Sent from this device"), h("div.card", { style: "margin-top:10px" }, h("div.list", rows)));
  }
  draw();
});
