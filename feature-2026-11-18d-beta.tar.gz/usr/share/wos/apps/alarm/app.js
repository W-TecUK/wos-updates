"use strict";
/* The alarm window: opened by the system when an alarm or timer goes off. Plays the alarm sound until you stop or snooze it
   (and stops by itself after about two minutes). Enter stops it, Space snoozes it for five minutes. */

boot(async info => {
  const root = $("#root");
  const [title, body] = (info.args || []).concat(["Alarm", ""]);
  const now = new Date();
  const clock = h("div", { style: "font-size:64px;font-weight:800;letter-spacing:-.03em;line-height:1;font-variant-numeric:tabular-nums" }, `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`);
  const stop = () => { wos.call("alarm.stop").catch(() => {}); wos.call("app.quit").catch(() => window.close()); };
  const snooze = async () => { try { await wos.call("alarm.snooze", { label: title, minutes: 5 }); toast("Snoozed for 5 minutes"); } catch (e) { /* still stop the sound */ } stop(); };
  root.append(h("div", { style: "height:100%;display:flex;align-items:center;justify-content:center;padding:20px" },
    h("div.panel.hero", { style: "width:100%;min-height:0;padding:28px 24px" },
      h("span.chip.gold.eyebrow", { html: icon("clock", 13), style: "gap:6px" }, ""), clock, h("h3", { style: "margin:14px 0 4px;font-size:22px" }, title), body ? h("p", { style: "margin:0 0 16px" }, body) : h("p", { style: "margin:0 0 16px" }, "Time is up"),
      h("div", { style: "display:flex;gap:10px" }, h("button.btn.large.ghost", { onclick: snooze }, "Snooze 5 min"), h("button.btn.large", { onclick: stop }, "Stop")))));
  document.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === "Escape") stop(); else if (e.key === " ") { e.preventDefault(); snooze(); } });
  window.addEventListener("beforeunload", () => { wos.call("alarm.stop").catch(() => {}); });
  wos.call("alarm.play").catch(() => {});
  setTimeout(stop, 130000);                        // nobody is there: stop the noise and close
});
