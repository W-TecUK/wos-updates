"use strict";
/* W-Mail: your W-Account mailbox. Needs a W-Account; a local account sees how to add one.
   Until the W-Mail service is connected, messages live on this device: mail you write waits
   in the Outbox and goes out when the service is reachable. */

boot(async info => {
  const root = $("#root");
  const account = await wos.call("account.get");
  if (account.type !== "waccount") {
    root.append(h("div.empty", { style: "height:100%" }, h("div", h("div", { html: icon("mail", 44), style: "color:var(--muted);margin-bottom:10px" }), h("h1", { style: "margin:0 0 6px" }, "W-Mail needs a W-Account"),
      h("p", "You are using a local account, which stays on this device. Sign in with your W-Account (the same one as W-Life) in Settings to use W-Mail."),
      h("button.btn", { onclick: () => wos.call("sys.launch", { id: "wos-settings.desktop" }) }, "Open Settings"))));
    return;
  }

  let boxes = await wos.data.get("boxes", null);
  if (!boxes) {
    boxes = { inbox: [{ id: uid(), from: "W-OS Team", addr: "hello@willgraves.co.uk", subject: "Welcome to W-Mail", date: Date.now(), read: false,
      body: `Hi ${info.full_name},\n\nThis is your W-Mail inbox. Mail from your W-Account will appear here once the service is connected.\n\nUntil then you can write messages: they wait in the Outbox and send automatically.\n\nThe W-OS team` }],
      sent: [], drafts: [], outbox: [], bin: [] };
    await wos.data.set("boxes", boxes);
  }
  const save = () => wos.data.set("boxes", boxes);
  let box = "inbox", current = null, query = "";
  const NAMES = { inbox: ["Inbox", "mail"], sent: ["Sent", "send"], drafts: ["Drafts", "edit"], outbox: ["Outbox", "refresh"], bin: ["Bin", "trash"] };

  const nav = h("nav.nav"); const list = h("div.list"); const reader = h("div", { style: "flex:1;overflow:auto;padding:24px 30px;min-width:0" });
  const search = h("input.field", { placeholder: "Search", oninput: e => { query = e.target.value.toLowerCase(); drawList(); } });
  const side = h("aside.side", h("button.btn", { style: "width:100%;justify-content:center;margin-bottom:14px", onclick: () => compose() }, h("span", { html: icon("edit", 15) }), "Write"), nav);
  const mid = h("div", { style: "width:320px;border-right:1px solid var(--line);display:flex;flex-direction:column;min-height:0" },
    h("div", { style: "padding:12px" }, h("div.search", h("span", { html: icon("search") }), search)), h("div", { style: "flex:1;overflow:auto" }, list));
  root.append(h("div", { style: "display:grid;grid-template-columns:200px 320px 1fr;height:100%" }, side, mid, reader));

  function drawNav() {
    nav.innerHTML = "";
    Object.entries(NAMES).forEach(([k, [label, ic]]) => {
      const unread = k === "inbox" ? boxes.inbox.filter(m => !m.read).length : 0;
      nav.append(h("button" + (box === k ? ".on" : ""), { onclick: () => { box = k; current = null; draw(); } }, h("span", { html: icon(ic) }), h("span", { style: "flex:1" }, label),
        unread ? h("span.badge", unread) : (boxes[k].length && k !== "inbox" ? h("span.small.muted", boxes[k].length) : null)));
    });
  }
  function drawList() {
    list.innerHTML = "";
    const shown = boxes[box].filter(m => !query || (m.subject + m.from + m.body).toLowerCase().includes(query)).sort((a, b) => b.date - a.date);
    if (!shown.length) list.append(h("div", { style: "padding:30px;text-align:center", class: "muted" }, "Nothing in " + NAMES[box][0]));
    shown.forEach(m => list.append(h("button.row" + (current === m.id ? ".on" : ""), { onclick: () => { current = m.id; m.read = true; save(); draw(); } },
      m.read ? null : h("span.dot"), h("div.grow", h("div.t", box === "inbox" ? m.from : (m.to || "No recipient")), h("div.s", m.subject || "(no subject)")),
      h("span.small.muted", new Date(m.date).toLocaleDateString("en-GB", { day: "numeric", month: "short" })))));
  }
  function drawReader() {
    reader.innerHTML = ""; const m = boxes[box].find(x => x.id === current);
    if (!m) { reader.append(h("div.empty", h("div", h("div", { html: icon("mail", 44), style: "color:var(--muted);margin-bottom:10px" }), h("p", "Select a message to read it.")))); return; }
    reader.append(h("div", { style: "max-width:680px" },
      h("div", { style: "display:flex;align-items:center;gap:10px;margin-bottom:6px" }, h("h1", { style: "margin:0;font-size:22px;flex:1" }, m.subject || "(no subject)"),
        box === "inbox" ? h("button.btn.ghost.small", { onclick: () => compose({ to: m.addr, subject: "Re: " + m.subject, body: `\n\n— ${m.from} wrote:\n` + m.body.split("\n").map(l => "> " + l).join("\n") }) }, "Reply") : null,
        box === "drafts" ? h("button.btn.small", { onclick: () => { boxes.drafts = boxes.drafts.filter(x => x !== m); save(); compose(m); } }, "Edit") : null,
        h("button.icon-btn", { title: "Delete", html: icon("trash"), onclick: () => del(m) })),
      h("div.small.muted", { style: "margin-bottom:18px" }, box === "inbox" ? `${m.from} <${m.addr}>` : `To ${m.to || "—"}`, "  ·  ", new Date(m.date).toLocaleString("en-GB")),
      h("div", { style: "white-space:pre-wrap;line-height:1.65;user-select:text" }, m.body)));
  }
  function del(m) { boxes[box] = boxes[box].filter(x => x !== m); if (box !== "bin") boxes.bin.push(m); current = null; save(); draw(); }
  function draw() { drawNav(); drawList(); drawReader(); }

  function compose(seed = {}) {
    const to = h("input.field", { placeholder: "To", value: seed.to || "" }), subject = h("input.field", { placeholder: "Subject", value: seed.subject || "" });
    const body = h("textarea.field", { rows: 10, placeholder: "Write your message…" }, seed.body || "");
    const close = () => back.remove();
    const back = h("div.modal-back", h("div.modal", { style: "width:min(640px,94vw)" }, h("h2", "New message"),
      h("div.form-row", to), h("div.form-row", subject), h("div.form-row", body),
      h("div.actions", h("button.btn.ghost", { onclick: () => { if (to.value || subject.value || body.value) { boxes.drafts.push({ id: uid(), to: to.value, subject: subject.value, body: body.value, date: Date.now(), read: true }); save(); } close(); box = "drafts"; draw(); } }, "Save draft"),
        h("button.btn", { onclick: () => {
          if (!/.+@.+\..+/.test(to.value.trim())) { toast("Add a valid email address"); return; }
          boxes.outbox.push({ id: uid(), to: to.value.trim(), subject: subject.value, body: body.value, date: Date.now(), read: true }); save(); close(); box = "outbox"; toast("Queued: it sends when W-Mail is connected"); draw(); } }, "Send"))));
    document.body.append(back); (seed.to ? body : to).focus();
  }
  draw();
});
