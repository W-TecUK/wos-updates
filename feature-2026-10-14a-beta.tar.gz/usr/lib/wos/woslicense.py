"""W-OS licensing: who may use W-OS, and what they get.

    Signed in with a W-Account (W-Life ID)  -> everything, free (except anything marked Premium)
    A product key bought for this computer  -> everything, free of an account (£150 one-off, linked to the device)
    Neither                                 -> unlicensed

A product key is a company-signed statement "this edition may run on the device with this code". It is
checked offline with the public key shipped in /usr/share/wos/license.json, so it needs no server to
verify and cannot be forged or moved to another computer. Standard library plus the system openssl.
"""
import base64
import hashlib
import json
import os
import re
import subprocess
import tempfile

PREFIX = "WOS4-"
EDITIONS = ("full", "premium")
KEY_MAX = 600


class LicenseError(Exception):
    """Message safe to show to the person."""


def device_code(machine_id):
    """Short code the person reads out when buying a key, derived from this computer's machine-id."""
    digest = hashlib.sha256(b"wos-device-v1:" + machine_id.strip().encode()).hexdigest()[:16].upper()
    return "-".join(digest[i:i + 4] for i in range(0, 16, 4))


def normalise_device(text):
    code = re.sub(r"[^0-9A-Fa-f]", "", str(text or "")).upper()
    if len(code) != 16:
        raise LicenseError("A device code is 16 letters and numbers, like 1A2B-3C4D-5E6F-7A8B.")
    return "-".join(code[i:i + 4] for i in range(0, 16, 4))


def _b32(data):
    return base64.b32encode(data).decode().rstrip("=")


def _unb32(text):
    text = text.upper()
    return base64.b32decode(text + "=" * (-len(text) % 8))


def _group(text, n=6):
    return "-".join(text[i:i + n] for i in range(0, len(text), n))


def make_key(payload, sign):
    """sign(bytes) -> signature bytes. Used by the company tool, never on a device."""
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return PREFIX + _group(_b32(raw)) + "." + _group(_b32(sign(raw)))


def parse_key(text):
    text = re.sub(r"\s+", "", str(text or ""))
    if not text or len(text) > KEY_MAX:
        raise LicenseError("That does not look like a W-OS product key.")
    if text.upper().startswith(PREFIX):
        text = text[len(PREFIX):]
    body, dot, sig = text.replace("-", "").partition(".")
    if not dot or not re.fullmatch(r"[A-Za-z2-7]+", body) or not re.fullmatch(r"[A-Za-z2-7]+", sig):
        raise LicenseError("That does not look like a W-OS product key.")
    try:
        raw, signature = _unb32(body), _unb32(sig)
        payload = json.loads(raw)
    except (ValueError, TypeError):
        raise LicenseError("That does not look like a W-OS product key.")
    if not isinstance(payload, dict):
        raise LicenseError("That does not look like a W-OS product key.")
    return raw, signature, payload


def _verify_signature(pubkey_pem, message, signature):
    try:
        with tempfile.TemporaryDirectory() as d:
            for name, data in (("pub.pem", pubkey_pem.encode()), ("msg", message), ("sig", signature)):
                with open(os.path.join(d, name), "wb") as f:
                    f.write(data)
            r = subprocess.run(["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", os.path.join(d, "pub.pem"), "-rawin",
                                "-in", os.path.join(d, "msg"), "-sigfile", os.path.join(d, "sig")], capture_output=True, timeout=20)
            return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def check_key(text, pubkey_pem, device):
    """The key's details when it is genuine and made for this device; otherwise LicenseError."""
    raw, signature, payload = parse_key(text)
    if not _verify_signature(pubkey_pem, raw, signature):
        raise LicenseError("This product key is not genuine.")
    if payload.get("v") != 1 or payload.get("edition") not in EDITIONS:
        raise LicenseError("This product key is for a different version of W-OS.")
    if normalise_device(payload.get("device")) != normalise_device(device):
        raise LicenseError("This product key belongs to a different computer.")
    return {"edition": payload["edition"], "id": str(payload.get("id", ""))[:40], "issued": str(payload.get("issued", ""))[:10]}


def status(account, key_text, pubkey_pem, device, premium_account=False):
    """What this computer is entitled to right now.

    account: "waccount" or "local". key_text: the installed product key or "". Never raises."""
    key = None
    if key_text:
        try:
            key = check_key(key_text, pubkey_pem, device)
        except LicenseError as e:
            key = {"error": str(e)}
    if account == "waccount":
        return {"state": "account", "premium": bool(premium_account), "edition": "full",
                "key_error": (key or {}).get("error", ""), "device": device}
    if key and "error" not in key:
        return {"state": "key", "premium": key["edition"] == "premium", "edition": key["edition"], "device": device,
                "key_error": "", "issued": key["issued"]}
    return {"state": "unlicensed", "premium": False, "edition": "", "device": device, "key_error": (key or {}).get("error", "")}
