"""Notification history: keep a copy of every desktop notification (from any app) for the date panel.

`parse_monitor` reads the text `dbus-monitor` prints for org.freedesktop.Notifications.Notify calls and yields
(app, title, body). `append_log` adds one entry to ~/.local/share/wos/notifications.json (newest last, capped),
skipping an identical one that just arrived, so apps that log their own notifications are not listed twice.
"""
import html
import json
import os
import re
import time
import uuid

LOG = os.path.expanduser("~/.local/share/wos/notifications.json")
MAX = 200
DEDUPE_SECONDS = 5
TYPE_LINE = re.compile(r"^ {3}(string|uint32|int32|array|dict|variant|boolean|byte|double|uint64|int64|object|struct)\b")
STRING_LINE = re.compile(r'^ {3}string "(.*)$', re.S)


def strip_markup(text):
    text = re.sub(r"<img[^>]*alt=\"([^\"]*)\"[^>]*>", r"\1", text)
    text = re.sub(r"<br\s*/?>", " ", text)
    return re.sub(r"[ 	]+", " ", html.unescape(re.sub(r"</?(b|i|u|a|img)[^>]*>", "", text))).strip()


def parse_monitor(lines):
    """Yield (app, title, body) for each Notify method call in dbus-monitor text output."""
    in_call = False
    strings = []             # finished top-level strings of the call
    current = None           # the string value still being read (it may span lines)

    def finish():
        nonlocal current
        if current is not None:
            strings.append(current[:-1] if current.endswith('"') else current)
            current = None

    for raw in lines:
        line = raw.rstrip("\n")
        if line.startswith(("method call", "method return", "signal", "error")):
            finish()
            in_call = line.startswith("method call") and "member=Notify" in line and "org.freedesktop.Notifications" in line
            strings = []
            continue
        if not in_call:
            continue
        if TYPE_LINE.match(line):
            finish()
            m = STRING_LINE.match(line)
            if m and len(strings) < 4:
                current = m.group(1)
            if len(strings) >= 4:
                app, _icon, title, body = strings[:4]
                in_call = False
                strings = []
                yield app, title, body
        elif current is not None:
            current += "\n" + line
    finish()


def append_log(app, title, body, path=None, now=None):
    path = path or LOG
    title, body = strip_markup(title)[:160], strip_markup(body)[:400]
    if not title and not body:
        return False
    now = time.time() if now is None else now
    try:
        with open(path) as f:
            items = json.load(f)
        if not isinstance(items, list):
            items = []
    except (OSError, ValueError):
        items = []
    for old in items[-5:]:
        if old.get("title") == title and old.get("body") == body and now - old.get("ts", 0) < DEDUPE_SECONDS:
            return False
    items.append({"id": uuid.uuid4().hex[:12], "app": str(app)[:60], "title": title, "body": body, "ts": now, "cleared": False})
    items = items[-MAX:]
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(items, f)
    os.replace(tmp, path)
    return True
