"use strict";
/* Contacts: people on the left, their details on the right. Stored on this device. */

boot(async () => {
  const root = $("#root");
  let people = await wos.data.get("people", null);
  if (!people) { people = []; await wos.data.set("people", people); }
  let current = null, query = "", editing = false, faves = false;
  const save = () => wos.data.set("people", people);
  const byName = (a, b) => (a.name || "~").toLowerCase().localeCompare((b.name || "~").toLowerCase());

  const search = h("input.field", { placeholder: "Search", oninput: e => { query = e.target.value.toLowerCase(); drawList(); } });
  const seg = h("div.seg", h("button.on", { onclick: e => { faves = false; toggleSeg(e); } }, "All"), h("button", { onclick: e => { faves = true; toggleSeg(e); } }, "Favourites"));
  const list = h("div.list");
  const side = h("aside.side", { style: "display:flex;flex-direction:column;padding:12px;gap:10px" },
    h("div", { style: "display:flex;gap:8px" }, h("div.search", { style: "flex:1" }, h("span", { html: icon("search") }), search),
      h("button.icon-btn", { title: "New contact", html: icon("plus"), onclick: add })),
    seg, h("div.card", { style: "flex:1;overflow:auto" }, list));
  const detail = h("div.body");
  root.append(h("div.app", side, h("div.main", detail)));

  function toggleSeg(e) { $$("button", seg).forEach(b => b.classList.remove("on")); e.target.classList.add("on"); drawList(); }
  function add() { const p = { id: uid(), name: "", phone: "", email: "", address: "", notes: "", fave: false }; people.push(p); current = p.id; editing = true; drawList(); drawDetail(); }
  const get = () => people.find(p => p.id === current);

  function drawList() {
    list.innerHTML = "";
    let shown = people.filter(p => (!faves || p.fave) && (!query || [p.name, p.phone, p.email].join(" ").toLowerCase().includes(query))).sort(byName);
    if (!shown.length) list.append(h("div.row.muted", { style: "cursor:default" }, people.length ? "No matches" : "No contacts yet"));
    let letter = "";
    shown.forEach(p => {
      const l = (p.name || "#")[0].toUpperCase();
      if (l !== letter) { letter = l; list.append(h("div.label", { style: "padding:10px 14px 4px" }, l)); }
      list.append(h("button.row" + (p.id === current ? ".on" : ""), { onclick: () => { current = p.id; editing = false; drawList(); drawDetail(); } },
        h("div.avatar", initials(p.name)), h("div.grow", h("div.t", p.name || "New contact"), h("div.s", p.phone || p.email || ""))));
    });
  }

  function field(label, key, p, type = "text") {
    return h("div.form-row", h("span.label", label), key === "notes" ? h("textarea.field", { rows: 3, oninput: e => p[key] = e.target.value }, p[key] || "")
      : h("input.field", { type, value: p[key] || "", oninput: e => p[key] = e.target.value }));
  }
  function drawDetail() {
    detail.innerHTML = ""; const p = get();
    if (!p) { detail.append(h("div.empty", h("div", h("div", { html: icon("user", 44), style: "color:var(--muted);margin-bottom:10px" }), h("p", "Select a contact, or add someone new."), h("button.btn", { onclick: add }, "New contact")))); return; }
    if (editing) {
      detail.append(h("div", { style: "max-width:460px" }, h("h2", { style: "margin:0 0 16px" }, p.name ? "Edit contact" : "New contact"),
        field("Name", "name", p), field("Phone", "phone", p, "tel"), field("Email", "email", p, "email"), field("Address", "address", p), field("Notes", "notes", p),
        h("div", { style: "display:flex;gap:8px" }, h("button.btn", { onclick: () => { editing = false; if (!p.name && !p.phone && !p.email) { people = people.filter(x => x !== p); current = null; } save(); drawList(); drawDetail(); } }, "Done"))));
      return;
    }
    const row = (label, value, href) => value ? h("div.row", { style: "cursor:default" }, h("span.label", { style: "width:80px" }, label),
      href ? h("button.btn.ghost.small", { onclick: () => wos.call("sys.openUrl", { url: href }) }, value) : h("span", { style: "user-select:text" }, value)) : null;
    detail.append(h("div", { style: "max-width:520px" },
      h("div", { style: "display:flex;align-items:center;gap:18px;margin-bottom:22px" },
        h("div.avatar", { style: "width:72px;height:72px;font-size:24px" }, initials(p.name)),
        h("div", { style: "flex:1" }, h("h1", { style: "margin:0;font-size:26px" }, p.name || "No name")),
        h("button.icon-btn", { title: "Favourite", html: icon("star"), style: p.fave ? "color:#ff9f0a" : "", onclick: () => { p.fave = !p.fave; save(); drawList(); drawDetail(); } }),
        h("button.icon-btn", { title: "Edit", html: icon("edit"), onclick: () => { editing = true; drawDetail(); } }),
        h("button.icon-btn", { title: "Delete", html: icon("trash"), onclick: async () => {
          if (!await confirmBox("Delete contact?", `${p.name || "This contact"} will be removed.`, "Delete", true)) return;
          people = people.filter(x => x !== p); current = null; save(); drawList(); drawDetail(); } })),
      h("div.card", row("Phone", p.phone), row("Email", p.email, p.email && "mailto:" + p.email), row("Address", p.address), row("Notes", p.notes))));
  }
  drawList(); drawDetail();
});
