"""Music visualisation maths: turns a short block of audio samples into a handful of band levels (0..1) with a real
frequency spectrum (Goertzel, no numpy needed), spaced like hearing is (more bands for bass and mids) and compressed
in decibels so quiet music still moves and loud music does not just sit at the top.
"""
import math

BANDS = 24
LOW_HZ, HIGH_HZ = 50.0, 8000.0
FLOOR_DB, CEIL_DB = -62.0, -6.0


def band_centres(count=BANDS, low=LOW_HZ, high=HIGH_HZ):
    return [low * (high / low) ** (i / (count - 1)) for i in range(count)]


def goertzel(samples, rate, freq):
    """Power of one frequency in the samples (each -1..1), normalised so a full-scale sine is about 1."""
    n = len(samples)
    if n == 0:
        return 0.0
    k = 2.0 * math.cos(2.0 * math.pi * freq / rate)
    s1 = s2 = 0.0
    for x in samples:
        s0 = x + k * s1 - s2
        s2, s1 = s1, s0
    power = s1 * s1 + s2 * s2 - k * s1 * s2
    return power * 4.0 / (n * n)


def levels(raw, rate, count=BANDS):
    """raw: signed 16-bit sample ints. Returns count floats in 0..1."""
    n = len(raw)
    if n < 64:
        return [0.0] * count
    win = [0.5 - 0.5 * math.cos(2 * math.pi * i / (n - 1)) for i in range(n)]       # Hann window: no smearing at the block edges
    xs = [raw[i] / 32768.0 * win[i] * 2.0 for i in range(n)]                         # *2 puts the window's loss back
    out = []
    for f in band_centres(count):
        if f >= rate / 2:
            out.append(0.0)
            continue
        db = 10.0 * math.log10(goertzel(xs, rate, f) + 1e-12)
        db += 3.0 * math.log2(f / LOW_HZ + 1)                                         # music falls off with pitch; tilt it back up
        out.append(round(max(0.0, min(1.0, (db - FLOOR_DB) / (CEIL_DB - FLOOR_DB))), 3))
    return out
