"use strict";
/* Shared by every W-OS app page: the bridge to the native runtime (usr/libexec/wos/app), theme
   handling, and small helpers. Opened in a plain browser (design preview) the bridge is a mock
   with sample data, so an app can be worked on without booting anything. */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

/* Build DOM quickly: h("div.card", {onclick: f}, "text", child, ...) */
function h(tag, attrs, ...kids) {
  const [name, ...classes] = tag.split(".");
  const el = document.createElement(name || "div");
  if (classes.length) el.className = classes.join(" ");
  if (attrs && (attrs.nodeType || typeof attrs === "string" || Array.isArray(attrs))) { kids.unshift(attrs); attrs = null; }
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "html") el.innerHTML = v;
    else if (v === true) el.setAttribute(k, "");
    else if (v !== false && v != null) el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(kid));
  return el;
}

/* ---------- icons: thin 1.6px line icons, currentColor ---------- */
const ICONS = {
  search: "<circle cx='11' cy='11' r='7'/><path d='M20 20l-3.5-3.5'/>",
  bell: "<path d='M6 16v-5a6 6 0 0 1 12 0v5l1.500 2h-15zM10 20a2 2 0 0 0 4 0'/>",
  globe: "<circle cx='12' cy='12' r='9'/><path d='M3 12h18M12 3c3.500 3.500 3.500 14.500 0 18M12 3c-3.500 3.500-3.500 14.500 0 18'/>",
  battery: "<rect x='3' y='8' width='16' height='9' rx='2.500'/><path d='M21.500 11v3'/>",
  clock: "<circle cx='12' cy='12' r='9'/><path d='M12 7v5l3 2'/>",
  disk: "<rect x='4' y='6' width='16' height='12' rx='3'/><path d='M8 14h.01M12 14h4'/>",
  plus: "<path d='M12 5v14M5 12h14'/>",
  trash: "<path d='M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13'/>",
  folder: "<path d='M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/>",
  file: "<path d='M6 3h8l5 5v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z'/><path d='M14 3v5h5'/>",
  image: "<rect x='3' y='4' width='18' height='16' rx='3'/><circle cx='9' cy='10' r='2'/><path d='M21 16l-5-5-8 8'/>",
  home: "<path d='M4 11l8-7 8 7v9H4z'/>",
  down: "<path d='M12 4v12M6 11l6 6 6-6M5 20h14'/>",
  doc: "<path d='M6 3h9l4 4v14H6z'/><path d='M9 12h7M9 16h7'/>",
  back: "<path d='M15 5l-7 7 7 7'/>", forward: "<path d='M9 5l7 7-7 7'/>", up: "<path d='M5 15l7-7 7 7'/>",
  grid: "<rect x='4' y='4' width='6' height='6' rx='1.5'/><rect x='14' y='4' width='6' height='6' rx='1.5'/><rect x='4' y='14' width='6' height='6' rx='1.5'/><rect x='14' y='14' width='6' height='6' rx='1.5'/>",
  list: "<path d='M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01'/>",
  mail: "<rect x='3' y='5' width='18' height='14' rx='3'/><path d='M4 8l8 6 8-6'/>",
  send: "<path d='M4 12l16-8-6 16-3-7z'/>",
  user: "<circle cx='12' cy='8' r='4'/><path d='M4 21c1-4 4-6 8-6s7 2 8 6'/>",
  star: "<path d='M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z'/>",
  cal: "<rect x='3' y='5' width='18' height='16' rx='3'/><path d='M3 10h18M8 3v4M16 3v4'/>",
  gear: "<circle cx='12' cy='12' r='3'/><path d='M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1'/>",
  wifi: "<path d='M2 9a15 15 0 0 1 20 0M5.5 12.5a10 10 0 0 1 13 0M9 16a5 5 0 0 1 6 0'/><circle cx='12' cy='19.5' r='1'/>",
  sound: "<path d='M4 9v6h4l5 4V5L8 9zM16 8a5 5 0 0 1 0 8'/>",
  paint: "<path d='M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2.3-2.5 1.7-2.5H18a3 3 0 0 0 3-3c0-5-4-10.5-9-10.5z'/><circle cx='8' cy='11' r='1'/><circle cx='12' cy='7.5' r='1'/><circle cx='16' cy='11' r='1'/>",
  info: "<circle cx='12' cy='12' r='9'/><path d='M12 11v6M12 7.5v.01'/>",
  refresh: "<path d='M20 11a8 8 0 1 0-2 6M20 4v7h-7'/>",
  phone: "<rect x='7' y='3' width='10' height='18' rx='3'/><path d='M11 18h2'/>",
  bag: "<path d='M5 8h14l-1 12H6zM9 8a3 3 0 0 1 6 0'/>",
  chat: "<path d='M4 5h16v11H9l-5 4z'/>",
  x: "<path d='M6 6l12 12M18 6L6 18'/>",
  check: "<path d='M5 12l5 5 9-10'/>",
  edit: "<path d='M4 20h4L19 9l-4-4L4 16zM13 7l4 4'/>",
  moon: "<path d='M20 14A8 8 0 0 1 10 4a8 8 0 1 0 10 10z'/>",
  sun: "<circle cx='12' cy='12' r='4'/><path d='M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2'/>",
  lock: "<rect x='5' y='11' width='14' height='10' rx='3'/><path d='M8 11V8a4 4 0 0 1 8 0v3'/>",
  shield: "<path d='M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6z'/>",
  zoomin: "<circle cx='11' cy='11' r='7'/><path d='M20 20l-3.5-3.5M11 8v6M8 11h6'/>",
  zoomout: "<circle cx='11' cy='11' r='7'/><path d='M20 20l-3.5-3.5M8 11h6'/>",
  download: "<path d='M12 4v11M7 11l5 5 5-5M5 20h14'/>",
  qr: "<rect x='4' y='4' width='6' height='6' rx='1'/><rect x='14' y='4' width='6' height='6' rx='1'/><rect x='4' y='14' width='6' height='6' rx='1'/><path d='M14 14h3v3M20 14v.01M14 20h.01M17 20h3v-3'/>",
  eye: "<path d='M2 12s3.500-7 10-7 10 7 10 7-3.500 7-10 7-10-7-10-7z'/><circle cx='12' cy='12' r='3'/>",
  eyeoff: "<path d='M2 12s3.500-7 10-7c1.7 0 3.2.4 4.5 1M22 12s-3.500 7-10 7c-1.7 0-3.2-.4-4.5-1'/><path d='M9.9 9.9a3 3 0 0 0 4.2 4.2M6.1 6.1 3 3M17.9 17.9l3.1 3.1'/>",
};
function icon(name, size) {
  const s = size ? ` style="width:${size}px;height:${size}px"` : "";
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"${s}>${ICONS[name] || ""}</svg>`;
}
function iconEl(name, size) { const s = h("span", { html: icon(name, size) }); s.style.display = "inline-grid"; return s.firstChild; }

/* ---------- the bridge ---------- */
const bridge = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.wos;
const pending = new Map();
let nextId = 1;
const listeners = {};

const wos = {
  info: {},
  /* Call a native method: wos.call("fs.list", {path}) -> Promise */
  call(method, args = {}) {
    if (!bridge) return mockCall(method, args);
    return new Promise((resolve, reject) => {
      const id = nextId++;
      pending.set(id, { resolve, reject });
      bridge.postMessage(JSON.stringify({ id, method, args }));
    });
  },
  on(event, cb) { (listeners[event] = listeners[event] || []).push(cb); },
  /* Called by the native side. */
  receive(m) {
    if (m.type === "reply") {
      const p = pending.get(m.id); if (!p) return;
      pending.delete(m.id);
      m.error ? p.reject(new Error(m.error)) : p.resolve(m.result);
    } else if (m.type === "theme") applyTheme(m.effective);
    else if (m.type === "prefs") applyPrefs(m.prefs);
    else (listeners[m.type] || []).forEach(cb => cb(m));
  },
  /* Small persistent store per app. */
  data: {
    get: (name, dflt) => wos.call("data.get", { name }).then(v => (v === null || v === undefined ? dflt : v)),
    set: (name, value) => wos.call("data.set", { name, value }),
  },
};
window.wos = wos;

/* Accessibility choices from Settings, shared by every app. */
function applyPrefs(p) {
  const c = document.documentElement.classList;
  window.__speak = !!(p && p.speak);
  c.toggle("a11y-zoom", !!(p && p.zoom)); c.toggle("a11y-contrast", !!(p && p.contrast)); c.toggle("a11y-motion", !!(p && p.motion));
  const A = { blue: "#0a84ff", purple: "#a25be0", pink: "#f0559a", red: "#f5453a", orange: "#f7821b", yellow: "#f5b800", green: "#30b34f", graphite: "#7d7d86" };
  const colour = A[p && p.accent] || A.blue, st = document.documentElement.style;
  const ink = (p && p.accent === "yellow") ? "#1a1a1a" : "#ffffff";
  st.setProperty("--accent", colour); st.setProperty("--btn", colour); st.setProperty("--accent-ink", ink); st.setProperty("--btn-ink", ink);
  st.setProperty("--sel", colour + "24");
}
function applyTheme(effective) { document.documentElement.dataset.theme = effective === "dark" ? "dark" : "light"; }

function toast(text) {
  const t = h("div.toast", text); document.body.append(t); setTimeout(() => t.remove(), 2200);
}
function confirmBox(title, text, okLabel = "OK", danger = false) {
  return new Promise(res => {
    const done = v => { back.remove(); res(v); };
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) done(false); } },
      h("div.modal", h("h2", title), h("p.muted", text),
        h("div.actions", h("button.btn.ghost", { onclick: () => done(false) }, "Cancel"),
          h("button.btn" + (danger ? ".danger" : ""), { onclick: () => done(true) }, okLabel))));
    document.body.append(back);
  });
}
function prompt2(title, value = "", placeholder = "") {
  return new Promise(res => {
    const input = h("input.field", { value, placeholder });
    const done = v => { back.remove(); res(v); };
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) done(null); } },
      h("div.modal", h("h2", title), input,
        h("div.actions", h("button.btn.ghost", { onclick: () => done(null) }, "Cancel"), h("button.btn", { onclick: () => done(input.value) }, "OK"))));
    input.addEventListener("keydown", e => { if (e.key === "Enter") done(input.value); if (e.key === "Escape") done(null); });
    document.body.append(back); input.focus(); input.select();
  });
}

function askPassword(title, hint = "") {
  return new Promise(res => {
    const input = h("input.field", { type: "password", placeholder: hint || "Password", style: "padding-right:38px" });
    const reveal = h("button", {
      type: "button", "aria-label": "Show password",
      style: "position:absolute;right:6px;top:50%;transform:translateY(-50%);width:26px;height:26px;border:0;background:none;color:var(--muted);cursor:pointer;display:grid;place-items:center",
      onclick: () => { const show = input.type === "password"; input.type = show ? "text" : "password"; reveal.innerHTML = icon(show ? "eyeoff" : "eye", 16); input.focus(); }
    }, icon("eye", 16));
    const field = h("div", { style: "position:relative" }, input, reveal);
    const done = v => { back.remove(); res(v); };
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) done(null); } },
      h("div.modal", h("h2", title), field,
        h("div.actions", h("button.btn.ghost", { onclick: () => done(null) }, "Cancel"), h("button.btn", { onclick: () => done(input.value) }, "OK"))));
    input.addEventListener("keydown", e => { if (e.key === "Enter") done(input.value); if (e.key === "Escape") done(null); });
    document.body.append(back); input.focus();
  });
}

const pad2 = n => String(n).padStart(2, "0");
const fmtSize = n => n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(0) + " KB" : n < 1073741824 ? (n / 1048576).toFixed(1) + " MB" : (n / 1073741824).toFixed(1) + " GB";
const initials = name => (name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map(p => p[0].toUpperCase()).join("") || "?";
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const debounce = (f, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => f(...a), ms); }; };

/* ---------- start-up ---------- */
async function boot(init) {
  wos.info = await wos.call("app.info");
  applyTheme(wos.info.effective_theme);
  try { applyPrefs(await wos.call("prefs.get")); } catch (e) { /* preferences are optional */ }
  document.title = wos.info.name || document.title;
  await init(wos.info);
}

/* ---------- mock host: sample data for the design preview ---------- */
const MOCK = { store: {}, theme: "light" };
function mockCall(method, a) {
  const later = v => new Promise(r => setTimeout(() => r(v), 30));
  const sampleFiles = [
    { name: "Documents", path: "/home/will/Documents", dir: true, size: 0, mtime: 1758300000 },
    { name: "Downloads", path: "/home/will/Downloads", dir: true, size: 0, mtime: 1758200000 },
    { name: "Pictures", path: "/home/will/Pictures", dir: true, size: 0, mtime: 1758100000 },
    { name: "notes.txt", path: "/home/will/notes.txt", dir: false, size: 1820, mtime: 1758290000, mime: "text/plain" },
    { name: "budget.ods", path: "/home/will/budget.ods", dir: false, size: 48211, mtime: 1758250000, mime: "application/vnd.oasis.opendocument.spreadsheet" },
    { name: "holiday.jpg", path: "/home/will/holiday.jpg", dir: false, size: 2481123, mtime: 1758240000, mime: "image/jpeg" },
  ];
  switch (method) {
    case "app.info": return later({ id: "preview", name: document.title, user: "will", full_name: "William", home: "/home/will", lang: "en_GB",
      theme: MOCK.theme, effective_theme: new URLSearchParams(location.search).get("theme") || MOCK.theme, version: "1.0.143194163", hostname: "wos3" });
    case "data.get": return later(MOCK.store[a.name] ?? null);
    case "data.set": MOCK.store[a.name] = a.value; return later(true);
    case "prefs.get": return later({ zoom: false, contrast: false, motion: false, speak: false });
    case "prefs.set": return later(true);
    case "theme.get": return later(MOCK.theme);
    case "theme.set": MOCK.theme = a.mode; applyTheme(a.mode === "dark" ? "dark" : "light"); return later(true);
    case "fs.home": return later("/home/will");
    case "fs.places": return later([{ name: "Home", path: "/home/will", icon: "home" }, { name: "Documents", path: "/home/will/Documents", icon: "doc" },
      { name: "Downloads", path: "/home/will/Downloads", icon: "down" }, { name: "Pictures", path: "/home/will/Pictures", icon: "image" }]);
    case "account.get": return later({ type: "waccount", email: "will@example.com", name: "William", user: "will" });
    case "sys.updates": return later({ current: "1.0.143194163", checked: "just now" });
    case "fs.list": return later(sampleFiles.filter(f => a.path === "/home/will" || !f.path.startsWith("/home/will/") || true).map(f => ({ ...f, path: a.path.replace(/\/$/, "") + "/" + f.name })));
    case "fs.readText": return later("Sample text for the preview.\nSecond line.");
    case "fs.bin.list": return later([{ name: "old-notes.txt", id: "1", dir: false, orig: "/home/will/old-notes.txt" }]);
    case "fs.copy": case "fs.move": case "fs.bin.restore": case "fs.bin.empty": case "sys.speak": return later(true);
    case "fs.writeText": case "fs.mkdir": case "fs.rename": case "fs.trash": case "fs.open": case "sys.launch": case "sys.openUrl": return later(true);
    case "photos.list": return later(Array.from({ length: 14 }, (_, i) => ({ name: `IMG_${1000 + i}.jpg`, path: `/home/will/Pictures/IMG_${1000 + i}.jpg`,
      uri: "", mtime: 1758000000 + i * 86400 })));
    case "sys.info": return later({ os: "William Graves Operating Services (W-OS) 4", nickname: "Windermere", version: "Penguin 4ALPHA", build: "1.0.143194163",
      device: "innotek VirtualBox", cpu: "Intel Core Ultra 5", memory_gb: 4, storage_gb: 19, device_id: "d27a8f7b7040" });
    case "sys.wifi.list": return later([{ ssid: "Home-5G", signal: 82, secure: true, active: true }, { ssid: "BT-Hub6-4XK2", signal: 55, secure: true }, { ssid: "Guest", signal: 40, secure: false }]);
    case "sys.wifi.connect": return later({ ok: true });
    case "sys.volume.get": return later(60);
    case "sys.volume.set": return later(true);
    case "sys.apps": return later([{ id: "firefox-esr.desktop", name: "Firefox" }, { id: "wos-files.desktop", name: "Files" }]);
    case "users.list": return later([{ name: "will", full: "William", admin: true, me: true }, { name: "guest1", full: "Alex", admin: false }]);
    case "users.add": case "users.passwd": case "users.del": case "sys.tz.set": case "sys.hostname.set": case "power.set": case "input.set": case "input.layout.set":
    case "displays.set": case "bt.power": case "sound.output.set": case "store.install": case "store.remove": case "store.refresh": case "account.signin": case "account.signout": return later(true);
    case "sys.tz.get": return later({ zone: "Europe/London", synced: true });
    case "sys.tz.list": return later(["Europe/London", "Europe/Madrid", "Europe/Paris", "America/New_York", "America/Los_Angeles", "Asia/Tokyo", "Australia/Sydney"]);
    case "displays.list": return later([{ name: "eDP-1", modes: ["1920x1200", "1920x1080", "1600x900", "1280x800"], current: "1920x1200", primary: true }]);
    case "power.get": return later({ lock_min: 5, off_min: 10 });
    case "power.battery": return later({ pct: 78, status: "Discharging" });
    case "input.get": return later({ tap: true, natural: true, layout: "gb" });
    case "bt.status": return later({ available: true, on: true });
    case "bt.devices": return later([{ mac: "AA:BB:CC:DD:EE:01", name: "Headphones", paired: true, connected: true }, { mac: "AA:BB:CC:DD:EE:02", name: "Keyboard", paired: false, connected: false }]);
    case "bt.action": return later({ ok: true });
    case "sound.outputs": return later([{ name: "speakers", label: "Built-in speakers", default: true }, { name: "hdmi", label: "HDMI display", default: false }]);
    case "printers.list": return later({ printers: [{ name: "Save-as-PDF", state: "idle" }], default: "Save-as-PDF" });
    case "phone.status": return later({ running: true, port: 8620, addresses: ["192.168.1.23"], code: "482913", phones: [{ name: "Pixel 8", added: 1758400000 }], prefs: { contacts: true, calendar: true, photos: false }, last: { contacts: { time: 1758400100, count: 212, from: "Pixel 8" } } });
    case "phone.set_pref": case "phone.forget": return later(true);
    case "phone.new_code": return later("730155");
    case "desktop.get": return later({ wallpaper: "default", dock: "medium", clock24: true, seconds: false, date: true, battery: true });
    case "desktop.wallpapers": return later([{ id: "default", name: "Buttermere", uri: "../../ui/wallpaper.webp" }, { id: "builtin:aurora", name: "Aurora", uri: "../../wallpapers/aurora.svg" },
      { id: "builtin:dusk", name: "Dusk", uri: "../../wallpapers/dusk.svg" }, { id: "builtin:meadow", name: "Meadow", uri: "../../wallpapers/meadow.svg" }, { id: "builtin:graphite", name: "Graphite", uri: "../../wallpapers/graphite.svg" }, { id: "builtin:sunrise", name: "Sunrise", uri: "../../wallpapers/sunrise.svg" }]);
    case "desktop.set": case "dnd.set": case "privacy.set": case "defaults.set": case "files.bin.empty": return later(true);
    case "dnd.get": return later(false);
    case "privacy.get": return later({ share: false });
    case "firewall.status": return later(true);
    case "storage.usage": return later({ total: 64e9, free: 47e9, bin: 3.2e8, items: [{ name: "Documents", bytes: 1.8e9 }, { name: "Pictures", bytes: 4.6e9 }, { name: "Downloads", bytes: 2.1e9 }, { name: "Music", bytes: 9e8 }, { name: "Bin", bytes: 3.2e8 }] });
    case "defaults.get": return later({ browser: "firefox-esr.desktop", options: [{ id: "firefox-esr.desktop", name: "Firefox" }, { id: "com.microsoft.Edge.desktop", name: "Microsoft Edge" }] });
    case "store.catalogue": return fetch("../../store/catalogue.json").then(r => r.json()).then(j => j.apps.map(a => ({ ...a, installed: false })))
      .catch(() => [{ package: "vlc", name: "VLC", by: "VideoLAN", cat: "Video", blurb: "Plays nearly any video or audio file.", glyph: "image", installed: false }]);
    case "sys.notices": return later({ offer: "Source offer text.", packages: [{ name: "linux-image", version: "6.1", licence: "GPL-2", home: "" }] });
    case "feedback.send": return later({ sent: false });
    case "updates.status": return later({ version: "1.0.143194163", history: [{ id: "shell", version: "1.0.143194164", time: 1758400000, result: "installed", kind: "feature", rollback_available: true }], configured: true });
    case "updates.check": return later({ version: "1.0.143194163", available: [{ id: "shell", version: "1.0.143194165", kind: "feature", action: "ask", notes: "Faster launcher" }] });
    case "updates.apply": return later({ ok: true, version: "1.0.143194165", restart_needed: true });
    case "updates.rollback": case "sys.restart": return later(true);
    default: return later(null);
  }
}

/* Read aloud (Settings > Accessibility): select text and press Alt+R, or press Alt+R with nothing selected
   to hear the whole page. Alt+R again stops it. */
document.addEventListener("keydown", e => {
  if (!window.__speak || !e.altKey || e.key.toLowerCase() !== "r") return;
  e.preventDefault();
  const sel = String(window.getSelection() || "").trim();
  wos.call("sys.speak", { text: sel || document.body.innerText });
});
