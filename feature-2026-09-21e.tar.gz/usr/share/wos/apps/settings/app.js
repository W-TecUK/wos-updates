"use strict";
/* Settings: appearance (light/dark), network, sound, account, language, accessibility, updates, about. */

boot(async info => {
  const root = $("#root");
  let page = "appearance", theme = await wos.call("theme.get");
  const acc = await wos.call("prefs.get");

  // key, label, icon, colour, words the search also matches
  const PAGES = [
    ["appearance", "Appearance", "paint", "#5e5ce6", "theme dark light accent colour highlight"],
    ["desktop", "Desktop & Dock", "image", "#0a84ff", "wallpaper background dock size clock menu bar battery"],
    ["notifications", "Notifications", "bell", "#ff453a", "do not disturb focus alerts banners"],
    ["network", "Network", "wifi", "#0a84ff", "wifi wi-fi internet"],
    ["bluetooth", "Bluetooth", "phone", "#1d8cf8", "headphones devices"],
    ["sound", "Sound", "sound", "#ff375f", "volume speaker output"],
    ["displays", "Displays", "image", "#32ade6", "screen resolution scale brightness"],
    ["power", "Power", "battery", "#30b04f", "battery sleep lock screen energy"],
    ["keyboard", "Keyboard & trackpad", "edit", "#8e8e93", "mouse touchpad typing scroll"],
    ["printers", "Printers", "doc", "#8e8e93", "print scan"],
    ["users", "Users", "user", "#64a0ff", "accounts people"],
    ["account", "W-Account", "shield", "#0a84ff", "sign in email w-life"],
    ["privacy", "Privacy & Security", "lock", "#2c9fb8", "firewall data sharing telemetry crash usage"],
    ["datetime", "Date & time", "clock", "#ff9f0a", "timezone clock 24 hour"],
    ["language", "Language & region", "globe", "#0a84ff", "english spanish"],
    ["defaults", "Default apps", "grid", "#bf5af2", "browser web"],
    ["storage", "Storage", "disk", "#8e8e93", "disk space bin trash free"],
    ["access", "Accessibility", "list", "#0a84ff", "zoom contrast motion speak"],
    ["updates", "Updates", "refresh", "#8e8e93", "software version"],
    ["about", "About", "gear", "#8e8e93", "name version device rename"],
  ];
  let query = "";
  { const want = (info.args || [])[0]; if (want && PAGES.some(p => p[0] === want)) page = want; }     // e.g. opened from the update notification
  const nav = h("nav.nav"); const body = h("div.body", { style: "max-width:680px;width:100%" });
  const searchBox = h("input.sidebar-search", { type: "search", placeholder: "Search", oninput: e => { query = e.target.value.trim().toLowerCase(); drawNav(); } });
  root.append(h("div.app", h("aside.side", h("div.side-title", "Settings"), searchBox, nav), h("div.main", { style: "overflow:auto" }, h("div", { style: "padding:22px;display:flex;justify-content:center" }, body))));

  const section = (title, ...kids) => h("div", { style: "margin-bottom:26px" }, h("span.label", { style: "display:block;margin:0 4px 10px" }, title), ...kids);
  const rowOf = (label, sub, control) => h("div.row", { style: "cursor:default;min-height:56px" }, h("div.grow", h("div.t", label), sub ? h("div.s", sub) : null), control);
  const flag = (key) => { const s = h("button.switch" + (acc[key] ? ".on" : ""), { onclick: () => { acc[key] = !acc[key]; s.classList.toggle("on", acc[key]); wos.call("prefs.set", { key, value: acc[key] }); applyPrefs(acc); } }); return s; };

  const drawNav = () => {
    nav.innerHTML = "";
    const shown = PAGES.filter(([k, l, i, c, w]) => !query || (l + " " + w).toLowerCase().includes(query));
    shown.forEach(([k, l, i, c]) => nav.append(h("button" + (page === k ? ".on" : ""), { onclick: () => { page = k; draw(); } },
      h("span.tile-ico", { style: "background:" + c, html: icon(i, 15) }), l)));
    if (!shown.length) nav.append(h("div.muted.small", { style: "padding:10px 12px" }, "Nothing matches"));
  };
  const draw = async () => {
    drawNav();
    body.innerHTML = ""; body.append(h("h1.dots", { style: "font-size:36px;margin:0 0 20px" }, PAGES.find(p => p[0] === page)[1]));
    body.classList.remove("page-in"); void body.offsetWidth; body.classList.add("page-in");
    await views[page]();
  };
  const seg = (options, current, onpick) => {
    const box = h("div.seg");
    options.forEach(([v, label]) => box.append(h("button" + (current === v ? ".on" : ""), { onclick: () => { [...box.children].forEach(x => x.classList.remove("on")); box.children[options.findIndex(o => o[0] === v)].classList.add("on"); onpick(v); } }, label)));
    return box;
  };
  const switchOf = (on, onchange) => { const sw = h("button.switch" + (on ? ".on" : ""), { onclick: () => { const now = !sw.classList.contains("on"); sw.classList.toggle("on", now); onchange(now); } }); return sw; };
  const fmtBytes = n => n >= 1e9 ? (n / 1e9).toFixed(1) + " GB" : n >= 1e6 ? Math.round(n / 1e6) + " MB" : n >= 1e3 ? Math.round(n / 1e3) + " KB" : n + " bytes";

  const views = {
    async appearance() {
      const card = (mode, label, ic) => h("button.tile" + (theme === mode ? ".on" : ""), { style: "padding:16px", onclick: async () => { theme = mode; await wos.call("theme.set", { mode }); if (mode !== "auto") applyTheme(mode); else applyTheme(new Date().getHours() >= 19 || new Date().getHours() < 7 ? "dark" : "light"); draw(); } },
        h("div", { style: "height:64px;border-radius:12px;margin-bottom:10px;display:grid;place-items:center;" + (mode === "dark" ? "background:#0a0a0b;color:#f4f4f6" : mode === "light" ? "background:#f3f3f4;color:#0c0c0e" : "background:linear-gradient(90deg,#f3f3f4 50%,#0a0a0b 50%);color:#0a84ff"), html: icon(ic, 26) }),
        h("div", { style: "font-weight:800" }, label));
      body.append(section("Theme", h("div.grid", { style: "grid-template-columns:repeat(3,1fr)" }, card("light", "Light", "sun"), card("dark", "Dark", "moon"), card("auto", "Automatic", "refresh"))),
        h("p.muted.small", { style: "margin:-12px 4px 26px" }, "Automatic uses dark from 7 pm to 7 am."));
      const ACCENTS = [["blue", "#0a84ff", "Blue"], ["purple", "#a25be0", "Purple"], ["pink", "#f0559a", "Pink"], ["red", "#f5453a", "Red"], ["orange", "#f7821b", "Orange"], ["yellow", "#f5b800", "Yellow"], ["green", "#30b34f", "Green"], ["graphite", "#7d7d86", "Graphite"]];
      const swatches = h("div", { style: "display:flex;gap:12px;flex-wrap:wrap;padding:16px 18px" });
      const drawSwatches = () => { swatches.innerHTML = ""; ACCENTS.forEach(([k, c, n]) => swatches.append(h("button.swatch" + ((acc.accent || "blue") === k ? ".on" : ""), { title: n, style: "background:" + c,
        onclick: async () => { acc.accent = k; await wos.call("prefs.set", { key: "accent", value: k }); applyPrefs(acc); drawSwatches(); } }, (acc.accent || "blue") === k ? h("span", { html: icon("check", 15) }) : null))); };
      drawSwatches();
      body.append(section("Accent colour", h("div.card", swatches)), h("p.muted.small", { style: "margin:-12px 4px 0" }, "Used for buttons, selections and highlights in W-OS apps."));
    },
    async network() {
      const list = h("div.list", h("div.row.muted", { style: "cursor:default" }, "Looking for networks…")); const card = h("div.card", list);
      body.append(section("Wi-Fi", card), h("button.btn.ghost.small", { onclick: draw }, h("span", { html: icon("refresh", 14) }), "Scan again"));
      let nets = []; try { nets = await wos.call("sys.wifi.list"); } catch (e) { nets = []; }
      list.innerHTML = "";
      if (!nets.length) list.append(h("div.row.muted", { style: "cursor:default" }, "No Wi-Fi networks found. If this computer uses a cable, you are connected that way."));
      nets.forEach(n => list.append(h("button.row", { onclick: () => connect(n) }, h("span", { html: icon("wifi", 18) }), h("div.grow", h("div.t", n.ssid), h("div.s", n.active ? "Connected" : n.secure ? "Secured" : "Open")),
        n.active ? h("span", { html: '<i class="dot"></i>' }) : n.secure ? h("span", { html: icon("lock", 15), style: "color:var(--muted)" }) : null)));
    },
    async sound() {
      const v = await wos.call("sys.volume.get"); const out = h("span.mono", { style: "width:46px;text-align:right" }, v + "%");
      const range = h("input", { type: "range", min: 0, max: 100, value: v, style: "flex:1;accent-color:var(--ink)", oninput: e => { out.textContent = e.target.value + "%"; wos.call("sys.volume.set", { value: +e.target.value }); } });
      let outs = []; try { outs = await wos.call("sound.outputs"); } catch (e) { outs = []; }
      const outSel = h("select.field", { style: "width:220px", onchange: e => wos.call("sound.output.set", { name: e.target.value }) }, outs.map(o => h("option", { value: o.name, selected: o.default }, o.label || o.name)));
      if (outs.length > 1) body.append(section("Play sound through", h("div.card", rowOf("Output", "", outSel))));
      body.append(section("Output", h("div.card", rowOf("Volume", "", h("div", { style: "display:flex;align-items:center;gap:12px;width:280px" }, h("span", { html: icon("sound", 18) }), range, out)))));
    },
    async account() {
      const a = await wos.call("account.get"); const isW = a.type === "waccount";
      const email = h("input.field", { placeholder: "Email", type: "email", style: "width:260px" }), pass = h("input.field", { placeholder: "Password", type: "password", style: "width:260px" });
      const inForm = h("div", { style: "display:flex;flex-direction:column;gap:8px;padding:14px" }, email, pass,
        h("div", h("button.btn.small", { onclick: async () => { try { toast("Signing in…"); await wos.call("account.signin", { email: email.value, password: pass.value }); toast("Signed in"); draw(); } catch (e) { toast(e.message); } } }, "Sign in")));
      body.append(section("You", h("div.card.pad", { style: "display:flex;align-items:center;gap:16px" }, h("div.avatar", { style: "width:56px;height:56px;font-size:20px" }, initials(a.name)),
        h("div", { style: "flex:1" }, h("div", { style: "font-weight:800;font-size:17px" }, a.name), h("div.small.muted", isW ? a.email : "Local account · stays on this device")), h("span.chip", isW ? "W-Account" : "Local"))),
        section("W-Account", h("div.card", isW ? rowOf("Signed in", "W-Mail and other W-Account features are available.", h("button.btn.ghost.small", { onclick: async () => { if (!await confirmBox("Sign out of W-Account?", "W-Mail will stop working until you sign in again.", "Sign out")) return; await wos.call("account.signout"); draw(); } }, "Sign out"))
          : h("div", h("div.row", { style: "cursor:default" }, h("div.grow", h("div.t", "Use a W-Account"), h("div.s", "One account for W-Mail and other W-OS services."))), inForm))));
    },
    async language() {
      body.append(section("Language", h("div.card", rowOf("Display language", "The language W-OS uses", h("span.chip", info.lang.replace("_", "-"))))),
        h("p.muted.small", "To change language or region, contact support: support@willgraves.co.uk. More languages are on the way."));
    },
    async bluetooth() {
      const st = await wos.call("bt.status");
      if (!st.available) { body.append(h("div.card.pad.muted", "No Bluetooth adapter was found on this computer.")); return; }
      const sw = h("button.switch" + (st.on ? ".on" : ""), { onclick: async () => { const on = !sw.classList.contains("on"); sw.classList.toggle("on", on); await wos.call("bt.power", { on }); draw(); } });
      const list = h("div.list", h("div.row.muted", { style: "cursor:default" }, st.on ? "Looking for devices…" : "Bluetooth is off"));
      body.append(section("Bluetooth", h("div.card", rowOf("Bluetooth", "Connect headphones, keyboards and more", sw))), section("Devices", h("div.card", list)),
        st.on ? h("button.btn.ghost.small", { onclick: draw }, h("span", { html: icon("refresh", 14) }), "Search again") : null);
      if (!st.on) return;
      const devs = await wos.call("bt.devices", { scan: true }); list.innerHTML = "";
      if (!devs.length) list.append(h("div.row.muted", { style: "cursor:default" }, "No devices found. Put your device in pairing mode."));
      devs.forEach(d => list.append(h("div.row", { style: "cursor:default" }, h("div.grow", h("div.t", d.name), h("div.s", d.connected ? "Connected" : d.paired ? "Paired" : "Not paired")),
        h("button.btn.ghost.small", { onclick: async () => { const r = await wos.call("bt.action", { mac: d.mac, action: d.connected ? "disconnect" : d.paired ? "connect" : "pair" }); toast(r.ok ? "Done" : "Could not do that"); draw(); } }, d.connected ? "Disconnect" : d.paired ? "Connect" : "Pair"),
        d.paired ? h("button.icon-btn", { title: "Forget", html: icon("trash"), onclick: async () => { await wos.call("bt.action", { mac: d.mac, action: "remove" }); draw(); } }) : null)));
    },
    async displays() {
      const list = await wos.call("displays.list");
      if (!list.length) { body.append(h("div.card.pad.muted", "No displays were found.")); return; }
      list.forEach(d => {
        const modes = h("select.field", { style: "width:180px" }, d.modes.map(m => h("option", { value: m, selected: m === d.current }, m)));
        const scale = h("select.field", { style: "width:120px" }, [1, 1.25, 1.5, 2].map(x => h("option", { value: x }, Math.round(x * 100) + "%")));
        const apply = h("button.btn.small", { onclick: async () => { try { await wos.call("displays.set", { name: d.name, mode: modes.value, scale: +scale.value }); toast("Applied"); } catch (e) { toast(e.message); } } }, "Apply");
        body.append(section(d.name + (d.primary ? " (main)" : ""), h("div.card", rowOf("Resolution", "", modes), rowOf("Scale", "Make everything bigger or smaller", scale)), h("div", { style: "margin-top:10px" }, apply)));
      });
    },
    async power() {
      const p = await wos.call("power.get"); const bat = await wos.call("power.battery");
      const opt = (val, label) => h("option", { value: val }, label);
      const mk = (cur, choices) => h("select.field", { style: "width:160px", onchange: save }, choices.map(([v, l]) => h("option", { value: v, selected: v === cur }, l)));
      const lock = mk(p.lock_min, [[0, "Never"], [2, "2 minutes"], [5, "5 minutes"], [10, "10 minutes"], [30, "30 minutes"]]);
      const off = mk(p.off_min, [[0, "Never"], [5, "5 minutes"], [10, "10 minutes"], [15, "15 minutes"], [30, "30 minutes"], [60, "1 hour"]]);
      async function save() { await wos.call("power.set", { lock_min: +lock.value, off_min: +off.value }); toast("Saved"); }
      body.append(bat ? section("Battery", h("div.card.pad", { style: "display:flex;gap:14px;align-items:center" }, h("div", { style: "font-size:28px;font-weight:800" }, bat.pct + "%"), h("div.muted", bat.status))) : null,
        section("Screen", h("div.card", rowOf("Lock the screen after", "When nothing is touched", lock), rowOf("Turn the screen off after", "Saves power", off))),
        h("p.muted.small", "Closing the lid locks the computer and puts it to sleep."));
    },
    async keyboard() {
      const v = await wos.call("input.get");
      const sw = key => { const b = h("button.switch" + (v[key] ? ".on" : ""), { onclick: async () => { v[key] = !v[key]; b.classList.toggle("on", v[key]); await wos.call("input.set", { tap: v.tap, natural: v.natural }); } }); return b; };
      const layout = h("select.field", { style: "width:160px", onchange: async e => { await wos.call("input.layout.set", { layout: e.target.value }); toast("Layout changed"); } },
        [["gb", "English (UK)"], ["us", "English (US)"], ["es", "Spanish"], ["fr", "French"], ["de", "German"]].map(([c, l]) => h("option", { value: c, selected: c === v.layout }, l)));
      body.append(section("Keyboard", h("div.card", rowOf("Layout", "The letters on your keys", layout))),
        section("Trackpad", h("div.card", rowOf("Tap to click", "Tap the pad instead of pressing", sw("tap")), rowOf("Natural scrolling", "Content follows your fingers", sw("natural")))));
    },
    async printers() {
      const r = await wos.call("printers_list".replace("_", "."));
      body.append(section("Printers", h("div.card", h("div.list", r.printers.length ? r.printers.map(p => h("div.row", { style: "cursor:default" }, h("div.grow", h("div.t", p.name), h("div.s", p.state)), p.name === r.default ? h("span.chip", "Default") : null))
        : h("div.row.muted", { style: "cursor:default" }, "No printers yet.")))),
        h("p.muted.small", "Printers on your network appear here by themselves. Every app can also Save as PDF."));
    },
    async users() {
      const list = await wos.call("users.list");
      const ask = async why => askPassword(why, "Your password");
      const rows = list.map(u => h("div.row", { style: "cursor:default" }, h("div.avatar", initials(u.full)), h("div.grow", h("div.t", u.full + (u.me ? " (you)" : "")), h("div.s", (u.admin ? "Administrator" : "Standard") + " · " + u.name)),
        h("button.btn.ghost.small", { onclick: async () => { const me = await ask("Enter your password"); if (me === null) return; const pw = await askPassword("New password for " + u.name, "At least 8 characters"); if (!pw) return;
          try { await wos.call("users.passwd", { username: u.name, password: pw, me_password: me }); toast("Password changed"); } catch (e) { toast(e.message); } } }, "Change password"),
        u.me ? null : h("button.icon-btn", { title: "Remove", html: icon("trash"), onclick: async () => { if (!await confirmBox("Remove " + u.full + "?", "Their account and files will be deleted.", "Remove", true)) return; const me = await ask("Enter your password"); if (me === null) return;
          try { await wos.call("users.del", { username: u.name, me_password: me }); draw(); } catch (e) { toast(e.message); } } })));
      body.append(section("People who use this computer", h("div.card", h("div.list", rows))),
        h("button.btn", { onclick: async () => { const name = await prompt2("Full name"); if (!name) return; const uname = await prompt2("User name", name.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20), "letters and numbers"); if (!uname) return;
          const pw = await askPassword("Password for " + name, "At least 8 characters"); if (!pw) return; const me = await askPassword("Enter your password to confirm", "Your password"); if (me === null) return;
          try { await wos.call("users.add", { username: uname, name, password: pw, admin: false, me_password: me }); toast("Account created"); draw(); } catch (e) { toast(e.message); } } }, h("span", { html: icon("plus", 14) }), "Add a person"));
    },
    async datetime() {
      const cur = await wos.call("sys.tz.get"); const zones = await wos.call("sys.tz.list");
      const sel = h("select.field", { style: "width:260px", onchange: async e => { try { await wos.call("sys.tz.set", { zone: e.target.value }); toast("Time zone changed"); } catch (er) { toast(er.message); } } },
        zones.map(z => h("option", { value: z, selected: z === cur.zone }, z.replace(/_/g, " "))));
      const host = h("input.field", { style: "width:200px", value: info.hostname });
      body.append(section("Time", h("div.card", rowOf("Time zone", cur.synced ? "Clock is set from the internet" : "Waiting for the internet to set the clock", sel))),
        section("This computer", h("div.card", rowOf("Name", "How it appears on your network", h("div", { style: "display:flex;gap:8px" }, host,
          h("button.btn.small", { onclick: async () => { try { await wos.call("sys.hostname.set", { name: host.value.trim().toLowerCase() }); toast("Name changed"); } catch (e) { toast(e.message); } } }, "Save"))))));
    },
    async access() {
      body.append(section("Vision", h("div.card", rowOf("Bigger text", "Make text easier to read", flag("zoom")), rowOf("Higher contrast", "Stronger borders and text", flag("contrast")))),
        section("Motion and speech", h("div.card", rowOf("Reduce motion", "Fewer animations", flag("motion")), rowOf("Read aloud", "Speak text on screen", flag("speak")))),
        h("p.muted.small", "These apply to every W-OS app straight away. The desktop bar and dock will follow."));
    },
    async updates() {
      let st; try { st = await wos.call("updates.status"); } catch (e) { st = { version: info.version, history: [] }; }
      const box = h("div.card.pad", { style: "display:flex;align-items:center;gap:14px" });
      const list = h("div", { style: "margin-top:14px" });
      const paint = (found, note) => {
        box.innerHTML = "";
        const ok = !found || !found.length;
        box.append(h("span", { html: icon(ok ? "check" : "download", 26), style: "color:" + (ok ? "var(--ok)" : "var(--accent)") }),
          h("div", { style: "flex:1" }, h("div", { style: "font-weight:800" }, ok ? "W-OS is up to date" : found.length + " update" + (found.length === 1 ? "" : "s") + " available"), h("div.small.muted", "Version " + (st.version || info.version) + (note ? " · " + note : ""))),
          h("button.btn.ghost.small", { onclick: check }, "Check now"));
        list.innerHTML = "";
        (found || []).forEach(u => list.append(h("div.card", { style: "margin-bottom:10px" }, rowOf(u.id + " " + u.version, (u.kind === "security" ? "Security update" : "Update") + (u.notes ? " · " + u.notes : ""),
          u.action === "blocked" ? h("span.chip", "Needs activation") : h("button.btn.small", { onclick: () => install(u) }, "Install")))));
      };
      async function check() { toast("Checking…"); try { const r = await wos.call("updates.check"); paint(r.available, r.note); } catch (e) { toast(e.message); } }
      async function install(u) {
        toast("Installing…");
        try { const r = await wos.call("updates.apply", { id: u.id }); st.version = r.version; paint([], ""); if (r.restart_needed && await confirmBox("Restart to finish?", "The update is installed. Restart now, or later when it suits you.", "Restart now")) wos.call("sys.restart"); }
        catch (e) { toast(e.message); }
      }
      paint([], st.configured === false ? "No update service is configured yet" : "");
      const hist = (st.history || []).slice(0, 10);
      body.append(section("W-OS", box, list),
        section("Recent updates", h("div.card", hist.length ? hist.map((x, i) => rowOf(x.id + " " + x.version, new Date(x.time * 1000).toLocaleString("en-GB") + " · " + x.result + (x.kind === "security" ? " · security" : ""),
          i === 0 && x.rollback_available ? h("button.btn.ghost.small", { onclick: async () => { if (!await confirmBox("Roll back this update?", "The previous version comes back after a restart.", "Roll back")) return; try { await wos.call("updates.rollback"); toast("Rolled back. Restart to finish."); draw(); } catch (e) { toast(e.message); } } }, "Roll back") : null))
          : h("div.row.muted", { style: "cursor:default" }, "Nothing installed yet"))),
        h("p.muted.small", "Security fixes for the system install by themselves. Other updates wait for you. Security updates cannot be rolled back."));
    },
    async desktop() {
      const d = await wos.call("desktop.get");
      const save = (k, v) => { d[k] = v; wos.call("desktop.set", { key: k, value: v }).catch(e => toast(e.message)); };
      let walls = []; try { walls = await wos.call("desktop.wallpapers"); } catch (e) { walls = []; }
      const grid = h("div", { style: "display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:12px;padding:16px" });
      const drawWalls = () => { grid.innerHTML = ""; walls.forEach(w => grid.append(h("button.wall" + (d.wallpaper === w.id ? ".on" : ""), { title: w.name, onclick: () => { save("wallpaper", w.id); drawWalls(); } },
        h("div.wall-img", { style: `background-image:url("${w.uri}")` }), h("div.wall-name", w.name)))); };
      drawWalls();
      body.append(section("Wallpaper", h("div.card", grid)),
        section("Dock", h("div.card", rowOf("Size", "How big the icons in the dock are", seg([["small", "Small"], ["medium", "Medium"], ["large", "Large"]], d.dock, v => save("dock", v))))),
        section("Menu bar", h("div.card",
          rowOf("24-hour clock", "", switchOf(d.clock24, v => save("clock24", v))),
          rowOf("Show seconds", "", switchOf(d.seconds, v => save("seconds", v))),
          rowOf("Show the date", "", switchOf(d.date, v => save("date", v))),
          rowOf("Show battery percentage", "On laptops", switchOf(d.battery, v => save("battery", v))))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "Put your own pictures in the Pictures folder and they appear under Wallpaper."));
    },
    async notifications() {
      let dnd = false; try { dnd = await wos.call("dnd.get"); } catch (e) { /* not available */ }
      body.append(section("Focus", h("div.card", rowOf("Do Not Disturb", "Hide notification banners until you turn this off", switchOf(dnd, v => wos.call("dnd.set", { value: v }).catch(e => toast(e.message)))))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "W-OS apps only notify you about things you started, such as a finished download."));
    },
    async privacy() {
      let p = { share: false }; try { p = await wos.call("privacy.get"); } catch (e) { /* default */ }
      let fw = false; try { fw = await wos.call("firewall.status"); } catch (e) { /* unknown */ }
      body.append(section("Data", h("div.card",
          rowOf("Share crash and usage information", "Helps us fix problems. Nothing personal, no files, no browsing.", switchOf(!!p.share, v => wos.call("privacy.set", { value: v }).catch(e => toast(e.message)))),
          rowOf("Feedback you write", "Only sent when you press Send in the feedback app.", h("span.chip", "Always your choice")))),
        section("Security", h("div.card",
          rowOf("Firewall", "Blocks connections you did not ask for", h("span.chip", fw ? "On" : "Off")),
          rowOf("Screen lock", "Your password is needed to unlock. Set when it locks in Power.", h("button.btn.ghost.small", { onclick: () => { page = "power"; draw(); } }, "Open Power")),
          rowOf("App access", "W-OS apps can only reach your own folders, nothing else on the computer.", h("span.chip", "Home folder only")),
          rowOf("Location", "No app uses your location.", h("span.chip", "Not used")))));
    },
    async storage() {
      const u = await wos.call("storage.usage");
      const colours = ["#0a84ff", "#30b04f", "#ff9f0a", "#bf5af2", "#ff375f", "#5ac8fa", "#8e8e93"];
      const used = u.total - u.free; const parts = u.items.filter(i => i.bytes > 0);
      const other = Math.max(0, used - parts.reduce((t, i) => t + i.bytes, 0));
      const all = parts.concat(other > 0 ? [{ name: "System and apps", bytes: other }] : []);
      const bar = h("div.bar-stack", all.map((i, n) => h("div", { title: i.name, style: `width:${Math.max(0.5, i.bytes / u.total * 100)}%;background:${colours[n % colours.length]}` })));
      body.append(section("This computer", h("div.card.pad", h("div", { style: "display:flex;justify-content:space-between;margin-bottom:10px" }, h("span", { style: "font-weight:800" }, fmtBytes(used) + " used"), h("span.muted", fmtBytes(u.free) + " free of " + fmtBytes(u.total))), bar)),
        section("What is using it", h("div.card", all.map((i, n) => h("div.row", { style: "cursor:default;min-height:46px" }, h("span", { style: `width:12px;height:12px;border-radius:4px;background:${colours[n % colours.length]};flex:none` }), h("div.grow", h("div.t", i.name)), h("span.muted", fmtBytes(i.bytes)))))),
        u.bin > 0 ? section("Bin", h("div.card", rowOf("Empty the Bin", fmtBytes(u.bin) + " you deleted from Files", h("button.btn.ghost.small", { onclick: async () => { if (await confirmBox("Empty the Bin?", "Everything in it is removed for good.", "Empty Bin", true)) { await wos.call("files.bin.empty"); toast("Bin emptied"); draw(); } } }, "Empty Bin")))) : null);
    },
    async defaults() {
      const d = await wos.call("defaults.get");
      const sel = h("select.field", { style: "width:240px", onchange: e => wos.call("defaults.set", { browser: e.target.value }).then(() => toast("Default browser changed")).catch(x => toast(x.message)) },
        d.options.map(o => h("option", { value: o.id, selected: o.id === d.browser }, o.name)));
      body.append(section("Web", h("div.card", rowOf("Web browser", "Opens links from mail and other apps", sel))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "Install more browsers from the App Store and they appear here."));
    },
    async about() {
      const i = await wos.call("sys.info");
      const r = (a, b) => h("div.row", { style: "cursor:default" }, h("span.muted", { style: "width:140px" }, a), h("span", { style: "user-select:text;font-weight:700" }, String(b)));
      body.append(section("This device", h("div.card", r("Name", i.hostname), r("Model", i.device), r("Processor", i.cpu || "—"), r("Memory", i.memory_gb + " GB"), r("Storage", `${i.storage_gb} GB (${i.free_gb} GB free)`), r("Device ID", i.device_id))),
        section("Software", h("div.card", r("System", i.os), r("Release", `${i.nickname} · ${i.version}`), r("Version", i.build))),
        section("Computer name", h("div.card", h("div.row", { style: "cursor:default;min-height:56px" }, h("div.grow", h("div.t", "Name"), h("div.s", "Shown on your network and in Phone Sync")),
          (() => { const inp = h("input.field", { value: i.hostname, style: "width:190px" }); return h("div", { style: "display:flex;gap:8px;align-items:center" }, inp,
            h("button.btn.ghost.small", { onclick: async () => { try { await wos.call("sys.hostname.set", { name: inp.value.trim().toLowerCase() }); toast("Renamed. Applies after you restart."); } catch (e) { toast(e.message); } } }, "Rename")); })()))),
        h("div", { style: "margin-top:6px" }, h("button.btn.ghost.small", { onclick: showNotices }, "Open source notices")),
        h("p.muted.small", { style: "margin-top:14px" }, "William Graves Corp. Ltd. (c) 2020-2026 William Graves Operating Services"));
    },
  };

  async function showNotices() {
    const n = await wos.call("sys.notices");
    const rows = n.packages.slice(0, 1500).map(p => h("div.row", { style: "cursor:default;min-height:36px" }, h("div.grow", h("div.t", p.name), h("div.s", p.licence || "")), h("span.small.muted", p.version)));
    const close = () => back.remove();
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) close(); } }, h("div.modal", { style: "width:min(680px,94vw);max-height:84vh;display:flex;flex-direction:column" },
      h("h2", "Open source notices"), h("p.muted.small", { style: "white-space:pre-wrap;user-select:text" }, n.offer),
      h("div.card", { style: "overflow:auto;flex:1;margin-top:10px" }, h("div.list", rows)), h("div.actions", h("button.btn", { onclick: close }, "Close"))));
    document.body.append(back);
  }

  async function connect(n) {
    if (n.active) return;
    let password = "";
    if (n.secure) { password = await prompt2(`Password for ${n.ssid}`, "", "Wi-Fi password"); if (password === null) return; }
    toast("Connecting…"); const r = await wos.call("sys.wifi.connect", { ssid: n.ssid, password });
    toast(r.ok ? "Connected" : "Could not connect"); draw();
  }
  wos.on("theme", m => { theme = theme; });
  draw();
});
