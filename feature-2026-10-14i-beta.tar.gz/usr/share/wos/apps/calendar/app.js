"use strict";
/* Calendar: month, week and day views. Signed in with a W-Account, events live in W-Life and follow you to every
   device; without one they stay on this computer. Weeks start on Monday. The logic is in cal.js (tested). */

boot(async info => {
  const root = $("#root");
  const C = window.Cal;
  const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const HOUR = 48;                                   // px per hour in the week and day views
  const errText = e => (e && e.message) || "Something went wrong";
  const today = () => C.midnight(new Date());

  let view = (await wos.data.get("view", "month")) || "month", anchor = today();
  let life = { signed_in: false }; try { life = await wos.call("life.status"); } catch (e) { /* older image */ }
  let local = await wos.data.get("events2", null);
  if (local === null) { local = C.migrateOld(await wos.data.get("events", [])); await wos.data.set("events2", local); }
  let cache = (await wos.data.get("cache", [])) || [];            // last events seen from W-Life, for when there is no connection
  let events = [], offline = false, banner = null, loadToken = 0;

  const saveLocal = () => wos.data.set("events2", local);
  const saveCache = () => wos.data.set("cache", cache.slice(-1500));

  // ---------- data ----------
  async function life_(method, path, body) {
    const r = await wos.call("life.request", { method, path, body });
    if (!r.ok) { const e = new Error(r.message); e.offline = !!r.offline; throw e; }
    return r.data;
  }
  async function load() {
    const my = ++loadToken, [from, to] = C.rangeFor(view, anchor);
    if (!life.signed_in) { events = local.filter(e => e.start < to.getTime() && e.end > from.getTime()); offline = false; draw(); return; }
    try {
      const rows = await life_("GET", `/api/v1/calendar/events?from=${encodeURIComponent(from.toISOString())}&to=${encodeURIComponent(to.toISOString())}`);
      if (my !== loadToken) return;
      events = rows.map(C.fromApi); offline = false;
      const ids = new Set(events.map(e => e.id));
      cache = cache.filter(e => !(e.start < to.getTime() && e.end > from.getTime()) || ids.has(e.id)).filter(e => !ids.has(e.id)).concat(events); saveCache();
    } catch (e) {
      if (my !== loadToken) return;
      if (e.offline) { events = cache.filter(x => x.start < to.getTime() && x.end > from.getTime()); offline = true; } else { events = []; toast(errText(e)); }
    }
    draw();
  }
  async function saveEvent(ev, isNew) {
    if (!life.signed_in) { const i = local.findIndex(x => x.id === ev.id); if (i >= 0) local[i] = ev; else local.push(ev); await saveLocal(); return; }
    if (isNew) await life_("POST", "/api/v1/calendar/events", C.toApi(ev)); else await life_("PUT", "/api/v1/calendar/events/" + encodeURIComponent(ev.id), C.toApi(ev));
  }
  async function removeEvent(ev) {
    if (!life.signed_in) { local = local.filter(x => x.id !== ev.id); await saveLocal(); return; }
    await life_("DELETE", "/api/v1/calendar/events/" + encodeURIComponent(ev.id));
    cache = cache.filter(x => x.id !== ev.id); saveCache();
  }
  async function uploadLocal() {
    let n = 0;
    for (const ev of local) { try { await life_("POST", "/api/v1/calendar/events", C.toApi(ev)); n++; } catch (e) { toast(errText(e)); break; } }
    if (n === local.length) { local = []; await saveLocal(); toast(n + (n === 1 ? " event" : " events") + " added to your W-Account"); } else toast("Added " + n + " of " + local.length + ". The rest are still on this computer.");
    banner = null; load();
  }

  // ---------- chrome ----------
  const title = h("h1", { style: "margin:0;font-size:26px" });
  const chip = h("span.chip");
  const seg = h("div.seg");
  const bannerEl = h("div");
  const stage = h("div", { style: "flex:1;min-height:0;display:flex;flex-direction:column;padding:0 22px 18px" });
  root.append(h("div", { style: "display:flex;flex-direction:column;height:100%" },
    h("div", { style: "display:flex;align-items:center;gap:10px;padding:18px 22px 12px" }, title, chip, h("div", { style: "flex:1" }), seg,
      h("button.icon-btn", { title: "Previous", html: icon("back"), onclick: () => step(-1) }),
      h("button.btn.small.ghost", { onclick: () => { anchor = today(); load(); } }, "Today"),
      h("button.icon-btn", { title: "Next", html: icon("forward"), onclick: () => step(1) }),
      h("button.btn.small", { onclick: () => edit(null) }, h("span", { html: icon("plus", 14) }), "New event")),
    bannerEl, stage));

  function step(n) {
    if (view === "month") anchor = new Date(anchor.getFullYear(), anchor.getMonth() + n, 1);
    else anchor = C.addDays(anchor, n * (view === "week" ? 7 : 1));
    load();
  }
  function paintHead() {
    seg.innerHTML = "";
    [["day", "Day"], ["week", "Week"], ["month", "Month"]].forEach(([k, l]) => seg.append(h("button" + (view === k ? ".on" : ""), { onclick: () => { view = k; wos.data.set("view", k); load(); } }, l)));
    if (view === "month") title.textContent = `${MONTHS[anchor.getMonth()]} ${anchor.getFullYear()}`;
    else if (view === "day") title.textContent = anchor.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    else { const [f] = C.rangeFor("week", anchor), l = C.addDays(f, 6); title.textContent = `${f.getDate()} ${f.getMonth() === l.getMonth() ? "" : MONTHS[f.getMonth()].slice(0, 3) + " "}– ${l.getDate()} ${MONTHS[l.getMonth()].slice(0, 3)} ${l.getFullYear()}`; }
    chip.textContent = !life.signed_in ? "On this computer" : offline ? "Offline: showing saved events" : "Synced · " + (life.email || "W-Account");
    chip.style.color = offline ? "#d98a00" : "";
    bannerEl.innerHTML = "";
    if (life.signed_in && local.length && banner !== "dismissed" && !offline) {
      bannerEl.append(h("div.card", { style: "margin:0 22px 12px;padding:12px 16px;display:flex;align-items:center;gap:12px" }, h("div", { style: "flex:1" }, h("b", `${local.length} ${local.length === 1 ? "event is" : "events are"} only on this computer.`), h("div.small.muted", "Add them to your W-Account so they sync to your other devices.")),
        h("button.btn.small.ghost", { onclick: () => { banner = "dismissed"; paintHead(); } }, "Not now"), h("button.btn.small", { onclick: uploadLocal }, "Add them")));
    }
  }

  // ---------- views ----------
  const chipFor = (ev, small) => h("button", { title: ev.title, style: `display:block;width:100%;text-align:left;border:0;border-radius:6px;padding:${small ? "1px 6px" : "2px 6px"};margin-bottom:2px;font-size:11px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer;` +
    (ev.allDay ? "background:var(--accent);color:var(--accent-ink);" : "background:var(--sel);color:var(--ink);border-left:3px solid var(--accent);"), onclick: e => { e.stopPropagation(); edit(ev); } },
    (ev.allDay ? "" : C.fmtTime(ev.start) + " ") + ev.title);

  function drawMonth() {
    const [from] = C.rangeFor("month", anchor), t0 = today().getTime();
    const weeks = Math.round((C.rangeFor("month", anchor)[1] - from) / (7 * C.DAY));
    stage.append(h("div", { style: "display:grid;grid-template-columns:repeat(7,1fr);gap:6px;margin-bottom:6px" }, DAYS.map(d => h("div.label", { style: "text-align:center" }, d))));
    const grid = h("div", { style: `display:grid;grid-template-columns:repeat(7,1fr);grid-template-rows:repeat(${weeks},minmax(0,1fr));gap:6px;flex:1;min-height:0` });
    for (let i = 0; i < weeks * 7; i++) {
      const d = C.addDays(from, i), inMonth = d.getMonth() === anchor.getMonth(), list = C.eventsOnDay(events, d);
      grid.append(h("div.tile", { style: `display:flex;flex-direction:column;align-items:stretch;gap:2px;padding:6px;text-align:left;cursor:default;overflow:hidden;${inMonth ? "" : "opacity:.45;"}`,
        ondblclick: () => edit(null, d) },
        h("button", { style: `align-self:flex-start;border:0;cursor:pointer;font-weight:800;font-size:13px;border-radius:999px;padding:1px 8px;margin-bottom:2px;` + (d.getTime() === t0 ? "background:#ff3b30;color:#fff;" : "background:none;color:var(--ink);"), onclick: () => { anchor = d; view = "day"; wos.data.set("view", "day"); load(); } }, d.getDate()),
        ...list.slice(0, 3).map(ev => chipFor(ev, true)), list.length > 3 ? h("div.small.muted", { style: "padding-left:6px" }, `+${list.length - 3} more`) : null));
    }
    stage.append(grid);
  }

  function drawTimeGrid(days) {
    const t0 = today().getTime();
    const cols = `56px repeat(${days.length},minmax(0,1fr))`;
    const allDay = days.map(d => C.eventsOnDay(events, d).filter(e => e.allDay));
    const rows = Math.max(...allDay.map(a => a.length));
    stage.append(h("div", { style: `display:grid;grid-template-columns:${cols};border-bottom:1px solid var(--line);padding-bottom:6px` },
      h("div"), ...days.map((d, i) => h("div", { style: "padding:0 4px" }, h("div", { style: "text-align:center;margin-bottom:4px" }, h("span.small.muted", { style: "font-weight:700" }, DAYS[(d.getDay() + 6) % 7] + " "),
        h("span", { style: "font-weight:800;" + (d.getTime() === t0 ? "background:#ff3b30;color:#fff;border-radius:999px;padding:1px 8px;" : "") }, d.getDate())),
        ...allDay[i].map(ev => chipFor(ev, true))))));
    void rows;
    const scroller = h("div", { style: "flex:1;min-height:0;overflow:auto;position:relative" });
    const body = h("div", { style: `display:grid;grid-template-columns:${cols};height:${24 * HOUR}px;position:relative` });
    const gutter = h("div", { style: "position:relative" });
    for (let hr = 1; hr < 24; hr++) gutter.append(h("div.small.muted", { style: `position:absolute;top:${hr * HOUR - 8}px;right:8px;font-size:11px` }, String(hr).padStart(2, "0") + ":00"));
    body.append(gutter);
    days.forEach(d => {
      const col = h("div", { style: "position:relative;border-left:1px solid var(--line);" + (d.getTime() === t0 ? "background:var(--sel);background:rgba(10,132,255,.04);" : ""),
        onclick: e => { if (e.target !== col) return; const r = col.getBoundingClientRect(); const mins = Math.floor((e.clientY - r.top) / HOUR * 2) * 30; const s = new Date(d); s.setHours(0, mins, 0, 0); edit(null, s, true); } });
      for (let hr = 1; hr < 24; hr++) col.append(h("div", { style: `position:absolute;left:0;right:0;top:${hr * HOUR}px;border-top:1px solid var(--line);pointer-events:none` }));
      C.layoutDay(events, d).forEach(l => {
        const w = 100 / l.cols;
        col.append(h("button", { title: l.ev.title, style: `position:absolute;top:${l.top / 60 * HOUR}px;height:${Math.max(18, l.height / 60 * HOUR - 2)}px;left:calc(${l.col * w}% + 2px);width:calc(${w}% - 4px);border:0;border-left:3px solid var(--accent);border-radius:8px;background:var(--sel);color:var(--ink);text-align:left;padding:3px 6px;overflow:hidden;cursor:pointer;font-size:11px;`, onclick: e => { e.stopPropagation(); edit(l.ev); } },
          h("div", { style: "font-weight:800;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" }, l.ev.title), l.height >= 40 ? h("div.muted", C.describe(l.ev)) : null));
      });
      if (d.getTime() === t0) { const n = new Date(); col.append(h("div", { style: `position:absolute;left:0;right:0;top:${(n.getHours() * 60 + n.getMinutes()) / 60 * HOUR}px;border-top:2px solid #ff3b30;pointer-events:none;z-index:2` })); }
      body.append(col);
    });
    scroller.append(body); stage.append(scroller);
    scroller.scrollTop = 7.5 * HOUR;
  }

  function draw() {
    paintHead();
    stage.innerHTML = "";
    if (view === "month") drawMonth();
    else { const [f] = C.rangeFor(view, anchor); drawTimeGrid(view === "day" ? [f] : Array.from({ length: 7 }, (_, i) => C.addDays(f, i))); }
  }

  // ---------- editor ----------
  function edit(existing, when, timed) {
    const base = when ? new Date(when) : new Date(anchor);
    if (!existing && !timed) base.setHours(9, 0, 0, 0);
    const ev = existing ? { ...existing } : { id: uid(), title: "", notes: "", location: "", start: base.getTime(), end: base.getTime() + 3600000, allDay: false };
    const lastDay = new Date(ev.allDay ? ev.end - 1 : ev.end);
    const title = h("input.field", { value: ev.title, placeholder: "Title" }), location = h("input.field", { value: ev.location, placeholder: "Location" });
    const notes = h("textarea.field", { rows: 3, placeholder: "Notes" }, ev.notes);
    const sd = datePicker({ value: C.ymd(new Date(ev.start)), width: 170 }), st = timePicker({ value: C.fmtTime(ev.start), width: 110 });
    const ed = datePicker({ value: C.ymd(lastDay), width: 170 }), et = timePicker({ value: C.fmtTime(ev.allDay ? ev.start : ev.end), width: 110 });
    let allDay = ev.allDay;
    const times = h("span", { style: "display:contents" });
    const sw = h("button.switch" + (allDay ? ".on" : ""), { onclick: () => { allDay = !allDay; sw.classList.toggle("on", allDay); st.style.display = et.style.display = allDay ? "none" : ""; } });
    st.style.display = et.style.display = allDay ? "none" : "";
    const err = h("div.small", { style: "color:var(--btn-danger,#d33);min-height:18px" });
    const done = () => back.remove();
    const save = h("button.btn", { onclick: async () => {
      err.textContent = "";
      if (!title.value.trim()) { err.textContent = "Give it a title."; return; }
      const [sy, sm, sdn] = sd.value.split("-").map(Number), [ey, em, edn] = ed.value.split("-").map(Number);
      const start = new Date(sy, sm - 1, sdn), end = new Date(ey, em - 1, edn);
      if (allDay) { ev.start = start.getTime(); ev.end = C.addDays(end, 1).getTime(); if (end < start) { err.textContent = "It cannot end before it starts."; return; } }
      else { const [sh, smn] = st.value.split(":").map(Number), [eh, emn] = et.value.split(":").map(Number); start.setHours(sh, smn); end.setHours(eh, emn); if (end <= start) { err.textContent = "It must end after it starts."; return; } ev.start = start.getTime(); ev.end = end.getTime(); }
      ev.allDay = allDay; ev.title = title.value.trim(); ev.location = location.value.trim(); ev.notes = notes.value;
      save.disabled = true; save.textContent = "Saving…";
      try { await saveEvent(ev, !existing); done(); anchor = C.midnight(new Date(ev.start)); load(); } catch (e) { err.textContent = e.offline ? "You are offline. Connect to save changes to your W-Account." : errText(e); save.disabled = false; save.textContent = "Save"; }
    } }, "Save");
    const back = h("div.modal-back", { onclick: x => { if (x.target === back) done(); } }, h("div.modal", { style: "width:min(520px,94vw);max-height:92vh;overflow:auto" }, h("h2", existing ? "Edit event" : "New event"),
      h("div.form-row", title), h("div.form-row", location),
      h("div", { style: "display:flex;align-items:center;gap:10px;margin:6px 0 10px" }, h("span", { style: "flex:1;font-weight:700" }, "All day"), sw),
      h("div", { style: "display:flex;gap:8px;align-items:center;margin-bottom:8px" }, h("span.muted", { style: "width:44px" }, "Starts"), sd, st),
      h("div", { style: "display:flex;gap:8px;align-items:center;margin-bottom:10px" }, h("span.muted", { style: "width:44px" }, "Ends"), ed, et),
      h("div.form-row", notes), err,
      h("div.actions", existing ? h("button.btn.danger", { style: "margin-right:auto", onclick: async () => { try { await removeEvent(existing); done(); load(); } catch (e) { err.textContent = e.offline ? "You are offline. Connect to delete this." : errText(e); } } }, "Delete") : null,
        h("button.btn.ghost", { onclick: done }, "Cancel"), save)));
    document.body.append(back); title.focus();
  }

  document.addEventListener("keydown", e => {
    if (e.target.closest && e.target.closest("input,textarea") || document.querySelector(".modal-back")) return;
    if (e.key === "ArrowLeft") step(-1); else if (e.key === "ArrowRight") step(1);
    else if (e.key === "t") { anchor = today(); load(); }
    else if (e.key === "n") edit(null);
    else if (["1", "2", "3"].includes(e.key)) { view = ["day", "week", "month"][+e.key - 1]; wos.data.set("view", view); load(); }
  });

  load();
});
