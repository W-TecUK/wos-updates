"use strict";
/* W-Calendar: a month at a glance, the selected day's events beside it. Weeks start on Monday. */

boot(async () => {
  const root = $("#root");
  let events = await wos.data.get("events", []);
  const save = () => wos.data.set("events", events);
  const today = new Date();
  let year = today.getFullYear(), month = today.getMonth(), picked = ymd(today);
  const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  function ymd(d) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
  const on = date => events.filter(e => e.date === date).sort((a, b) => (a.time || "").localeCompare(b.time || ""));

  const title = h("h1"); const grid = h("div", { style: "display:grid;grid-template-columns:repeat(7,1fr);gap:6px;flex:1;min-height:0" });
  const nav = h("div.bar", title, h("div.grow"),
    h("button.icon-btn", { html: icon("back"), title: "Previous month", onclick: () => shift(-1) }),
    h("button.btn.small.ghost", { onclick: () => { year = today.getFullYear(); month = today.getMonth(); picked = ymd(today); draw(); } }, "Today"),
    h("button.icon-btn", { html: icon("forward"), title: "Next month", onclick: () => shift(1) }));
  const days = h("div.body", { style: "display:flex;flex-direction:column;gap:10px" },
    h("div", { style: "display:grid;grid-template-columns:repeat(7,1fr);gap:6px" }, DAYS.map(d => h("div.label", { style: "text-align:center" }, d))), grid);
  const dayTitle = h("h2", { style: "margin:0" }); const dayList = h("div.list");
  const side = h("aside.side", { style: "width:300px;padding:18px;display:flex;flex-direction:column;gap:12px;border-right:0;border-left:1px solid var(--line)" },
    dayTitle, h("div.card", { style: "flex:1;overflow:auto" }, dayList),
    h("button.btn", { onclick: () => editEvent() }, h("span", { html: icon("plus", 14) }), "New event"));
  root.append(h("div", { style: "display:grid;grid-template-columns:1fr 300px;height:100%" }, h("div.main", nav, days), side));

  function shift(d) { month += d; if (month < 0) { month = 11; year--; } if (month > 11) { month = 0; year++; } draw(); }

  function draw() {
    title.textContent = `${MONTHS[month]} ${year}`;
    grid.innerHTML = "";
    const first = new Date(year, month, 1), offset = (first.getDay() + 6) % 7, count = new Date(year, month + 1, 0).getDate();
    const rows = Math.ceil((offset + count) / 7); grid.style.gridTemplateRows = `repeat(${rows}, 1fr)`;
    for (let i = 0; i < rows * 7; i++) {
      const dayNum = i - offset + 1; const d = new Date(year, month, dayNum), key = ymd(d), inMonth = dayNum >= 1 && dayNum <= count;
      const evs = on(key);
      grid.append(h("button.tile", { style: `display:flex;flex-direction:column;align-items:flex-start;gap:4px;padding:8px 10px;text-align:left;${inMonth ? "" : "opacity:.35;"}${key === picked ? "outline:2px solid var(--ink);" : ""}`,
        onclick: () => { picked = key; if (!inMonth) { month = d.getMonth(); year = d.getFullYear(); } draw(); }, ondblclick: () => editEvent() },
        h("span", { style: `font-weight:800;${key === ymd(today) ? "background:#ff3b30;color:#fff;border-radius:999px;padding:0 7px;" : ""}` }, d.getDate()),
        h("div", { style: "display:flex;gap:3px;flex-wrap:wrap" }, evs.slice(0, 5).map(() => h("span.dot", { style: "width:6px;height:6px;background:var(--ink)" })))));
    }
    const d = new Date(picked + "T00:00:00");
    dayTitle.textContent = d.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" });
    dayList.innerHTML = "";
    const evs = on(picked);
    if (!evs.length) dayList.append(h("div.row.muted", { style: "cursor:default" }, "Nothing planned"));
    evs.forEach(e => dayList.append(h("button.row", { onclick: () => editEvent(e) }, h("span.mono.small", { style: "width:46px" }, e.time || "All day"), h("div.grow", h("div.t", e.title), e.notes ? h("div.s", e.notes) : null))));
  }

  async function editEvent(e) {
    const ev = e || { id: uid(), title: "", date: picked, time: "", notes: "" };
    const title = h("input.field", { value: ev.title, placeholder: "Title" }), date = h("input.field", { type: "date", value: ev.date });
    const time = h("input.field", { type: "time", value: ev.time }), notes = h("textarea.field", { rows: 3, placeholder: "Notes" }, ev.notes);
    const done = () => back.remove();
    const back = h("div.modal-back", { onclick: x => { if (x.target === back) done(); } },
      h("div.modal", h("h2", e ? "Edit event" : "New event"),
        h("div.form-row", h("span.label", "Title"), title), h("div", { style: "display:flex;gap:10px" }, h("div.form-row", { style: "flex:1" }, h("span.label", "Date"), date), h("div.form-row", { style: "flex:1" }, h("span.label", "Time"), time)),
        h("div.form-row", h("span.label", "Notes"), notes),
        h("div.actions", e ? h("button.btn.ghost", { style: "margin-right:auto", onclick: () => { events = events.filter(x => x.id !== ev.id); save(); done(); draw(); } }, "Delete") : null,
          h("button.btn.ghost", { onclick: done }, "Cancel"),
          h("button.btn", { onclick: () => {
            if (!title.value.trim()) { toast("Give it a title"); return; }
            Object.assign(ev, { title: title.value.trim(), date: date.value || picked, time: time.value, notes: notes.value });
            if (!e) events.push(ev); picked = ev.date; const pd = new Date(ev.date + "T00:00:00"); month = pd.getMonth(); year = pd.getFullYear(); save(); done(); draw(); } }, "Save"))));
    document.body.append(back); title.focus();
  }
  draw();
});
