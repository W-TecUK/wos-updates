"""Weather for the Weather app, from Open-Meteo (free, no account, no key). Only two fixed web addresses are ever contacted,
and the page only ever sends a city name or a pair of coordinates, never anything else."""
import json
import re
import urllib.error
import urllib.parse
import urllib.request

GEO = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST = "https://api.open-meteo.com/v1/forecast"
MAX_BYTES = 600_000


class WxError(Exception):
    """Message safe to show to the person."""


def search_url(query, count=6, language="en"):
    q = re.sub(r"[\x00-\x1f]", " ", str(query or "")).strip()
    if len(q) < 2 or len(q) > 80:
        raise WxError("Type at least two letters of a city name.")
    lang = language if re.fullmatch(r"[a-z]{2}", str(language)) else "en"
    return GEO + "?" + urllib.parse.urlencode({"name": q, "count": max(1, min(10, int(count))), "language": lang, "format": "json"})


def check_coords(lat, lon):
    try:
        lat, lon = float(lat), float(lon)
    except (TypeError, ValueError):
        raise WxError("That place has no position.")
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        raise WxError("That place has no position.")
    return round(lat, 4), round(lon, 4)


def forecast_url(lat, lon):
    lat, lon = check_coords(lat, lon)
    return FORECAST + "?" + urllib.parse.urlencode({
        "latitude": lat, "longitude": lon, "timezone": "auto", "forecast_days": 7,
        "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day",
        "hourly": "temperature_2m,weather_code,precipitation_probability",
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset"})


def clean_places(data):
    """Geocoding reply -> [{name, region, country, lat, lon}], whatever the server sent."""
    out = []
    for r in (data.get("results") if isinstance(data, dict) else None) or []:
        try:
            lat, lon = check_coords(r["latitude"], r["longitude"])
        except (KeyError, TypeError, WxError):
            continue
        out.append({"name": str(r.get("name") or "")[:60], "region": str(r.get("admin1") or "")[:60], "country": str(r.get("country") or "")[:60], "lat": lat, "lon": lon})
    return [p for p in out if p["name"]][:10]


def _num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _col(block, key, text=False):
    vals = block.get(key) if isinstance(block, dict) else None
    vals = vals if isinstance(vals, list) else []
    return [str(v)[:30] if text else _num(v) for v in vals[:200]]


def clean_forecast(data):
    """Forecast reply -> only the fields the app uses, as plain numbers and strings. Raises WxError when it is not a forecast."""
    if not isinstance(data, dict) or not isinstance(data.get("current"), dict) or not isinstance(data.get("daily"), dict) or not data["current"]:
        raise WxError("The weather service sent something unexpected.")
    cur, hourly, daily = data["current"], data.get("hourly") or {}, data["daily"]
    return {"timezone": str(data.get("timezone") or "")[:40],
            "current": {"temp": _num(cur.get("temperature_2m")), "feels": _num(cur.get("apparent_temperature")), "humidity": _num(cur.get("relative_humidity_2m")),
                        "code": _num(cur.get("weather_code")), "wind": _num(cur.get("wind_speed_10m")), "day": bool(cur.get("is_day")), "time": str(cur.get("time") or "")[:20]},
            "hourly": {"time": _col(hourly, "time", True), "temp": _col(hourly, "temperature_2m"), "code": _col(hourly, "weather_code"), "rain": _col(hourly, "precipitation_probability")},
            "daily": {"time": _col(daily, "time", True), "code": _col(daily, "weather_code"), "max": _col(daily, "temperature_2m_max"), "min": _col(daily, "temperature_2m_min"),
                      "rain": _col(daily, "precipitation_probability_max"), "sunrise": _col(daily, "sunrise", True), "sunset": _col(daily, "sunset", True)}}


def fetch(url, timeout=12, opener=None):
    if not (url.startswith(GEO + "?") or url.startswith(FORECAST + "?")):
        raise WxError("That address is not allowed.")
    try:
        with (opener or urllib.request.urlopen)(urllib.request.Request(url, headers={"User-Agent": "W-OS Weather"}), timeout=timeout) as r:
            raw = r.read(MAX_BYTES)
        return json.loads(raw)
    except urllib.error.HTTPError:
        raise WxError("The weather service could not answer that.")
    except (urllib.error.URLError, OSError, TimeoutError):
        raise WxError("Could not reach the weather service. Check your connection.")
    except ValueError:
        raise WxError("The weather service sent something unexpected.")
