#!/bin/sh
# live-config creates the default session user at BOOT time, not build
# time (its own live-config.service), so this can't be done in a build
# hook -- it has to run after that unit, once the user actually exists.
# See os/build/config/includes.chroot/usr/lib/systemd/system/wos3-group-fixup.service.
set -e

if getent passwd user >/dev/null 2>&1; then
  usermod -aG peksd user
fi
