"use strict";
/* Settings: appearance (light/dark), network, sound, account, language, accessibility, updates, about. */

boot(async info => {
  const root = $("#root");
  let page = "overview", theme = await wos.call("theme.get");
  const acc = await wos.call("prefs.get");

  // group, key, label, icon, colour, words the search also matches -- grouped and ordered the
  // way System Settings and Windows Settings both are (identity/personal first, then hardware
  // and connections, then the machine-wide stuff), not one flat alphabetical Linux-style list.
  const PAGES = [
    ["W-OS", "overview", "Overview", "home", "#0a84ff", "home start summary welcome device"],
    ["Personalization", "appearance", "Appearance", "paint", "#5e5ce6", "theme dark light accent colour highlight"],
    ["Personalization", "desktop", "Desktop & Dock", "image", "#0a84ff", "wallpaper background dock size clock menu bar battery"],
    ["Personalization", "displays", "Displays", "image", "#32ade6", "screen resolution scale brightness night light warm"],
    ["Personalization", "sound", "Sound", "sound", "#ff375f", "volume speaker output"],
    ["Personalization", "notifications", "Notifications", "bell", "#ff453a", "do not disturb focus alerts banners"],
    ["Network & devices", "network", "Network", "wifi", "#0a84ff", "wifi wi-fi internet"],
    ["Network & devices", "bluetooth", "Bluetooth", "phone", "#1d8cf8", "headphones devices"],
    ["Network & devices", "keyboard", "Keyboard & trackpad", "edit", "#8e8e93", "mouse touchpad typing scroll shortcuts hotkeys"],
    ["Network & devices", "printers", "Printers", "doc", "#8e8e93", "print scan"],
    ["Accounts & privacy", "users", "Users", "user", "#64a0ff", "accounts people login items startup apps"],
    ["Accounts & privacy", "account", "W-Account", "shield", "#0a84ff", "sign in email w-life"],
    ["Accounts & privacy", "license", "Activation", "star", "#ffb800", "licence license product key buy premium free device code"],
    ["Accounts & privacy", "privacy", "Privacy & Security", "lock", "#2c9fb8", "firewall data sharing telemetry crash usage"],
    ["System", "power", "Power", "battery", "#30b04f", "battery sleep lock screen energy"],
    ["System", "datetime", "Date & time", "clock", "#ff9f0a", "timezone clock 24 hour"],
    ["System", "language", "Language & region", "globe", "#0a84ff", "english spanish"],
    ["System", "defaults", "Default apps", "grid", "#bf5af2", "browser web"],
    ["System", "backup", "Backup", "disk", "#30b04f", "backup restore time machine file history copy usb drive"],
    ["System", "transfer", "Transfer", "refresh", "#0a84ff", "dock style move windows mac import old computer drive network"],
    ["System", "storage", "Storage", "disk", "#8e8e93", "disk space bin trash free"],
    ["System", "access", "Accessibility", "list", "#0a84ff", "zoom contrast motion speak"],
    ["System", "updates", "Updates", "refresh", "#8e8e93", "software version"],
    ["System", "about", "About", "gear", "#8e8e93", "name version device rename"],
  ];
  let query = "";
  { const want = (info.args || [])[0]; if (want && PAGES.some(p => p[1] === want)) page = want; }     // e.g. opened from the update notification
  const nav = h("nav.nav"); const body = h("div.body", { style: "max-width:680px;width:100%" });
  const searchBox = h("input.sidebar-search", { type: "search", placeholder: "Search", oninput: e => { query = e.target.value.trim().toLowerCase(); drawNav(); } });
  root.append(h("div.app.settings-app", h("aside.side", h("div.side-title", "Settings"), searchBox, nav), h("div.main", { style: "overflow:auto" }, h("div", { style: "padding:22px;display:flex;justify-content:center" }, body))));

  const section = (title, ...kids) => h("div", { style: "margin-bottom:26px" }, h("span.label", { style: "display:block;margin:0 4px 10px" }, title), ...kids);
  const rowOf = (label, sub, control) => h("div.row", { style: "cursor:default;min-height:56px" }, h("div.grow", h("div.t", label), sub ? h("div.s", sub) : null), control);
  const flag = (key) => { const s = h("button.switch" + (acc[key] ? ".on" : ""), { onclick: () => { acc[key] = !acc[key]; s.classList.toggle("on", acc[key]); wos.call("prefs.set", { key, value: acc[key] }); applyPrefs(acc); } }); return s; };

  const drawNav = () => {
    nav.innerHTML = "";
    const shown = PAGES.filter(([g, k, l, i, c, w]) => !query || (l + " " + w).toLowerCase().includes(query));
    let lastGroup = null;
    shown.forEach(([g, k, l, i, c]) => {
      if (g !== lastGroup) { nav.append(h("span.nav-group", g)); lastGroup = g; }
      nav.append(h("button" + (page === k ? ".on" : ""), { onclick: () => { page = k; draw(); } },
        h("span.tile-ico", { style: "background:" + c, html: icon(i, 15) }), l));
    });
    if (!shown.length) nav.append(h("div.muted.small", { style: "padding:10px 12px" }, "Nothing matches"));
  };
  const draw = async () => {
    drawNav();
    body.innerHTML = ""; body.append(h("h1.dots", { style: "font-size:36px;margin:0 0 20px" }, PAGES.find(p => p[1] === page)[2]));
    body.classList.remove("page-in"); void body.offsetWidth; body.classList.add("page-in");
    await views[page]();
  };
  const seg = (options, current, onpick) => {
    const box = h("div.seg");
    options.forEach(([v, label]) => box.append(h("button" + (current === v ? ".on" : ""), { onclick: () => { [...box.children].forEach(x => x.classList.remove("on")); box.children[options.findIndex(o => o[0] === v)].classList.add("on"); onpick(v); } }, label)));
    return box;
  };
  const switchOf = (on, onchange) => { const sw = h("button.switch" + (on ? ".on" : ""), { onclick: () => { const now = !sw.classList.contains("on"); sw.classList.toggle("on", now); onchange(now); } }); return sw; };
  const fmtBytes = n => n >= 1e9 ? (n / 1e9).toFixed(1) + " GB" : n >= 1e6 ? Math.round(n / 1e6) + " MB" : n >= 1e3 ? Math.round(n / 1e3) + " KB" : n + " bytes";

  // Look inside one backup and bring back a file or folder.
  function browseBackup(name) {
    let rel = "";
    const crumbs = h("div.small.muted", { style: "margin-bottom:8px;word-break:break-all" }), list = h("div.card", { style: "max-height:46vh;overflow:auto" });
    const done = () => back.remove();
    const load = async () => {
      crumbs.textContent = "Backup of " + (rel ? rel : "everything");
      list.innerHTML = "";
      let entries = [];
      try { entries = await wos.call("backup.browse", { name, rel }); } catch (e) { list.append(h("div.muted", { style: "padding:18px" }, e.message)); return; }
      if (rel) list.append(h("button.row", { onclick: () => { rel = rel.split("/").slice(0, -1).join("/"); load(); } }, h("span", { html: icon("back", 15) }), h("div.grow", "Back")));
      if (!entries.length) list.append(h("div.muted", { style: "padding:18px;text-align:center" }, "This folder is empty."));
      entries.forEach(e => list.append(h("div.row", { style: "min-height:44px" },
        h("div.grow", { style: "cursor:" + (e.dir ? "pointer" : "default") + ";min-width:0", onclick: () => { if (e.dir) { rel = rel ? rel + "/" + e.name : e.name; load(); } } },
          h("div.t", e.name), h("div.s", e.dir ? "Folder" : fmtBytes(e.size))),
        h("button.btn.ghost.small", { onclick: async () => { try { const p = await wos.call("backup.restore", { name, rel: rel ? rel + "/" + e.name : e.name }); toast("Restored to " + p.split("/").slice(-2).join("/")); } catch (er) { toast(er.message); } } }, "Restore"))));
    };
    const back = h("div.modal-back", h("div.modal", { style: "width:min(560px,94vw)" }, h("h2", "Restore from backup"), crumbs, list, h("div.actions", h("button.btn", { onclick: done }, "Done"))));
    document.body.append(back);
    load();
  }

  const views = {
    async appearance() {
      const card = (mode, label, ic) => h("button.tile" + (theme === mode ? ".on" : ""), { style: "padding:16px", onclick: async () => { theme = mode; await wos.call("theme.set", { mode }); if (mode !== "auto") applyTheme(mode); else applyTheme(new Date().getHours() >= 19 || new Date().getHours() < 7 ? "dark" : "light"); draw(); } },
        h("div", { style: "height:64px;border-radius:14px;margin-bottom:10px;display:grid;place-items:center;" + (mode === "dark" ? "background:#000;color:#f4f4f6" : mode === "light" ? "background:#f3f3f4;color:#0c0c0e" : "background:linear-gradient(90deg,#f3f3f4 50%,#000 50%);color:#0a84ff"), html: icon(ic, 26) }),
        h("div", { style: "font-weight:800" }, label));
      body.append(section("Theme", h("div.grid", { style: "grid-template-columns:repeat(3,1fr)" }, card("light", "Light", "sun"), card("dark", "Dark", "moon"), card("auto", "Automatic", "refresh"))),
        h("p.muted.small", { style: "margin:-12px 4px 26px" }, "Automatic uses dark from 7 pm to 7 am."));
      const ACCENTS = [["blue", "#0a84ff", "Blue"], ["purple", "#a25be0", "Purple"], ["pink", "#f0559a", "Pink"], ["red", "#f5453a", "Red"], ["orange", "#f7821b", "Orange"], ["yellow", "#f5b800", "Yellow"], ["green", "#30b34f", "Green"], ["graphite", "#7d7d86", "Graphite"]];
      const swatches = h("div", { style: "display:flex;gap:12px;flex-wrap:wrap;padding:16px 18px" });
      const drawSwatches = () => { swatches.innerHTML = ""; ACCENTS.forEach(([k, c, n]) => swatches.append(h("button.swatch" + ((acc.accent || "blue") === k ? ".on" : ""), { title: n, style: "background:" + c,
        onclick: async () => { acc.accent = k; await wos.call("prefs.set", { key: "accent", value: k }); applyPrefs(acc); drawSwatches(); } }, (acc.accent || "blue") === k ? h("span", { html: icon("check", 15) }) : null))); };
      drawSwatches();
      body.append(section("Accent colour", h("div.card", swatches)), h("p.muted.small", { style: "margin:-12px 4px 0" }, "Used for buttons, selections and highlights in W-OS apps."));
    },
    async network() {
      const list = h("div.list", h("div.row.muted", { style: "cursor:default" }, "Looking for networks…")); const card = h("div.card", list);
      let airplane = { on: false }; try { airplane = await wos.call("sys.airplane.get"); } catch (e) { /* older image */ }
      const airSwitch = switchOf(airplane.on === true, async v => { try { await wos.call("sys.airplane.set", { on: v }); toast(v ? "Airplane mode on" : "Airplane mode off"); setTimeout(draw, 1500); } catch (e) { toast(e.message); } });
      body.append(section("Airplane mode", h("div.card", rowOf("Airplane mode", "Turns off Wi-Fi and Bluetooth", airSwitch))),
        section("Wi-Fi", card), h("div", { style: "display:flex;gap:8px" },
          h("button.btn.ghost.small", { onclick: draw }, h("span", { html: icon("refresh", 14) }), "Scan again"),
          h("button.btn.ghost.small", { onclick: () => joinOther() }, h("span", { html: icon("plus", 14) }), "Other network…")));
      let nets = []; try { nets = await wos.call("sys.wifi.list"); } catch (e) { nets = []; }
      list.innerHTML = "";
      if (!nets.length) list.append(h("div.row.muted", { style: "cursor:default" }, "No Wi-Fi networks found. If this computer uses a cable, you are connected that way."));
      nets.forEach(n => list.append(h("button.row", { onclick: () => connect(n) }, h("span", { html: icon("wifi", 18) }),
        h("div.grow", h("div.t", n.ssid), h("div.s", n.active ? "Connected" : n.saved ? "Saved" : n.enterprise ? "Work or school" : n.secure ? "Secured" : "Open")),
        n.saved && !n.active ? h("span.icon-btn", { title: "Forget this network", style: "width:28px;height:28px", html: icon("trash", 15), onclick: async e => {
          e.stopPropagation();
          if (!await confirmBox(`Forget “${n.ssid}”?`, "You will need its password again to rejoin.", "Forget", true)) return;
          try { await wos.call("sys.wifi.forget", { ssid: n.ssid }); toast("Forgotten"); draw(); } catch (er) { toast(er.message); }
        } }) : null,
        n.active ? h("span", { html: '<i class="dot"></i>' }) : n.secure ? h("span", { html: icon("lock", 15), style: "color:var(--muted)" }) : null)));

      const vpnCard = h("div.card");
      const paintVpn = async () => {
        let vpns = []; try { vpns = await wos.call("vpn.list"); } catch (e) { /* not available */ }
        vpnCard.innerHTML = "";
        if (!vpns.length) vpnCard.append(h("div.muted", { style: "padding:20px;text-align:center" }, "No VPN yet. Add the profile file your VPN provider gave you."));
        vpns.forEach(v => vpnCard.append(rowOf(v.name, v.kind + (v.active ? " · Connected" : ""), h("span", { style: "display:flex;gap:8px;align-items:center" },
          h("button.btn.small" + (v.active ? ".ghost" : ""), { onclick: async e => { const b = e.currentTarget; b.disabled = true; b.textContent = v.active ? "Disconnecting…" : "Connecting…";
            try { await wos.call(v.active ? "vpn.disconnect" : "vpn.connect", { uuid: v.uuid }); } catch (er) { toast(er.message); } paintVpn(); } }, v.active ? "Disconnect" : "Connect"),
          h("button.icon-btn", { title: "Remove", html: icon("trash", 15), onclick: async () => { if (!await confirmBox("Remove " + v.name + "?", "You can add it again from the profile file.", "Remove", true)) return; await wos.call("vpn.forget", { uuid: v.uuid }).catch(er => toast(er.message)); paintVpn(); } })))));
      };
      await paintVpn();
      body.append(h("div", { style: "margin-top:26px" }, section("VPN", vpnCard, h("div", { style: "margin-top:10px" }, h("button.btn.ghost.small", { onclick: async () => {
        const path = await pickFile({ title: "Choose a VPN profile", exts: [".ovpn", ".conf"], start: info.home });
        if (!path) return; try { toast("Adding VPN…"); await wos.call("vpn.import", { path }); toast("VPN added"); paintVpn(); } catch (e) { toast(e.message); } } }, h("span", { html: icon("plus", 14) }), "Add VPN…")))));

      let net; try { net = await wos.call("sys.net.get"); } catch (e) { net = { connected: false }; }
      if (!net.connected) return;
      const address = h("input.field", { style: "width:220px", placeholder: "192.168.1.50", value: net.address || "" });
      const prefix = h("input.field", { style: "width:80px", placeholder: "24", value: net.prefix || "24" });
      const gateway = h("input.field", { style: "width:220px", placeholder: "192.168.1.1", value: net.gateway || "" });
      const dns = h("input.field", { style: "width:220px", placeholder: "1.1.1.1, 8.8.8.8", value: net.dns || "" });
      const mtu = h("input.field", { style: "width:120px", placeholder: "Automatic", value: net.mtu || "" });
      const manualRows = h("div", rowOf("IP address", "", address), rowOf("Subnet prefix", "e.g. 24 for 255.255.255.0", prefix), rowOf("Router (gateway)", "", gateway), rowOf("DNS servers", "Comma-separated", dns));
      const syncManual = () => { manualRows.style.display = method.value === "manual" ? "" : "none"; };
      const method = dropdown([["auto", "Automatic (DHCP)"], ["manual", "Manual"]], { value: net.method === "manual" ? "manual" : "auto", width: 160, onChange: syncManual });
      syncManual();
      const advSave = h("button.btn.small", {
        onclick: async () => {
          try {
            await wos.call("sys.net.set", { method: method.value, address: address.value.trim(), prefix: prefix.value.trim(), gateway: gateway.value.trim(), dns: dns.value.trim(), mtu: mtu.value.trim() });
            toast("Saved"); draw();
          } catch (e) { toast(e.message); }
        }
      }, "Apply");
      body.append(section("Advanced (" + net.name + ")", h("div.card",
        rowOf("Configure IPv4", "How this connection gets its address", method), manualRows,
        rowOf("MTU", "Maximum packet size. Leave blank for automatic", mtu)),
        h("div", { style: "margin-top:10px" }, advSave)));
    },
    async sound() {
      const v = await wos.call("sys.volume.get"); const out = h("span.mono", { style: "width:46px;text-align:right" }, v + "%");
      const range = slider({ value: v, onInput: n => { out.textContent = n + "%"; wos.call("sys.volume.set", { value: n }); } });
      range.style.flex = "1";
      let outs = []; try { outs = await wos.call("sound.outputs"); } catch (e) { outs = []; }
      const defOut = outs.find(o => o.default);
      const outSel = dropdown(outs.map(o => [o.name, o.label || o.name]), { value: defOut && defOut.name, width: 220, onChange: name => wos.call("sound.output.set", { name }) });
      if (outs.length > 1) body.append(section("Play sound through", h("div.card", rowOf("Output", "", outSel))));
      body.append(section("Output", h("div.card", rowOf("Volume", "", h("div", { style: "display:flex;align-items:center;gap:12px;width:280px" }, h("span", { html: icon("sound", 18) }), range, out)))));
      let st = { inputs: [], apps: [] }; try { st = await wos.call("sound.state"); } catch (e) { /* older image or no sound server */ }
      const setVol = (kind, id) => n => wos.call("sound.set", { kind, id, volume: n }).catch(e => toast(e.message));
      const muteSwitch = (kind, id, on) => switchOf(!on, v => wos.call("sound.set", { kind, id, muted: !v }).catch(e => toast(e.message)));      // on = sound on
      const vol = (kind, id, n, w) => h("div", { style: `display:flex;align-items:center;gap:10px;width:${w || 240}px` }, slider({ value: Math.min(100, n), onChange: setVol(kind, id), width: 150 }));
      if (st.inputs.length) {
        const mic = st.inputs.find(i => i.default) || st.inputs[0];
        const rows = [];
        if (st.inputs.length > 1) rows.push(rowOf("Input", "The microphone to use", dropdown(st.inputs.map(i => [i.name, i.label]), { value: mic.name, width: 220, onChange: name => wos.call("sound.input.set", { name }).catch(e => toast(e.message)) })));
        rows.push(rowOf("Input volume", mic.label, h("div", { style: "display:flex;align-items:center;gap:12px" }, vol("input", mic.name, mic.volume), muteSwitch("input", mic.name, mic.muted))));
        body.append(section("Input", h("div.card", ...rows)));
      }
      body.append(section("Apps", st.apps.length ? h("div.card", ...st.apps.map(a => rowOf(a.name, a.muted ? "Muted" : "", h("div", { style: "display:flex;align-items:center;gap:12px" }, vol("app", a.id, a.volume), muteSwitch("app", a.id, a.muted)))))
        : h("div.card.pad.muted", "Programs that are playing sound show up here, each with its own volume.")));
    },
    async account() {
      const a = await wos.call("account.get"); const isW = a.type === "waccount";
      const email = h("input.field", { placeholder: "Email", type: "email", style: "width:260px" }), pass = h("input.field", { placeholder: "Password", type: "password", style: "width:260px" });
      const inForm = h("div", { style: "display:flex;flex-direction:column;gap:8px;padding:14px" }, email, pass,
        h("div", h("button.btn.small", { onclick: async () => { try { toast("Signing in…"); await wos.call("account.signin", { email: email.value, password: pass.value }); toast("Signed in"); draw(); } catch (e) { toast(e.message); } } }, "Sign in")));
      body.append(section("You", h("div.card.pad", { style: "display:flex;align-items:center;gap:16px" }, h("div.avatar", { style: "width:56px;height:56px;font-size:20px" }, initials(a.name)),
        h("div", { style: "flex:1" }, h("div", { style: "font-weight:800;font-size:17px" }, a.name), h("div.small.muted", isW ? a.email : "Local account · stays on this device")), h("span.chip", isW ? "W-Account" : "Local"))),
        section("W-Account", h("div.card", isW ? rowOf("Signed in", "W-Mail and other W-Account features are available.", h("button.btn.ghost.small", { onclick: async () => { if (!await confirmBox("Sign out of W-Account?", "W-Mail will stop working until you sign in again.", "Sign out")) return; await wos.call("account.signout"); draw(); } }, "Sign out"))
          : h("div", h("div.row", { style: "cursor:default" }, h("div.grow", h("div.t", "Use a W-Account"), h("div.s", "One account for W-Mail and other W-OS services."))), inForm))));
    },
    async license() {
      const st = await wos.call("license.status");
      const card = h("div.card.pad", { style: "display:flex;align-items:center;gap:16px" },
        h("div", { style: "width:48px;height:48px;border-radius:14px;display:grid;place-items:center;color:#fff;background:" + (st.state === "unlicensed" ? "#ff9f0a" : "#30b04f"), html: icon(st.state === "unlicensed" ? "info" : "check", 24) }),
        h("div", { style: "flex:1" }, h("div", { style: "font-weight:800;font-size:17px" }, st.state === "account" ? "W-OS is activated" : st.state === "key" ? "W-OS is activated with a product key" : "W-OS is in limited mode"),
          h("div.small.muted", st.state === "account" ? "Signed in with your W-Account: everything is included for free." :
            st.state === "key" ? "This computer has a product key" + (st.issued ? " (issued " + st.issued + ")" : "") + ". It works without an account." :
            st.live ? "You are trying W-OS, so nothing is limited yet. Once installed, sign in with a free W-Account or enter a product key." : "Everything already here keeps working and security updates still install, but new apps cannot be added from the Store. Sign in with a free W-Account, or enter a product key, to unlock everything.")),
        h("span.chip", st.premium ? "Premium" : st.state === "unlicensed" ? "Limited" : "Full"));
      body.append(section("Status", card));
      if (st.state !== "account") {
        body.append(section("Free with a W-Account", h("div.card", rowOf("Sign in with your W-Account", "Everything in W-OS, free, and your settings follow you.", h("button.btn.small", { onclick: () => { page = "account"; draw(); } }, "Sign in")))));
      }
      if (st.state === "unlicensed" || st.key_error) {
        const code = st.device;
        const key = h("textarea.field", { rows: 3, placeholder: "Paste your product key (starts WOS4-)", style: "font-family:ui-monospace,monospace;font-size:12px" });
        const err = h("div.small", { style: "color:var(--danger,#d33);min-height:18px;margin-top:6px" }, st.key_error || "");
        body.append(section("Or use a product key", h("div.card",
          rowOf("Buy a product key", "£" + st.price_gbp + " once, for this computer only. No account needed.", h("button.btn.small", { onclick: () => wos.call("sys.open_url", { url: st.buy_url }) }, "Buy")),
          rowOf("This computer's device code", "Give this code when you buy so the key is made for this computer.", h("span", { style: "display:flex;gap:8px;align-items:center" }, h("code", { style: "font-weight:800;letter-spacing:.05em" }, code),
            h("button.icon-btn", { title: "Copy", html: icon("file", 15), onclick: () => { navigator.clipboard && navigator.clipboard.writeText(code).catch(() => {}); toast("Copied"); } }))),
          h("div", { style: "padding:14px" }, key, err, h("div", { style: "margin-top:10px" }, h("button.btn.small", { onclick: async () => {
            err.textContent = ""; if (!key.value.trim()) { err.textContent = "Paste the product key first."; return; }
            try { await wos.call("license.activate", { key: key.value }); toast("W-OS is activated"); draw(); } catch (e) { err.textContent = e.message; } } }, "Activate"))))));
      } else if (st.state === "key") {
        body.append(section("Product key", h("div.card", rowOf("Remove product key", "You can enter it again later on this computer.", h("button.btn.ghost.small", { onclick: async () => { if (!await confirmBox("Remove the product key?", "W-OS will need a W-Account or a product key again.", "Remove")) return; await wos.call("license.remove"); draw(); } }, "Remove")))));
      }
      body.append(h("p.muted.small", { style: "margin:0 4px" }, "Some features may be marked Premium in future. Those need a Premium product key or plan; everything else is included."));
    },
    async transfer() {
      body.append(section("Bring your things from another computer", h("div.card",
        rowOf("Dock style", "Join or Morph: how an app you open reaches the middle of the shelf.",
          h("button.btn.small", { onclick: () => wos.call("sys.launch", { id: "wos-shelf-style.desktop" }).catch(e => toast(e.message)) }, "Choose")),
        rowOf("Transfer", "Documents, photos, music, videos and bookmarks from a Windows PC or a Mac, from a drive or over your network. Your old computer is never changed.",
          h("button.btn.small", { onclick: () => wos.call("sys.launch", { id: "wos-transfer.desktop" }).catch(e => toast(e.message)) }, "Open")))));
    },
    async backup() {
      const st = await wos.call("backup.status");
      const ago = ts => { if (!ts) return "Never"; const m = Math.round((Date.now() / 1000 - ts) / 60); return m < 2 ? "Just now" : m < 60 ? m + " minutes ago" : m < 1440 ? Math.round(m / 60) + " hours ago" : Math.round(m / 1440) + " days ago"; };
      const snapDate = n => { const [d, t] = n.split("_"); return new Date(`${d}T${t.slice(0, 2)}:${t.slice(2, 4)}:${t.slice(4)}`).toLocaleString("en-GB", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }); };
      const ok = !st.error && st.last_success;
      body.append(section("Status", h("div.card.pad", { style: "display:flex;align-items:center;gap:16px" },
        h("div", { style: "width:48px;height:48px;border-radius:14px;display:grid;place-items:center;color:#fff;background:" + (st.error ? "#ff453a" : st.running ? "#0a84ff" : ok ? "#30b04f" : "#8e8e93"), html: icon(st.error ? "info" : st.running ? "refresh" : "disk", 24) }),
        h("div", { style: "flex:1" }, h("div", { style: "font-weight:800;font-size:17px" }, st.running ? "Backing up…" : st.error ? "The last backup did not finish" : ok ? "Backed up " + ago(st.last_success).toLowerCase() : "No backup yet"),
          h("div.small.muted", st.running ? st.files + " files so far. You can keep using your computer." : st.error ? st.error : ok ? (st.skipped ? st.skipped + " files could not be read and were skipped." : "Your files are safe on the drive.") : "Choose a drive below and make your first backup.")),
        st.running ? h("button.btn.ghost.small", { onclick: async () => { await wos.call("backup.cancel"); setTimeout(draw, 800); } }, "Stop")
          : h("button.btn.small", { disabled: !st.connected, onclick: async () => { await wos.call("backup.run"); toast("Backing up…"); setTimeout(draw, 700); } }, "Back up now"))));
      const dd = st.drives.length || st.dest ? dropdown([...(st.dest && !st.drives.some(d => d.path === st.dest) ? [[st.dest, st.dest.split("/").pop() + (st.connected ? "" : " (not connected)")]] : []), ...st.drives.map(d => [d.path, d.name])],
        { value: st.dest, width: 260, onChange: async p => { try { await wos.call("backup.set", { dest: p }); toast("Backup drive chosen"); draw(); } catch (e) { toast(e.message); } } }) : null;
      body.append(section("Backup drive", h("div.card",
        rowOf("Back up to", st.drives.length ? "A USB drive or external disk." : "Plug in a USB drive or external disk to back up to.", dd || h("span.chip", "No drive")),
        rowOf("Back up automatically", "Once a day while the drive is connected.", switchOf(st.auto, async on => { try { await wos.call("backup.set", { auto: on }); } catch (e) { toast(e.message); } })))));
      if (st.running) setTimeout(() => { if (page === "backup") draw(); }, 2000);
      const list = h("div.card");
      if (!st.connected) list.append(h("div.muted", { style: "padding:22px;text-align:center" }, st.dest ? "Connect the backup drive to see your backups." : "Backups you make will be listed here."));
      else if (!st.snapshots.length) list.append(h("div.muted", { style: "padding:22px;text-align:center" }, "No backups on this drive yet."));
      st.snapshots.forEach((n, i) => list.append(h("div.row", { style: "cursor:default;min-height:56px" }, h("div.grow", h("div.t", snapDate(n)), h("div.s", i === 0 ? "Latest" : "")),
        h("button.btn.ghost.small", { onclick: () => browseBackup(n) }, "Browse & restore"),
        h("button.icon-btn", { title: "Delete this backup", html: icon("trash", 15), onclick: async () => { if (!await confirmBox("Delete this backup?", "The other backups are not affected.", "Delete", true)) return; try { await wos.call("backup.delete", { name: n }); draw(); } catch (e) { toast(e.message); } } }))));
      body.append(section("Backups", list), h("p.muted.small", { style: "margin:0 4px" }, "Recent backups are kept for a day, then one a day for a month, then one a week. Caches and the Bin are not backed up. Restored files go to “Restored from backup” in your home folder, never over your current files."));
    },
    async overview() {
      const soft = (m, a) => wos.call(m, a).catch(() => null);          // older image or no such hardware: carry on without it
      const [i0, acc0, lic0, bk0, bat, air0, dnd0, bt0] = await Promise.all([soft("sys.info"), soft("account.get"), soft("license.status"), soft("backup.status"),
        soft("power.battery"), soft("sys.airplane.get"), soft("dnd.get"), soft("bt.status")]);       // all at once: one after another made this page slow to appear
      const i = i0 || {}, acc = acc0 || {}, lic = lic0 || {}, bk = bk0 || {};
      const air = !!(air0 && air0.on === true), dnd = dnd0 === true, bt = bt0 || { available: false, on: false };
      const go = k => () => { page = k; draw(); };
      const ago = ts => { const m = Math.round((Date.now() / 1000 - ts) / 60); return m < 2 ? "just now" : m < 60 ? m + " minutes ago" : m < 1440 ? Math.round(m / 60) + " hours ago" : Math.round(m / 1440) + " days ago"; };
      const who = acc.type === "waccount" ? "Signed in as " + acc.email : "Using a local account";
      const stat = (label, value, sub, to, ic) => h("button.card", { style: "padding:16px;text-align:left;border:1px solid var(--line);cursor:pointer;display:flex;flex-direction:column;gap:2px", onclick: go(to) },
        h("span", { html: icon(ic, 20), style: "color:var(--accent);margin-bottom:6px" }), h("span.small.muted", { style: "font-weight:700" }, label), h("span", { style: "font-size:22px;font-weight:800;letter-spacing:-.02em" }, value), h("span.small.muted", sub));
      body.querySelector("h1.dots").style.display = "none";
      // The phone's Settings, on the desktop: your account on top, quick switches, then rows that show their current value.
      const name = acc.type === "waccount" ? (acc.name || acc.email.split("@")[0]) : (info.user || i.user || "You");
      const profile = h("button.card", { style: "display:flex;align-items:center;gap:14px;width:100%;padding:14px 16px;text-align:left;border:1px solid var(--line);cursor:pointer;margin-bottom:14px", onclick: go("account") },
        h("span", { style: "width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#0a84ff,#5e5ce6);color:#fff;display:grid;place-items:center;font-size:24px;font-weight:800;flex:none" }, (name[0] || "W").toUpperCase()),
        h("div.grow", { style: "min-width:0" }, h("div", { style: "font-size:18px;font-weight:800" }, name), h("div.small.muted", acc.type === "waccount" ? acc.email : "Local account · sign in with a W-Account to sync")),
        h("span.muted", { html: icon("chevron", 16) }));
      const quick = (label, ic, on, flip) => { const t = h("button.tile" + (on ? ".on.lit" : ""), { style: "display:flex;flex-direction:column;align-items:center;gap:6px;padding:14px 8px" }, h("span", { html: icon(ic, 22) }), h("span.small", { style: "font-weight:800" }, label));
        t.onclick = async () => { const now = !t.classList.contains("on"); try { await flip(now); t.classList.toggle("on", now); t.classList.toggle("lit", now); } catch (er) { toast(er.message); } }; return t; };
      const dark = document.documentElement.dataset.theme === "dark";
      const quickRow = h("div.grid", { style: "grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:22px" },
        quick("Airplane", "plane", air, async v => { await wos.call("sys.airplane.set", { on: v }); toast(v ? "Airplane mode on" : "Airplane mode off"); }),
        quick("Dark", "moon", dark, async v => { theme = v ? "dark" : "light"; await wos.call("theme.set", { mode: theme }); applyTheme(theme); }),
        quick("Focus", "bell", dnd, v => wos.call("dnd.set", { value: v })),
        quick("Bluetooth", "bluetooth", bt.on, async v => { if (!bt.available) throw new Error("No Bluetooth adapter found"); await wos.call("bt.power", { on: v }); }));
      const row = (label, ic, colour, detail, to) => h("button.row", { onclick: go(to) }, h("span.tile-ico", { style: "background:" + colour, html: icon(ic, 15) }), h("div.grow", h("div.t", label)),
        detail ? h("span.muted", { style: "margin-right:6px" }, detail) : null, h("span.muted", { html: icon("chevron", 14) }));
      body.append(profile, quickRow,
        h("div.panel.hero", { style: "margin-bottom:14px" }, h("span.chip.gold.eyebrow", "W-OS 4 · " + (i.nickname || "Windermere")), h("h1", i.hostname || "This computer"),
          h("p", `Version ${i.build || info.version} · ${lic.limited ? "Limited mode" : "Activated"} · ${who}`), h("button.cta", { onclick: go("updates") }, "Check for updates")),
        section("At a glance", h("div.card",
          row("Appearance", "paint", "#5e5ce6", dark ? "Dark" : "Light", "appearance"),
          row("Notifications", "bell", "#ff453a", dnd ? "Focus on" : "", "notifications"),
          row("Bluetooth", "phone", "#1d8cf8", bt.available ? (bt.on ? "On" : "Off") : "No adapter", "bluetooth"),
          bat ? row("Power", "battery", "#30b04f", bat.pct + "%" + (bat.status ? " · " + bat.status : ""), "power") : null,
          row("Storage", "disk", "#8e8e93", (i.free_gb != null ? i.free_gb : "?") + " GB free", "storage"),
          row("Backup", "disk", "#30b04f", bk.last_success ? "Backed up " + ago(bk.last_success) : "Not set up", "backup"))),
        h("div.panel.gold", { style: "margin-bottom:6px" }, h("h3", "Make W-OS yours"), h("p", "Light or dark, your accent colour, wallpaper and the dock."), h("button.cta", { onclick: go("appearance") }, "Personalise")));
    },
    async language() {
      body.append(section("Language", h("div.card", rowOf("Display language", "The language W-OS uses", h("span.chip", info.lang.replace("_", "-"))))),
        h("p.muted.small", "To change language or region, contact support: support@willgraves.co.uk. More languages are on the way."));
    },
    async bluetooth() {
      const st = await wos.call("bt.status");
      if (!st.available) { body.append(h("div.card.pad.muted", "No Bluetooth adapter was found on this computer.")); return; }
      const sw = h("button.switch" + (st.on ? ".on" : ""), { onclick: async () => { const on = !sw.classList.contains("on"); sw.classList.toggle("on", on); await wos.call("bt.power", { on }); draw(); } });
      const list = h("div.list", h("div.row.muted", { style: "cursor:default" }, st.on ? "Looking for devices…" : "Bluetooth is off"));
      body.append(section("Bluetooth", h("div.card", rowOf("Bluetooth", "Connect headphones, keyboards and more", sw))), section("Devices", h("div.card", list)),
        st.on ? h("button.btn.ghost.small", { onclick: draw }, h("span", { html: icon("refresh", 14) }), "Search again") : null);
      if (!st.on) return;
      const devs = await wos.call("bt.devices", { scan: true }); list.innerHTML = "";
      if (!devs.length) list.append(h("div.row.muted", { style: "cursor:default" }, "No devices found. Put your device in pairing mode."));
      devs.forEach(d => {
        const action = d.connected ? "disconnect" : "setup";
        const sub = h("div.s", d.connected ? "Connected" : d.paired ? "Paired, not connected" : "Not paired");
        const actionBtn = h("button.btn.ghost.small", { onclick: async () => {
          actionBtn.disabled = true;
          if (action === "disconnect") {
            actionBtn.textContent = "Disconnecting…";
            try { await wos.call("bt.action", { mac: d.mac, action: "disconnect" }); } catch (e) { toast(e.message); }
            draw(); return;
          }
          // Pair, connect and switch the sound in one go. The backend reports what it is doing, so show it.
          const poll = setInterval(async () => { try { const s = await wos.call("bt.state", { mac: d.mac }); if (s && s.text && s.busy) sub.textContent = s.text; } catch (e) { /* keep waiting */ } }, 700);
          actionBtn.textContent = d.paired ? "Connecting…" : "Pairing…"; sub.textContent = actionBtn.textContent;
          let r;
          try { r = await wos.call("bt.setup", { mac: d.mac }); } catch (e) { r = { ok: false, message: e.message }; }
          clearInterval(poll);
          if (r.ok) { toast(r.message || "Connected"); draw(); return; }
          sub.textContent = r.message || "Could not connect.";
          sub.style.color = "var(--danger,#d33)";
          actionBtn.disabled = false; actionBtn.textContent = "Retry";
        } }, d.connected ? "Disconnect" : d.paired ? "Connect" : "Pair");
        list.append(h("div.row", { style: "cursor:default" }, h("div.grow", h("div.t", d.name), sub),
          actionBtn,
          d.paired ? h("button.icon-btn", { title: "Forget", html: icon("trash"), onclick: async () => { await wos.call("bt.action", { mac: d.mac, action: "remove" }); draw(); } }) : null));
      });
    },
    async displays() {
      const list = await wos.call("displays.list");
      let night = { on: false, strength: 50 }; try { night = await wos.call("displays.nightlight.get"); } catch (e) { /* older image */ }
      const strengthOut = h("span.mono", { style: "width:40px;text-align:right" }, night.strength + "%");
      const strengthRange = slider({ value: night.strength, onInput: n => strengthOut.textContent = n + "%",
        onChange: n => wos.call("displays.nightlight.set", { strength: n }).catch(er => toast(er.message)) });
      strengthRange.style.flex = "1";
      const nightSwitch = switchOf(night.on === true, async v => { try { await wos.call("displays.nightlight.set", { on: v }); } catch (e) { toast(e.message); } });
      body.append(section("Night Light", h("div.card",
          rowOf("Night Light", "Warms the screen so it's easier on the eyes", nightSwitch),
          rowOf("Strength", "", h("div", { style: "display:flex;align-items:center;gap:10px" }, strengthRange, strengthOut)))));
      if (!list.length) { body.append(h("div.card.pad.muted", "No displays were found.")); return; }
      list.forEach(d => {
        const modes = dropdown(d.modes.map(m => [m, m]), { value: d.current, width: 180 });
        const scale = dropdown([1, 1.25, 1.5, 2].map(x => [x, Math.round(x * 100) + "%"]), { value: 1, width: 120 });
        const apply = h("button.btn.small", { onclick: async () => { try { await wos.call("displays.set", { name: d.name, mode: modes.value, scale: +scale.value }); toast("Applied"); } catch (e) { toast(e.message); } } }, "Apply");
        body.append(section(d.name + (d.primary ? " (main)" : ""), h("div.card", rowOf("Resolution", "", modes), rowOf("Scale", "Make everything bigger or smaller", scale)), h("div", { style: "margin-top:10px" }, apply)));
      });
    },
    async power() {
      const p = await wos.call("power.get"); const bat = await wos.call("power.battery");
      const mk = (cur, choices) => dropdown(choices, { value: cur, width: 160, onChange: save });
      const lock = mk(p.lock_min, [[0, "Never"], [2, "2 minutes"], [5, "5 minutes"], [10, "10 minutes"], [30, "30 minutes"]]);
      const off = mk(p.off_min, [[0, "Never"], [5, "5 minutes"], [10, "10 minutes"], [15, "15 minutes"], [30, "30 minutes"], [60, "1 hour"]]);
      async function save() { await wos.call("power.set", { lock_min: +lock.value, off_min: +off.value }); toast("Saved"); }
      const lowPower = switchOf(p.low_power === true, async v => { if (v) toast("Turning on…"); try { await wos.call("power.set", { low_power: v }); toast(v ? "Low Power Mode on" : "Low Power Mode off"); } catch (e) { toast(e.message); } });
      const left = bat && bat.minutes_left ? (bat.minutes_left >= 60 ? Math.floor(bat.minutes_left / 60) + " h " : "") + (bat.minutes_left % 60) + " min " + (bat.status === "Charging" ? "until full" : "left") : "";
      body.append(bat ? section("Battery", h("div.card",
          h("div.pad", { style: "display:flex;gap:14px;align-items:center;padding:18px" }, h("div", { style: "font-size:28px;font-weight:800" }, bat.pct + "%"),
            h("div", { style: "flex:1" }, h("div", bat.status), left ? h("div.small.muted", left + (bat.watts ? " · using " + bat.watts + " W" : "")) : null)),
          bat.health_pct != null ? rowOf("Battery health", bat.health_words || "", h("span.chip", bat.health_pct + "% of original" + (bat.cycles ? " · " + bat.cycles + " cycles" : ""))) : null)) : null,
        section("Low Power Mode", h("div.card", rowOf("Low Power Mode", "Trims background activity to stretch the battery further", lowPower))),
        section("Screen", h("div.card", rowOf("Lock the screen after", "When nothing is touched", lock), rowOf("Turn the screen off after", "Saves power", off))),
        h("p.muted.small", "Closing the lid locks the computer and puts it to sleep."));
    },
    async keyboard() {
      const v = await wos.call("input.get");
      const sw = key => { const b = h("button.switch" + (v[key] ? ".on" : ""), { onclick: async () => { v[key] = !v[key]; b.classList.toggle("on", v[key]); await wos.call("input.set", { [key]: v[key] }).catch(e => toast(e.message)); } }); return b; };
      const layout = dropdown((v.layouts || [["gb", "English (UK)"], ["us", "English (US)"]]), { value: v.layout, width: 200, onChange: async c => { try { await wos.call("input.layout.set", { layout: c }); toast("Layout changed"); } catch (e) { toast(e.message); } } });
      const speed = slider({ min: -100, max: 100, value: v.speed || 0, width: 180, onChange: val => wos.call("input.set", { speed: val }).then(() => toast("Saved")).catch(e => toast(e.message)) });
      const delay = dropdown((v.delays || [400]).map(d => [d, d <= 200 ? "Short" : d <= 400 ? "Medium" : d <= 600 ? "Long" : "Longest"]), { value: v.repeat_delay, width: 140, onChange: x => wos.call("input.set", { repeat_delay: +x }).then(() => toast("Saved")).catch(e => toast(e.message)) });
      const rate = dropdown((v.rates || [25]).map(r => [r, r <= 10 ? "Slow" : r <= 15 ? "Relaxed" : r <= 25 ? "Medium" : r <= 35 ? "Fast" : "Fastest"]), { value: v.repeat_rate, width: 140, onChange: x => wos.call("input.set", { repeat_rate: +x }).then(() => toast("Saved")).catch(e => toast(e.message)) });
      const shortcuts = [
        ["Super + Space", "Open Apps (the launcher and search)"],
        ["Super + Left / Right", "Snap the window to a half of the screen"],
        ["Super + Up / Down", "Maximise / restore the window"],
        ["Super + V", "Clipboard history"],
        ["Super + L  or  Ctrl + Alt + L", "Lock the screen"],
        ["Super + E", "Open Files"],
        ["Super + I", "Open Settings"],
        ["Ctrl + Shift + Esc", "Open Monitor (force quit a stuck program)"],
        ["Ctrl + Alt + Left / Right", "Switch desktop (also Super + Ctrl + Left / Right)"],
        ["Ctrl + Alt + Shift + Left / Right", "Move the window to the next or previous desktop"],
        ["Alt + Tab", "Switch between open windows"],
        ["Alt + F4", "Close the window"],
        ["Alt + F9 / F10", "Hide / maximise the window"],
        ["Print", "Screenshot the whole screen"],
        ["Super + Shift + S", "Screenshot an area"],
      ];
      body.append(section("Keyboard", h("div.card", rowOf("Layout", "The letters on your keys", layout), rowOf("Key repeat delay", "How long to hold a key before it repeats", delay), rowOf("Key repeat rate", "How fast it repeats once it starts", rate))),
        section("Mouse and trackpad", h("div.card", rowOf("Pointer speed", "Slower on the left, faster on the right", speed), rowOf("Tap to click", "Tap the pad instead of pressing", sw("tap")), rowOf("Natural scrolling", "Content follows your fingers", sw("natural")))),
        section("Keyboard shortcuts", h("div.card", shortcuts.map(([keys, what]) =>
          h("div.row", { style: "cursor:default;min-height:44px" }, h("div.grow", what), h("kbd.shortcut", keys))))));
    },
    async printers() {
      const r = await wos.call("printers.list");
      const pretty = n => n.replace(/_/g, " ");
      const run = async (label, call, args, done) => { try { await wos.call(call, args); toast(label); if (done) done(); } catch (e) { toast(e.message); } };
      const rows = r.printers.map(p => h("div.row", { style: "cursor:default" },
        h("div.grow", h("div.t", pretty(p.name)), h("div.s", p.state === "idle" ? "Ready" : p.state === "disabled" ? "Turned off" : "Busy")),
        p.name === r.default ? h("span.chip", "Default") : h("button.btn.ghost.small", { onclick: () => run("Default printer changed", "printers.default", { name: p.name }, draw) }, "Make default"),
        h("button.btn.ghost.small", { onclick: () => run("Test page sent", "printers.test", { name: p.name }) }, "Test page"),
        h("button.icon-btn", { title: "Remove", html: icon("trash"), onclick: async () => { if (await confirmBox(`Remove “${pretty(p.name)}”?`, "You can add it again later.", "Remove", true)) run("Printer removed", "printers.remove", { name: p.name }, draw); } })));
      body.append(section("Printers", h("div.card", h("div.list", rows.length ? rows : h("div.row.muted", { style: "cursor:default" }, "No printers yet. Add one to print on paper."))), h("div", { style: "margin-top:10px" },
        h("button.btn.small", { onclick: addPrinter }, h("span", { html: icon("plus", 14) }), "Add printer…"))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "Every app can also Save as PDF."));
      /* Add printer: look for printers on the network and plugged in, pick one. Most printers made in the last
         ten years need no driver; for anything else, type its address (for example ipp://192.168.1.50/ipp/print). */
      function addPrinter() {
        const found = h("div.list", h("div.row.muted", { style: "cursor:default" }, "Looking for printers…"));
        const address = h("input.field", { placeholder: "ipp://192.168.1.50/ipp/print", style: "flex:1" });
        const done = () => back.remove();
        const add = async (uri, name) => { done(); toast("Setting up the printer…"); try { await wos.call("printers.add", { uri, name }); toast("Printer added"); draw(); } catch (e) { toast(e.message); } };
        const scan = async () => {
          found.innerHTML = ""; found.append(h("div.row.muted", { style: "cursor:default" }, "Looking for printers…"));
          let devs = []; try { devs = await wos.call("printers.discover"); } catch (e) { found.innerHTML = ""; found.append(h("div.row.muted", { style: "cursor:default" }, e.message)); return; }
          found.innerHTML = "";
          const fresh = devs.filter(d => !d.added);
          if (!fresh.length) found.append(h("div.row.muted", { style: "cursor:default" }, devs.length ? "Every printer found is already added." : "No printers found. Check it is on and on the same network, or plugged in."));
          fresh.forEach(d => found.append(h("div.row", { style: "cursor:default" }, h("span", { html: icon("doc", 18) }), h("div.grow", h("div.t", d.name), h("div.s", d.kind === "usb" ? "Plugged in" : "On your network")),
            h("button.btn.small", { onclick: () => add(d.uri, d.name) }, "Add"))));
        };
        const back = h("div.modal-back", { onclick: e => { if (e.target === back) done(); } },
          h("div.modal", { style: "width:min(520px,92vw)" }, h("h2", "Add a printer"), h("div.card", { style: "max-height:40vh;overflow:auto" }, found),
            h("div", { style: "margin-top:14px" }, h("span.label", "Or type its address"), h("div", { style: "display:flex;gap:8px;margin-top:6px" }, address,
              h("button.btn.ghost", { onclick: () => { const v = address.value.trim(); if (v) add(v, ""); } }, "Add"))),
            h("div.actions", h("button.btn.ghost", { onclick: scan }, "Look again"), h("button.btn.ghost", { onclick: done }, "Close"))));
        document.body.append(back); scan();
      }
    },
    async users() {
      const list = await wos.call("users.list");
      const ask = async why => askPassword(why, "Your password");
      const rows = list.map(u => h("div.row", { style: "cursor:default" }, h("div.avatar", initials(u.full)), h("div.grow", h("div.t", u.full + (u.me ? " (you)" : "")), h("div.s", (u.admin ? "Administrator" : "Standard") + " · " + u.name)),
        h("button.btn.ghost.small", { onclick: async () => { const me = await ask("Enter your password"); if (me === null) return; const pw = await askPassword("New password for " + u.name, "At least 8 characters"); if (!pw) return;
          try { await wos.call("users.passwd", { username: u.name, password: pw, me_password: me }); toast("Password changed"); } catch (e) { toast(e.message); } } }, "Change password"),
        u.me ? null : h("button.icon-btn", { title: "Remove", html: icon("trash"), onclick: async () => { if (!await confirmBox("Remove " + u.full + "?", "Their account and files will be deleted.", "Remove", true)) return; const me = await ask("Enter your password"); if (me === null) return;
          try { await wos.call("users.del", { username: u.name, me_password: me }); draw(); } catch (e) { toast(e.message); } } })));
      body.append(section("People who use this computer", h("div.card", h("div.list", rows))),
        h("button.btn", { onclick: async () => { const name = await prompt2("Full name"); if (!name) return; const uname = await prompt2("User name", name.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20), "letters and numbers"); if (!uname) return;
          const pw = await askPassword("Password for " + name, "At least 8 characters"); if (!pw) return; const me = await askPassword("Enter your password to confirm", "Your password"); if (me === null) return;
          try { await wos.call("users.add", { username: uname, name, password: pw, admin: false, me_password: me }); toast("Account created"); draw(); } catch (e) { toast(e.message); } } }, h("span", { html: icon("plus", 14) }), "Add a person"));
      let items = []; try { items = await wos.call("login_items.list"); } catch (e) { items = []; }
      const itemSwitch = it => switchOf(it.enabled, async v => { try { await wos.call("login_items.set", { id: it.id, enabled: v }); } catch (e) { toast(e.message); } } );
      body.append(section("Open at Login", h("div.card", items.length ? items.map(it => rowOf(it.name, "", itemSwitch(it)))
        : h("div.row.muted", { style: "cursor:default" }, "Nothing starts automatically for you yet."))));
    },
    async datetime() {
      const cur = await wos.call("sys.tz.get"); const zones = await wos.call("sys.tz.list");
      const sel = dropdown(zones.map(z => [z, z.replace(/_/g, " ")]), { value: cur.zone, width: 260,
        onChange: async z => { try { await wos.call("sys.tz.set", { zone: z }); toast("Time zone changed"); } catch (er) { toast(er.message); } } });
      body.append(section("Time", h("div.card", rowOf("Time zone", cur.synced ? "Clock is set from the internet" : "Waiting for the internet to set the clock", sel))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "Renaming this computer is in Settings → About."));
    },
    async access() {
      const d = await wos.call("desktop.get");
      const viz = switchOf(d.music_viz === true, async v => { try { await wos.call("desktop.set", { key: "music_viz", value: v }); } catch (e) { toast(e.message); } });
      const setPref = (key, value, quiet) => wos.call("prefs.set", { key, value }).then(() => { acc[key] = value; if (key === "text_scale") window.__mockScale = value; applyPrefs(acc); if (!quiet) toast("Saved"); }).catch(e => toast(e.message));
      const sizes = dropdown([[100, "Default"], [115, "115%"], [130, "130%"], [150, "150%"], [175, "175%"], [200, "200%"]], { value: acc.text_scale || 100, width: 140, onChange: v => setPref("text_scale", +v) });
      const cursors = dropdown([[24, "Standard"], [32, "Large"], [48, "Larger"], [64, "Largest"]], { value: acc.cursor_size || 24, width: 140, onChange: v => setPref("cursor_size", +v) });
      const keySwitch = key => switchOf(!!acc[key], v => setPref(key, v, true));
      body.append(section("Vision", h("div.card", rowOf("Text size", "Makes text bigger in W-OS apps. In Firefox use Ctrl and +", sizes), rowOf("Pointer size", "A bigger mouse pointer that is easier to find", cursors),
          rowOf("Higher contrast", "Stronger borders and text", flag("contrast")))),
        section("Keyboard", h("div.card", rowOf("Sticky Keys", "Press Ctrl, Alt or Shift one key at a time instead of holding them", keySwitch("sticky")),
          rowOf("Slow Keys", "Ignore keys that are only brushed, not pressed on purpose", keySwitch("slow")), rowOf("Bounce Keys", "Ignore a key pressed twice by mistake", keySwitch("bounce")))),
        section("Motion and speech", h("div.card", rowOf("Reduce motion", "Fewer animations", flag("motion")), rowOf("Read aloud", "Speak text on screen. Select text, then press Alt + R", flag("speak")))),
        section("Music", h("div.card", rowOf("Music visualisation", "A glowing wave across the bottom of the screen that moves with whatever is playing", viz))),
        h("p.muted.small", "Pointer size and the keyboard helpers apply everywhere. The desktop bar and dock keep their size."));
    },
    async updates() {
      let st; try { st = await wos.call("updates.status"); } catch (e) { st = { version: info.version, history: [] }; }
      body.querySelector("h1.dots").style.display = "none";
      // The OS name and version, one status line, the newest update (if any) as one card, and a Roll back link.
      const head = h("div", { style: "display:flex;flex-direction:column;align-items:center;text-align:center;padding:10px 0 22px" });
      const list = h("div", { style: "margin-bottom:22px" });
      let checking = false, installing = false, lastChecked = null;
      const clock = d => d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
      const paint = (found, note) => {
        head.innerHTML = "";
        const ok = !found || !found.length;
        const status = checking ? "Checking for updates…" : installing ? "Installing…" : ok ? "W-OS is up to date" : found.length === 1 ? "An update is available" : found.length + " updates are available";
        head.append(h("h2", { style: "margin:0;font-size:22px;letter-spacing:-.01em" }, "W-OS 4 " + ((info.nickname || "Windermere"))), h("div.muted", { style: "margin-top:2px" }, "Version " + (st.version || info.version)),
          h("div", { style: "display:flex;align-items:center;gap:8px;margin-top:14px;font-weight:700" },
            h("span", { html: icon(checking || installing ? "refresh" : ok ? "check" : "download", 16), style: "color:" + (checking || installing ? "var(--muted)" : ok ? "var(--ok)" : "var(--accent)") }), status),
          h("div.small.muted", { style: "margin-top:4px" }, note ? note : lastChecked ? "Last checked: today at " + clock(lastChecked) : ""),
          h("button.btn.ghost.small", { style: "margin-top:12px", disabled: checking || installing, onclick: () => check() }, "Check for updates"));
        list.innerHTML = "";
        // Only the newest update is shown: what it is, what changed, one button.
        const vkey = v => String(v || "").split(".").map(n => parseInt(n, 10) || 0);
        const newest = (found || []).slice().sort((x, y) => { const p = vkey(x.version), q = vkey(y.version); for (let i = 0; i < 4; i++) { if ((p[i] || 0) !== (q[i] || 0)) return (q[i] || 0) - (p[i] || 0); } return 0; })[0];
        if (newest) {
          const u = newest;
          const bar = h("div", { style: "display:none;height:6px;border-radius:var(--r-pill);background:var(--panel-3);overflow:hidden;margin-top:18px" }, h("div", { style: "height:100%;width:40%;border-radius:var(--r-pill);background:var(--accent);animation:wos-slide 1.2s ease-in-out infinite" }));
          const go = h("button.btn", { style: "font-size:16px;padding:12px 34px", onclick: async () => { go.disabled = true; bar.style.display = "block"; await install(u); } }, "Update");
          list.append(h("div.card.pad", { style: "padding:28px;text-align:center" },
            h("div.small.muted", { style: "margin-bottom:6px" }, u.kind === "security" ? "Security update" : "New version"),
            h("div", { style: "font-weight:800;font-size:30px;letter-spacing:-.02em" }, "W-OS " + u.version),
            h("div", { style: "margin:14px auto 22px;max-width:520px;font-size:15px;line-height:1.5;white-space:pre-wrap;color:var(--ink-2)" }, u.notes || "Fixes and improvements."),
            u.action === "blocked" ? h("span.chip", "Needs activation") : go, bar));
        }
      };
      async function check(quiet) {
        checking = true; paint([], ""); if (quiet !== true) toast("Checking…");
        try { const r = await wos.call("updates.check"); checking = false; lastChecked = new Date(); paint(r.available, r.note); }
        catch (e) { checking = false; paint([], "Could not check: " + e.message); }
      }
      async function install(u) {
        installing = true;
        try { const r = await wos.call("updates.apply", { id: u.id }); installing = false; st.probation = true; st.version = r.version; paint([], ""); if (r.restart_needed && await confirmBox("Restart to finish?", "The update is installed. Restart now, or later when it suits you.", "Restart now")) wos.call("sys.restart"); }
        catch (e) { installing = false; toast(e.message); paint([], e.message); }
      }
      paint([], st.configured === false ? "No update service is configured yet" : "");
      if (st.configured !== false) check(true);            // look straight away: opening this page should not say "up to date" without asking
      const notice = st.probation ? h("div.card", { style: "margin-bottom:12px" }, rowOf("Restart to finish the last update", "W-OS confirms an update after one restart. Then the next one can be installed.",
        h("button.btn.small", { onclick: async () => { if (await confirmBox("Restart now?", "Save your work first. W-OS restarts and finishes the update.", "Restart")) wos.call("sys.restart").catch(e => toast(e.message)); } }, "Restart"))) : null;
      const beta = st.beta_available ? switchOf(st.beta === true, async v => {
        if (v && !await confirmBox("Turn on Beta updates?", "Beta updates try new things before they reach everyone else. They can be rougher around the edges and are not meant for a computer you depend on.", "Turn on")) { draw(); return; }
        try { await wos.call("updates.set_beta", { on: v }); st.beta = v; toast(v ? "Beta updates on" : "Beta updates off"); check(true); } catch (e) { toast(e.message); draw(); }
      }) : null;
      const last = (st.history || [])[0];
      const rollback = last && last.rollback_available ? h("div", { style: "text-align:center;margin:6px 0 14px" }, h("button.btn.ghost.small", { onclick: async () => { if (!await confirmBox("Roll back this update?", "The previous version comes back after a restart.", "Roll back")) return; try { await wos.call("updates.rollback"); toast("Rolled back. Restart to finish."); draw(); } catch (e) { toast(e.message); } } }, "Roll back the last update")) : "";
      body.append(head, notice || "", list,
        section("Automatic updates", h("div.card", rowOf("Security updates", "Security fixes for the system install by themselves", h("span.chip", "On")),
          beta ? rowOf("Beta updates", "Try new things early, on a separate track from the update everyone else gets", beta) : "")),
        // Developer/Satisfaction don't belong mixed into the everyday app grid alongside Mail
        // and Photos -- one clear entry point here instead, and only once Beta is actually on.
        st.beta === true ? section("Beta features", h("div.card",
          rowOf("Developer", "Write, run and install apps in Satisfaction, W-OS's own trial language", h("button.btn.ghost.small", { onclick: () => wos.call("sys.launch", { id: "wos-developer.desktop" }).catch(e => toast(e.message)) }, "Open")),
          rowOf("Satisfaction Counter", "A small demo app written in Satisfaction", h("button.btn.ghost.small", { onclick: () => wos.call("sys.launch", { id: "wos-satisfaction-demo.desktop" }).catch(e => toast(e.message)) }, "Open")))) : "",
        rollback,
        h("p.muted.small", "Other updates wait for you. Security updates cannot be rolled back."));
    },
    async desktop() {
      const d = await wos.call("desktop.get");
      const save = (k, v) => { d[k] = v; wos.call("desktop.set", { key: k, value: v }).catch(e => toast(e.message)); };
      let walls = []; try { walls = await wos.call("desktop.wallpapers"); } catch (e) { walls = []; }
      // Grouped by category, the way both macOS's and Windows' own wallpaper pickers show them --
      // not one flat grid. "Your Photos" (from the Pictures folder) always sorts last, since it's
      // personal content rather than part of the collection.
      const wallSections = h("div");
      const drawWalls = () => {
        wallSections.innerHTML = "";
        const order = [], byCat = new Map();
        walls.forEach(w => { const c = w.category || "Wallpapers"; if (!byCat.has(c)) { byCat.set(c, []); order.push(c); } byCat.get(c).push(w); });
        order.sort((a, b) => (a === "Your Photos" ? 1 : 0) - (b === "Your Photos" ? 1 : 0));
        order.forEach(cat => {
          const grid = h("div", { style: "display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:12px;padding:16px" });
          byCat.get(cat).forEach(w => grid.append(h("button.wall" + (d.wallpaper === w.id ? ".on" : ""), { title: w.name, onclick: () => { save("wallpaper", w.id); drawWalls(); } },
            h("div.wall-img", { style: `background-image:url("${w.uri}")` }), h("div.wall-name", w.name))));
          wallSections.append(section(cat, h("div.card", grid)));
        });
      };
      drawWalls();
      const cornerChoices = [["none", "—"], ["desktop", "Show Desktop"], ["lock", "Lock Screen"], ["launcher", "Open Apps"]];
      const dockAlign = rowOf("Icons", "Where the icons sit in the Full dock", seg([["center", "Centre"], ["left", "Left"]], d.dock_align || "center", v => save("dock_align", v)));
      dockAlign.style.display = d.dock_style === "full" ? "" : "none";
      const cornerSel = key => dropdown(cornerChoices, { value: d[key] || "none", width: 160, onChange: v => save(key, v) });
      body.append(wallSections,
        section("Dock", h("div.card",
          ...(d.new_dock ? [
            rowOf("Style", "How an app you open reaches the middle of the dock", dropdown([["join", "Join"], ["morph", "Morph"]],
              { value: d.shelf_style || "join", width: 190, onChange: v => { save("shelf_style", v); toast("Dock style saved"); } })),
            rowOf("Background", "Put the dock on a panel. Off, the icons float on the desktop.", switchOf(d.shelf_background === true, v => save("shelf_background", v)))
          ] : [
            rowOf("New dock", "The new W-OS dock is off on this computer. Turn it on and log in again.", h("button.btn.small", { onclick: async () => { await wos.call("desktop.set", { key: "new_dock", value: true }); toast("Log out and in to use the new dock"); } }, "Turn on")),
            rowOf("Style", "Default and Bubbled float; Full is an edge-to-edge bar like the Windows 11 taskbar", dropdown([["default", "Default"], ["full", "Full"], ["bubbled", "Bubbled"], ["condensed", "Bubbled condensed"]],
              { value: d.dock_style || "default", width: 190, onChange: v => { save("dock_style", v); dockAlign.style.display = v === "full" ? "" : "none"; } })),
            dockAlign
          ]),
          rowOf("Size", "How big the icons in the dock are", seg([["small", "Small"], ["medium", "Medium"], ["large", "Large"]], d.dock, v => save("dock", v))),
          rowOf("Auto-hide in full screen", "Hide the menu bar and dock while an app is full screen", switchOf(d.autohide_fullscreen === true, v => save("autohide_fullscreen", v))))),
        section("Hot corners", h("div.card",
          rowOf("Top-left", "Drag the pointer into this corner of the screen", cornerSel("corner_tl")),
          rowOf("Top-right", "Drag the pointer into this corner of the screen", cornerSel("corner_tr")),
          rowOf("Bottom-left", "Drag the pointer into this corner of the screen", cornerSel("corner_bl")),
          rowOf("Bottom-right", "Drag the pointer into this corner of the screen", cornerSel("corner_br")))),
        section("Desktop", h("div.card",
          rowOf("Show files on the desktop", "Anything in your Desktop folder", switchOf(d.desk_icons !== false, v => save("desk_icons", v))),
          rowOf("Show the Bin on the desktop", "", switchOf(d.desk_bin !== false, v => save("desk_bin", v))),
          rowOf("Show widgets", "Clock, calendar, notes and more. Right-click the desktop to add or change them", switchOf(d.desk_widgets !== false, v => save("desk_widgets", v))))),
        section("Menu bar", h("div.card",
          rowOf("24-hour clock", "", switchOf(d.clock24, v => save("clock24", v))),
          rowOf("Show seconds", "", switchOf(d.seconds, v => save("seconds", v))),
          rowOf("Show the date", "", switchOf(d.date, v => save("date", v))),
          rowOf("Show battery percentage", "On laptops", switchOf(d.battery, v => save("battery", v))))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "Put your own pictures in the Pictures folder and they appear under Wallpaper."));
    },
    async notifications() {
      let dnd = false; try { dnd = await wos.call("dnd.get"); } catch (e) { /* not available */ }
      let apps = []; try { apps = await wos.call("notif.apps"); } catch (e) { /* not available */ }
      const ago = ts => { if (!ts) return "No recent notifications"; const m = Math.round((Date.now() / 1000 - ts) / 60); return "Last " + (m < 2 ? "just now" : m < 60 ? m + " minutes ago" : m < 1440 ? Math.round(m / 60) + " hours ago" : Math.round(m / 1440) + " days ago"); };
      const list = h("div.card");
      if (!apps.length) list.append(h("div.muted", { style: "padding:22px;text-align:center" }, "Apps that send you notifications will appear here."));
      apps.forEach(a => list.append(rowOf(a.name, (a.count ? a.count + (a.count === 1 ? " notification · " : " notifications · ") : "") + ago(a.last),
        switchOf(!a.muted, on => wos.call("notif.mute", { app: a.name, muted: !on }).catch(e => toast(e.message))))));
      let focus = { on: false, from: "22:00", to: "07:00" }; try { focus = await wos.call("focus.get"); } catch (e) { /* older image */ }
      const saveFocus = patch => wos.call("focus.set", patch).then(f => { focus = f; toast("Saved"); }).catch(e => toast(e.message));
      const fromPick = timePicker({ value: focus.from, onChange: v => saveFocus({ from: v }) }), toPick = timePicker({ value: focus.to, onChange: v => saveFocus({ to: v }) });
      body.append(section("Focus", h("div.card", rowOf("Do Not Disturb", "Hide notification banners until you turn this off", switchOf(dnd, v => wos.call("dnd.set", { value: v }).catch(e => toast(e.message)))),
          rowOf("Quiet hours", "Turn Do Not Disturb on by itself between these times, every day", switchOf(!!focus.on, v => saveFocus({ on: v }))),
          h("div.row", { style: "cursor:default;min-height:56px" }, h("div.grow", h("div.t", "From and to"), h("div.s", "You can still switch Do Not Disturb by hand at any time")), h("span", { style: "display:flex;gap:8px;align-items:center" }, fromPick, h("span.muted", "to"), toPick)))),
        section("Apps", list),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "Turn an app off to stop its banners. Its notifications are still kept in the date panel (click the clock)."));
    },
    async privacy() {
      let p = { share: false }; try { p = await wos.call("privacy.get"); } catch (e) { /* default */ }
      let fw = false; try { fw = await wos.call("firewall.status"); } catch (e) { /* unknown */ }
      body.append(section("Data", h("div.card",
          rowOf("Share crash and usage information", "Helps us fix problems. Nothing personal, no files, no browsing.", switchOf(!!p.share, v => wos.call("privacy.set", { value: v }).catch(e => toast(e.message)))),
          rowOf("Feedback you write", "Only sent when you press Send in the feedback app.", h("span.chip", "Always your choice")))),
        section("Security", h("div.card",
          rowOf("Firewall", "Blocks connections you did not ask for. Leave this on unless a technician asks you to turn it off.", switchOf(!!fw, async on => {
            if (!on && !await confirmBox("Turn the firewall off?", "Other computers on the network will be able to try to connect to this one.", "Turn off", true)) { draw(); return; }
            try { await wos.call("firewall.set", { on }); toast(on ? "Firewall on" : "Firewall off"); } catch (e) { toast(e.message); draw(); } })),
          rowOf("Screen lock", "Your password is needed to unlock. Set when it locks in Power.", h("button.btn.ghost.small", { onclick: () => { page = "power"; draw(); } }, "Open Power")),
          rowOf("App access", "W-OS apps can only reach your own folders, nothing else on the computer.", h("span.chip", "Home folder only")),
          rowOf("Location", "No app uses your location.", h("span.chip", "Not used")))));
    },
    async storage() {
      const u = await wos.call("storage.usage");
      const colours = ["#0a84ff", "#30b04f", "#ff9f0a", "#bf5af2", "#ff375f", "#5ac8fa", "#8e8e93"];
      const used = u.total - u.free; const parts = u.items.filter(i => i.bytes > 0);
      const other = Math.max(0, used - parts.reduce((t, i) => t + i.bytes, 0));
      const all = parts.concat(other > 0 ? [{ name: "System and apps", bytes: other }] : []);
      const bar = h("div.bar-stack", all.map((i, n) => h("div", { title: i.name, style: `width:${Math.max(0.5, i.bytes / u.total * 100)}%;background:${colours[n % colours.length]}` })));
      body.append(section("This computer", h("div.card.pad", h("div", { style: "display:flex;justify-content:space-between;margin-bottom:10px" }, h("span", { style: "font-weight:800" }, fmtBytes(used) + " used"), h("span.muted", fmtBytes(u.free) + " free of " + fmtBytes(u.total))), bar)),
        section("What is using it", h("div.card", all.map((i, n) => h("div.row", { style: "cursor:default;min-height:46px" }, h("span", { style: `width:12px;height:12px;border-radius:5px;background:${colours[n % colours.length]};flex:none` }), h("div.grow", h("div.t", i.name)), h("span.muted", fmtBytes(i.bytes)))))),
        u.bin > 0 ? section("Bin", h("div.card", rowOf("Empty the Bin", fmtBytes(u.bin) + " you deleted from Files", h("button.btn.ghost.small", { onclick: async () => { if (await confirmBox("Empty the Bin?", "Everything in it is removed for good.", "Empty Bin", true)) { await wos.call("files.bin.empty"); toast("Bin emptied"); draw(); } } }, "Empty Bin")))) : null);
    },
    async defaults() {
      const d = await wos.call("defaults.get");
      const sel = dropdown(d.options.map(o => [o.id, o.name]), { value: d.browser, width: 240,
        onChange: id => wos.call("defaults.set", { browser: id }).then(() => toast("Default browser changed")).catch(x => toast(x.message)) });
      body.append(section("Web", h("div.card", rowOf("Web browser", "Opens links from mail and other apps", sel))),
        h("p.muted.small", { style: "margin:-12px 4px 0" }, "Install more browsers from the App Store and they appear here."));
    },
    async about() {
      const i = await wos.call("sys.info");
      const r = (a, b) => h("div.row", { style: "cursor:default" }, h("span.muted", { style: "width:140px" }, a), h("span", { style: "user-select:text;font-weight:700" }, String(b)));
      body.append(section("This device", h("div.card", r("Name", i.hostname), r("Model", i.device), r("Processor", i.cpu || "—"), r("Memory", i.memory_gb + " GB"), r("Storage", `${i.storage_gb} GB (${i.free_gb} GB free)`), r("Device ID", i.device_id))),
        section("Software", h("div.card", r("System", i.os), r("Release", `${i.nickname} · ${i.version}`), r("Version", i.build))),
        section("Computer name", h("div.card", h("div.row", { style: "cursor:default;min-height:56px" }, h("div.grow", h("div.t", "Name"), h("div.s", "Shown on your network and in Phone Sync")),
          (() => { const inp = h("input.field", { value: i.hostname, style: "width:190px" }); return h("div", { style: "display:flex;gap:8px;align-items:center" }, inp,
            h("button.btn.ghost.small", { onclick: async () => { try { await wos.call("sys.hostname.set", { name: inp.value.trim().toLowerCase() }); toast("Renamed. Applies after you restart."); } catch (e) { toast(e.message); } } }, "Rename")); })()))),
        h("div", { style: "margin-top:6px" }, h("button.btn.ghost.small", { onclick: showNotices }, "Open source notices")),
        section("Credits", h("div.card", r("Wallpaper", "Copyright: Harry Johnson Photography"), h("div.row.muted.small", { style: "cursor:default" }, "Windermere pink sky, from the Lake District National Park Authority free photos."))),
        h("p.muted.small", { style: "margin-top:14px" }, "William Graves Corp. Ltd. (c) 2020-2026 William Graves Operating Services"));
    },
  };

  async function showNotices() {
    const n = await wos.call("sys.notices");
    const rows = n.packages.slice(0, 1500).map(p => h("div.row", { style: "cursor:default;min-height:36px" }, h("div.grow", h("div.t", p.name), h("div.s", p.licence || "")), h("span.small.muted", p.version)));
    const close = () => back.remove();
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) close(); } }, h("div.modal", { style: "width:min(680px,94vw);max-height:84vh;display:flex;flex-direction:column" },
      h("h2", "Open source notices"), h("p.muted.small", { style: "white-space:pre-wrap;user-select:text" }, n.offer),
      h("div.card", { style: "overflow:auto;flex:1;margin-top:10px" }, h("div.list", rows)), h("div.actions", h("button.btn", { onclick: close }, "Close"))));
    document.body.append(back);
  }

  const wifiError = m => /secrets were required|password|802\.1x|authentication/i.test(m || "") ? "That password was not accepted" : (m && m.replace(/^Error: /, "")) || "Could not connect";
  async function connect(n) {
    if (n.active) return;
    if (n.enterprise && !n.saved) { joinOther({ ssid: n.ssid, enterprise: true }); return; }     // a school or work network needs a username too
    let password = "";
    // A network this computer already knows reconnects by itself: asking for the password again every time
    // is what made switching between two Wi-Fi networks so tedious.
    if (n.secure && !n.saved) { password = await askPassword(`Password for ${n.ssid}`, "Wi-Fi password"); if (password === null) return; }
    toast("Connecting…");
    let r = await wos.call("sys.wifi.connect", { ssid: n.ssid, password });
    if (!r.ok && n.saved && n.secure) {          // the saved password has probably changed: ask once, and replace it
      password = await askPassword(`Password for ${n.ssid}`, "The saved password did not work"); if (password === null) return;
      toast("Connecting…"); r = await wos.call("sys.wifi.connect", { ssid: n.ssid, password, replace: true });
    }
    toast(r.ok ? "Connected" : wifiError(r.message)); draw();
  }
  /* "Other network…": a hidden network, an open one, or a school/work (802.1X) network such as eduroam. */
  function joinOther(prefill = {}) {
    let kind = prefill.enterprise ? "enterprise" : "wpa", eap = "peap", skip = false;
    const ssid = h("input.field", { placeholder: "Network name", value: prefill.ssid || "" });
    const identity = h("input.field", { placeholder: "Username" });
    const password = h("input.field", { type: "password", placeholder: "Password" });
    const secSel = dropdown([["open", "None (open network)"], ["wpa", "Password"], ["enterprise", "Work or school (802.1X)"]], { value: kind, width: 260, onChange: v => { kind = v; sync(); } });
    const eapSel = dropdown([["peap", "PEAP"], ["ttls", "TTLS"]], { value: "peap", width: 120, onChange: v => { eap = v; } });
    const skipSw = switchOf(false, v => { skip = v; });
    const row = (label, control) => h("div.form-row", h("span.label", label), control);
    const idRow = row("Username", identity), pwRow = row("Password", password), eapRow = row("Method", eapSel);
    const skipRow = h("div.form-row", { style: "flex-direction:row;align-items:center;justify-content:space-between" }, h("span.label", "Skip the network's certificate check"), skipSw);
    function sync() { idRow.style.display = eapRow.style.display = skipRow.style.display = kind === "enterprise" ? "" : "none"; pwRow.style.display = kind === "open" ? "none" : ""; }
    sync();
    const done = () => back.remove();
    const submit = async () => {
      const name = ssid.value.trim();
      if (!name) { toast("Enter the network name"); return; }
      if (kind === "enterprise" && (!identity.value || !password.value)) { toast("Enter your username and password"); return; }
      done(); toast("Connecting…");
      try {
        const r = kind === "enterprise"
          ? await wos.call("sys.wifi.enterprise", { ssid: name, identity: identity.value, password: password.value, eap, skip_cert: skip })
          : await wos.call("sys.wifi.connect", { ssid: name, password: kind === "open" ? "" : password.value, hidden: !prefill.ssid });
        toast(r.ok ? "Connected" : wifiError(r.message)); draw();
      } catch (e) { toast(e.message); }
    };
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) done(); } },
      h("div.modal", h("h2", prefill.ssid ? `Join “${prefill.ssid}”` : "Join another network"),
        row("Name", ssid), row("Security", secSel), idRow, pwRow, eapRow, skipRow,
        h("div.actions", h("button.btn.ghost", { onclick: done }, "Cancel"), h("button.btn", { onclick: submit }, "Join"))));
    document.body.append(back); (prefill.ssid ? (kind === "enterprise" ? identity : password) : ssid).focus();
  }
  wos.on("theme", m => { theme = theme; });
  draw();
});
