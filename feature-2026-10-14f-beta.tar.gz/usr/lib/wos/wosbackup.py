"""Backups: dated snapshots of the person's files on an external drive, like Time Machine and File History.

Each backup is a plain folder tree named by date (browse it in Files, copy files out). Files that did not change since
the last backup are hard-linked, so a snapshot costs only what changed, where the drive allows hard links; on drives
that do not (exFAT, FAT, some NTFS setups) they are copied instead. Standard library only, no rsync needed.
"""
import datetime
import errno
import json
import os
import re
import shutil
import socket

FOLDER = "W-OS Backup"
SNAP_RE = re.compile(r"^\d{4}-\d\d-\d\d_\d{6}$")
EXCLUDE = (".cache", ".local/share/Trash", ".local/share/wos/clipboard-history.json", ".local/share/wos/backup-state.json", ".local/share/wos/backup.lock",
           ".thumbnails", ".mozilla/firefox/Crash Reports")
MIN_FREE_BYTES = 200 * 1024 * 1024
ROOTS = ("/media/", "/run/media/", "/mnt/")


class BackupError(Exception):
    """Message safe to show to the person."""


def snapshot_name(now):
    return now.strftime("%Y-%m-%d_%H%M%S")


def parse_snapshot(name):
    try:
        return datetime.datetime.strptime(name, "%Y-%m-%d_%H%M%S")
    except ValueError:
        return None


def machine_folder(user=None, host=None):
    user = user or os.environ.get("USER") or "user"
    host = host or socket.gethostname()
    return re.sub(r"[^A-Za-z0-9._-]", "_", "%s-%s" % (user, host))[:60]


def check_destination(path, home, roots=ROOTS):
    """A location on an external drive (under /media, /run/media or /mnt), not the computer's own disk and not inside
    the files being backed up."""
    path = os.path.realpath(str(path or ""))
    if not any(path.startswith(r) and len(path) > len(r) for r in roots):
        raise BackupError("Choose an external drive (a USB drive or another disk).")
    if not os.path.isdir(path):
        raise BackupError("That drive is not connected.")
    if path == home or path.startswith(home + os.sep):
        raise BackupError("The backup cannot go inside the files it is backing up.")
    if not os.access(path, os.W_OK):
        raise BackupError("This drive is read-only or you may not write to it.")
    return path


def snapshots_dir(dest, user=None, host=None):
    return os.path.join(dest, FOLDER, machine_folder(user, host))


def list_snapshots(base):
    try:
        names = [n for n in os.listdir(base) if SNAP_RE.match(n) and os.path.isdir(os.path.join(base, n))]
    except OSError:
        return []
    return sorted(names)


def excluded(rel):
    rel = rel.replace(os.sep, "/")
    return any(rel == e or rel.startswith(e + "/") for e in EXCLUDE)


def _same(a, b):
    try:
        sa, sb = os.lstat(a), os.lstat(b)
    except OSError:
        return False
    return sa.st_size == sb.st_size and int(sa.st_mtime) == int(sb.st_mtime)


def run_backup(src, base, now=None, progress=None, cancelled=None):
    """Back up src into base/<now>. Returns {name, files, copied, linked, bytes, skipped}. Raises BackupError."""
    now = now or datetime.datetime.now()
    name = snapshot_name(now)
    os.makedirs(base, exist_ok=True)
    if shutil.disk_usage(base).free < MIN_FREE_BYTES:
        raise BackupError("The drive is almost full. Free some space or choose another drive.")
    prev_names = list_snapshots(base)
    prev = os.path.join(base, prev_names[-1]) if prev_names else None
    partial = os.path.join(base, ".partial-" + name)
    final = os.path.join(base, name)
    if os.path.exists(final):
        raise BackupError("A backup was just made. Try again in a minute.")
    shutil.rmtree(partial, ignore_errors=True)
    stats = {"name": name, "files": 0, "copied": 0, "linked": 0, "bytes": 0, "skipped": []}
    can_link = prev is not None
    try:
        for root, dirs, files in os.walk(src, followlinks=False):
            rel_root = os.path.relpath(root, src)
            rel_root = "" if rel_root == "." else rel_root
            if cancelled and cancelled():
                raise BackupError("Backup cancelled.")
            dirs[:] = [d for d in dirs if not excluded(os.path.join(rel_root, d)) and not os.path.realpath(os.path.join(root, d)).startswith(os.path.realpath(base))]
            target_dir = os.path.join(partial, rel_root)
            os.makedirs(target_dir, exist_ok=True)
            for d in dirs:
                os.makedirs(os.path.join(target_dir, d), exist_ok=True)
            for f in files:
                rel = os.path.join(rel_root, f)
                if excluded(rel):
                    continue
                s, t = os.path.join(root, f), os.path.join(target_dir, f)
                try:
                    if os.path.islink(s):
                        os.symlink(os.readlink(s), t)
                        continue
                    if not os.path.isfile(s):
                        continue            # sockets, devices
                    old = os.path.join(prev, rel) if prev else None
                    if can_link and old and os.path.isfile(old) and not os.path.islink(old) and _same(s, old):
                        try:
                            os.link(old, t)
                            stats["linked"] += 1
                        except OSError as e:
                            if e.errno in (errno.EPERM, errno.EXDEV, errno.EMLINK, errno.ENOTSUP, errno.EOPNOTSUPP, errno.EACCES):
                                can_link = False        # this drive cannot hard-link: copy from now on
                            shutil.copy2(s, t)
                            stats["copied"] += 1
                            stats["bytes"] += os.path.getsize(s)
                    else:
                        shutil.copy2(s, t)
                        stats["copied"] += 1
                        stats["bytes"] += os.path.getsize(s)
                    stats["files"] += 1
                    if progress and stats["files"] % 200 == 0:
                        progress(stats)
                except OSError as e:
                    if e.errno == errno.ENOSPC:
                        raise BackupError("The drive filled up. Free some space or choose a bigger drive.")
                    stats["skipped"].append(rel)       # a file that vanished or cannot be read must not stop the whole backup
        os.rename(partial, final)
    except BaseException:
        shutil.rmtree(partial, ignore_errors=True)
        raise
    if progress:
        progress(stats)
    return stats


def plan_prune(names, now):
    """Which snapshot names to delete. Keep: everything from the last 24 hours, one a day for 30 days, one a week after
    that, and always the newest. Pure."""
    stamps = [(parse_snapshot(n), n) for n in names]
    stamps = sorted((s, n) for s, n in stamps if s)
    if not stamps:
        return []
    keep = {stamps[-1][1]}
    seen = set()
    for s, n in reversed(stamps):           # newest first, so the newest of each day/week survives
        age = now - s
        if age <= datetime.timedelta(hours=24):
            keep.add(n)
            continue
        key = ("d", s.date()) if age <= datetime.timedelta(days=30) else ("w", s.isocalendar()[:2])
        if key not in seen:
            seen.add(key)
            keep.add(n)
    return [n for _, n in stamps if n not in keep]


def delete_snapshot(base, name):
    if not SNAP_RE.match(name):
        raise BackupError("That is not a backup.")
    shutil.rmtree(os.path.join(base, name), ignore_errors=True)


def browse(base, name, rel=""):
    """Entries of a folder inside a snapshot: [{name, dir, size}]. Refuses to leave the snapshot."""
    root = os.path.realpath(os.path.join(base, name)) if SNAP_RE.match(name) else None
    if not root:
        raise BackupError("That is not a backup.")
    path = os.path.realpath(os.path.join(root, rel.strip("/")))
    if path != root and not path.startswith(root + os.sep):
        raise BackupError("That is outside the backup.")
    out = []
    try:
        for e in sorted(os.scandir(path), key=lambda e: (not e.is_dir(follow_symlinks=False), e.name.lower())):
            out.append({"name": e.name, "dir": e.is_dir(follow_symlinks=False), "size": 0 if e.is_dir(follow_symlinks=False) else e.stat(follow_symlinks=False).st_size})
    except OSError:
        raise BackupError("Could not read that folder.")
    return out


def unique(path):
    if not os.path.exists(path):
        return path
    stem, ext = os.path.splitext(path)
    n = 2
    while os.path.exists("%s (%d)%s" % (stem, n, ext)):
        n += 1
    return "%s (%d)%s" % (stem, n, ext)


def restore(base, name, rel, dest_dir):
    """Copy a file or folder out of a snapshot into dest_dir (never over existing files). Returns the new path."""
    root = os.path.realpath(os.path.join(base, name)) if SNAP_RE.match(name) else None
    if not root or not rel.strip("/"):
        raise BackupError("Choose something to restore.")
    src = os.path.realpath(os.path.join(root, rel.strip("/")))
    if not src.startswith(root + os.sep) or not os.path.exists(src):
        raise BackupError("That is not in the backup.")
    os.makedirs(dest_dir, exist_ok=True)
    target = unique(os.path.join(dest_dir, os.path.basename(src)))
    if os.path.isdir(src):
        shutil.copytree(src, target, symlinks=True)
    else:
        shutil.copy2(src, target)
    return target


def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f)
    os.replace(tmp, path)


def due(config, state, now_ts, interval=86400):
    """Should an automatic backup start now? config: {dest, auto}. state: {running, last_success}."""
    if not config.get("auto") or not config.get("dest") or state.get("running"):
        return False
    return now_ts - float(state.get("last_success") or 0) >= interval
