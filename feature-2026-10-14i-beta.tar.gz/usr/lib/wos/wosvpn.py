"""VPN support through NetworkManager: parse the connection list and vet configuration files before importing.

Pure functions (tested anywhere). A VPN file is vetted because OpenVPN and WireGuard configs can name commands to run
as root when the tunnel comes up (`up`, `PostUp`, ...); a file from the internet must never be able to do that.
"""
import re

UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
MAX_BYTES = 256 * 1024

# directives that make a config run programs or load code
OPENVPN_BLOCKED = ("up", "down", "route-up", "route-pre-down", "ipchange", "tls-verify", "auth-user-pass-verify", "client-connect",
                   "client-disconnect", "learn-address", "plugin", "script-security", "setenv-safe", "management", "log", "log-append",
                   "writepid", "config", "cd", "chroot", "daemon")
WIREGUARD_BLOCKED = ("preup", "postup", "predown", "postdown", "saveconfig")


class VpnError(Exception):
    """Message safe to show to the person."""


def split_terse(line):
    """nmcli -t output: fields separated by ':' with literal colons written '\\:'."""
    return [p.replace("\\:", ":").replace("\\\\", "\\") for p in re.split(r"(?<!\\):", line)]


def parse_connections(out):
    """`nmcli -t -f NAME,UUID,TYPE,ACTIVE connection show` -> [{name, uuid, kind, active}] for VPNs only."""
    rows = []
    for line in out.splitlines():
        f = split_terse(line)
        if len(f) < 4:
            continue
        name, uuid, kind, active = f[0], f[1], f[2], f[3]
        if kind not in ("vpn", "wireguard") or not UUID_RE.match(uuid):
            continue
        rows.append({"name": name, "uuid": uuid, "kind": "WireGuard" if kind == "wireguard" else "VPN", "active": active == "yes"})
    return sorted(rows, key=lambda r: r["name"].lower())


def kind_for(filename):
    low = str(filename).lower()
    if low.endswith(".ovpn"):
        return "openvpn"
    if low.endswith(".conf"):
        return "wireguard"
    raise VpnError("Choose an .ovpn (OpenVPN) or .conf (WireGuard) file from your VPN provider.")


def vet_config(text, kind):
    """Raise VpnError unless the file looks like a plain, safe VPN profile."""
    if len(text) > MAX_BYTES:
        raise VpnError("That file is too big to be a VPN profile.")
    if "\x00" in text:
        raise VpnError("That does not look like a VPN profile.")
    if kind == "openvpn":
        if not re.search(r"(?im)^\s*remote\s+\S+", text):
            raise VpnError("That file does not name a VPN server.")
        for line in text.splitlines():
            word = line.strip().split(None, 1)[0].lower() if line.strip() and not line.strip().startswith(("#", ";")) else ""
            if word in OPENVPN_BLOCKED:
                raise VpnError("This profile asks to run programs (%s), which W-OS does not allow. Ask your provider for a plain profile." % word)
    elif kind == "wireguard":
        if "[interface]" not in text.lower() or "privatekey" not in text.lower().replace(" ", ""):
            raise VpnError("That does not look like a WireGuard profile.")
        for line in text.splitlines():
            key = line.split("=", 1)[0].strip().lower()
            if key in WIREGUARD_BLOCKED:
                raise VpnError("This profile asks to run programs (%s), which W-OS does not allow. Ask your provider for a plain profile." % line.split("=", 1)[0].strip())
    else:
        raise VpnError("Unknown VPN type.")
    return True


def clean_name(filename, kind="openvpn"):
    """A connection name from the file name. WireGuard names become network interface names: letters, digits, - and _, 15 at most."""
    stem = re.sub(r"\.(ovpn|conf)$", "", str(filename), flags=re.I)
    if kind == "wireguard":
        stem = re.sub(r"[^A-Za-z0-9_-]+", "-", stem).strip("-")[:15].strip("-")
    else:
        stem = re.sub(r"[^A-Za-z0-9 ._-]", "", stem).strip()[:40]
    return stem or "vpn"


def check_uuid(value):
    if not UUID_RE.match(str(value or "")):
        raise VpnError("That is not a VPN connection.")
    return str(value)
