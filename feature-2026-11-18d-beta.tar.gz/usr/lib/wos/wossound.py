"""Sound devices and per-app volumes from `pactl` (PulseAudio / PipeWire): parsing and the commands to change them. Pure, tested anywhere."""
import re

ID_RE = re.compile(r"^\d{1,6}$")
NAME_RE = re.compile(r"^[A-Za-z0-9_.:+-]{1,200}$")


def parse_blocks(text, header):
    """`pactl list <kind>` text -> [{'id': '52', fields..., 'props': {...}}]. header is 'Sink Input', 'Source', ..."""
    blocks, cur, in_props = [], None, False
    for raw in text.splitlines():
        m = re.match(r"^%s #(\d+)\s*$" % re.escape(header), raw)
        if m:
            cur = {"id": m.group(1), "props": {}}
            blocks.append(cur)
            in_props = False
            continue
        if cur is None:
            continue
        if re.match(r"^\tProperties:\s*$", raw):
            in_props = True
            continue
        if in_props:
            pm = re.match(r'^\t\t([\w.\-]+) = "(.*)"\s*$', raw)
            if pm:
                cur["props"][pm.group(1)] = pm.group(2)
                continue
            if not raw.startswith("\t\t"):
                in_props = False
        km = re.match(r"^\t([A-Za-z][A-Za-z ]*): (.*)$", raw)
        if km and not in_props:
            cur[km.group(1).strip()] = km.group(2).strip()
    return blocks


def volume_percent(value):
    """'front-left: 39322 /  60% / -13.27 dB, front-right: ...' -> 60 (the loudest channel)."""
    pcts = [int(p) for p in re.findall(r"(\d+)%", value or "")]
    return max(pcts) if pcts else 0


def sources(text, default_name=""):
    """Microphones and other inputs, without the 'monitor of' entries that just echo a speaker."""
    out = []
    for b in parse_blocks(text, "Source"):
        if b.get("Monitor of Sink", "n/a") not in ("n/a", ""):
            continue
        out.append({"id": b["id"], "name": b.get("Name", ""), "label": b.get("Description", b.get("Name", "")), "volume": volume_percent(b.get("Volume")),
                    "muted": b.get("Mute") == "yes", "default": b.get("Name") == default_name})
    return out


def sinks(text, default_name=""):
    out = []
    for b in parse_blocks(text, "Sink"):
        out.append({"id": b["id"], "name": b.get("Name", ""), "label": b.get("Description", b.get("Name", "")), "volume": volume_percent(b.get("Volume")),
                    "muted": b.get("Mute") == "yes", "default": b.get("Name") == default_name})
    return out


def apps(text):
    """Programs currently playing sound, each with its own volume."""
    out = []
    for b in parse_blocks(text, "Sink Input"):
        p = b["props"]
        name = p.get("application.name") or p.get("media.name") or "Sound"
        out.append({"id": b["id"], "name": name[:60], "icon": p.get("application.icon_name", ""), "volume": volume_percent(b.get("Volume")), "muted": b.get("Mute") == "yes"})
    return out


def check_id(value):
    if not ID_RE.match(str(value)):
        raise ValueError("Bad request")
    return str(value)


def check_name(value):
    if not NAME_RE.match(str(value)):
        raise ValueError("Bad request")
    return str(value)


def clamp_percent(value):
    try:
        return max(0, min(150, int(value)))
    except (TypeError, ValueError):
        raise ValueError("Bad request")


def set_volume_command(kind, ident, percent):
    """kind: 'app' (a playing program), 'input' (a microphone) or 'output'."""
    verb = {"app": "set-sink-input-volume", "input": "set-source-volume", "output": "set-sink-volume"}.get(kind)
    if not verb:
        raise ValueError("Bad request")
    target = check_id(ident) if kind == "app" else check_name(ident)
    return ["pactl", verb, target, "%d%%" % clamp_percent(percent)]


def set_mute_command(kind, ident, muted):
    verb = {"app": "set-sink-input-mute", "input": "set-source-mute", "output": "set-sink-mute"}.get(kind)
    if not verb:
        raise ValueError("Bad request")
    target = check_id(ident) if kind == "app" else check_name(ident)
    return ["pactl", verb, target, "1" if muted else "0"]
