"""Talk to W-Life (the W-Account service) for the Calendar and Notes apps: signed-in requests to a short allow-list of paths.

The session token is the one `account.signin` saved in ~/.config/wos/wlife.json; the apps never see it. Standard library only.
"""
import json
import os
import re
import urllib.error
import urllib.request

BASE = "https://api.wmail.life"
ID = r"[0-9A-Za-z-]{1,40}"
ALLOWED = (re.compile(r"^/api/v1/calendar/events(/%s)?(\?[A-Za-z0-9_=&%%:.+-]{0,200})?$" % ID),
           re.compile(r"^/api/v1/notes(/%s)?$" % ID))
METHODS = ("GET", "POST", "PUT", "DELETE")
MAX_BODY = 200_000


class LifeError(Exception):
    """Message safe to show to the person. .offline is True when W-Life could not be reached."""

    def __init__(self, message, offline=False, status=0):
        super().__init__(message)
        self.offline = offline
        self.status = status


def load_token(path):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        token = str(data.get("token") or "")
        return token if re.fullmatch(r"[A-Za-z0-9._~-]{8,400}", token) else ""
    except (OSError, ValueError, AttributeError):
        return ""


def check_request(method, path, body):
    if method not in METHODS:
        raise LifeError("That request is not allowed.")
    if not any(p.match(str(path)) for p in ALLOWED):
        raise LifeError("That request is not allowed.")
    if body is not None and len(json.dumps(body)) > MAX_BODY:
        raise LifeError("That is too big to sync.")


def call(token, method, path, body=None, base=BASE, timeout=15, opener=None):
    """One W-Life request. Returns the decoded JSON (or None for an empty reply). Raises LifeError."""
    check_request(method, path, body)
    if not token:
        raise LifeError("Sign in with your W-Account in Settings to sync.", status=401)
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(base + path, data=data, method=method,
                                 headers={"Cookie": "wmail_session=" + token, "Content-Type": "application/json", "Accept": "application/json"})
    try:
        with (opener or urllib.request.urlopen)(req, timeout=timeout) as r:
            raw = r.read(2_000_000)
    except urllib.error.HTTPError as e:
        if e.code == 401:
            raise LifeError("Your W-Account session ended. Sign in again in Settings.", status=401)
        try:
            msg = json.loads(e.read(5000)).get("message")
        except (ValueError, AttributeError, OSError):
            msg = None
        raise LifeError(msg or "W-Life said no (%d)." % e.code, status=e.code)
    except (urllib.error.URLError, OSError, TimeoutError):
        raise LifeError("Could not reach W-Life. Check your connection.", offline=True)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except ValueError:
        raise LifeError("W-Life sent something unexpected.")


def token_file():
    return os.path.join(os.path.expanduser("~"), ".config", "wos", "wlife.json")
