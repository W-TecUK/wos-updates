"use strict";
/* Developer: write, run, and install/update W-OS apps written in Satisfaction (.satif/.satUI).
   Laid out like an IDE on purpose -- a project navigator, tabbed editor with a breadcrumb, a
   console dock, and a right-hand inspector/docs rail -- because that's the vocabulary a
   Satisfaction developer already knows from Xcode and Android Studio, not something to
   reinvent. Always dark (see style.css): a code editor's own choice, independent of the
   system theme every other W-OS app follows.
   Installing/updating an app here never touches the OS update system -- it writes straight
   into the person's own home folder, the same way Flatpak apps already do. Beta-only, same
   as the language itself. */

boot(async () => {
  // Always dark, regardless of the system theme -- and stays that way even after the native
  // side's own theme message arrives (it always sends one, and would otherwise flip this back
  // to light on a light-mode system, since wos.js applies it unconditionally on every message).
  document.documentElement.dataset.theme = "dark";
  new MutationObserver(() => { if (document.documentElement.dataset.theme !== "dark") document.documentElement.dataset.theme = "dark"; })
    .observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
  const root = $("#root");

  const scheme = h("select.ide-scheme");
  const runBtn = h("button.ide-run", "▶ Run");
  const status = h("span.ide-status", "");
  const inspectBtn = h("button", { title: "Inspector", html: icon("gear") });
  const docsBtn = h("button", { title: "Language reference", html: icon("doc") });
  const panelPick = h("div.ide-panelpick", inspectBtn, docsBtn);
  const installBtn = h("button.icon-btn", { title: "Install / Update on this computer", html: icon("download") });
  const exportBtn = h("button.icon-btn", { title: "Export\u2026", html: icon("send") });
  const deleteBtn = h("button.icon-btn", { title: "Delete project", html: icon("trash") });
  const toolbar = h("div.ide-toolbar", scheme, runBtn, status, h("div", { style: "flex:1" }), installBtn, exportBtn, deleteBtn, panelPick);

  const nav = h("div.ide-nav");
  const tabs = h("div.ide-tabs");
  const breadcrumb = h("div.ide-breadcrumb");
  const gutter = h("div.ide-gutter");
  const textarea = h("textarea.ide-textarea", { spellcheck: "false" });
  const editArea = h("div.ide-edit-area", gutter, textarea);
  const consoleBar = h("div.ide-console-bar", h("span", "Console"));
  const consoleLog = h("div.ide-console-log");
  const consoleDock = h("div.ide-console", { "data-collapsed": "0" }, consoleBar, consoleLog);
  const editorCol = h("div.ide-editor-col", tabs, breadcrumb, editArea, consoleDock);
  const rail = h("div.ide-rail");
  const bodyEl = h("div.ide-body", nav, editorCol, rail);

  root.append(h("div.ide", toolbar, bodyEl));

  let projects = [];
  let currentId = null;
  let currentFile = "main.satif";
  let railMode = "inspector";
  let consoleCollapsed = false;
  const FILES = [["app.json", "app.json", "gear"], ["main.satif", "Logic", "edit"], ["main.satUI", "View", "grid"]];

  function log(text, kind) {
    const time = new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    consoleLog.append(h("div.ide-console-line" + (kind ? "." + kind : ""), h("span.t", time), text));
    consoleLog.scrollTop = consoleLog.scrollHeight;
  }

  consoleBar.addEventListener("click", () => {
    consoleCollapsed = !consoleCollapsed;
    consoleDock.dataset.collapsed = consoleCollapsed ? "1" : "0";
  });
  inspectBtn.addEventListener("click", () => { railMode = "inspector"; drawRail(); });
  docsBtn.addEventListener("click", () => { railMode = "docs"; drawRail(); });

  async function refresh() {
    projects = await wos.call("dev.list");
    scheme.innerHTML = "";
    if (!projects.length) scheme.append(h("option", { value: "" }, "No projects yet"));
    projects.forEach(p => scheme.append(h("option", { value: p.id, selected: p.id === currentId }, p.name + (p.installed ? " \u2022 Installed" : ""))));
  }
  scheme.addEventListener("change", () => selectProject(scheme.value));

  async function newProject() {
    const name = await prompt2("Name your app", "", "e.g. Tide Times");
    if (!name) return;
    try {
      const { id } = await wos.call("dev.create", { name });
      log("Created " + name, "ok");
      await refresh();
      selectProject(id);
    } catch (e) { log(e.message, "err"); toast(e.message); }
  }

  function selectProject(id) {
    currentId = id || null;
    currentFile = "main.satif";
    scheme.value = id || "";
    drawNav(); drawTabs(); drawRail();
  }

  function current() { return projects.find(p => p.id === currentId) || null; }

  function drawNav() {
    nav.innerHTML = "";
    nav.append(h("div.ide-nav-group", "Project"));
    const p = current();
    if (p) {
      FILES.forEach(([name, label, iconName]) => nav.append(h("button.ide-nav-item" + (currentFile === name ? ".on" : ""),
        { onclick: () => { currentFile = name; drawTabs(); } }, h("span", { html: icon(iconName) }), label)));
    } else {
      nav.append(h("div", { style: "padding:8px 16px;color:#6a6a72;font-size:12px" }, "No project open"));
    }
    nav.append(h("button.ide-new-project", { onclick: newProject }, h("span", { html: icon("plus", 14) }), "New project\u2026"));
  }

  function showEmptyEditor() {
    editArea.innerHTML = "";
    editArea.style.display = "grid";
    editArea.style.placeItems = "center";
    editArea.append(h("div.ide-empty", { style: "display:block" }, h("div.big", "No project open"),
      h("p", "Pick one from the toolbar, or create a new one."),
      h("button.btn", { onclick: newProject }, "New project\u2026")));
  }
  function showRealEditor() {
    editArea.innerHTML = "";
    editArea.style.display = "flex";
    editArea.style.placeItems = "";
    editArea.append(gutter, textarea);
  }

  async function drawTabs() {
    tabs.innerHTML = ""; breadcrumb.innerHTML = "";
    const p = current();
    if (!p) {
      showEmptyEditor();
      installBtn.disabled = exportBtn.disabled = deleteBtn.disabled = runBtn.disabled = true;
      return;
    }
    showRealEditor();
    installBtn.disabled = exportBtn.disabled = deleteBtn.disabled = runBtn.disabled = false;
    FILES.forEach(([name, label, iconName]) => tabs.append(h("button.ide-tab" + (currentFile === name ? ".on" : ""),
      { onclick: () => { currentFile = name; drawTabs(); } }, h("span", { html: icon(iconName, 13) }), label)));
    breadcrumb.append(h("b", p.name), " \u203a " + currentFile);
    const wantedFile = currentFile;
    let text = "";
    try { text = await wos.call("fs.read_text", { path: p.path + "/" + wantedFile }); } catch (e) { text = ""; }
    if (wantedFile !== currentFile) return;    // a stale load lost a race against a newer tab switch
    textarea.value = text;
    updateGutter();
    drawNav();
  }

  function updateGutter() {
    const n = Math.max(1, textarea.value.split("\n").length);
    gutter.innerHTML = "";
    for (let i = 1; i <= n; i++) gutter.append(h("div", String(i)));
  }
  textarea.addEventListener("scroll", () => { gutter.scrollTop = textarea.scrollTop; });
  const save = debounce(async () => {
    const p = current(); if (!p) return;
    try { await wos.call("fs.write_text", { path: p.path + "/" + currentFile, text: textarea.value }); status.textContent = "Saved " + currentFile; }
    catch (e) { log(e.message, "err"); }
  }, 500);
  textarea.addEventListener("input", () => { updateGutter(); status.textContent = "Saving\u2026"; save(); });

  runBtn.addEventListener("click", async () => {
    const p = current(); if (!p) return;
    try { await wos.call("dev.run", { path: p.path }); log("Running " + p.name, "ok"); }
    catch (e) { log("Could not run " + p.name + ": " + e.message, "err"); }
  });
  installBtn.addEventListener("click", async () => {
    const p = current(); if (!p) return;
    try { const r = await wos.call("dev.install", { path: p.path }); log(r.name + " installed. Find it in Apps.", "ok"); toast(r.name + " installed"); await refresh(); }
    catch (e) { log("Install failed: " + e.message, "err"); toast(e.message); }
  });
  exportBtn.addEventListener("click", async () => {
    const p = current(); if (!p) return;
    try { const r = await wos.call("dev.export", { path: p.path }); log("Exported to " + r.path, "ok"); toast("Exported to " + r.path); }
    catch (e) { log("Export failed: " + e.message, "err"); toast(e.message); }
  });
  deleteBtn.addEventListener("click", async () => {
    const p = current(); if (!p) return;
    if (!await confirmBox("Delete " + p.name + "?", "The project's files are deleted for good. Anything already installed on this computer is not affected.", "Delete", true)) return;
    try { await wos.call("dev.delete", { path: p.path }); log("Deleted " + p.name, ""); await refresh(); selectProject(projects[0] && projects[0].id); }
    catch (e) { toast(e.message); }
  });

  function drawRail() {
    inspectBtn.classList.toggle("on", railMode === "inspector");
    docsBtn.classList.toggle("on", railMode === "docs");
    rail.innerHTML = "";
    if (railMode === "docs") { drawDocs(); return; }
    const p = current();
    if (!p) { rail.append(h("h3", "Inspector"), h("p", { style: "color:#7a7a82;font-size:12.5px" }, "Open a project to see its settings.")); return; }
    rail.append(h("h3", "App settings"));
    const field = (label, key, kind) => {
      const inp = h("input", { value: String(p.manifest ? p.manifest[key] ?? "" : ""), type: kind || "text",
        onchange: async e => { await updateManifest(key, kind === "number" ? +e.target.value : e.target.value); } });
      return h("div.ide-field-row", h("label", label), inp);
    };
    wos.call("fs.read_text", { path: p.path + "/app.json" }).then(text => {
      try { p.manifest = JSON.parse(text); } catch (e) { p.manifest = {}; }
      rail.innerHTML = ""; rail.append(h("h3", "App settings"),
        field("Name", "name"), field("Width", "width", "number"), field("Height", "height", "number"),
        field("Min width", "min_width", "number"), field("Min height", "min_height", "number"),
        h("p", { style: "color:#5a5a62;font-size:11.5px;margin-top:8px" }, "Edits here save straight to app.json."));
    });
  }

  async function updateManifest(key, value) {
    const p = current(); if (!p) return;
    p.manifest[key] = value;
    try {
      await wos.call("fs.write_text", { path: p.path + "/app.json", text: JSON.stringify(p.manifest, null, 2) });
      if (currentFile === "app.json") { textarea.value = JSON.stringify(p.manifest, null, 2); updateGutter(); }
      log("Saved app.json", "ok");
      if (key === "name") await refresh();
    } catch (e) { log(e.message, "err"); }
  }

  function drawDocs() {
    const code = s => h("pre", s);
    rail.append(h("h3", "Language reference"), h("div.ide-docs",
      h("p", "What's actually supported today, not a wishlist. Full source: ",
        h("a", { href: "#", onclick: e => { e.preventDefault(); wos.call("sys.open_url", { url: "https://github.com/W-TecUK/satisfaction-lang" }); } }, "satisfaction-lang"), "."),
      h("h4", ".satif -- logic"),
      h("p", "Numbers, strings, booleans, ", h("code", "nil"), ", lists, functions. No optionals, no generics, no type annotations."),
      code("let name = \"World\"\nvar count = 0\n\nfunc greet(who) {\n    print(\"Hi, \\(who)!\")\n}\n\nif count > 0 { } else { }\nwhile count < 3 { count = count + 1 }\nfor item in [1, 2, 3] { print(item) }\n\nfunc double(x) { return x * 2 }"),
      h("p", h("b", "Operators: "), h("code", "+ - * / == != < <= > >=")),
      h("p", h("b", "Errors: "), "always plain English, e.g. ", h("code", "\"Line 7: Can't divide by zero.\"")),
      h("h4", ".satUI -- the view tree"),
      h("p", "Re-evaluated against live state on every ", h("code", "render()"), " -- never compiled once."),
      code("View {\n    Text(\"Count: \\(count)\")\n    HStack {\n        Button(\"Add one\") { bump() }\n        Spacer()\n    }\n}"),
      h("p", h("b", "Containers: "), h("code", "View, VStack, HStack, ZStack")),
      h("p", h("b", "Content: "), h("code", "Text(expr)"), ", ", h("code", "Button(label){...}"), ", ", h("code", "Spacer()")),
      h("p.gap", h("b", "Known gap: "), h("code", "ZStack"), " renders like ", h("code", "VStack"), " (no real overlay yet)."),
      h("h4", "Host builtins"),
      h("p", "Run/Install use ", h("code", "wos-sat-run"), ", which provides exactly two functions:"),
      h("p", h("code", "print(value)"), " -- to the system log only, not on screen."),
      h("p", h("code", "render()"), " -- redraws the view tree from current state."),
      h("p.gap", "That's all today: no files, no network, no ", h("code", "wos.call"), " bridge reachable from Satisfaction code yet."),
      h("h4", "Publishing"),
      h("p", "Install/Update copies the project into ", h("code", "~/.local/share/wos/apps"), " -- same place Flatpak installs into, same reason: no OS update, no signing key, no reboot. Running it again after changes replaces the old copy -- that's how an update ships."),
      h("p", "Export writes a plain ", h("code", ".satapp.tar.gz"), " to Downloads to hand to someone else.")));
  }

  await refresh();
  if (projects.length) selectProject(projects[0].id); else { drawNav(); drawTabs(); railMode = "docs"; drawRail(); }
  log("Ready.", "");
});
