"use strict";
/* Text: opens a plain text file (double-click one in Files) and saves as you type, so closing the window
   never loses anything. Opened without a file it is a blank page that asks for a name on the first save.
   Files with Windows line endings keep them; files that are not text are refused, never mangled. */

boot(async info => {
  const root = $("#root");
  const arg = (info.args || []).find(a => a.startsWith("/"));
  const MAX = 2000000;
  let path = arg || null, crlf = false, dirty = false, saving = false, timer = null, ready = !arg, failed = false;
  let size = +(await wos.data.get("size", 15)) || 15, wrap = (await wos.data.get("wrap", true)) !== false;

  const nameOf = () => path ? path.split("/").pop() : "Untitled";
  const title = h("h1", { style: "font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" }, nameOf());
  const state = h("span.chip", "Saved");
  const smaller = h("button.icon-btn", { title: "Smaller text", html: "<b style='font-size:12px'>A</b>", onclick: () => setSize(size - 1) });
  const bigger = h("button.icon-btn", { title: "Bigger text", html: "<b style='font-size:17px'>A</b>", onclick: () => setSize(size + 1) });
  const wrapBtn = h("button.btn.small.ghost", { style: "white-space:nowrap", onclick: () => { wrap = !wrap; wos.data.set("wrap", wrap); applyView(); } });
  const saveBtn = h("button.btn.small", { onclick: () => saveNow(true) }, "Save");
  const bar = h("div.bar", title, state, h("div.grow"), smaller, bigger, wrapBtn, saveBtn);
  const ta = h("textarea", { spellcheck: "false", disabled: !ready,
    style: "flex:1;width:100%;border:0;outline:0;resize:none;background:var(--panel);color:var(--ink);padding:18px 22px;user-select:text;tab-size:4" });
  const status = h("div.small.muted", { style: "padding:8px 18px;border-top:1px solid var(--line);display:flex;gap:16px;justify-content:space-between" });
  const left = h("span", { style: "overflow:hidden;text-overflow:ellipsis;white-space:nowrap" }), right = h("span", { style: "flex:none" });
  status.append(left, right);
  root.append(h("div.app.no-side", h("div.main", bar, ta, status)));

  function setSize(n) { size = Math.max(10, Math.min(32, n)); wos.data.set("size", size); applyView(); }
  function applyView() {
    ta.style.font = `${size}px/1.6 ui-monospace, "SF Mono", Menlo, Consolas, monospace`;
    ta.wrap = wrap ? "soft" : "off"; ta.style.whiteSpace = wrap ? "pre-wrap" : "pre"; ta.style.overflowX = wrap ? "hidden" : "auto";
    wrapBtn.textContent = wrap ? "Wrap: on" : "Wrap: off";
  }
  function stats() {
    const t = ta.value, words = (t.match(/\S+/g) || []).length;
    right.textContent = `${words} word${words === 1 ? "" : "s"}  ·  ${t ? t.split("\n").length : 0} line${t.split("\n").length === 1 ? "" : "s"}`;
    left.textContent = path ? path.replace(info.home, "~") : "Not saved yet";
  }
  function mark(text) { state.textContent = text; state.style.color = text === "Could not save" ? "#ff453a" : ""; }

  async function load() {
    if (!path) { ready = true; ta.disabled = false; ta.focus(); applyView(); stats(); return; }
    try {
      const text = await wos.call("fs.read_text", { path, limit: MAX + 1 });
      if (text.length > MAX) throw new Error("This file is too big to edit here (over 2 MB).");
      if (text.includes("\u0000") || (text.match(/�/g) || []).length > Math.max(8, text.length * 0.02)) throw new Error("This does not look like a text file, so it is not opened here.");
      const crlfCount = (text.match(/\r\n/g) || []).length;
      crlf = crlfCount > (text.match(/\n/g) || []).length - crlfCount;
      ta.value = crlf ? text.replace(/\r\n/g, "\n") : text;
      ready = true; ta.disabled = false; ta.focus(); ta.setSelectionRange(0, 0);
    } catch (e) {
      failed = true; ta.value = ""; ta.disabled = true; saveBtn.disabled = true; mark("Not opened");
      root.querySelector(".main").insertBefore(h("div.card.pad", { style: "margin:18px" }, h("div.t", { style: "font-weight:800" }, "Cannot open this file"), h("p.muted", e.message),
        h("button.btn.small.ghost", { onclick: () => wos.call("sys.launch", { id: "wos-files.desktop" }) }, "Open Files")), ta);
    }
    document.title = nameOf(); applyView(); stats();
  }

  async function pickName() {
    const raw = await prompt2("Name this document", "Untitled", "File name");
    if (!raw || !raw.trim()) return false;
    const name = raw.trim().replace(/[\/\0]/g, "-"); const withExt = /\.[A-Za-z0-9]{1,6}$/.test(name) ? name : name + ".txt";
    let folder = info.home; try { const places = await wos.call("fs.places"); const d = places.find(p => p.name === "Documents"); if (d) folder = d.path; } catch (e) { /* home is fine */ }
    try { path = await wos.call("fs.new_file", { parent: folder, name: withExt }); title.textContent = nameOf(); document.title = nameOf(); return true; }
    catch (e) { toast(e.message); return false; }
  }

  async function saveNow(explicit) {
    clearTimeout(timer);
    if (!ready || failed || saving || (!dirty && !explicit)) return;
    if (!path && !(await pickName())) { if (!path) { mark("Not saved"); return; } }
    saving = true; mark("Saving…");
    const text = crlf ? ta.value.replace(/\n/g, "\r\n") : ta.value;
    dirty = false;
    try { await wos.call("fs.write_text", { path, text }); mark("Saved"); }
    catch (e) { dirty = true; mark("Could not save"); toast(e.message); }
    saving = false; stats();
    if (dirty && !saving && state.textContent !== "Could not save") schedule();
  }
  function schedule() { clearTimeout(timer); timer = setTimeout(() => saveNow(false), 900); }

  ta.addEventListener("input", () => { if (!ready) return; dirty = true; mark("Edited"); stats(); schedule(); });
  ta.addEventListener("keydown", e => {
    if (e.key === "Tab") { e.preventDefault(); const s = ta.selectionStart; ta.setRangeText("\t", s, ta.selectionEnd, "end"); ta.dispatchEvent(new Event("input")); }
  });
  document.addEventListener("keydown", e => {
    const mod = e.ctrlKey || e.metaKey, k = e.key.toLowerCase();
    if (mod && k === "s") { e.preventDefault(); saveNow(true); }
    else if (mod && (k === "=" || k === "+")) { e.preventDefault(); setSize(size + 1); }
    else if (mod && k === "-") { e.preventDefault(); setSize(size - 1); }
  });
  window.addEventListener("blur", () => saveNow(false));
  document.addEventListener("visibilitychange", () => { if (document.hidden) saveNow(false); });
  wos.on("theme", () => {});

  applyView(); await load();
});
