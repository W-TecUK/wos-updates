"use strict";
/* Developer: build, run, and install W-OS apps written in Satisfaction (.satif/.satUI).
   Installing/updating an app here never touches the OS update system -- it writes straight
   into the person's own home folder, the same way Flatpak apps already do, so a new app or a
   new version of one is just a file copy, not an OS update. Beta-only, same as the language. */

boot(async () => {
  const root = $("#root");
  const nav = h("nav.nav");
  const body = h("div.body", { style: "max-width:760px;width:100%" });
  root.append(h("div.app", h("aside.side", h("div.side-title", "Developer"), nav), h("div.main", { style: "overflow:auto" },
    h("div", { style: "padding:22px;display:flex;justify-content:center" }, body))));

  const section = (title, ...kids) => h("div", { style: "margin-bottom:26px" }, h("span.label", { style: "display:block;margin:0 4px 10px" }, title), ...kids);
  const rowOf = (label, sub, control) => h("div.row", { style: "cursor:default;min-height:56px" }, h("div.grow", h("div.t", label), sub ? h("div.s", sub) : null), control);

  let projects = [];
  let page = "docs";

  async function refresh() { projects = await wos.call("dev.list"); }

  function drawNav() {
    nav.innerHTML = "";
    nav.append(h("button.row" + (page === "docs" ? ".on" : ""), { onclick: () => { page = "docs"; draw(); } },
      h("div.grow", h("div.t", "Language reference"))));
    nav.append(h("span.label", { style: "display:block;margin:16px 4px 6px" }, "Your projects"));
    projects.forEach(p => nav.append(h("button.row" + (page === p.id ? ".on" : ""), { onclick: () => { page = p.id; draw(); } },
      h("div.grow", h("div.t", p.name), p.installed ? h("div.s", "Installed") : null))));
    nav.append(h("button.row", { onclick: newProject }, h("div.grow", h("div.t", "+ New project"))));
  }

  async function newProject() {
    const name = await prompt2("Name your app", "", "e.g. Tide Times");
    if (!name) return;
    try {
      const { id } = await wos.call("dev.create", { name });
      await refresh(); page = id; draw();
    } catch (e) { toast(e.message); }
  }

  function editorPage(p) {
    const files = [["app.json", "app.json"], ["main.satif", "Logic (main.satif)"], ["main.satUI", "View (main.satUI)"]];
    let activeFile = "main.satif";
    const tabs = h("div", { style: "display:flex;gap:6px;margin-bottom:10px" });
    const editArea = h("textarea.field", { style: "flex:1;min-height:420px;font-family:monospace;font-size:13px;line-height:1.6;resize:vertical" });
    const status = h("span.small.muted", "");
    const save = debounce(async () => {
      try { await wos.call("fs.write_text", { path: p.path + "/" + activeFile, text: editArea.value }); status.textContent = "Saved"; }
      catch (e) { status.textContent = e.message; }
    }, 400);
    editArea.addEventListener("input", () => { status.textContent = "Saving…"; save(); });

    async function loadFile(name) {
      activeFile = name;
      drawTabs();
      try { editArea.value = await wos.call("fs.read_text", { path: p.path + "/" + name }); }
      catch (e) { editArea.value = ""; }
      status.textContent = "";
    }
    function drawTabs() {
      tabs.innerHTML = "";
      files.forEach(([name, label]) => tabs.append(h("button.btn.small" + (activeFile === name ? "" : ".ghost"), { onclick: () => loadFile(name) }, label)));
    }
    drawTabs(); loadFile(activeFile);

    const runBtn = h("button.btn", { onclick: async () => { try { await wos.call("dev.run", { path: p.path }); } catch (e) { toast(e.message); } } }, "▶ Run");
    const installBtn = h("button.btn.ghost", { onclick: async () => {
      try { const r = await wos.call("dev.install", { path: p.path }); toast(r.name + " installed. Find it in Apps."); await refresh(); drawNav(); }
      catch (e) { toast(e.message); }
    } }, "Install / Update on this computer");
    const exportBtn = h("button.btn.ghost", { onclick: async () => {
      try { const r = await wos.call("dev.export", { path: p.path }); toast("Exported to " + r.path); }
      catch (e) { toast(e.message); }
    } }, "Export…");
    const deleteBtn = h("button.icon-btn", { title: "Delete project", html: icon("trash"), onclick: async () => {
      if (!await confirmBox("Delete " + p.name + "?", "The project's files are deleted for good. Anything already installed on this computer is not affected.", "Delete", true)) return;
      try { await wos.call("dev.delete", { path: p.path }); await refresh(); page = "docs"; draw(); } catch (e) { toast(e.message); }
    } });

    body.innerHTML = "";
    body.append(
      h("h1", { style: "margin:0 0 4px" }, p.name),
      h("p.muted.small", { style: "margin:0 0 18px" }, p.path),
      h("div.card.pad", { style: "display:flex;gap:10px;align-items:center;margin-bottom:18px;flex-wrap:wrap" },
        runBtn, installBtn, exportBtn, h("div.grow"), deleteBtn),
      tabs, editArea,
      h("div", { style: "margin-top:8px" }, status),
      h("p.muted.small", { style: "margin-top:18px" },
        "Run opens this project as a real, native window without installing it anywhere. Install/Update copies it into ",
        h("code", "~/.local/share/wos/apps"), " and adds it to Apps -- running Install again on the same name replaces the old copy, ",
        "which is how you push an update: no OS update, no reboot. Export writes a ", h("code", ".satapp.tar.gz"),
        " to Downloads that anyone can install with \u201cInstall from file\u2026\u201d in the App Store (not built yet -- for now, share the file and open it from Files)."));
  }

  function docsPage() {
    body.innerHTML = "";
    const code = (s) => h("pre", { style: "background:var(--panel-2);border-radius:8px;padding:10px 12px;font-size:12.5px;overflow:auto;margin:6px 0 14px" }, s);
    body.append(
      h("h1", { style: "margin:0 0 4px" }, "Satisfaction language reference"),
      h("p.muted.small", { style: "margin:0 0 20px" }, "What's actually supported today, not a wishlist. The language itself lives at ",
        h("a", { href: "#", onclick: e => { e.preventDefault(); wos.call("sys.open_url", { url: "https://github.com/W-TecUK/satisfaction-lang" }); } }, "github.com/W-TecUK/satisfaction-lang"), "."),
      section(".satif -- logic",
        h("div.card.pad",
          h("p", "Values: numbers, strings, booleans, ", h("code", "nil"), ", lists, and functions. No optionals, no generics, no type annotations at all -- deliberately easier than Swift, not a smaller Swift."),
          code("let name = \"World\"      // constant\nvar count = 0            // can be reassigned\n\nfunc greet(who) {\n    print(\"Hello, \\(who)!\")   // string interpolation\n}\n\nif count > 0 {\n    // ...\n} else {\n    // ...\n}\n\nwhile count < 3 {\n    count = count + 1\n}\n\nfor item in [1, 2, 3] {\n    print(item)\n}\n\nfunc double(x) {\n    return x * 2\n}"),
          h("p", h("b", "Operators: "), h("code", "+ - * / == != < <= > >="), ". ", h("code", "+"), " also joins strings and concatenates lists."),
          h("p", h("b", "Errors "), "are always plain English: ", h("code", "\"Line 7: Can't divide by zero.\""), " -- never a stack trace.")),
      ),
      section(".satUI -- the view tree",
        h("div.card.pad",
          h("p", "A declarative tree, re-evaluated against the live program state every time ", h("code", "render()"), " is called -- never compiled once and cached."),
          code("View {\n    Text(\"Count: \\(count)\")\n    HStack {\n        Button(\"Add one\") {\n            bump()\n        }\n        Spacer()\n    }\n}"),
          h("p", h("b", "Containers: "), h("code", "View, VStack, HStack, ZStack"), " (children stack top-to-bottom or side-by-side)."),
          h("p", h("b", "Content: "), h("code", "Text(expr)"), ", ", h("code", "Button(label) { ...statements... }"), ", ", h("code", "Spacer()"), "."),
          h("p.muted.small", "Known gap: ", h("code", "ZStack"), " parses but currently renders exactly like ", h("code", "VStack"), " (top-to-bottom, not overlaid) -- the native renderer hasn't implemented real layering yet."))),
      section("What a host actually provides",
        h("div.card.pad",
          h("p", "The language itself has no way to reach the rest of the OS -- every ", h("code", "func"), " your program can call that it didn't write itself is handed in by whatever is running it. This app's own Run/Install use ", h("code", "wos-sat-run"), ", which provides exactly:"),
          h("p", h("code", "print(value)"), " -- writes to the system log (not visible in a window; useful only while testing from a terminal)."),
          h("p", h("code", "render()"), " -- redraws the view tree from the current state. Call it after anything that should change what's on screen."),
          h("p.muted.small", "That's it today: no files, no network, no notifications, no ", h("code", "wos.call"), " bridge reachable from Satisfaction code yet. A real app is limited to on-screen state and buttons until more host builtins are wired in."))),
      section("Publishing and updating",
        h("div.card.pad",
          h("p", "Install/Update (on a project's page) copies it into your own ", h("code", "~/.local/share/wos/apps"), " and registers it with the desktop -- exactly like a Flatpak app, and for the same reason: nothing here touches the OS image, so it needs no signing key, no OS update, and no reboot. Running Install again after changing your code replaces the old copy in place, which ", h("i", "is"), " how you push an update."),
          h("p", "Export writes a plain ", h("code", ".satapp.tar.gz"), " -- just your project's files -- to Downloads, so you can hand it to someone else. They install it by extracting it and running Install/Update on the extracted folder (a one-click \u201cInstall from file\u201d in the App Store is a natural next step, not built yet)."))));
  }

  function draw() {
    drawNav();
    if (page === "docs") { docsPage(); return; }
    const p = projects.find(x => x.id === page);
    if (!p) { page = "docs"; docsPage(); return; }
    editorPage(p);
  }

  await refresh();
  if (!projects.length) page = "docs";
  draw();
});
