"""satindex: Index, the W-OS 4 launcher, native GTK (no web). One panel over a solid dimmed backdrop: a search line that also
answers sums and conversions, World filters, a Continue row of recent files, and a grid of apps, most used first.

Keys: type to search, arrows move, Enter opens, Tab next World, Ctrl+1..5 jump to a World, Esc closes.
Not built yet: file and settings results, the preview card, right-click pin/hide, the keyboard shortcut that opens it.
"""
import hashlib
import os
import sys
import time
from urllib.parse import unquote, urlparse

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, Gio, GLib, Gtk  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import satindex_logic as X  # noqa: E402
import satshelf_layout as L  # noqa: E402
from satglass import Glass, read_mode, reduce_transparency  # noqa: E402

COLUMNS = 8
PREVIEW_COLOURS = ["#3A5FA8", "#F5A623", "#2A8FE0", "#3E9A6A", "#C0449A", "#7B5BD6", "#D9622B"]
CSS = b"""
window.sat-index { background-color: rgba(4, 10, 28, 0.72); font-family: "Syne", sans-serif; color: #ffffff; }
.si-panel { background-color: transparent; border: none; box-shadow: none; padding: 28px 36px; }
.si-search entry placeholder, .si-search entry text { color: rgba(255,255,255,0.55); }
.si-search entry text { color: #fff; }
.si-search { background-color: #141414; border-radius: 36px; padding: 0 28px; }
.si-search entry { background: transparent; border: none; box-shadow: none; color: #fff; font-size: 22px; font-weight: 500; caret-color: #FFC933; }
.si-hint { font-size: 14px; color: rgba(255,255,255,0.55); }
.si-answer { background-color: #FFC933; color: #1A1300; font-size: 20px; font-weight: 800; border-radius: 22px; padding: 6px 18px; }
button.si-world { background-image: none; background-color: #2B2B2B; border: none; border-radius: 20px; padding: 9px 20px; color: #fff; font-size: 15px; font-weight: 700; box-shadow: none; }
button.si-world.on { background-color: #ffffff; color: #141414; }
.si-section { font-size: 12px; font-weight: 700; letter-spacing: 2px; color: rgba(255,255,255,0.7); }
.si-card { background-color: #1F1F1F; border-radius: 26px; padding: 12px; }
.si-card:hover { background-color: #2B2B2B; }
.si-preview { border-radius: 18px; }
.si-card-title { font-size: 14px; font-weight: 700; } .si-card-sub { font-size: 12px; color: rgba(255,255,255,0.7); }
.si-cell { border-radius: 24px; padding: 10px; border: 2px solid transparent; }
.si-cell.sel { background-color: #2B2B2B; border-color: #FFC933; }
.si-label { font-size: 13px; font-weight: 600; }
.si-foot { font-size: 13px; color: rgba(255,255,255,0.7); }
window.si-light, window.si-light .si-label, window.si-light .si-card-title { color: #0A1A3C; }
window.si-light .si-section, window.si-light .si-foot, window.si-light .si-card-sub, window.si-light .si-hint, window.si-light .si-empty { color: rgba(10,26,60,0.68); }
window.si-light button.si-world { background-color: #E4E4E8; color: #0A1A3C; } window.si-light button.si-world.on { background-color: #141414; color: #ffffff; }
window.si-light .si-search { background-color: #E9E9EC; } window.si-light .si-search entry, window.si-light .si-search entry text { color: #0A1A3C; }
.si-empty { font-size: 16px; color: rgba(255,255,255,0.7); }
scrolledwindow, viewport { background: transparent; }
"""


def load_apps():
    apps = []
    for info in Gio.AppInfo.get_all():
        if not info.should_show():
            continue
        did = info.get_id() or ""
        cats = info.get_categories() if isinstance(info, Gio.DesktopAppInfo) else ""
        kw = ";".join(info.get_keywords() or []) if isinstance(info, Gio.DesktopAppInfo) else ""
        generic = info.get_generic_name() if isinstance(info, Gio.DesktopAppInfo) else ""
        apps.append({"id": did, "name": info.get_display_name() or did, "icon": info.get_icon(), "info": info,
                     "world": X.world_of(cats), "keywords": "%s;%s" % (generic or "", kw)})
    return apps


def recent_files(limit=5):
    out = []
    for item in Gtk.RecentManager.get_default().get_items():
        uri = item.get_uri()
        if not uri.startswith("file://"):
            continue
        path = unquote(urlparse(uri).path)
        if not os.path.isfile(path):
            continue
        out.append((item.get_modified(), path, item.get_mime_type()))
    out.sort(reverse=True)
    return [(p, m) for _, p, m in out[:limit]]


class Index:
    def __init__(self, launch=None, geo=None, glass=None):
        self.launch = launch
        self.shown = False
        self.world = "All"
        self.sel = 0
        self.cells = []
        self.visible_apps = []
        self.apps = []
        display = Gdk.Display.get_default()
        mon = display.get_primary_monitor() or display.get_monitor(0)
        self.geo = geo or mon.get_geometry()
        self.scale = max(0.7, min(1.3, min(self.geo.width / 1920.0, self.geo.height / 1080.0)))
        self.glass = glass or Glass(self.geo.width, self.geo.height)
        self.rise = L.Spring(24.0)
        self.rise.target = 24.0
        provider = Gtk.CssProvider()
        provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        self.win = Gtk.Window()
        self.win.set_decorated(False)
        self.win.set_skip_taskbar_hint(True)
        self.win.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.win.set_keep_above(True)
        self.win.set_app_paintable(True)
        vis = self.win.get_screen().get_rgba_visual()
        if vis is not None:
            self.win.set_visual(vis)
        self.win.get_style_context().add_class("sat-index")
        self.win.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.KEY_PRESS_MASK)
        self.win.connect("key-press-event", self._key)
        self.win.connect("button-press-event", self._backdrop_click)
        self.win.connect("delete-event", lambda *_: True)
        self.fixed = Gtk.Fixed()
        self.win.add(self.fixed)
        self._build_panel()

    # ---------- build ----------
    def _build_panel(self):
        s = self.scale
        self.pw, self.ph = int(1280 * s), int(800 * s)
        self.panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(14 * s))
        self.panel.get_style_context().add_class("si-panel")
        self.panel.set_size_request(self.pw, self.ph)
        self.panel.connect("draw", self._draw_glass)
        self.fixed.put(self.panel, (self.geo.width - self.pw) // 2, int(120 * s))

        bar = Gtk.Box(spacing=12)
        bar.get_style_context().add_class("si-search")
        bar.set_size_request(-1, int(72 * s))
        bar.pack_start(Gtk.Image.new_from_icon_name("system-search-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        self.entry = Gtk.Entry()
        self.entry.set_placeholder_text("Search apps, or type a sum")
        self.entry.connect("changed", lambda *_: self._refresh())
        bar.pack_start(self.entry, True, True, 0)
        self.answer_lbl = Gtk.Label()
        self.answer_lbl.get_style_context().add_class("si-answer")
        self.answer_lbl.set_no_show_all(True)
        bar.pack_start(self.answer_lbl, False, False, 0)
        hint = Gtk.Label(label="Tab · Worlds")
        hint.get_style_context().add_class("si-hint")
        bar.pack_start(hint, False, False, 0)
        self.panel.pack_start(bar, False, False, 0)

        worlds = Gtk.Box(spacing=10)
        self.world_btns = {}
        for w in X.WORLDS:
            b = Gtk.Button(label=w)
            b.set_can_focus(False)
            b.get_style_context().add_class("si-world")
            b.connect("clicked", lambda _b, w=w: self._set_world(w))
            worlds.pack_start(b, False, False, 0)
            self.world_btns[w] = b
        self.panel.pack_start(worlds, False, False, 0)

        self.cont_label = self._section("CONTINUE")
        self.cont_row = Gtk.Box(spacing=int(14 * s), homogeneous=True)
        self.panel.pack_start(self.cont_label, False, False, 0)
        self.panel.pack_start(self.cont_row, False, False, 0)

        self.apps_label = self._section("APPS · MOST USED FIRST")
        self.panel.pack_start(self.apps_label, False, False, 0)
        self.grid = Gtk.Grid()
        self.grid.set_row_spacing(int(8 * s))
        self.grid.set_column_homogeneous(True)
        self.scroll = Gtk.ScrolledWindow()
        self.scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.scroll.add(self.grid)
        self.panel.pack_start(self.scroll, True, True, 0)

        foot = Gtk.Label(label="↑ ↓ ← → Move     Enter Open     Tab Next World     Type to search     Esc Close")
        foot.set_xalign(0)
        foot.get_style_context().add_class("si-foot")
        self.panel.pack_start(foot, False, False, 0)

    @staticmethod
    def _section(text):
        l = Gtk.Label(label=text)
        l.set_xalign(0)
        l.get_style_context().add_class("si-section")
        return l

    def _draw_glass(self, panel, cr):
        a = panel.get_allocation()
        cr.save()
        cr.translate(-a.x, -a.y)                              # the glass is painted in window (= monitor) coordinates
        self.glass.paint(cr, a.x, a.y, a.width, a.height, (44 * self.scale, 44 * self.scale, 44 * self.scale, 12 * self.scale), tint_floor=0.70, tag="index")
        cr.restore()
        return False

    # ---------- content ----------
    def _refresh(self, reset=True):
        query = self.entry.get_text()
        ans = X.answer(query)
        self.answer_lbl.set_text(ans or "")
        (self.answer_lbl.show if ans else self.answer_lbl.hide)()
        for w, b in self.world_btns.items():
            (b.get_style_context().add_class if w == self.world else b.get_style_context().remove_class)("on")
        searching = bool(query.strip())
        self.visible_apps = X.filter_apps(X.order(self.apps, self.counts), query, self.world)
        self.apps_label.set_text("RESULTS" if searching else "APPS · MOST USED FIRST")
        for w in (self.cont_label, self.cont_row):
            w.set_visible(not searching and bool(self.recents))
        for c in self.grid.get_children():
            self.grid.remove(c)
        self.cells = []
        if not self.visible_apps:
            e = Gtk.Label(label="Nothing found" if searching else "No apps here yet")
            e.get_style_context().add_class("si-empty")
            self.grid.attach(e, 0, 0, COLUMNS, 1)
        for i, app in enumerate(self.visible_apps):
            cell = self._cell(app, i)
            self.cells.append(cell)
            self.grid.attach(cell, i % COLUMNS, i // COLUMNS, 1, 1)
        if reset:
            self.sel = 0
        self._mark()
        self.grid.show_all()

    def _cell(self, app, i):
        ev = Gtk.EventBox()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.get_style_context().add_class("si-cell")
        img = Gtk.Image.new_from_gicon(app["icon"], Gtk.IconSize.DIALOG) if app["icon"] else Gtk.Image.new_from_icon_name("application-x-executable", Gtk.IconSize.DIALOG)
        img.set_pixel_size(int(60 * self.scale))
        lbl = Gtk.Label(label=app["name"])
        lbl.set_max_width_chars(12)
        lbl.set_ellipsize(3)
        lbl.get_style_context().add_class("si-label")
        box.pack_start(img, False, False, 0)
        box.pack_start(lbl, False, False, 0)
        ev.add(box)
        ev.connect("button-release-event", lambda w, e, i=i: self._open_index(i) if e.button == 1 else None)
        ev.connect("enter-notify-event", lambda *_a, i=i: (setattr(self, "sel", i), self._mark(), False)[2])
        return ev

    def _mark(self):
        for i, ev in enumerate(self.cells):
            ctx = ev.get_child().get_style_context()
            (ctx.add_class if i == self.sel else ctx.remove_class)("sel")

    def _build_continue(self):
        for c in self.cont_row.get_children():
            self.cont_row.remove(c)
        for path, mime in self.recents:
            ev = Gtk.EventBox()
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            card.get_style_context().add_class("si-card")
            colour = PREVIEW_COLOURS[int(hashlib.md5((mime or "").encode()).hexdigest(), 16) % len(PREVIEW_COLOURS)]
            prev = Gtk.Box()
            prev.set_size_request(-1, int(84 * self.scale))
            prev.get_style_context().add_class("si-preview")
            p = Gtk.CssProvider()
            p.load_from_data(("box { background-color: %s; border-radius: 18px; }" % colour).encode())
            prev.get_style_context().add_provider(p, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
            card.pack_start(prev, False, False, 0)
            handler = Gio.AppInfo.get_default_for_type(mime, False) if mime else None
            row = Gtk.Box(spacing=8)
            if handler and handler.get_icon():
                ic = Gtk.Image.new_from_gicon(handler.get_icon(), Gtk.IconSize.LARGE_TOOLBAR)
                ic.set_pixel_size(28)
                row.pack_start(ic, False, False, 0)
            col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            t = Gtk.Label(label=os.path.splitext(os.path.basename(path))[0]); t.set_xalign(0); t.set_ellipsize(3); t.set_max_width_chars(14)
            t.get_style_context().add_class("si-card-title")
            sub = Gtk.Label(label=handler.get_display_name() if handler else "File"); sub.set_xalign(0)
            sub.get_style_context().add_class("si-card-sub")
            col.pack_start(t, False, False, 0); col.pack_start(sub, False, False, 0)
            row.pack_start(col, True, True, 0)
            card.pack_start(row, False, False, 0)
            ev.add(card)
            ev.connect("button-release-event", lambda w, e, path=path: self._open_file(path))
            self.cont_row.pack_start(ev, True, True, 0)

    # ---------- actions ----------
    def _set_world(self, w):
        self.world = w
        self._refresh()

    def _open_index(self, i):
        if 0 <= i < len(self.visible_apps):
            app = self.visible_apps[i]
            X.bump(app["id"])
            self.hide()
            if self.launch:
                self.launch(app["id"])
            else:
                app["info"].launch([], None)

    def _open_file(self, path):
        self.hide()
        try:
            Gio.AppInfo.launch_default_for_uri("file://" + path, None)
        except GLib.Error as e:
            print("satindex: could not open %s: %s" % (path, e), file=sys.stderr)

    def _backdrop_click(self, w, ev):
        a = self.panel.get_allocation()
        if not (a.x <= ev.x <= a.x + a.width and a.y <= ev.y <= a.y + a.height):
            self.hide()

    def _key(self, w, ev):
        k, st = ev.keyval, ev.state
        ctrl = bool(st & Gdk.ModifierType.CONTROL_MASK)
        if k == Gdk.KEY_Escape:
            self.hide()
        elif k in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            self._open_index(self.sel)
        elif k in (Gdk.KEY_Tab, Gdk.KEY_ISO_Left_Tab):
            step = -1 if k == Gdk.KEY_ISO_Left_Tab else 1
            self._set_world(X.WORLDS[(X.WORLDS.index(self.world) + step) % len(X.WORLDS)])
        elif ctrl and Gdk.KEY_1 <= k <= Gdk.KEY_5:
            self._set_world(X.WORLDS[k - Gdk.KEY_1])
        elif k in (Gdk.KEY_Left, Gdk.KEY_Right, Gdk.KEY_Up, Gdk.KEY_Down):
            d = {Gdk.KEY_Left: -1, Gdk.KEY_Right: 1, Gdk.KEY_Up: -COLUMNS, Gdk.KEY_Down: COLUMNS}[k]
            n = self.sel + d
            if 0 <= n < len(self.cells):
                self.sel = n
                self._mark()
                a = self.cells[n].get_allocation()
                self.scroll.get_vadjustment().clamp_page(a.y, a.y + a.height)
        else:
            return False
        return True

    # ---------- show / hide ----------
    def show(self):
        self.apps = load_apps()
        self.glass.set_mode(read_mode(), reduce_transparency())
        ctx = self.win.get_style_context()
        (ctx.add_class if self.glass.mode == "light" else ctx.remove_class)("si-light")
        self.counts = X.load_counts()
        self.recents = recent_files()
        self._build_continue()
        self.world = "All"
        self.entry.set_text("")
        self._refresh()
        self.win.move(self.geo.x, self.geo.y)
        self.win.resize(self.geo.width, self.geo.height)
        self.win.show_all()
        self.cont_label.set_visible(bool(self.recents))
        self.cont_row.set_visible(bool(self.recents))
        self.answer_lbl.hide()
        self.win.present()
        self.entry.grab_focus()
        self.shown = True
        self.rise.value, self.rise.target, self.rise.velocity = 24.0 * self.scale, 0.0, 0.0
        self._t0 = time.monotonic()
        self.win.add_tick_callback(self._tick)

    def _tick(self, widget, clock):
        now = time.monotonic()
        dt, self._t0 = now - self._t0, now
        self.rise.step(dt)
        self.fixed.move(self.panel, (self.geo.width - self.pw) // 2, int(120 * self.scale + self.rise.value))
        if self.win.get_visual() is not None and self.win.is_composited():
            self.win.set_opacity(max(0.0, min(1.0, 1.0 - self.rise.value / (24.0 * self.scale))))
        return self.shown and not self.rise.settled

    def hide(self):
        self.win.hide()
        self.shown = False

    def toggle(self):
        self.hide() if self.shown else self.show()
