"use strict";
/* Shared by every W-OS app page: the bridge to the native runtime (usr/libexec/wos/app), theme
   handling, and small helpers. Opened in a plain browser (design preview) the bridge is a mock
   with sample data, so an app can be worked on without booting anything. */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

/* Build DOM quickly: h("div.card", {onclick: f}, "text", child, ...) */
function h(tag, attrs, ...kids) {
  const [name, ...classes] = tag.split(".");
  const el = document.createElement(name || "div");
  if (classes.length) el.className = classes.join(" ");
  if (attrs && (attrs.nodeType || typeof attrs === "string" || Array.isArray(attrs))) { kids.unshift(attrs); attrs = null; }
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "html") el.innerHTML = v;
    else if (v === true) el.setAttribute(k, "");
    else if (v !== false && v != null) el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(kid));
  return el;
}

/* ---------- icons: duotone (filled accent + outline), currentColor -----------
   Every glyph pairs a low-opacity filled shape with a stroked outline on top,
   the same trick SF Symbols/Fluent use for depth -- deliberately not a flat
   single-weight line set, since that's the generic look every icon font
   (Feather, Material Outlined, etc.) already has out of the box. */
const ICONS = {
  search: "<circle cx='11' cy='11' r='7' fill='currentColor' fill-opacity='.15' stroke='none'/><circle cx='11' cy='11' r='7'/><path d='M20 20l-3.5-3.5'/>",
  bell: "<path d='M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z' fill='currentColor' fill-opacity='.15' stroke='none'/><path d='M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z'/><path d='M10 20a2 2 0 0 0 4 0'/>",
  globe: "<circle cx='12' cy='12' r='9' fill='currentColor' fill-opacity='.1' stroke='none'/><circle cx='12' cy='12' r='9'/><path d='M3 12h18M12 3c3.5 3.5 3.5 14.5 0 18M12 3c-3.5 3.5-3.5 14.5 0 18'/>",
  battery: "<rect x='3' y='8' width='16' height='9' rx='2.5' fill='currentColor' fill-opacity='.15' stroke='none'/><rect x='3' y='8' width='16' height='9' rx='2.5'/><path d='M21.5 11v3'/>",
  clock: "<circle cx='12' cy='12' r='9' fill='currentColor' fill-opacity='.12' stroke='none'/><circle cx='12' cy='12' r='9'/><path d='M12 7v5l3 2'/>",
  disk: "<rect x='4' y='6' width='16' height='12' rx='3' fill='currentColor' fill-opacity='.15' stroke='none'/><rect x='4' y='6' width='16' height='12' rx='3'/><path d='M8 14h.01M12 14h4'/>",
  plus: "<circle cx='12' cy='12' r='9' fill='currentColor' fill-opacity='.12' stroke='none'/><path d='M12 7.5v9M7.5 12h9'/>",
  trash: "<path d='M6 7l1 13h10l1-13z' fill='currentColor' fill-opacity='.15' stroke='none'/><path d='M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13'/>",
  folder: "<path d='M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z' fill='currentColor' fill-opacity='.15' stroke='none'/><path d='M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/>",
  file: "<path d='M6 3h8l5 5v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z' fill='currentColor' fill-opacity='.12' stroke='none'/><path d='M6 3h8l5 5v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z'/><path d='M14 3v5h5'/>",
  image: "<rect x='3' y='4' width='18' height='16' rx='3' fill='currentColor' fill-opacity='.1' stroke='none'/><rect x='3' y='4' width='18' height='16' rx='3'/><circle cx='9' cy='10' r='2' fill='currentColor' stroke='none'/><path d='M21 16l-5-5-8 8'/>",
  home: "<path d='M4 11l8-7 8 7v9H4z' fill='currentColor' fill-opacity='.15' stroke='none'/><path d='M4 11l8-7 8 7v9H4z'/>",
  down: "<path d='M12 4v12M6 11l6 6 6-6M5 20h14'/>",
  doc: "<path d='M6 3h9l4 4v14H6z' fill='currentColor' fill-opacity='.12' stroke='none'/><path d='M6 3h9l4 4v14H6z'/><path d='M9 12h7M9 16h7'/>",
  back: "<path d='M15 5l-7 7 7 7'/>", forward: "<path d='M9 5l7 7-7 7'/>", up: "<path d='M5 15l7-7 7 7'/>",
  grid: "<rect x='4' y='4' width='6' height='6' rx='1.8' fill='currentColor' fill-opacity='.85' stroke='none'/><rect x='14' y='4' width='6' height='6' rx='1.8' fill='currentColor' fill-opacity='.5' stroke='none'/><rect x='4' y='14' width='6' height='6' rx='1.8' fill='currentColor' fill-opacity='.5' stroke='none'/><rect x='14' y='14' width='6' height='6' rx='1.8' fill='currentColor' fill-opacity='.85' stroke='none'/>",
  list: "<path d='M8 6h12M8 12h12M8 18h12'/><circle cx='4' cy='6' r='1.3' fill='currentColor' stroke='none'/><circle cx='4' cy='12' r='1.3' fill='currentColor' stroke='none'/><circle cx='4' cy='18' r='1.3' fill='currentColor' stroke='none'/>",
  mail: "<rect x='3' y='5' width='18' height='14' rx='3' fill='currentColor' fill-opacity='.12' stroke='none'/><rect x='3' y='5' width='18' height='14' rx='3'/><path d='M4 8l8 6 8-6'/>",
  send: "<path d='M4 12l16-8-6 16-3-7z' fill='currentColor' fill-opacity='.18' stroke='none'/><path d='M4 12l16-8-6 16-3-7zM10 13l4-4'/>",
  user: "<path d='M4 21c1-4 4-6 8-6s7 2 8 6z' fill='currentColor' fill-opacity='.12' stroke='none'/><circle cx='12' cy='8' r='4' fill='currentColor' fill-opacity='.18' stroke='none'/><circle cx='12' cy='8' r='4'/><path d='M4 21c1-4 4-6 8-6s7 2 8 6'/>",
  star: "<path d='M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z' fill='currentColor' fill-opacity='.25' stroke='none'/><path d='M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z'/>",
  cal: "<rect x='3' y='5' width='18' height='16' rx='3' fill='currentColor' fill-opacity='.1' stroke='none'/><rect x='3' y='5' width='18' height='16' rx='3'/><path d='M3 10h18M8 3v4M16 3v4'/><rect x='7' y='13' width='4' height='4' rx='1' fill='currentColor' stroke='none'/>",
  gear: "<circle cx='12' cy='12' r='8' fill='currentColor' fill-opacity='.08' stroke='none'/><circle cx='12' cy='12' r='3'/><path d='M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1'/>",
  wifi: "<path d='M2 9a15 15 0 0 1 20 0M5.5 12.5a10 10 0 0 1 13 0M9 16a5 5 0 0 1 6 0'/><circle cx='12' cy='19.5' r='1.4' fill='currentColor' stroke='none'/>",
  sound: "<path d='M4 9v6h4l5 4V5L8 9z' fill='currentColor' fill-opacity='.18' stroke='none'/><path d='M4 9v6h4l5 4V5L8 9z'/><path d='M16 8a5 5 0 0 1 0 8'/>",
  paint: "<path d='M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2.3-2.5 1.7-2.5H18a3 3 0 0 0 3-3c0-5-4-10.5-9-10.5z' fill='currentColor' fill-opacity='.12' stroke='none'/><path d='M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2.3-2.5 1.7-2.5H18a3 3 0 0 0 3-3c0-5-4-10.5-9-10.5z'/><circle cx='8' cy='11' r='1.2' fill='currentColor' stroke='none'/><circle cx='12' cy='7.5' r='1.2' fill='currentColor' stroke='none'/><circle cx='16' cy='11' r='1.2' fill='currentColor' stroke='none'/>",
  info: "<circle cx='12' cy='12' r='9' fill='currentColor' fill-opacity='.12' stroke='none'/><circle cx='12' cy='12' r='9'/><path d='M12 11v6'/><circle cx='12' cy='7.5' r='1' fill='currentColor' stroke='none'/>",
  refresh: "<path d='M20 11a8 8 0 1 0-2 6M20 4v7h-7'/>",
  phone: "<rect x='7' y='3' width='10' height='18' rx='3' fill='currentColor' fill-opacity='.12' stroke='none'/><rect x='7' y='3' width='10' height='18' rx='3'/><path d='M11 18h2'/>",
  bag: "<path d='M5 8h14l-1 12H6z' fill='currentColor' fill-opacity='.15' stroke='none'/><path d='M5 8h14l-1 12H6zM9 8a3 3 0 0 1 6 0'/>",
  chat: "<path d='M4 5h16v11H9l-5 4z' fill='currentColor' fill-opacity='.15' stroke='none'/><path d='M4 5h16v11H9l-5 4z'/>",
  x: "<path d='M6 6l12 12M18 6L6 18'/>",
  updown: "<path d='M8 10l4-4 4 4M8 14l4 4 4-4'/>",
  minus: "<path d='M6 12h12'/>",
  plane: "<path d='M21 4L3 11l6 2 2 6z' fill='currentColor' fill-opacity='.15' stroke='none'/><path d='M21 4L3 11l6 2 2 6zM9 13l12-9'/>",
  chevron: "<path d='M9 5l7 7-7 7'/>",
  bluetooth: "<path d='M7 7l10 10-5 4V3l5 4L7 17'/>",
  check: "<path d='M5 12l5 5 9-10'/>",
  edit: "<path d='M4 20h4L19 9l-4-4L4 16z' fill='currentColor' fill-opacity='.12' stroke='none'/><path d='M4 20h4L19 9l-4-4L4 16zM13 7l4 4'/>",
  moon: "<path d='M20 14A8 8 0 0 1 10 4a8 8 0 1 0 10 10z' fill='currentColor' fill-opacity='.25' stroke='none'/><path d='M20 14A8 8 0 0 1 10 4a8 8 0 1 0 10 10z'/>",
  sun: "<circle cx='12' cy='12' r='4' fill='currentColor' fill-opacity='.3' stroke='none'/><circle cx='12' cy='12' r='4'/><path d='M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2'/>",
  lock: "<rect x='5' y='11' width='14' height='10' rx='3' fill='currentColor' fill-opacity='.15' stroke='none'/><rect x='5' y='11' width='14' height='10' rx='3'/><path d='M8 11V8a4 4 0 0 1 8 0v3'/><circle cx='12' cy='16' r='1.3' fill='currentColor' stroke='none'/>",
  shield: "<path d='M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6z' fill='currentColor' fill-opacity='.15' stroke='none'/><path d='M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6z'/><path d='M9 12l2 2 4-4'/>",
  zoomin: "<circle cx='11' cy='11' r='7' fill='currentColor' fill-opacity='.1' stroke='none'/><circle cx='11' cy='11' r='7'/><path d='M20 20l-3.5-3.5M11 8v6M8 11h6'/>",
  zoomout: "<circle cx='11' cy='11' r='7' fill='currentColor' fill-opacity='.1' stroke='none'/><circle cx='11' cy='11' r='7'/><path d='M20 20l-3.5-3.5M8 11h6'/>",
  download: "<path d='M12 4v11M7 11l5 5 5-5M5 20h14'/>",
  qr: "<rect x='4' y='4' width='6' height='6' rx='1'/><rect x='14' y='4' width='6' height='6' rx='1'/><rect x='4' y='14' width='6' height='6' rx='1'/><path d='M14 14h3v3M20 14v.01M14 20h.01M17 20h3v-3'/>",
  eye: "<path d='M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z' fill='currentColor' fill-opacity='.1' stroke='none'/><path d='M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z'/><circle cx='12' cy='12' r='3' fill='currentColor' stroke='none'/>",
  eyeoff: "<path d='M2 12s3.5-7 10-7c1.7 0 3.2.4 4.5 1M22 12s-3.5 7-10 7c-1.7 0-3.2-.4-4.5-1'/><path d='M9.9 9.9a3 3 0 0 0 4.2 4.2M6.1 6.1 3 3M17.9 17.9l3.1 3.1'/>",
};
function icon(name, size) {
  const s = size ? ` style="width:${size}px;height:${size}px"` : "";
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"${s}>${ICONS[name] || ""}</svg>`;
}
function iconEl(name, size) { const s = h("span", { html: icon(name, size) }); s.style.display = "inline-grid"; return s.firstChild; }

/* ---------- dropdown: a custom-styled replacement for <select> ----------
   A plain <select>'s closed box can be styled with .field, but the open popup is
   the browser's own native listbox -- unstyled OS chrome dropped into an otherwise
   custom design, which is exactly the kind of seam that reads as unfinished. This
   draws both the closed control and the open list ourselves, in the same card/row
   language as everything else. items: [value, label] pairs or plain strings. */
let closeOpenDropdown = null;
function dropdown(items, opts = {}) {
  const norm = items.map(it => Array.isArray(it) ? it : [it, String(it)]);
  let value = opts.value;
  const label = h("span.dd-label");
  const btn = h("button.dd", { type: "button", style: opts.width ? `width:${opts.width}px` : "" }, label, h("span.dd-arrow", { html: icon("updown", 14) }));
  const paint = () => { const cur = norm.find(([v]) => String(v) === String(value)); label.textContent = cur ? cur[1] : ""; };
  paint();
  btn.addEventListener("click", e => {
    e.stopPropagation();
    if (closeOpenDropdown) { const was = closeOpenDropdown; closeOpenDropdown(); if (was === btn._close) return; }
    open();
  });
  function open() {
    const r = btn.getBoundingClientRect();
    const filter = norm.length > 8 ? h("input.dd-filter", { placeholder: "Search" }) : null;
    const listEl = h("div.dd-list");
    const paintList = q => {
      listEl.innerHTML = "";
      norm.filter(([, l]) => !q || l.toLowerCase().includes(q.toLowerCase())).forEach(([v, l]) =>
        listEl.append(h("button", { type: "button", onclick: e2 => { e2.stopPropagation(); value = v; paint(); close(); opts.onChange && opts.onChange(v); } },
          h("span.check", { html: String(v) === String(value) ? icon("check", 14) : "" }), h("span", l))));
    };
    paintList("");
    if (filter) filter.addEventListener("input", () => paintList(filter.value));
    const panel = h("div.dd-panel", { style: `left:${r.left}px;top:${r.bottom + 4}px;min-width:${r.width}px` }, filter, listEl);
    document.body.append(panel);
    if (filter) filter.focus();
    const onDocClick = () => close();
    const onKey = e => { if (e.key === "Escape") close(); };
    function close() { panel.remove(); document.removeEventListener("click", onDocClick); document.removeEventListener("keydown", onKey); if (closeOpenDropdown === close) closeOpenDropdown = null; btn._close = null; }
    setTimeout(() => document.addEventListener("click", onDocClick), 0);
    document.addEventListener("keydown", onKey);
    closeOpenDropdown = close; btn._close = close;
  }
  Object.defineProperty(btn, "value", { get: () => value, set: v => { value = v; paint(); } });
  return btn;
}

/* ---------- datePicker/timePicker: replace <input type=date/time> the same way ----------
   Native date/time inputs draw the browser's own calendar-icon button and popup --
   another seam. These give a button that opens a small styled calendar grid / hour-minute
   picker instead. value/onChange use the same "YYYY-MM-DD" / "HH:MM" strings the native
   inputs already used, so callers don't need to change anything else. */
function datePicker(opts = {}) {
  let value = opts.value || "";
  const label = h("span.dd-label");
  const btn = h("button.dd", { type: "button", style: opts.width ? `width:${opts.width}px` : "" }, h("span", { html: icon("cal", 15) }), label, h("span.dd-arrow", { html: icon("down", 14) }));
  const fmt = v => v ? new Date(v + "T00:00:00").toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short", year: "numeric" }) : "Pick a date";
  const paint = () => label.textContent = fmt(value);
  paint();
  btn.addEventListener("click", e => {
    e.stopPropagation();
    if (closeOpenDropdown) { const was = closeOpenDropdown; closeOpenDropdown(); if (was === btn._close) return; }
    open();
  });
  function open() {
    const r = btn.getBoundingClientRect();
    const base = value ? new Date(value + "T00:00:00") : new Date();
    let vy = base.getFullYear(), vm = base.getMonth();
    const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const head = h("div.dp-head"), gridEl = h("div.dp-grid");
    function paintMonth() {
      head.innerHTML = "";
      head.append(h("button.icon-btn", { type: "button", html: icon("back", 14), onclick: e2 => { e2.stopPropagation(); vm--; if (vm < 0) { vm = 11; vy--; } paintMonth(); } }),
        h("span", { style: "flex:1;text-align:center;font-weight:700" }, MONTHS[vm] + " " + vy),
        h("button.icon-btn", { type: "button", html: icon("forward", 14), onclick: e2 => { e2.stopPropagation(); vm++; if (vm > 11) { vm = 0; vy++; } paintMonth(); } }));
      gridEl.innerHTML = "";
      ["M", "T", "W", "T", "F", "S", "S"].forEach(d => gridEl.append(h("span.dp-dow", d)));
      const first = new Date(vy, vm, 1), offset = (first.getDay() + 6) % 7, count = new Date(vy, vm + 1, 0).getDate();
      const now = new Date(), todayKey = `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(now.getDate())}`;
      for (let i = 0; i < offset; i++) gridEl.append(h("span"));
      for (let day = 1; day <= count; day++) {
        const key = `${vy}-${pad2(vm + 1)}-${pad2(day)}`;
        gridEl.append(h("button.dp-day" + (key === value ? ".on" : "") + (key === todayKey ? ".today" : ""),
          { type: "button", onclick: e2 => { e2.stopPropagation(); value = key; paint(); close(); opts.onChange && opts.onChange(key); } }, day));
      }
    }
    paintMonth();
    const panel = h("div.dd-panel.dp-panel", { style: `left:${r.left}px;top:${r.bottom + 4}px` }, head, gridEl);
    document.body.append(panel);
    const onDocClick = () => close();
    const onKey = e => { if (e.key === "Escape") close(); };
    function close() { panel.remove(); document.removeEventListener("click", onDocClick); document.removeEventListener("keydown", onKey); if (closeOpenDropdown === close) closeOpenDropdown = null; btn._close = null; }
    setTimeout(() => document.addEventListener("click", onDocClick), 0);
    document.addEventListener("keydown", onKey);
    closeOpenDropdown = close; btn._close = close;
  }
  Object.defineProperty(btn, "value", { get: () => value, set: v => { value = v; paint(); } });
  return btn;
}

function timePicker(opts = {}) {
  const [h0, m0] = (opts.value || "").split(":");
  let hh = h0 ? +h0 : 9, mm = m0 ? +m0 : 0;
  const label = h("span.dd-label");
  const btn = h("button.dd", { type: "button", style: opts.width ? `width:${opts.width}px` : "" }, h("span", { html: icon("clock", 15) }), label, h("span.dd-arrow", { html: icon("down", 14) }));
  const paintNow = () => label.textContent = `${pad2(hh)}:${pad2(mm)}`;
  paintNow();
  btn.addEventListener("click", e => {
    e.stopPropagation();
    if (closeOpenDropdown) { const was = closeOpenDropdown; closeOpenDropdown(); if (was === btn._close) return; }
    open();
  });
  function open() {
    const r = btn.getBoundingClientRect();
    const hourCol = h("div.dp-col"), minCol = h("div.dp-col");
    for (let i = 0; i < 24; i++) hourCol.append(h("button" + (i === hh ? ".on" : ""), { type: "button", onclick: e2 => { e2.stopPropagation(); hh = i; paintNow(); opts.onChange && opts.onChange(`${pad2(hh)}:${pad2(mm)}`); [...hourCol.children].forEach(c => c.classList.remove("on")); e2.target.classList.add("on"); } }, pad2(i)));
    for (let i = 0; i < 60; i += 5) minCol.append(h("button" + (i === mm ? ".on" : ""), { type: "button", onclick: e2 => { e2.stopPropagation(); mm = i; paintNow(); opts.onChange && opts.onChange(`${pad2(hh)}:${pad2(mm)}`); [...minCol.children].forEach(c => c.classList.remove("on")); e2.target.classList.add("on"); } }, pad2(i)));
    const panel = h("div.dd-panel.tp-panel", { style: `left:${r.left}px;top:${r.bottom + 4}px` }, hourCol, minCol);
    document.body.append(panel);
    const onHour = panel.querySelector(".dp-col button.on"); if (onHour) onHour.scrollIntoView({ block: "center" });
    const onDocClick = () => close();
    const onKey = e => { if (e.key === "Escape") close(); };
    function close() { panel.remove(); document.removeEventListener("click", onDocClick); document.removeEventListener("keydown", onKey); if (closeOpenDropdown === close) closeOpenDropdown = null; btn._close = null; }
    setTimeout(() => document.addEventListener("click", onDocClick), 0);
    document.addEventListener("keydown", onKey);
    closeOpenDropdown = close; btn._close = close;
  }
  Object.defineProperty(btn, "value", { get: () => `${pad2(hh)}:${pad2(mm)}`, set: v => { const [a, b] = (v || "0:0").split(":"); hh = +a; mm = +b; paintNow(); } });
  return btn;
}

/* ---------- slider: a filled pill track instead of the browser's flat default ----------
   `accent-color` alone still leaves a thin flat native track -- every other control in the
   OS (buttons, switches, segmented controls) is a filled pill, so a plain thin line next to
   them reads as unstyled. Keeps a real <input type=range> underneath (dragging, keyboard,
   accessibility all still native) and only restyles the track/thumb, filled up to the value. */
function slider(opts = {}) {
  const min = opts.min ?? 0, max = opts.max ?? 100, step = opts.step ?? 1;
  const input = h("input.wos-range" + (opts.small ? ".small" : "") + (opts.ticks ? ".ticks" : ""), { type: "range", min, max, step, value: opts.value ?? min, style: opts.width ? `width:${opts.width}px` : "" });
  const paint = () => input.style.setProperty("--pct", ((input.value - min) / (max - min) * 100) + "%");
  if (opts.ticks) input.style.setProperty("--n", Math.max(1, Math.round((max - min) / step)));
  if (opts.disabled) input.disabled = true;
  paint();
  input.addEventListener("input", () => { paint(); opts.onInput && opts.onInput(+input.value); });
  if (opts.onChange) input.addEventListener("change", () => opts.onChange(+input.value));
  return input;
}

/* ---------- checkbox / radio / stepper: the Inputs family (see _shared/inputs.html) ----------
   checkbox({label, checked, indeterminate, disabled, onChange}) and radio({name, label, checked, disabled, onChange}) return a <label class="opt">
   (the <input> is its .input). stepper({value, min, max, step, format, onChange}) returns a pill with minus and plus; read or set .value. */
function checkbox(opts = {}) {
  const input = h("input", { type: "checkbox" });
  input.checked = !!opts.checked; input.indeterminate = !!opts.indeterminate; input.disabled = !!opts.disabled;
  if (opts.onChange) input.addEventListener("change", () => opts.onChange(input.checked));
  const box = h("label.opt" + (opts.disabled ? ".disabled" : ""), input, opts.label ? h("span", opts.label) : null);
  box.input = input;
  return box;
}
function radio(opts = {}) {
  const input = h("input", { type: "radio", name: opts.name || "" });
  input.checked = !!opts.checked; input.disabled = !!opts.disabled;
  if (opts.onChange) input.addEventListener("change", () => input.checked && opts.onChange(true));
  const box = h("label.opt" + (opts.disabled ? ".disabled" : ""), input, opts.label ? h("span", opts.label) : null);
  box.input = input;
  return box;
}
function stepper(opts = {}) {
  const min = opts.min ?? -Infinity, max = opts.max ?? Infinity, step = opts.step ?? 1, fmt = opts.format || (v => String(v));
  let value = Math.min(max, Math.max(min, opts.value ?? 0));
  const val = h("span.val", fmt(value)), less = h("button", { type: "button", "aria-label": "Decrease", html: icon("minus") }), more = h("button", { type: "button", "aria-label": "Increase", html: icon("plus") });
  const set = v => { value = Math.min(max, Math.max(min, v)); val.textContent = fmt(value); less.disabled = value <= min; more.disabled = value >= max; };
  less.onclick = () => { set(value - step); opts.onChange && opts.onChange(value); };
  more.onclick = () => { set(value + step); opts.onChange && opts.onChange(value); };
  set(value);
  const box = h("div.stepper", less, opts.showValue === false ? null : val, more);
  Object.defineProperty(box, "value", { get: () => value, set });
  return box;
}

/* ---------- contextMenu: a right-click menu in the same card language as dropdown() ----------
   items: {label, icon?, hint?, danger?, disabled?, onclick} or "-" for a divider. Opens at x,y, kept on
   screen; closes on any click, Escape, scroll or window blur. */
let closeCtx = null;
function contextMenu(items, x, y) {
  if (closeCtx) closeCtx();
  if (closeOpenDropdown) closeOpenDropdown();
  const menu = h("div.ctx");
  items.filter(Boolean).forEach(it => {
    if (it === "-") { menu.append(h("div.ctx-sep")); return; }
    menu.append(h("button" + (it.danger ? ".danger" : ""), { type: "button", disabled: !!it.disabled,
      onclick: e => { e.stopPropagation(); close(); if (it.onclick) it.onclick(); } },
      h("span.ctx-ic", { html: it.icon ? icon(it.icon, 15) : "" }), h("span.ctx-label", it.label), it.hint ? h("span.ctx-hint", it.hint) : null));
  });
  document.body.append(menu);
  const r = menu.getBoundingClientRect();
  menu.style.left = Math.max(6, Math.min(x, innerWidth - r.width - 6)) + "px";
  menu.style.top = Math.max(6, Math.min(y, innerHeight - r.height - 6)) + "px";
  const onKey = e => { if (e.key === "Escape") close(); };
  const onAny = () => close();
  function close() {
    menu.remove();
    document.removeEventListener("keydown", onKey); document.removeEventListener("mousedown", onDown, true);
    document.removeEventListener("scroll", onAny, true); window.removeEventListener("blur", onAny);
    if (closeCtx === close) closeCtx = null;
  }
  function onDown(e) { if (!menu.contains(e.target)) close(); }
  document.addEventListener("keydown", onKey); document.addEventListener("mousedown", onDown, true);
  document.addEventListener("scroll", onAny, true); window.addEventListener("blur", onAny);
  closeCtx = close;
}


/* ---------- pickFile: an Open dialog in the same pill language ----------
   pickFile({title, exts: [".ovpn"], start: "/home/x"}) -> Promise<path | null>. Browses folders with fs.list, shows only
   folders and files with the wanted endings, and returns the chosen file's path. */
function pickFile(opts = {}) {
  return new Promise(async resolve => {
    const exts = (opts.exts || []).map(e => e.toLowerCase());
    let cwd = opts.start || await wos.call("fs.home");
    let chosen = null;
    const crumbs = h("div.small.muted", { style: "margin-bottom:8px;word-break:break-all" }), list = h("div.card", { style: "max-height:44vh;overflow:auto" });
    const open = h("button.btn", { disabled: true, onclick: () => done(chosen) }, "Open");
    const done = v => { back.remove(); resolve(v); };
    const fmt = n => n >= 1e6 ? (n / 1e6).toFixed(1) + " MB" : n >= 1e3 ? Math.round(n / 1e3) + " KB" : n + " bytes";
    const load = async () => {
      crumbs.textContent = cwd; list.innerHTML = ""; chosen = null; open.disabled = true;
      let items = [];
      try { items = await wos.call("fs.list", { path: cwd }); } catch (e) { list.append(h("div.muted", { style: "padding:18px" }, e.message)); return; }
      const parent = cwd.replace(/\/[^/]+\/?$/, "") || "/";
      if (parent !== cwd) list.append(h("button.row", { onclick: () => { cwd = parent; load(); } }, h("span", { html: icon("back", 15) }), h("div.grow", "Up one folder")));
      items = items.filter(f => !f.name.startsWith(".") && (f.dir || !exts.length || exts.some(e => f.name.toLowerCase().endsWith(e))));
      if (!items.length) list.append(h("div.muted", { style: "padding:18px;text-align:center" }, exts.length ? "No " + exts.join(" or ") + " files here." : "Nothing here."));
      items.forEach(f => {
        const row = h("button.row", { onclick: () => { if (f.dir) { cwd = f.path; load(); } else { chosen = f.path; [...list.children].forEach(c => c.classList.remove("on")); row.classList.add("on"); open.disabled = false; } },
          ondblclick: () => { if (!f.dir) done(f.path); } },
          h("span", { html: icon(f.dir ? "folder" : "file", 16) }), h("div.grow", h("div.t", f.name), h("div.s", f.dir ? "Folder" : fmt(f.size))));
        list.append(row);
      });
    };
    const back = h("div.modal-back", h("div.modal", { style: "width:min(560px,94vw)" }, h("h2", opts.title || "Choose a file"), crumbs, list,
      h("div.actions", h("button.btn.ghost", { onclick: () => done(null) }, "Cancel"), open)));
    document.body.append(back);
    load();
  });
}

/* ---------- the bridge ---------- */
const bridge = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.wos;
const pending = new Map();
let nextId = 1;
const listeners = {};

const wos = {
  info: {},
  /* Call a native method: wos.call("fs.list", {path}) -> Promise */
  call(method, args = {}) {
    if (!bridge) return mockCall(method, args);
    return new Promise((resolve, reject) => {
      const id = nextId++;
      pending.set(id, { resolve, reject });
      bridge.postMessage(JSON.stringify({ id, method, args }));
    });
  },
  on(event, cb) { (listeners[event] = listeners[event] || []).push(cb); },
  /* Called by the native side. */
  receive(m) {
    if (m.type === "reply") {
      const p = pending.get(m.id); if (!p) return;
      pending.delete(m.id);
      m.error ? p.reject(new Error(m.error)) : p.resolve(m.result);
    } else if (m.type === "theme") applyTheme(m.effective);
    else if (m.type === "prefs") applyPrefs(m.prefs);
    else (listeners[m.type] || []).forEach(cb => cb(m));
  },
  /* Small persistent store per app. */
  data: {
    get: (name, dflt) => wos.call("data.get", { name }).then(v => (v === null || v === undefined ? dflt : v)),
    set: (name, value) => wos.call("data.set", { name, value }),
  },
};
window.wos = wos;

/* Accessibility choices from Settings, shared by every app. */
function applyPrefs(p) {
  const c = document.documentElement.classList;
  window.__speak = !!(p && p.speak);
  const z = p && p.text_scale ? p.text_scale / 100 : (p && p.zoom ? 1.15 : 1);      // percent from Settings, or the old on/off switch
  c.toggle("a11y-zoom", false); document.body && (document.body.style.zoom = z === 1 ? "" : String(z));
  c.toggle("a11y-contrast", !!(p && p.contrast)); c.toggle("a11y-motion", !!(p && p.motion));
  const A = { blue: "#0a84ff", purple: "#a25be0", pink: "#f0559a", red: "#f5453a", orange: "#f7821b", yellow: "#f5b800", green: "#30b34f", graphite: "#7d7d86" };
  const colour = A[p && p.accent] || A.blue, st = document.documentElement.style;
  const ink = (p && p.accent === "yellow") ? "#1a1a1a" : "#ffffff";
  st.setProperty("--accent", colour); st.setProperty("--btn", colour); st.setProperty("--accent-ink", ink); st.setProperty("--btn-ink", ink);
  st.setProperty("--sel", colour + "24");
}
function applyTheme(effective) { document.documentElement.dataset.theme = effective === "dark" ? "dark" : "light"; }

function toast(text) {
  const t = h("div.toast", text); document.body.append(t); setTimeout(() => t.remove(), 2200);
}
function confirmBox(title, text, okLabel = "OK", danger = false) {
  return new Promise(res => {
    const done = v => { back.remove(); res(v); };
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) done(false); } },
      h("div.modal", h("h2", title), h("p.muted", text),
        h("div.actions", h("button.btn.ghost", { onclick: () => done(false) }, "Cancel"),
          h("button.btn" + (danger ? ".danger" : ""), { onclick: () => done(true) }, okLabel))));
    document.body.append(back);
  });
}
function prompt2(title, value = "", placeholder = "") {
  return new Promise(res => {
    const input = h("input.field", { value, placeholder });
    const done = v => { back.remove(); res(v); };
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) done(null); } },
      h("div.modal", h("h2", title), input,
        h("div.actions", h("button.btn.ghost", { onclick: () => done(null) }, "Cancel"), h("button.btn", { onclick: () => done(input.value) }, "OK"))));
    input.addEventListener("keydown", e => { if (e.key === "Enter") done(input.value); if (e.key === "Escape") done(null); });
    document.body.append(back); input.focus(); input.select();
  });
}

function askPassword(title, hint = "") {
  return new Promise(res => {
    const input = h("input.field", { type: "password", placeholder: hint || "Password", style: "padding-right:38px" });
    const reveal = h("button", {
      type: "button", "aria-label": "Show password",
      style: "position:absolute;right:6px;top:50%;transform:translateY(-50%);width:26px;height:26px;border:0;background:none;color:var(--muted);cursor:pointer;display:grid;place-items:center",
      onclick: () => { const show = input.type === "password"; input.type = show ? "text" : "password"; reveal.innerHTML = icon(show ? "eyeoff" : "eye", 16); input.focus(); }
    }, icon("eye", 16));
    const field = h("div", { style: "position:relative" }, input, reveal);
    const done = v => { back.remove(); res(v); };
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) done(null); } },
      h("div.modal", h("h2", title), field,
        h("div.actions", h("button.btn.ghost", { onclick: () => done(null) }, "Cancel"), h("button.btn", { onclick: () => done(input.value) }, "OK"))));
    input.addEventListener("keydown", e => { if (e.key === "Enter") done(input.value); if (e.key === "Escape") done(null); });
    document.body.append(back); input.focus();
  });
}

const pad2 = n => String(n).padStart(2, "0");
const fmtSize = n => n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(0) + " KB" : n < 1073741824 ? (n / 1048576).toFixed(1) + " MB" : (n / 1073741824).toFixed(1) + " GB";
const initials = name => (name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map(p => p[0].toUpperCase()).join("") || "?";
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const debounce = (f, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => f(...a), ms); }; };

/* ---------- start-up ---------- */
async function boot(init) {
  wos.info = await wos.call("app.info");
  applyTheme(wos.info.effective_theme);
  try { applyPrefs(await wos.call("prefs.get")); } catch (e) { /* preferences are optional */ }
  document.title = wos.info.name || document.title;
  await init(wos.info);
}

/* ---------- mock host: sample data for the design preview ---------- */
const MOCK = { store: {}, theme: "light" };
/* preview stand-in for W-Life's notes API (see life.request below) */
function mockNotes(a, later) {
  MOCK.cn = MOCK.cn || { seq: 3, notes: [
    { id: "1", title: "Shopping list", body: "Milk\nBread\nCoffee", pinned: true, updated_at: "2026-10-13T10:00:00.000Z" },
    { id: "2", title: "Ideas", body: "A calendar that syncs.", pinned: false, updated_at: "2026-10-12T09:00:00.000Z" }] };
  if (window.__mockOffline) return later({ ok: false, offline: true, status: 0, message: "Could not reach W-Life. Check your connection." });
  const m = a.method, id = a.path.split("/")[4], n = MOCK.cn.notes.find(x => x.id === id), now = new Date().toISOString();
  if (m === "GET" && !id) return later({ ok: true, data: MOCK.cn.notes.map(({ id, title, pinned, updated_at }) => ({ id, title, pinned, updated_at })) });
  if (m === "GET") return later(n ? { ok: true, data: n } : { ok: false, status: 404, message: "Note not found" });
  if (m === "POST") { const nn = { id: String(MOCK.cn.seq++), title: a.body.title, body: a.body.body, pinned: false, updated_at: now }; MOCK.cn.notes.push(nn); return later({ ok: true, data: { id: nn.id } }); }
  if (m === "PUT" && n) { Object.assign(n, { title: a.body.title, body: a.body.body, pinned: !!a.body.pinned, updated_at: now }); return later({ ok: true, data: { ok: true } }); }
  if (m === "DELETE") { MOCK.cn.notes = MOCK.cn.notes.filter(x => x.id !== id); return later({ ok: true, data: { ok: true } }); }
  return later({ ok: false, status: 404, message: "Not found" });
}

function mockCall(method, a) {
  const later = v => new Promise(r => setTimeout(() => r(v), 30));
  const sampleFiles = [
    { name: "Documents", path: "/home/will/Documents", dir: true, size: 0, mtime: 1758300000 },
    { name: "Downloads", path: "/home/will/Downloads", dir: true, size: 0, mtime: 1758200000 },
    { name: "Pictures", path: "/home/will/Pictures", dir: true, size: 0, mtime: 1758100000 },
    { name: "notes.txt", path: "/home/will/notes.txt", dir: false, size: 1820, mtime: 1758290000, mime: "text/plain" },
    { name: "budget.ods", path: "/home/will/budget.ods", dir: false, size: 48211, mtime: 1758250000, mime: "application/vnd.oasis.opendocument.spreadsheet" },
    { name: "holiday.jpg", path: "/home/will/holiday.jpg", dir: false, size: 2481123, mtime: 1758240000, mime: "image/jpeg" },
  ];
  (window.__mockLog = window.__mockLog || []).push([method, a]);    // lets a preview check what the page asked the host to do
  switch (method) {
    case "monitor.sample": { const t = Date.now() / 1000; MOCK.mon = (MOCK.mon || 0) + 1; const wave = 20 + 15 * Math.sin(t / 5);
      return later({ cpu: Math.round(wave * 10) / 10, cores: 8, mem: { total_kb: 16e6, available_kb: 9e6, swap_total_kb: 2e6, swap_free_kb: 2e6 }, net_down: 120000 + 90000 * Math.sin(t / 3), net_up: 20000, uptime: 93000, load: ["0.42", "0.51", "0.48"],
        disk: { total: 512e9, free: 301e9 }, procs: [{ pid: 4021, name: "firefox-esr", cpu: 12.4, mem_mb: 812, state: "S", locked: false }, { pid: 3100, name: "W-OS Files", cpu: 0.6, mem_mb: 142, state: "S", locked: false },
        { pid: 2210, name: "W-OS Mail", cpu: 0.1, mem_mb: 118, state: "S", locked: false }, { pid: 1800, name: "Web Content", cpu: 3.2, mem_mb: 420, state: "S", locked: false }, { pid: 900, name: "xfwm4", cpu: 0.8, mem_mb: 64, state: "S", locked: true },
        { pid: 901, name: "wos shell", cpu: 1.9, mem_mb: 230, state: "S", locked: true }] }); }
    case "monitor.quit": return later(true);
    case "clock.get": return later(MOCK.clock || (MOCK.clock = { alarms: [{ id: "a1", time: "07:30", label: "Wake up", days: [0, 1, 2, 3, 4], on: true }, { id: "a2", time: "09:00", label: "", days: [], on: false }], timers: [] }));
    case "clock.set": MOCK.clock = a.data; return later(a.data);
    case "power.battery": return later({ pct: 62, status: "Discharging", health_pct: 89, health_words: "Good", cycles: 214, watts: 8.0, minutes_left: 186 });
    case "notif.apps": return later(MOCK.notifApps || (MOCK.notifApps = [{ name: "Firefox", count: 12, last: Date.now() / 1000 - 600, muted: false }, { name: "Mail", count: 4, last: Date.now() / 1000 - 7200, muted: false }, { name: "W-OS", count: 3, last: Date.now() / 1000 - 90000, muted: true }]));
    case "notif.mute": (MOCK.notifApps || []).forEach(x => { if (x.name === a.app) x.muted = !!a.muted; }); return later(true);
    case "vpn.list": return later(MOCK.vpn || (MOCK.vpn = [{ name: "Work London", uuid: "0b6a1c1e-1111-4222-8333-444455556666", kind: "VPN", active: false }, { name: "home-wg", uuid: "1b6a1c1e-1111-4222-8333-444455556666", kind: "WireGuard", active: true }]));
    case "vpn.import": if (!/\.(ovpn|conf)$/i.test(a.path)) return Promise.reject(new Error("Choose an .ovpn (OpenVPN) or .conf (WireGuard) file from your VPN provider.")); (MOCK.vpn = MOCK.vpn || []).push({ name: a.path.split("/").pop().replace(/\.\w+$/, ""), uuid: "2b6a1c1e-1111-4222-8333-44445555" + String(MOCK.vpn.length).padStart(4, "0"), kind: "VPN", active: false }); return later(true);
    case "vpn.connect": (MOCK.vpn || []).forEach(x => { if (x.uuid === a.uuid) x.active = true; }); return later(true);
    case "vpn.disconnect": (MOCK.vpn || []).forEach(x => { if (x.uuid === a.uuid) x.active = false; }); return later(true);
    case "vpn.forget": MOCK.vpn = (MOCK.vpn || []).filter(x => x.uuid !== a.uuid); return later(true);
    case "life.status": return later({ signed_in: !new URLSearchParams(location.search).has("local"), email: "will@wmail.life" });
    case "life.request": { if (/\/api\/v1\/notes/.test(a.path)) return mockNotes(a, later); MOCK.cloud = MOCK.cloud || { events: [], notes: [] };
      const p = a.path, m = a.method, d0 = new Date(); d0.setHours(0, 0, 0, 0); const t = (days, h, mi) => new Date(d0.getTime() + days * 86400000 + (h * 60 + (mi || 0)) * 60000).toISOString();
      if (!MOCK.cloud.seeded) { MOCK.cloud.seeded = 1; MOCK.cloud.events = [
        { id: "c1", title: "Stand-up", description: "", location: "Room 1", start_at: t(0, 9, 30), end_at: t(0, 10), all_day: false },
        { id: "c2", title: "Design review", description: "Bring the button spec", location: "", start_at: t(0, 9, 45), end_at: t(0, 11), all_day: false },
        { id: "c3", title: "Lunch with Ana", description: "", location: "High Street", start_at: t(0, 13), end_at: t(0, 14), all_day: false },
        { id: "c4", title: "Holiday", description: "", location: "", start_at: t(2, 0), end_at: t(3, 23, 59), all_day: true },
        { id: "c5", title: "Dentist", description: "", location: "", start_at: t(1, 15), end_at: t(1, 16), all_day: false }]; }
      if (window.__mockOffline) return later({ ok: false, offline: true, status: 0, message: "Could not reach W-Life. Check your connection." });
      if (/\/calendar\/events/.test(p)) {
        if (m === "GET") return later({ ok: true, data: MOCK.cloud.events });
        if (m === "POST") { const id = "n" + Date.now(); MOCK.cloud.events.push({ id, title: a.body.title, description: a.body.description, location: a.body.location, start_at: a.body.startAt, end_at: a.body.endAt, all_day: a.body.allDay }); return later({ ok: true, data: { id } }); }
        const id = p.split("/").pop();
        if (m === "PUT") { const e = MOCK.cloud.events.find(x => x.id === id); if (e) Object.assign(e, { title: a.body.title, description: a.body.description, location: a.body.location, start_at: a.body.startAt, end_at: a.body.endAt, all_day: a.body.allDay }); return later({ ok: true, data: { ok: true } }); }
        if (m === "DELETE") { MOCK.cloud.events = MOCK.cloud.events.filter(x => x.id !== id); return later({ ok: true, data: { ok: true } }); }
      }
      return later({ ok: false, status: 404, message: "Not found" }); }
    case "backup.status": return later(MOCK.backup || { dest: "/media/will/BACKUP", auto: true, connected: true, drives: [{ name: "BACKUP", path: "/media/will/BACKUP" }], running: false, files: 0, last_success: Date.now() / 1000 - 7200, error: "", skipped: 2,
      snapshots: ["2026-10-14_090000", "2026-10-13_090000", "2026-10-12_090000"], interval: 86400 });
    case "backup.set": case "backup.run": case "backup.cancel": case "backup.delete": return later(true);
    case "backup.browse": return later(a.rel ? [{ name: "notes.txt", dir: false, size: 1820 }] : [{ name: "Documents", dir: true, size: 0 }, { name: "Pictures", dir: true, size: 0 }, { name: "todo.txt", dir: false, size: 220 }]);
    case "backup.restore": return later("/home/will/Restored from backup/" + a.rel.split("/").pop());
    case "license.status": return later(window.__mockLicense || { state: "unlicensed", premium: false, edition: "", device: "1A2B-3C4D-5E6F-7A8B", key_error: "", live: false, limited: true, price_gbp: 150, buy_url: "https://example.com/buy" });
    case "license.activate": if (!/^WOS4-/.test(String(a.key).trim())) return Promise.reject(new Error("That does not look like a W-OS product key.")); window.__mockLicense = { state: "key", premium: false, edition: "full", device: "1A2B-3C4D-5E6F-7A8B", key_error: "", issued: "2026-10-14", price_gbp: 150, buy_url: "" }; return later(window.__mockLicense);
    case "license.remove": window.__mockLicense = null; return later({ state: "unlicensed", premium: false, edition: "", device: "1A2B-3C4D-5E6F-7A8B", key_error: "", price_gbp: 150, buy_url: "" });
    case "input.get": return later({ tap: true, natural: true, speed: 0, repeat_delay: 400, repeat_rate: 25, layout: "gb", delays: [200, 300, 400, 600, 800], rates: [10, 15, 25, 35, 50],
      layouts: [["gb", "English (UK)"], ["us", "English (US)"], ["ie", "Irish"], ["es", "Spanish"], ["fr", "French"], ["de", "German"], ["it", "Italian"]] });
    case "input.set": case "input.layout.set": return later(true);
    case "focus.get": return later(MOCK.focus || (MOCK.focus = { on: true, from: "22:00", to: "07:00" }));
    case "focus.set": MOCK.focus = Object.assign(MOCK.focus || {}, a); return later(MOCK.focus);
    case "sound.state": return later({ inputs: [{ id: "56", name: "alsa_input.pci.analog-stereo", label: "Built-in microphone", volume: 69, muted: false, default: true }, { id: "57", name: "usb-mic", label: "USB headset", volume: 80, muted: false, default: false }],
      apps: [{ id: "52", name: "Firefox", icon: "firefox-esr", volume: 60, muted: false }, { id: "61", name: "Music", icon: "", volume: 100, muted: true }] });
    case "sound.set": case "sound.input.set": return later(true);
    case "firewall.set": return later(!!a.on);
    case "app.quit": case "alarm.play": case "alarm.stop": case "alarm.snooze": return later(true);
    case "mail.presets": return later([{ id: "wmail", label: "W-Mail", help: "Your W-Mail address and password." }, { id: "icloud", label: "iCloud", help: "Use an app-specific password from appleid.apple.com (Sign-In and Security)." },
      { id: "yahoo", label: "Yahoo", help: "Use an app password from your Yahoo account security page." }, { id: "fastmail", label: "Fastmail", help: "Use an app password from Fastmail settings." },
      { id: "custom", label: "Other (IMAP)", help: "Enter the server details your provider gave you." }]);
    case "mail.accounts": return later(MOCK.mail || (MOCK.mail = new URLSearchParams(location.search).has("empty") ? [] : [{ id: "m1", provider: "wmail", address: "will@wmail.life", name: "William" }]));
    case "mail.add": if (String(a.password) === "wrong") return Promise.reject(new Error("The server did not accept the address or password.")); MOCK.mail = (MOCK.mail || []).concat({ id: uid(), provider: a.provider, address: a.address, name: a.name }); return later(MOCK.mail[MOCK.mail.length - 1]);
    case "mail.remove": MOCK.mail = (MOCK.mail || []).filter(x => x.id !== a.account); return later(true);
    case "mail.folders": return later([{ name: "INBOX", role: "inbox" }, { name: "Drafts", role: "drafts" }, { name: "Sent", role: "sent" }, { name: "Junk", role: "junk" }, { name: "Trash", role: "bin" }]);
    case "mail.list": return later(a.folder === "INBOX" ? [{ uid: "3", from: "Ana Pérez", addr: "ana@example.org", to: "will@wmail.life", subject: "Lunch on Friday?", date: Date.now() - 3600e3, read: false },
      { uid: "2", from: "W-OS Team", addr: "hello@willgraves.co.uk", to: "will@wmail.life", subject: "Welcome to W-Mail", date: Date.now() - 86400e3 * 3, read: true }] : []);
    case "mail.read": return later({ body: "Hi William,\n\nAre you free for lunch on Friday? There is a new place on the high street.\n\nAna", attachments: a.uid === "3" ? [{ index: 0, name: "menu.pdf", size: 184320, type: "application/pdf" }, { index: 1, name: "map.png", size: 2411724, type: "image/png" }] : [], message_id: "<m" + a.uid + "@example.org>", references: "" });
    case "mail.send": if (window.__mockFailSend) return Promise.reject(new Error("Could not reach mail.wmail.life")); return later({ sent: true, filed: true });
    case "mail.contacts": return later([{ name: "Ana Pérez", email: "ana@example.org" }, { name: "Bob Smith", email: "bob@example.net" }, { name: "", email: "carol@example.com" }]);
    case "mail.save_attachment": return later("/home/will/Downloads/" + (a.index ? "map.png" : "menu.pdf"));
    case "mail.delete": case "mail.mark": case "mail.flag": case "mail.move": return later(true);
    case "mail.save_draft": return later("Drafts");
    case "fs.search": return later([{ name: "holiday-plan.txt", path: "/home/will/Documents/Trips/holiday-plan.txt", dir: false, size: 900, mtime: 1758290000, mime: "text/plain", parent: "/home/will/Documents/Trips" },
      { name: "Holiday photos", path: "/home/will/Pictures/Holiday photos", dir: true, size: 0, mtime: 1758290000, mime: "inode/directory", parent: "/home/will/Pictures" }].filter(f => f.name.toLowerCase().includes(String(a.query).toLowerCase())));
    case "fs.compress": return later("/home/will/Archive.zip");
    case "fs.extract": return later("/home/will/unpacked");
    case "fs.new_file": return later("/home/will/Untitled.txt");
    case "fs.apps_for": return later([{ id: "firefox-esr.desktop", name: "Firefox", default: true }, { id: "wos-notepad.desktop", name: "Notepad", default: false }]);
    case "fs.open_with": return later(true);
    case "app.info": return later({ id: "preview", name: document.title, user: "will", full_name: "William", home: "/home/will", lang: "en_GB",
      theme: MOCK.theme, effective_theme: new URLSearchParams(location.search).get("theme") || MOCK.theme, version: "1.0.143194163", hostname: "wos3",
      args: new URLSearchParams(location.search).getAll("arg") });
    case "data.get": return later(MOCK.store[a.name] ?? null);
    case "data.set": MOCK.store[a.name] = a.value; return later(true);
    case "prefs.get": return later({ zoom: false, contrast: false, motion: false, speak: false, accent: "blue", text_scale: window.__mockScale || 100, cursor_size: 24, sticky: false, slow: false, bounce: false });
    case "prefs.set": return later(true);
    case "theme.get": return later(MOCK.theme);
    case "theme.set": MOCK.theme = a.mode; applyTheme(a.mode === "dark" ? "dark" : "light"); return later(true);
    case "fs.home": return later("/home/will");
    case "fs.places": return later([{ name: "Home", path: "/home/will", icon: "home" }, { name: "Documents", path: "/home/will/Documents", icon: "doc" },
      { name: "Downloads", path: "/home/will/Downloads", icon: "down" }, { name: "Pictures", path: "/home/will/Pictures", icon: "image" }]);
    case "account.get": return later({ type: "waccount", email: "will@example.com", name: "William", user: "will" });
    case "sys.updates": return later({ current: "1.0.143194163", checked: "just now" });
    case "fs.list": return later(sampleFiles.filter(f => a.path === "/home/will" || !f.path.startsWith("/home/will/") || true).map(f => ({ ...f, path: a.path.replace(/\/$/, "") + "/" + f.name })));
    case "fs.readText": return later("Sample text for the preview.\nSecond line.");
    case "fs.read_text": { const q = new URLSearchParams(location.search); if (q.get("huge")) return later("x".repeat(2000001));
      return later(q.get("text") !== null ? q.get("text") : "Shopping list\n\nmilk\neggs\nbread\n"); }
    case "fs.write_text": if (window.__mockFailWrite) return Promise.reject(new Error("Disk full")); window.__mockWritten = a; return later(true);
    case "fs.bin.list": return later([{ name: "old-notes.txt", id: "1", dir: false, orig: "/home/will/old-notes.txt" }]);
    case "fs.copy": case "fs.move": case "fs.bin.restore": case "fs.bin.empty": case "sys.speak": return later(true);
    case "fs.writeText": case "fs.mkdir": case "fs.rename": case "fs.trash": case "fs.open": case "sys.launch": case "sys.openUrl": return later(true);
    case "weather.search": return later([{ name: "Windermere", region: "England", country: "United Kingdom", lat: 54.38, lon: -2.9 }, { name: "Windermere", region: "Florida", country: "United States", lat: 28.49, lon: -81.53 }].filter(p => p.name.toLowerCase().includes(String(a.query).toLowerCase().slice(0, 4)) || true));
    case "weather.forecast": { const now = new Date(), p = n => String(n).padStart(2, "0"), iso = d => `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`, hr = new Date(now); hr.setMinutes(0, 0, 0);
      const hours = Array.from({ length: 72 }, (_, i) => new Date(hr.getTime() + (i - 2) * 3600000));
      return later({ timezone: "Europe/London", current: { temp: 11.2, feels: 9.1, humidity: 82, code: 61, wind: 14.4, day: now.getHours() >= 7 && now.getHours() < 19, time: iso(hr) + "T" + p(hr.getHours()) + ":00" },
        hourly: { time: hours.map(d => iso(d) + "T" + p(d.getHours()) + ":00"), temp: hours.map((d, i) => Math.round((9 + 4 * Math.sin(i / 4)) * 10) / 10), code: hours.map((d, i) => [61, 3, 2, 0, 80, 3][i % 6]), rain: hours.map((d, i) => (i * 13) % 90) },
        daily: { time: Array.from({ length: 7 }, (_, i) => iso(new Date(now.getTime() + i * 86400000))), code: [61, 3, 0, 2, 80, 95, 71], max: [13, 12, 15, 14, 11, 10, 2], min: [7, 6, 5, 6, 5, 4, -2], rain: [80, 20, 0, 10, 60, 90, 70],
          sunrise: Array(7).fill(iso(now) + "T07:41"), sunset: Array(7).fill(iso(now) + "T18:04") } }); }
    case "photos.list": { const svg = i => "data:image/svg+xml;utf8," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${(i * 47) % 360},70%,60%)"/><stop offset="1" stop-color="hsl(${(i * 47 + 60) % 360},65%,35%)"/></linearGradient></defs><rect width="1200" height="800" fill="url(#g)"/><circle cx="${300 + (i % 4) * 150}" cy="300" r="120" fill="rgba(255,255,255,.35)"/><rect x="560" y="420" width="420" height="220" rx="30" fill="rgba(0,0,0,.25)"/></svg>`);
      const dirs = ["Pictures", "Pictures", "Pictures/Holiday", "Pictures/Holiday", "Pictures/Screenshots"];
      return later(Array.from({ length: 14 }, (_, i) => { const d = dirs[i % dirs.length], n = d.endsWith("Screenshots") ? `Screenshot 2026-10-${10 + i}.png` : `IMG_${1000 + i}.jpg`; return { name: n, path: `/home/will/${d}/${n}`, uri: svg(i), mtime: 1760000000 + i * 86400 * 3, size: 1800000 + i * 91000 }; })); }
    case "photos.save_edit": return later("/home/will/Pictures/" + a.path.split("/").pop().replace(/(\.\w+)$/, " (edited)$1"));
    case "sys.info": return later({ os: "William Graves Operating Services (W-OS) 4", nickname: "Windermere", version: "Penguin 4ALPHA", build: "1.0.143194163",
      device: "innotek VirtualBox", cpu: "Intel Core Ultra 5", memory_gb: 4, storage_gb: 19, device_id: "d27a8f7b7040" });
    case "sys.wifi.list": return later([{ ssid: "Home-5G", signal: 82, secure: true, enterprise: false, saved: true, active: true }, { ssid: "BT-Hub6-4XK2", signal: 55, secure: true, enterprise: false, saved: true },
      { ssid: "eduroam", signal: 50, secure: true, enterprise: true, saved: false }, { ssid: "Cafe", signal: 45, secure: true, enterprise: false, saved: false }, { ssid: "Guest", signal: 40, secure: false, enterprise: false, saved: false }]);
    case "sys.wifi.connect": return later(window.__mockWifiResult || { ok: true });
    case "sys.wifi.enterprise": case "sys.wifi.forget": case "sys.airplane.set": return later(a && a.ssid === "fail" ? { ok: false, message: "Error: Connection activation failed" } : { ok: true });
    case "sys.airplane.get": return later({ on: false });
    case "sys.volume.get": return later(60);
    case "sys.volume.set": return later(true);
    case "sys.apps": return later([{ id: "firefox-esr.desktop", name: "Firefox" }, { id: "wos-files.desktop", name: "Files" }]);
    case "users.list": return later([{ name: "will", full: "William", admin: true, me: true }, { name: "guest1", full: "Alex", admin: false }]);
    case "users.add": case "users.passwd": case "users.del": case "sys.tz.set": case "sys.hostname.set": case "power.set": case "input.set": case "input.layout.set":
    case "displays.set": case "bt.power": case "sound.output.set": case "store.install": case "store.remove": case "store.refresh": case "account.signin": case "account.signout": return later(true);
    case "sys.tz.get": return later({ zone: "Europe/London", synced: true });
    case "sys.tz.list": return later(["Europe/London", "Europe/Madrid", "Europe/Paris", "America/New_York", "America/Los_Angeles", "Asia/Tokyo", "Australia/Sydney"]);
    case "displays.list": return later([{ name: "eDP-1", modes: ["1920x1200", "1920x1080", "1600x900", "1280x800"], current: "1920x1200", primary: true }]);
    case "power.get": return later({ lock_min: 5, off_min: 10 });
    case "bt.status": return later({ available: true, on: true });
    case "bt.devices": return later([{ mac: "AA:BB:CC:DD:EE:01", name: "Headphones", paired: true, connected: true }, { mac: "AA:BB:CC:DD:EE:02", name: "Keyboard", paired: false, connected: false }]);
    case "bt.action": return later({ ok: true });
    case "sound.outputs": return later([{ name: "speakers", label: "Built-in speakers", default: true }, { name: "hdmi", label: "HDMI display", default: false }]);
    case "printers.list": return later({ printers: [{ name: "Save-as-PDF", state: "idle" }, { name: "Kitchen_Printer", state: "idle" }], default: "Save-as-PDF" });
    case "printers.discover": return later([{ uri: "dnssd://Office%20Printer._ipp._tcp.local/", name: "Office Printer", kind: "network", added: false },
      { uri: "usb://Brother/HL-L2350DW", name: "Brother HL-L2350DW", kind: "usb", added: false }, { uri: "ipp://kitchen/ipp/print", name: "Kitchen Printer", kind: "network", added: true }]);
    case "printers.add": case "printers.remove": case "printers.default": case "printers.test": return later(true);
    case "phone.status": return later({ running: true, port: 8620, addresses: ["192.168.1.23"], code: "482913", phones: [{ name: "Pixel 8", added: 1758400000 }], prefs: { contacts: true, calendar: true, photos: false }, last: { contacts: { time: 1758400100, count: 212, from: "Pixel 8" } } });
    case "phone.set_pref": case "phone.forget": return later(true);
    case "phone.new_code": return later("730155");
    case "desktop.get": return later({ wallpaper: "default", dock: "medium", clock24: true, seconds: false, date: true, battery: true });
    case "desktop.wallpapers": return later([{ id: "default", name: "Windermere dusk", category: "Featured", uri: "../../ui/wallpaper.webp" }, { id: "builtin:aurora", name: "Aurora", category: "Gradients", uri: "../../wallpapers/aurora.svg" },
      { id: "builtin:dusk", name: "Dusk", category: "Gradients", uri: "../../wallpapers/dusk.svg" }, { id: "builtin:meadow", name: "Meadow", category: "Gradients", uri: "../../wallpapers/meadow.svg" }, { id: "builtin:graphite", name: "Graphite", category: "Gradients", uri: "../../wallpapers/graphite.svg" }, { id: "builtin:sunrise", name: "Sunrise", category: "Gradients", uri: "../../wallpapers/sunrise.svg" }]);
    case "desktop.set": case "dnd.set": case "privacy.set": case "defaults.set": case "files.bin.empty": return later(true);
    case "dnd.get": return later(false);
    case "privacy.get": return later({ share: false });
    case "firewall.status": return later(true);
    case "storage.usage": return later({ total: 64e9, free: 47e9, bin: 3.2e8, items: [{ name: "Documents", bytes: 1.8e9 }, { name: "Pictures", bytes: 4.6e9 }, { name: "Downloads", bytes: 2.1e9 }, { name: "Music", bytes: 9e8 }, { name: "Bin", bytes: 3.2e8 }] });
    case "defaults.get": return later({ browser: "firefox-esr.desktop", options: [{ id: "firefox-esr.desktop", name: "Firefox" }, { id: "com.microsoft.Edge.desktop", name: "Microsoft Edge" }] });
    case "store.catalogue": return fetch("../../store/catalogue.json").then(r => r.json()).then(j => j.apps.map(a => ({ ...a, installed: false })))
      .catch(() => [{ package: "vlc", name: "VLC", by: "VideoLAN", cat: "Video", blurb: "Plays nearly any video or audio file.", glyph: "image", installed: false }]);
    case "sys.notices": return later({ offer: "Source offer text.", packages: [{ name: "linux-image", version: "6.1", licence: "GPL-2", home: "" }] });
    case "feedback.send": return later({ sent: false });
    case "updates.status": return later({ version: "1.0.143194163", history: [{ id: "shell", version: "1.0.143194164", time: 1758400000, result: "installed", kind: "feature", rollback_available: true }], configured: true });
    case "updates.check": return later({ version: "1.0.143194163", available: [{ id: "shell", version: "1.0.143194165", kind: "feature", action: "ask", notes: "Faster launcher" }] });
    case "updates.apply": return later({ ok: true, version: "1.0.143194165", restart_needed: true });
    case "updates.rollback": case "sys.restart": return later(true);
    default: return later(null);
  }
}

/* Read aloud (Settings > Accessibility): select text and press Alt+R, or press Alt+R with nothing selected
   to hear the whole page. Alt+R again stops it. */
document.addEventListener("keydown", e => {
  if (!window.__speak || !e.altKey || e.key.toLowerCase() !== "r") return;
  e.preventDefault();
  const sel = String(window.getSelection() || "").trim();
  wos.call("sys.speak", { text: sel || document.body.innerText });
});
