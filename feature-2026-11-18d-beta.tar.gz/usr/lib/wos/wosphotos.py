"""Saving an edited picture from the Photos app: decode what the page's canvas produced and pick a safe name."""
import base64
import os
import re

MAX_BYTES = 60 * 1024 * 1024
TYPES = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp"}
MAGIC = {"image/png": b"\x89PNG\r\n\x1a\n", "image/jpeg": b"\xff\xd8\xff", "image/webp": b"RIFF"}


class PhotoError(Exception):
    """Message safe to show to the person."""


def decode_data_url(url):
    """'data:image/png;base64,....' -> (mime, bytes). Refuses anything that is not a real PNG, JPEG or WebP."""
    m = re.fullmatch(r"data:(image/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=\s]+)", str(url or ""))
    if not m:
        raise PhotoError("That is not a picture I can save.")
    mime = m.group(1)
    if len(m.group(2)) > MAX_BYTES * 4 // 3 + 8:
        raise PhotoError("That picture is too big to save.")
    try:
        data = base64.b64decode(m.group(2), validate=False)
    except ValueError:
        raise PhotoError("That is not a picture I can save.")
    if len(data) > MAX_BYTES:
        raise PhotoError("That picture is too big to save.")
    if not data.startswith(MAGIC[mime]):
        raise PhotoError("That is not a picture I can save.")
    return mime, data


def edited_path(original, mime):
    """Next to the original, never over it: 'holiday.jpg' -> 'holiday (edited).jpg', then '(edited 2)'...
    Keeps the original's file ending when it matches the picture type, otherwise uses the type's own ending."""
    folder, name = os.path.split(original)
    stem, ext = os.path.splitext(name)
    same = {"image/png": (".png",), "image/jpeg": (".jpg", ".jpeg"), "image/webp": (".webp",)}[mime]
    ext = ext.lower() if ext.lower() in same else TYPES[mime]
    out, n = os.path.join(folder, "%s (edited)%s" % (stem, ext)), 2
    while os.path.exists(out):
        out = os.path.join(folder, "%s (edited %d)%s" % (stem, n, ext))
        n += 1
    return out
