"""Battery health and per-app notification settings: parsing helpers (pure) so they can be tested anywhere."""
import os
import re


def _num(files, name):
    try:
        return int(str(files.get(name, "")).strip())
    except ValueError:
        return None


def battery_info(files):
    """files: contents of one /sys/class/power_supply/<battery>/ folder as {file name: text}.

    Returns {pct, status, health_pct, cycles, watts, minutes_left} with None for anything the hardware does not report.
    Health is the full-charge capacity now against what the battery was designed for."""
    full, design = _num(files, "energy_full"), _num(files, "energy_full_design")
    if not full or not design:
        full, design = _num(files, "charge_full"), _num(files, "charge_full_design")
    health = round(100.0 * full / design) if full and design else None
    if health is not None:
        health = min(health, 100)
    status = str(files.get("status", "")).strip()
    watts = None
    minutes = None
    power = _num(files, "power_now")
    if power:
        watts = round(power / 1e6, 1)
    now = _num(files, "energy_now") or _num(files, "charge_now")
    rate = power or _num(files, "current_now")
    if now and rate and rate > 0:
        if status == "Discharging":
            minutes = int(now * 60 / rate)
        elif status == "Charging" and full and full > now:
            minutes = int((full - now) * 60 / rate)
    cycles = _num(files, "cycle_count")
    return {"pct": _num(files, "capacity") or 0, "status": status, "health_pct": health,
            "cycles": cycles if cycles and cycles > 0 else None, "watts": watts, "minutes_left": minutes}


def health_words(health):
    if health is None:
        return ""
    if health >= 90:
        return "Excellent"
    if health >= 80:
        return "Good"
    if health >= 60:
        return "Fair. It holds noticeably less charge than when new."
    return "Worn. Consider replacing the battery."


def read_battery(base="/sys/class/power_supply"):
    try:
        for n in sorted(os.listdir(base)):
            folder = os.path.join(base, n)
            try:
                with open(os.path.join(folder, "type")) as f:
                    if f.read().strip() != "Battery":
                        continue
            except OSError:
                continue
            files = {}
            for name in ("capacity", "status", "energy_full", "energy_full_design", "charge_full", "charge_full_design", "energy_now", "charge_now",
                         "power_now", "current_now", "cycle_count"):
                try:
                    with open(os.path.join(folder, name)) as f:
                        files[name] = f.read().strip()
                except OSError:
                    pass
            return battery_info(files)
    except OSError:
        pass
    return None


# ---- xfce4-notifyd: apps whose banners are muted
def parse_xfconf_array(text):
    """Output of `xfconf-query -p <array property>` -> list of strings."""
    lines = text.splitlines()
    if not lines or "array" not in lines[0]:
        return []
    return [l for l in lines[1:] if l.strip()]


def mute_command(apps):
    """xfconf-query arguments that set the muted-applications list to exactly `apps` (an empty list removes it)."""
    base = ["xfconf-query", "-c", "xfce4-notifyd", "-p", "/applications/muted_applications"]
    if not apps:
        return base + ["-r"]
    args = base + ["-n", "-a"]
    for a in apps:
        args += ["-t", "string", "-s", a]
    return args


def clean_app(name):
    name = re.sub(r"[\x00-\x1f]", "", str(name or "")).strip()
    if not name or len(name) > 60:
        raise ValueError("That is not an app name")
    return name


def app_summary(entries, muted):
    """Apps seen in the notification history, busiest first: [{name, count, last, muted}]. Muted apps stay listed
    even when they have no history, so they can be turned back on."""
    seen = {}
    for e in entries:
        if not isinstance(e, dict) or not e.get("app"):
            continue
        row = seen.setdefault(e["app"], {"name": e["app"], "count": 0, "last": 0})
        row["count"] += 1
        row["last"] = max(row["last"], e.get("ts", 0))
    for m in muted:
        seen.setdefault(m, {"name": m, "count": 0, "last": 0})
    rows = sorted(seen.values(), key=lambda r: (-r["count"], r["name"].lower()))
    for r in rows:
        r["muted"] = r["name"] in muted
    return rows
