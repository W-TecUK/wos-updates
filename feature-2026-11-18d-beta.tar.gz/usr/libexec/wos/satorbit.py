"""satorbit: Orbit Pro, the W-OS 4 favourites fan, native GTK (no web). Press the ring and six favourite apps fan out
on one arc around it, over a solid dimmed backdrop (no blur: the shell is software-drawn). The "All apps" pill opens
Index, the full launcher (satindex.py).

Geometry is the designer's (v9 LAUNCHER-SPEC.md, Orbit Pro), written for a 1920x1080 screen and scaled to the real one:
  ring: 112 px circle centred at (170, 910), white, W mark, 6 px yellow outline
  icons: 88 px, icon i of 6 at angle -8 - i*15 degrees, radius 440
  "All apps" pill: left = ring centre + 72, 48 px high, #0C2F6F with a #2E4C83 edge, grid icon + label
"""
import math

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk  # noqa: E402

REF_W, REF_H = 1920.0, 1080.0
RING_CENTRE = (170.0, 910.0)
RING_SIZE = 112
ICON_SIZE = 88
RADII = (440.0, 440.0)
ARC_START, ARC_STEP = -8.0, 15.0
# What is in the Orbit: label, icon name, .desktop id (the designer's order, with the apps W-OS has today)
ORBIT_APPS = [
    ("files", "wos-files", "wos-files"),
    ("web", "firefox-esr", "firefox-esr"),
    ("mail", "wos-mail", "wos-mail"),
    ("photos", "wos-photos", "wos-photos"),
    ("notes", "wos-notepad", "wos-notepad"),
    ("settings", "wos-settings", "wos-settings"),
]
MARK = "/usr/share/wos/satisfaction/icons/wos-mark-dark.svg"


def icon_centres(scale_x, scale_y, count=len(ORBIT_APPS)):
    """Screen-pixel centres of the arc icons, in order. Pure arithmetic, so it is testable."""
    out = []
    for i in range(count):
        a = math.radians(ARC_START - i * ARC_STEP)
        r = RADII[i % 2]
        out.append((int((RING_CENTRE[0] + r * math.cos(a)) * scale_x), int((RING_CENTRE[1] + r * math.sin(a)) * scale_y)))
    return out


class Orbit:
    def __init__(self, launch, on_all_apps=None, glass=None):
        self.glass = glass
        self.bubbles = []
        self.pill_rect = None
        self.launch = launch
        self.on_all_apps = on_all_apps
        self.win = Gtk.Window()
        self.win.set_decorated(False)
        self.win.set_skip_taskbar_hint(True)
        self.win.set_skip_pager_hint(True)
        self.win.set_type_hint(Gdk.WindowTypeHint.POPUP_MENU)
        self.win.set_keep_above(True)
        visual = self.win.get_screen().get_rgba_visual()
        if visual is not None:              # a compositor is running: the dim backdrop lets the wallpaper through
            self.win.set_visual(visual)
        self.win.set_app_paintable(True)
        self.win.get_style_context().add_class("sat-orbit")
        self.win.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.KEY_PRESS_MASK)
        self.win.connect("button-press-event", lambda *_: self.hide())     # a click on the backdrop closes it
        self.win.connect("key-press-event", self._key)
        self.win.connect("delete-event", lambda *_: True)
        self.win.connect("draw", self._draw_glass)
        self.fixed = Gtk.Fixed()
        self.win.add(self.fixed)
        self.shown = False

    def _key(self, _w, event):
        if event.keyval == Gdk.KEY_Escape:
            self.hide()
            return True
        return False

    def _draw_glass(self, win, cr):
        """A frosted bubble behind each favourite and behind the All apps pill (drawn before the buttons)."""
        if self.glass is None:
            return False
        for (cx, cy, r) in self.bubbles:
            self.glass.paint(cr, cx - r, cy - r, 2 * r, 2 * r, (r, r, r, r))
        if self.pill_rect:
            x, y, w, h = self.pill_rect
            self.glass.paint(cr, x, y, w, h, (h / 2.0,) * 4)
        return False

    def _build(self, geo):
        self.bubbles = []
        for child in self.fixed.get_children():
            self.fixed.remove(child)
        sx, sy = geo.width / REF_W, geo.height / REF_H
        scale = min(sx, sy)
        ring = max(int(RING_SIZE * scale), 48)
        halo = int((RING_SIZE + 60) * scale)
        cx, cy = int(RING_CENTRE[0] * sx), int(RING_CENTRE[1] * sy)
        icon = max(int(ICON_SIZE * scale), 40)

        halo_box = Gtk.Box()
        halo_box.set_size_request(halo, halo)
        halo_box.get_style_context().add_class("sat-orbit-halo")
        self.fixed.put(halo_box, cx - halo // 2, cy - halo // 2)
        ring_btn = Gtk.Button()
        ring_btn.set_size_request(ring, ring)
        ring_btn.set_relief(Gtk.ReliefStyle.NONE)
        ring_btn.get_style_context().add_class("sat-orbit-ring")
        try:
            mark = Gtk.Image.new_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_size(MARK, int(56 * scale), int(56 * scale)))
            ring_btn.set_image(mark)
        except GLib.Error:
            ring_btn.set_label("W")
        ring_btn.connect("clicked", lambda *_: self.hide())
        self.fixed.put(ring_btn, cx - ring // 2, cy - ring // 2)

        for (label, icon_name, app_id), (x, y) in zip(ORBIT_APPS, icon_centres(sx, sy)):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(6 * scale))
            btn = Gtk.Button()
            btn.set_relief(Gtk.ReliefStyle.NONE)
            btn.set_image(self._icon(icon_name, icon))
            btn.get_style_context().add_class("sat-orbit-icon")
            btn.connect("clicked", self._open, app_id)
            name = Gtk.Label(label=label)
            name.get_style_context().add_class("sat-orbit-label")
            box.pack_start(btn, False, False, 0)
            box.pack_start(name, False, False, 0)
            self.fixed.put(box, x - icon // 2 - 6, y - icon // 2 - 6)
            self.bubbles.append((x, y, int(icon * 0.68)))

        pill = Gtk.Button()
        pill.set_relief(Gtk.ReliefStyle.NONE)
        pill.get_style_context().add_class("sat-orbit-all")
        row = Gtk.Box(spacing=10)
        row.pack_start(Gtk.Image.new_from_icon_name("view-app-grid-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        row.pack_start(Gtk.Label(label="All apps"), False, False, 0)
        pill.add(row)
        pill.set_size_request(-1, int(48 * scale))
        pill.connect("clicked", self._all_apps)
        self.fixed.put(pill, cx + int(72 * scale), cy - int(24 * scale))
        self.pill_rect = (cx + int(72 * scale), cy - int(24 * scale), int(150 * scale), int(48 * scale))

    def _all_apps(self, *_):
        self.hide()
        if self.on_all_apps:
            self.on_all_apps()

    @staticmethod
    def _icon(name, size):
        img = Gtk.Image.new_from_icon_name(name, Gtk.IconSize.DIALOG)
        img.set_pixel_size(size)
        return img

    def _open(self, _btn, app_id):
        self.hide()
        self.launch(app_id)

    def show(self, geo):
        self.win.move(geo.x, geo.y)
        self.win.resize(geo.width, geo.height)
        self._build(geo)
        self.win.show_all()
        self.win.present()
        self.shown = True

    def hide(self):
        self.win.hide()
        self.shown = False

    def toggle(self, geo):
        self.hide() if self.shown else self.show(geo)
