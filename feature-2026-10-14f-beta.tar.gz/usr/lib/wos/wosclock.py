"""Clock app data: alarms and timers that still go off when the Clock window is closed.

The Clock app saves ~/.config/wos/clock.json; the shell reads the same file every few seconds and rings what is due.
Pure functions here so the rules can be tested.
"""
import datetime
import re
import uuid

TIME_RE = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")
MAX_ITEMS = 50
GRACE_SECONDS = 120          # an alarm still rings if the shell was busy or the poll was late, but not for old news


def clean_label(text, limit=60):
    return re.sub(r"[\x00-\x1f]", " ", str(text or "")).strip()[:limit]


def normalise(data):
    """Whatever the app saved -> a safe, bounded {alarms, timers}. Never raises."""
    alarms, timers = [], []
    if not isinstance(data, dict):
        return {"alarms": alarms, "timers": timers}
    for a in (data.get("alarms") or [])[:MAX_ITEMS]:
        if not isinstance(a, dict) or not TIME_RE.match(str(a.get("time", ""))):
            continue
        days = sorted({int(d) for d in (a.get("days") or []) if str(d).isdigit() and 0 <= int(d) <= 6})
        alarms.append({"id": str(a.get("id") or uuid.uuid4().hex[:8])[:20], "time": a["time"], "label": clean_label(a.get("label")),
                       "days": days, "on": bool(a.get("on", True))})
    for t in (data.get("timers") or [])[:MAX_ITEMS]:
        try:
            end = float(t["end"])
        except (KeyError, TypeError, ValueError):
            continue
        timers.append({"id": str(t.get("id") or uuid.uuid4().hex[:8])[:20], "end": end, "label": clean_label(t.get("label")), "done": bool(t.get("done"))})
    return {"alarms": alarms, "timers": timers}


def due(data, now, fired):
    """What should ring right now.

    now: datetime (local). fired: dict of ring-keys already rung (mutated and pruned). Returns [(key, title, body)]."""
    data = normalise(data)
    rings = []
    today = now.strftime("%Y-%m-%d")
    for k in [k for k in fired if not k.endswith(today) and not k.startswith("t:")]:
        del fired[k]
    for a in data["alarms"]:
        if not a["on"]:
            continue
        if a["days"] and now.weekday() not in a["days"]:
            continue
        h, m = int(a["time"][:2]), int(a["time"][3:])
        target = now.replace(hour=h, minute=m, second=0, microsecond=0)
        late = (now - target).total_seconds()
        key = "a:%s:%s" % (a["id"], today)
        if 0 <= late <= GRACE_SECONDS and key not in fired:
            fired[key] = True
            rings.append((key, a["label"] or "Alarm", a["time"]))
    ts = now.timestamp()
    for t in data["timers"]:
        key = "t:%s" % t["id"]
        if not t["done"] and t["end"] <= ts and key not in fired:
            fired[key] = True
            rings.append((key, t["label"] or "Timer finished", "Time is up"))
    return rings


def next_alarm(data, now):
    """The next enabled alarm as (datetime, label) or None, for 'rings in 7 h 30 min'."""
    best = None
    for a in normalise(data)["alarms"]:
        if not a["on"]:
            continue
        h, m = int(a["time"][:2]), int(a["time"][3:])
        for add in range(0, 8):
            day = now + datetime.timedelta(days=add)
            cand = day.replace(hour=h, minute=m, second=0, microsecond=0)
            if cand <= now or (a["days"] and cand.weekday() not in a["days"]):
                continue
            if best is None or cand < best[0]:
                best = (cand, a["label"])
            break
    return best
