"""satindex_logic: the thinking behind the Index launcher (no GTK, so it can be tested): the maths/units answer line,
search ranking, Worlds, and most-used ordering."""
import ast
import json
import operator
import os
import re

WORLDS = ["All", "Work", "Home", "Study", "Developer"]
# Worlds are a first guess from freedesktop categories until people can put apps in their own Worlds.
WORLD_CATEGORIES = {
    "Work": {"Office", "Email", "Calendar", "ContactManagement", "ProjectManagement", "Network", "WebBrowser", "Presentation", "Spreadsheet", "WordProcessor"},
    "Home": {"AudioVideo", "Audio", "Video", "Game", "Graphics", "Photography", "Player", "Music"},
    "Study": {"Education", "Science", "Languages", "Math", "Literature"},
    "Developer": {"Development", "IDE", "TerminalEmulator", "Debugger", "WebDevelopment"},
}
COUNTS = os.path.join(os.path.expanduser("~"), ".local", "share", "wos", "launch-counts.json")

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow}

UNITS = {  # unit -> (kind, factor to the base unit)
    "mm": ("len", 0.001), "cm": ("len", 0.01), "m": ("len", 1.0), "km": ("len", 1000.0), "in": ("len", 0.0254), "ft": ("len", 0.3048),
    "yd": ("len", 0.9144), "mi": ("len", 1609.344),
    "g": ("mass", 0.001), "kg": ("mass", 1.0), "oz": ("mass", 0.028349523125), "lb": ("mass", 0.45359237), "st": ("mass", 6.35029318),
    "ml": ("vol", 0.001), "l": ("vol", 1.0), "pt": ("vol", 0.56826125), "gal": ("vol", 4.54609),
    "c": ("temp", None), "f": ("temp", None), "k": ("temp", None),
}


def _eval(node, depth=0):
    if depth > 30:
        raise ValueError("too deep")
    if isinstance(node, ast.Expression):
        return _eval(node.body, depth + 1)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
        return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        v = _eval(node.operand, depth + 1)
        return v if isinstance(node.op, ast.UAdd) else -v
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        a, b = _eval(node.left, depth + 1), _eval(node.right, depth + 1)
        if isinstance(node.op, ast.Pow) and (abs(b) > 100 or abs(a) > 1e6):
            raise ValueError("too big")
        return _OPS[type(node.op)](a, b)
    raise ValueError("not a sum")


def _fmt(v):
    if isinstance(v, float):
        if v != v or v in (float("inf"), float("-inf")):
            raise ValueError("no answer")
        if v == int(v) and abs(v) < 1e15:
            return "{:,}".format(int(v))
        return "{:,.6g}".format(v) if abs(v) < 1e6 else "{:,.2f}".format(v)
    return "{:,}".format(v)


def _temp(v, a, b):
    c = v if a == "c" else (v - 32) * 5 / 9 if a == "f" else v - 273.15
    return c if b == "c" else c * 9 / 5 + 32 if b == "f" else c + 273.15


def answer(text):
    """"12*(3+4)" -> "84", "10 km in mi" -> "6.21371 mi". None when it is not a sum or a conversion."""
    t = text.strip().lower().replace("×", "*").replace("÷", "/").replace("^", "**").replace(",", "")
    if not t:
        return None
    m = re.fullmatch(r"(-?[\d.]+)\s*°?\s*([a-z]+)\s+(?:in|to|as)\s+°?\s*([a-z]+)", t)
    if m:
        try:
            v = float(m.group(1))
        except ValueError:
            return None
        a, b = m.group(2), m.group(3)
        if a in UNITS and b in UNITS and UNITS[a][0] == UNITS[b][0]:
            if UNITS[a][0] == "temp":
                return "%s °%s" % (_fmt(round(_temp(v, a, b), 4)), b.upper())
            return "%s %s" % (_fmt(round(v * UNITS[a][1] / UNITS[b][1], 6)), b)
        return None
    if not re.search(r"[-+*/%()]", t[1:] if t[:1] in "+-" else t) or re.search(r"[a-z]", t):
        return None
    try:
        return _fmt(_eval(ast.parse(t, mode="eval")))
    except (ValueError, SyntaxError, ZeroDivisionError, OverflowError, TypeError, RecursionError):
        return None


def score(name, query, extra=""):
    q, n = query.lower().strip(), name.lower()
    if not q:
        return 1.0
    if n.startswith(q):
        return 3.0
    if any(w.startswith(q) for w in re.split(r"[\s\-_.]+", n)):
        return 2.0
    if q in n:
        return 1.0
    if q in extra.lower():
        return 0.5
    return 0.0


def world_of(categories):
    cats = {c for c in (categories or "").split(";") if c}
    for w in ("Developer", "Study", "Work", "Home"):
        if cats & WORLD_CATEGORIES[w]:
            return w
    return None


def load_counts():
    try:
        with open(COUNTS, encoding="utf-8") as f:
            d = json.load(f)
        return {k: int(v) for k, v in d.items() if isinstance(v, int)}
    except (OSError, ValueError, AttributeError):
        return {}


def bump(app_id):
    d = load_counts()
    d[app_id] = d.get(app_id, 0) + 1
    try:
        os.makedirs(os.path.dirname(COUNTS), exist_ok=True)
        tmp = COUNTS + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, COUNTS)
    except OSError:
        pass


def order(apps, counts):
    """Most used first, then by name."""
    return sorted(apps, key=lambda a: (-counts.get(a["id"], 0), a["name"].lower()))


def filter_apps(apps, query, world):
    out = []
    for a in apps:
        if world != "All" and a.get("world") != world:
            continue
        s = score(a["name"], query, a.get("keywords", ""))
        if s > 0:
            out.append((s, a))
    return [a for s, a in sorted(out, key=lambda x: (-x[0], x[1]["name"].lower()))] if query.strip() else [a for s, a in out]
