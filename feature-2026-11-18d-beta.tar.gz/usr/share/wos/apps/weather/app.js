"use strict";
/* Weather: pick your cities, see now, the next 24 hours and the week. Data from Open-Meteo (free, no account). Only the
   city name you search for and its position are sent. The logic and the drawings are in wx.js (tested). */

boot(async info => {
  const root = $("#root");
  const W = window.Wx;
  const errText = e => (e && e.message) || "Something went wrong";
  let cities = (await wos.data.get("cities", [])) || [], at = (await wos.data.get("at", 0)) || 0, unit = (await wos.data.get("unit", "c")) || "c";
  let vm = null, status = "", loading = false, cache = (await wos.data.get("cache", {})) || {};
  const lang = (info.lang || "en_GB").slice(0, 2);
  const save = () => Promise.all([wos.data.set("cities", cities), wos.data.set("at", at), wos.data.set("unit", unit)]);

  const search = h("input.field", { placeholder: "Search for a city", style: "width:260px", onkeydown: e => { if (e.key === "Enter") find(); } });
  const results = h("div.card", { style: "position:absolute;top:44px;left:0;width:340px;z-index:6;display:none;max-height:300px;overflow:auto" });
  const chips = h("div", { style: "display:flex;gap:6px;flex-wrap:wrap;flex:1" });
  const seg = h("div.seg");
  const head = h("div", { style: "display:flex;align-items:center;gap:12px;padding:16px 22px 10px" }, h("div", { style: "position:relative" }, search, results), chips, seg,
    h("button.icon-btn", { title: "Refresh", html: icon("refresh"), onclick: () => refresh() }));
  const main = h("div", { style: "flex:1;min-height:0;overflow:auto;padding:0 22px 22px" });
  root.append(h("div", { style: "display:flex;flex-direction:column;height:100%" }, head, main));

  function paintHead() {
    chips.innerHTML = "";
    cities.forEach((c, i) => chips.append(h("button.btn.small" + (i === at ? "" : ".ghost"), { onclick: () => { at = i; save(); refresh(); } }, c.name,
      i === at ? h("span", { title: "Remove this city", style: "margin-left:6px;opacity:.8", onclick: e => { e.stopPropagation(); cities.splice(i, 1); at = Math.max(0, at - 1); save(); refresh(); } }, "×") : null)));
    seg.innerHTML = ""; [["c", "°C"], ["f", "°F"]].forEach(([k, l]) => seg.append(h("button" + (unit === k ? ".on" : ""), { onclick: () => { unit = k; save(); paintHead(); draw(); } }, l)));
  }

  async function find() {
    const q = search.value.trim(); if (q.length < 2) return;
    results.style.display = "block"; results.innerHTML = ""; results.append(h("div.muted", { style: "padding:14px" }, "Searching…"));
    try {
      const places = await wos.call("weather.search", { query: q, language: lang });
      results.innerHTML = "";
      if (!places.length) results.append(h("div.muted", { style: "padding:14px" }, "No city found. Check the spelling."));
      places.forEach(p => results.append(h("button.row", { style: "min-height:46px", onclick: () => { results.style.display = "none"; search.value = ""; add(p); } },
        h("div.grow", h("div.t", p.name), h("div.s", [p.region, p.country].filter(Boolean).join(", "))))));
    } catch (e) { results.innerHTML = ""; results.append(h("div", { style: "padding:14px;color:var(--btn-danger,#d33)" }, errText(e))); }
  }
  document.addEventListener("click", e => { if (!results.contains(e.target) && e.target !== search) results.style.display = "none"; });
  function add(p) {
    const i = cities.findIndex(c => Math.abs(c.lat - p.lat) < 0.05 && Math.abs(c.lon - p.lon) < 0.05);
    if (i >= 0) at = i; else { cities.push({ name: p.name, region: p.region, country: p.country, lat: p.lat, lon: p.lon }); at = cities.length - 1; }
    save(); refresh();
  }

  async function refresh() {
    paintHead();
    const c = cities[at];
    if (!c) { vm = null; draw(); return; }
    const key = c.lat + "," + c.lon; loading = true; status = ""; if (!cache[key]) draw();
    try {
      const fc = await wos.call("weather.forecast", { lat: c.lat, lon: c.lon });
      cache[key] = { fc, at: Date.now() }; wos.data.set("cache", cache);
    } catch (e) { status = cache[key] ? "Offline: showing the last forecast from " + new Date(cache[key].at).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }) : errText(e); }
    loading = false;
    vm = cache[key] ? W.build(cache[key].fc) : null;
    draw();
  }

  const SKY = { sun: "#4aa8ff,#9ad0ff", partly: "#6aa7e8,#b8d4f0", cloud: "#8d9bb3,#c3cbd9", rain: "#56667f,#8ea0b8", fog: "#9aa5b5,#cbd2dc", snow: "#8aa4c8,#d6e2f2", storm: "#3f4660,#6d7694", moon: "#1d2a54,#3d4a82", "moon-cloud": "#27324f,#4c587c" };
  function draw() {
    main.innerHTML = "";
    const c = cities[at];
    if (!c) { main.append(h("div.panel.hero", { style: "margin-top:20px" }, h("span.chip.gold.eyebrow", "Weather"), h("h1", "Where are you?"), h("p", "Search for your city above to see the weather."))); return; }
    if (!vm) { main.append(h("div.panel", { style: "margin-top:10px" }, h("p", { style: "margin:0" }, loading ? "Loading the forecast…" : status || "No forecast yet."), loading ? null : h("button.cta", { style: "margin-top:16px", onclick: refresh }, "Try again"))); return; }
    const n = vm.now, [from, to] = (SKY[n.icon] || SKY.sun).split(",");
    main.append(h("div.panel", { style: `margin-top:6px;min-height:260px;color:#fff;background:linear-gradient(to bottom,${from},${to});border:0` },
      h("div", { style: "font-weight:700;opacity:.9;margin-bottom:2px" }, c.name + (c.region ? ", " + c.region : "")), h("div", { html: W.iconSvg(n.icon, 64), style: "margin:4px 0" }),
      h("div", { style: "font-size:76px;font-weight:800;letter-spacing:-.04em;line-height:1" }, W.temp(n.temp, unit)), h("div", { style: "font-size:20px;font-weight:700;margin:6px 0 4px" }, n.label),
      h("div", { style: "opacity:.92" }, `H ${W.temp(n.hi, unit)}   L ${W.temp(n.lo, unit)}`),
      status ? h("div.small", { style: "margin-top:10px;background:rgba(0,0,0,.25);padding:4px 12px;border-radius:100px" }, status) : null));
    const stat = (l, v) => h("div.card", { style: "padding:14px 16px;flex:1;min-width:120px" }, h("div.small.muted", { style: "font-weight:700" }, l), h("div", { style: "font-size:20px;font-weight:800;margin-top:2px" }, v));
    main.append(h("div", { style: "display:flex;gap:10px;flex-wrap:wrap;margin-top:12px" }, stat("Feels like", W.temp(n.feels, unit)), stat("Humidity", n.humidity == null ? "–" : n.humidity + "%"), stat("Wind", W.wind(n.wind, unit)), stat("Sunrise", n.sunrise || "–"), stat("Sunset", n.sunset || "–")));
    main.append(h("div.label", { style: "margin:20px 2px 8px" }, "Next 24 hours"),
      h("div.card", { style: "display:flex;overflow-x:auto;padding:12px 6px" }, vm.hours.map(x => h("div", { style: "flex:none;width:64px;text-align:center" }, h("div.small.muted", { style: "font-weight:700" }, x.hour + ":00"),
        h("div", { html: W.iconSvg(x.icon, 30), style: "margin:6px 0 2px;display:grid;place-items:center" }), h("div", { style: "font-weight:800" }, W.temp(x.temp, unit)), x.rain >= 20 ? h("div.small", { style: "color:#3d8bff" }, x.rain + "%") : h("div.small", " ")))));
    main.append(h("div.label", { style: "margin:20px 2px 8px" }, "This week"),
      h("div.card", vm.days.map(d => h("div.row", { style: "cursor:default;min-height:52px" }, h("span", { style: "width:90px;font-weight:700" }, d.name), h("span", { html: W.iconSvg(d.icon, 30) }),
        h("span.small", { style: "width:46px;color:#3d8bff;margin-left:8px" }, d.rain >= 20 ? d.rain + "%" : ""), h("div.grow", { style: "text-align:right" }, h("b", W.temp(d.hi, unit)), h("span.muted", "   " + W.temp(d.lo, unit)))))));
    main.append(h("p.small.muted", { style: "margin:14px 2px 0" }, "Weather data by Open-Meteo.com"));
  }

  paintHead(); draw(); refresh();
  setInterval(() => { if (!document.hidden) refresh(); }, 15 * 60000);
});
