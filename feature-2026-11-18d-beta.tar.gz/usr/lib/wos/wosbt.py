"""Bluetooth for Settings: pair, trust and connect a device in one real bluetoothctl session, then check it
really is connected and move the sound to it. No GTK in here, so it can be tested on its own.

Why one session: `bluetoothctl pair X` run on its own quits the moment it has sent the request, before
the device has answered, and has no agent to answer a passkey question. Here one bluetoothctl stays open,
an agent is registered, and we wait for what bluez actually says."""
import os
import queue
import re
import subprocess
import threading
import time

LOG = os.path.join(os.path.expanduser("~"), ".cache", "wos-bluetooth.log")
ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\r")
ASK = re.compile(r"(Confirm passkey|Request confirmation|Authorize service|Accept pairing|Request authorization).*\(yes/no\)|\(yes/no\)", re.I)

PLAIN = (
    (("AuthenticationFailed", "AuthenticationRejected", "AuthenticationCanceled", "Authentication Failed"),
     "Pairing was refused. Hold the pairing button on the device until its light flashes, then try again."),
    (("AuthenticationTimeout", "page-timeout", "Page Timeout", "Host is down", "ConnectionAttemptFailed", "Timed out", "Timeout"),
     "The device did not answer. Check it is on and close to the laptop, then try again."),
    (("br-connection-profile-unavailable", "profile-unavailable"),
     "The audio link could not start. Turn the device off and on, then try again."),
    (("NotReady", "No default controller", "not available", "Not Powered"),
     "Bluetooth is not ready. Switch it off and on again."),
    (("br-connection-canceled", "Canceled", "Cancelled"), "The connection was cancelled."),
)


def plain_reason(text):
    t = text or ""
    for keys, msg in PLAIN:
        if any(k.lower() in t.lower() for k in keys):
            return msg
    t = re.sub(r"org\.bluez\.Error\.", "", t).strip()
    return "Could not connect" + (" (%s)." % t[:80] if t else ".")


def log(line):
    try:
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (time.strftime("%H:%M:%S"), line))
    except OSError:
        pass


def run(cmd, timeout=8):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout
    except (OSError, subprocess.SubprocessError):
        return 1, ""


class Session:
    """One long-running bluetoothctl. send() types a line; expect() waits for output matching one of the patterns."""

    def __init__(self, binary="bluetoothctl"):
        self.p = subprocess.Popen([binary], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        self.q = queue.Queue()
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        for line in self.p.stdout:
            line = ANSI.sub("", line).rstrip("\n")
            if line.strip():
                log("< " + line)
                self.q.put(line)
        self.q.put(None)

    def send(self, line):
        log("> " + line)
        try:
            self.p.stdin.write(line + "\n")
            self.p.stdin.flush()
        except (OSError, ValueError):
            pass

    def expect(self, patterns, timeout):
        """Index of the first pattern seen and its match, or (None, None) on timeout or if bluetoothctl died. Answers yes/no questions with yes."""
        end = time.time() + timeout
        while time.time() < end:
            try:
                line = self.q.get(timeout=max(0.05, min(0.5, end - time.time())))
            except queue.Empty:
                continue
            if line is None:
                return None, None
            if ASK.search(line):
                self.send("yes")
            for i, pat in enumerate(patterns):
                m = re.search(pat, line)
                if m:
                    return i, m
        return None, None

    def close(self):
        try:
            self.send("quit")
            self.p.wait(timeout=2)
        except Exception:
            try:
                self.p.kill()
            except Exception:
                pass
        for f in (self.p.stdin, self.p.stdout):
            try:
                f.close()
            except Exception:
                pass


def info(mac, runner=run, binary="bluetoothctl"):
    code, out = runner([binary, "info", mac], 6)
    return {"paired": "Paired: yes" in out, "connected": "Connected: yes" in out, "known": "Device " in out}


def route_audio(mac, runner=run, wait=8.0, sleep=time.sleep):
    """Make the connected device the sound output. PipeWire usually does this itself, but not always (it can sit on the
    call-quality profile, or not pick the new output at all). Returns the sink name, or None if no output showed up."""
    key = mac.upper().replace(":", "_")
    end = time.time() + wait
    while True:
        _, out = runner(["pactl", "list", "short", "sinks"], 5)
        sink = next((l.split("\t")[1] for l in out.splitlines() if "\t" in l and key in l.split("\t")[1].upper()), None)
        if sink:
            runner(["pactl", "set-default-sink", sink], 5)
            _, inputs = runner(["pactl", "list", "short", "sink-inputs"], 5)
            for l in inputs.splitlines():
                if l.strip():
                    runner(["pactl", "move-sink-input", l.split("\t")[0], sink], 5)
            return sink
        _, cards = runner(["pactl", "list", "short", "cards"], 5)
        card = next((l.split("\t")[1] for l in cards.splitlines() if "\t" in l and key in l.split("\t")[1].upper()), None)
        if card:
            runner(["pactl", "set-card-profile", card, "a2dp-sink"], 5)
        if time.time() >= end:
            return None
        sleep(1)


def setup(mac, progress, binary="bluetoothctl", runner=run, sleep=time.sleep):
    """Pair (if needed), trust, connect, verify, and route sound. progress(state, text) is told what is happening.
    Returns {"ok", "state": "connected"|"failed", "message", "audio"}. Never says connected unless bluez says so twice."""
    def fail(msg):
        progress("failed", msg)
        return {"ok": False, "state": "failed", "message": msg, "audio": False}

    log("== setup %s" % mac)
    try:
        s = Session(binary)
    except OSError:
        return fail("Bluetooth is not available on this computer.")
    try:
        s.send("power on")
        s.send("agent NoInputNoOutput")
        s.send("default-agent")
        s.send("scan off")
        sleep(0.5)
        st = info(mac, runner, binary)
        if not st["paired"]:
            progress("pairing", "Pairing…")
            s.send("pair " + mac)
            i, m = s.expect([r"Pairing successful", r"Failed to pair: (.*)", r"AlreadyExists"], 35)
            if i is None:
                return fail("Pairing took too long. Hold the pairing button on the device until its light flashes, then try again.")
            if i == 1:
                return fail(plain_reason(m.group(1)))
            if not info(mac, runner, binary)["paired"]:
                return fail("The device did not finish pairing. Try again.")
        s.send("trust " + mac)
        s.expect([r"trust succeeded", r"Failed to trust"], 5)
        reason = ""
        for attempt in range(3):
            progress("connecting", "Connecting…")
            s.send("connect " + mac)
            i, m = s.expect([r"Connection successful", r"Failed to connect: (.*)"], 25)
            if i == 0:
                break
            reason = m.group(1) if i == 1 else "Timeout"
            if "AlreadyConnected" in reason:
                break
            if not any(k in reason for k in ("InProgress", "in progress", "Timeout", "page-timeout", "NotReady")) and attempt >= 1:
                break
            sleep(2)
        else:
            return fail(plain_reason(reason))
        if info(mac, runner, binary)["connected"] is False and "AlreadyConnected" not in reason:
            return fail(plain_reason(reason))
        sleep(2)                                       # a link that drops straight away must not be reported as connected
        if not info(mac, runner, binary)["connected"]:
            return fail("It connected and then dropped. Turn the device off and on, then try again.")
        progress("audio", "Setting up sound…")
        sink = route_audio(mac, runner, sleep=sleep)
        msg = "Connected." if sink else "Connected, but no sound output appeared. Open Sound and choose it there."
        progress("connected", msg)
        return {"ok": True, "state": "connected", "message": msg, "audio": bool(sink)}
    finally:
        s.close()
