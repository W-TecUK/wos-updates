"use strict";
/* Deciding what to do to bring this computer's notes and W-Life's notes into line. No network and no screen in here,
   so it can be tested (os/tests/notesync.test.js). Nothing is ever deleted on one side unless it was deleted on the other.

   A local note: {id, title, body, pinned, updated, rid, dirty, stamp}
     rid   the note's id in W-Life, or null if it has not been uploaded
     dirty changed here since the last sync
     stamp W-Life's updated_at for it when we last synced
   A remote note (from the list): {id, updated_at, ...}
   plan() returns what to do; the app does it and records the new stamps. */
(function (root) {
  function plan(local, remote, pendingDeletes) {
    const remoteById = new Map(remote.map(r => [String(r.id), r]));
    const known = new Set(local.filter(n => n.rid).map(n => String(n.rid)));
    const out = { push: [], pull: [], pullNew: [], removeLocal: [], conflicts: [], deleteRemote: [], dropPending: [] };
    for (const n of local) {
      if (!n.rid) { if ((n.title || "").trim() || (n.body || "").trim()) out.push.push({ id: n.id, create: true }); continue; }
      const r = remoteById.get(String(n.rid));
      if (!r) {                                             // gone from W-Life
        if (n.dirty) out.push.push({ id: n.id, create: true });          // but edited here since: keep it and upload it again
        else out.removeLocal.push(n.id);                                 // deleted on another device
        continue;
      }
      const changedThere = r.updated_at !== n.stamp;
      if (n.dirty && changedThere) { out.conflicts.push({ id: n.id, rid: String(n.rid) }); out.push.push({ id: n.id, create: false }); }
      else if (n.dirty) out.push.push({ id: n.id, create: false });
      else if (changedThere) out.pull.push({ id: n.id, rid: String(n.rid) });
    }
    const pending = new Set((pendingDeletes || []).map(String));
    for (const r of remote) {
      const id = String(r.id);
      if (pending.has(id)) { out.deleteRemote.push(id); continue; }
      if (!known.has(id)) out.pullNew.push(id);
    }
    for (const id of pending) if (!remoteById.has(id)) out.dropPending.push(id);
    return out;
  }

  /* The title W-Life stores: the note's first line, since this app's title is the first thing you type. */
  const makeTitle = n => (n.title || (n.body || "").split("\n")[0] || "").trim().slice(0, 120);

  const api = { plan, makeTitle };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.NoteSync = api;
})(typeof window !== "undefined" ? window : globalThis);
