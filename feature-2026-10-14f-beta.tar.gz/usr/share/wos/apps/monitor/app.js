"use strict";
/* Monitor: what is running and how hard the computer is working. Quit a stuck program the polite way, or
   force it. Only your own programs are listed; anything that would end your session is locked. */

boot(async () => {
  const root = $("#root");
  let tab = "procs", sort = { key: "cpu", dir: -1 }, query = "", selected = null, data = null, busy = false;
  const hist = { cpu: [], mem: [], down: [], up: [] };
  const HIST = 60;
  const fmtMB = mb => mb >= 1024 ? (mb / 1024).toFixed(1) + " GB" : Math.round(mb) + " MB";
  const fmtKB = kb => fmtMB(kb / 1024);
  const fmtRate = b => b >= 1e6 ? (b / 1e6).toFixed(1) + " MB/s" : b >= 1e3 ? Math.round(b / 1e3) + " KB/s" : b + " B/s";
  const fmtBytes = b => b >= 1e12 ? (b / 1e12).toFixed(1) + " TB" : (b / 1e9).toFixed(0) + " GB";
  const fmtUp = s => { const d = Math.floor(s / 86400), hh = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return (d ? d + " d " : "") + (hh || d ? hh + " h " : "") + m + " min"; };
  const errText = e => (e && e.message) || "Something went wrong";

  const content = h("div", { style: "flex:1;min-height:0;overflow:auto;padding:0 22px 22px" });
  const seg = h("div.seg");
  const paintSeg = () => { seg.innerHTML = ""; [["procs", "Programs"], ["perf", "Performance"]].forEach(([k, l]) => seg.append(h("button" + (tab === k ? ".on" : ""), { onclick: () => { tab = k; paintSeg(); draw(); } }, l))); };
  const search = h("input.field", { placeholder: "Search programs", style: "width:220px", oninput: e => { query = e.target.value.toLowerCase(); if (tab === "procs") drawProcs(); } });
  const quitBtn = h("button.btn.ghost.small", { disabled: true, onclick: () => quit(false) }, "Quit");
  const forceBtn = h("button.btn.small", { disabled: true, onclick: () => quit(true) }, "Force quit");
  const bar = h("div", { style: "display:flex;align-items:center;gap:12px;padding:18px 22px 14px" }, seg, h("div", { style: "flex:1" }), search, quitBtn, forceBtn);
  root.append(h("div", { style: "display:flex;flex-direction:column;height:100%" }, bar, content));
  paintSeg();

  function confirmBox(title, text, okLabel) {
    return new Promise(res => {
      const done = v => { back.remove(); res(v); };
      const back = h("div.modal-back", h("div.modal", h("h2", title), h("p.muted", text), h("div.actions", h("button.btn.ghost", { onclick: () => done(false) }, "Cancel"), h("button.btn", { onclick: () => done(true) }, okLabel))));
      document.body.append(back);
    });
  }

  async function quit(force) {
    const p = data && data.procs.find(x => x.pid === selected);
    if (!p) return;
    if (force && !(await confirmBox("Force quit " + p.name + "?", "Anything you have not saved in it will be lost.", "Force quit"))) return;
    try { await wos.call("monitor.quit", { pid: p.pid, force }); toast(force ? "Force quit " + p.name : "Asked " + p.name + " to quit"); } catch (e) { toast(errText(e)); }
    setTimeout(tick, 600);
  }

  function spark(values, color, max) {
    const w = 260, hgt = 56, top = max || Math.max(1, ...values);
    const pts = values.map((v, i) => `${(w - (values.length - 1 - i) / (HIST - 1) * w).toFixed(1)},${(hgt - 3 - (v / top) * (hgt - 6)).toFixed(1)}`);
    const line = pts.join(" ");
    const area = pts.length > 1 ? `${(w - (values.length - 1) / (HIST - 1) * w).toFixed(1)},${hgt} ${line} ${w},${hgt}` : "";
    return h("div", { html: `<svg viewBox="0 0 ${w} ${hgt}" preserveAspectRatio="none" style="width:100%;height:${hgt}px;display:block"><polygon points="${area}" fill="${color}" fill-opacity=".14"/><polyline points="${line}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>` });
  }
  const stat = (title, big, sub, chart) => h("div.card.pad", h("div.small.muted", { style: "font-weight:700" }, title), h("div", { style: "font-size:28px;font-weight:800;margin:2px 0 6px" }, big), chart || null, h("div.small.muted", { style: "margin-top:6px" }, sub));

  function drawPerf() {
    content.innerHTML = "";
    if (!data) return;
    const used = data.mem.total_kb - data.mem.available_kb, memPct = Math.round(used / Math.max(1, data.mem.total_kb) * 100);
    const diskUsed = data.disk.total - data.disk.free;
    content.append(h("div", { style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px" },
      stat("Processor", data.cpu + "%", `${data.cores} cores · load ${data.load.join("  ")}`, spark(hist.cpu, "#0a84ff", 100)),
      stat("Memory", memPct + "%", `${fmtKB(used)} of ${fmtKB(data.mem.total_kb)} in use` + (data.mem.swap_total_kb ? ` · swap ${fmtKB(data.mem.swap_total_kb - data.mem.swap_free_kb)}` : ""), spark(hist.mem, "#bf5af2", 100)),
      stat("Network", "↓ " + fmtRate(data.net_down), "↑ " + fmtRate(data.net_up) + " sending", spark(hist.down, "#30b04f")),
      stat("Storage", Math.round(diskUsed / Math.max(1, data.disk.total) * 100) + "%", `${fmtBytes(diskUsed)} of ${fmtBytes(data.disk.total)} used · up for ${fmtUp(data.uptime)}`,
        h("div", { style: "height:8px;border-radius:99px;background:var(--panel-3);overflow:hidden;margin-top:14px" }, h("div", { style: `height:100%;width:${Math.round(diskUsed / Math.max(1, data.disk.total) * 100)}%;background:#ff9f0a` })))));
  }

  const COLS = [["name", "Name", 1], ["cpu", "CPU", 0], ["mem_mb", "Memory", 0]];
  function drawProcs() {
    content.innerHTML = "";
    if (!data) { content.append(h("p.muted", "Loading…")); return; }
    let rows = data.procs.filter(p => !query || p.name.toLowerCase().includes(query));
    rows.sort((a, b) => (typeof a[sort.key] === "string" ? a[sort.key].localeCompare(b[sort.key]) : a[sort.key] - b[sort.key]) * sort.dir || a.pid - b.pid);
    const head = h("div", { style: "display:grid;grid-template-columns:1fr 90px 100px;padding:8px 14px;position:sticky;top:0;background:var(--bg);z-index:1" },
      ...COLS.map(([k, l, left]) => h("button", { style: `border:0;background:none;font-weight:800;font-size:12px;color:var(--muted);cursor:pointer;text-align:${left ? "left" : "right"}`, onclick: () => { sort = sort.key === k ? { key: k, dir: -sort.dir } : { key: k, dir: k === "name" ? 1 : -1 }; drawProcs(); } },
        l + (sort.key === k ? (sort.dir > 0 ? " ▲" : " ▼") : ""))));
    const body = h("div.card");
    rows.forEach(p => body.append(h("button.row" + (selected === p.pid ? ".on" : ""), { style: "display:grid;grid-template-columns:1fr 90px 100px;min-height:40px", onclick: () => { selected = p.pid; syncButtons(); drawProcs(); } },
      h("div", { style: "display:flex;align-items:center;gap:8px;min-width:0" }, p.locked ? h("span.muted", { html: icon("lock", 13), title: "Part of the system" }) : null, h("span.t", p.name)),
      h("div", { style: "text-align:right;font-variant-numeric:tabular-nums" }, p.cpu.toFixed(1) + "%"), h("div", { style: "text-align:right;font-variant-numeric:tabular-nums" }, fmtMB(p.mem_mb)))));
    if (!rows.length) body.append(h("div.muted", { style: "padding:24px;text-align:center" }, "No programs match"));
    content.append(head, body);
  }
  function syncButtons() {
    const p = data && data.procs.find(x => x.pid === selected);
    quitBtn.disabled = forceBtn.disabled = !p || p.locked;
    search.style.display = tab === "procs" ? "" : "none";
    quitBtn.style.display = forceBtn.style.display = tab === "procs" ? "" : "none";
  }
  function draw() { syncButtons(); tab === "procs" ? drawProcs() : drawPerf(); }

  async function tick() {
    if (busy || document.hidden) return;
    busy = true;
    try {
      data = await wos.call("monitor.sample");
      const used = data.mem.total_kb - data.mem.available_kb;
      const push = (a, v) => { a.push(v); if (a.length > HIST) a.shift(); };
      push(hist.cpu, data.cpu); push(hist.mem, used / Math.max(1, data.mem.total_kb) * 100); push(hist.down, data.net_down); push(hist.up, data.net_up);
      if (selected && !data.procs.some(p => p.pid === selected)) selected = null;
      draw();
    } catch (e) { content.innerHTML = ""; content.append(h("p.muted", errText(e))); }
    busy = false;
  }
  draw();
  await tick();
  setInterval(tick, 2000);
});
