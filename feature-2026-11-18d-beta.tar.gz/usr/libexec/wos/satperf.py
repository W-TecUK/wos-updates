"""Cheap mode: how the native shell behaves where there is no graphics card (a virtual machine, an old laptop).

Cheap mode draws every capsule as a plain rounded rectangle (no blurred wallpaper copy, no shadow, no tint easing), snaps instead
of animating, polls less, and never uses see-through windows: the shell windows are cut to the capsule shape instead, so no
compositor is needed. Chosen automatically in a virtual machine; override with ~/.config/wos/performance = "cheap" | "full" | "auto"
(or the environment variable WOS_PERF)."""
import os
import re

PREF = os.path.join(os.environ.get("WOS_CONF") or os.path.join(os.path.expanduser("~"), ".config", "wos"), "performance")
_cache = {}


def _read(path):
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            return f.read()
    except OSError:
        return ""


def in_vm():
    """True inside a virtual machine (VirtualBox, VMware, QEMU/KVM, Hyper-V, Parallels) or with software GL forced."""
    if os.environ.get("LIBGL_ALWAYS_SOFTWARE") == "1":
        return True
    dmi = " ".join(_read("/sys/class/dmi/id/" + n) for n in ("sys_vendor", "product_name", "board_vendor", "bios_vendor")).lower()
    if any(k in dmi for k in ("virtualbox", "vmware", "qemu", "kvm", "bochs", "microsoft corporation virtual", "parallels", "innotek", "xen")):
        return True
    return " hypervisor" in _read("/proc/cpuinfo").lower().split("flags", 1)[-1][:2000] if "flags" in _read("/proc/cpuinfo").lower() else False


def setting():
    """"cheap", "full" or "auto" (the default)."""
    v = (os.environ.get("WOS_PERF") or _read(PREF)).strip().lower()
    return v if v in ("cheap", "full") else "auto"


def cheap():
    if "cheap" not in _cache:
        s = setting()
        _cache["cheap"] = s != "full"          # Will's call (18 Nov): no glass, flat solid look by default; "full" is a hidden opt-in
    return _cache["cheap"]


def use_alpha(screen):
    """See-through windows only when a compositor runs and cheap mode is off; otherwise windows are shaped instead."""
    try:
        return (not cheap()) and screen.is_composited() and screen.get_rgba_visual() is not None
    except AttributeError:
        return False


def rounded_region(x, y, w, h, r):
    """A cairo.Region shaped like a rounded rectangle (row by row at the corners), for window shapes without a compositor."""
    import cairo
    x, y, w, h = int(x), int(y), int(w), int(h)
    r = int(max(0, min(r, w / 2.0, h / 2.0)))
    reg = cairo.Region()
    if w <= 0 or h <= 0:
        return reg
    reg.union(cairo.RectangleInt(x, y + r, w, max(0, h - 2 * r)))
    for row in range(r):
        d = r - row - 0.5
        inset = r - int((max(0.0, r * r - d * d)) ** 0.5)
        reg.union(cairo.RectangleInt(x + inset, y + row, max(1, w - 2 * inset), 1))
        reg.union(cairo.RectangleInt(x + inset, y + h - 1 - row, max(1, w - 2 * inset), 1))
    return reg


if __name__ == "__main__":
    import sys
    print("cheap" if cheap() else "full")
    sys.exit(0 if cheap() else 1)
