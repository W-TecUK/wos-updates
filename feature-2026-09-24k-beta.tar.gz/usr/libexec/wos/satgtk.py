"""satgtk: turns a .satUI view tree into real, native GTK3 widgets -- no WebKit, no HTML, no JS
anywhere in this path. This is W-OS-specific (tied to one desktop toolkit), which is exactly why
it lives here and not in satlang-lang: that repo stays host-agnostic, this file is one host's
choice of how to draw what satlang evaluates.

Beta only. Used by wos-sat-run (a single app) and satshell (the parallel, WebKit-free desktop
shell) alike -- both just call build() with a fresh handler dict and hand the result to a GTK
container.
"""
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib  # noqa: E402

from satlang import to_display_string  # noqa: E402

CSS_CLASS = {"View": "sat-view", "VStack": "sat-vstack", "HStack": "sat-hstack", "ZStack": "sat-zstack",
             "Text": "sat-text", "Button": "sat-button", "Spacer": "sat-spacer"}
ORIENTATION = {"View": Gtk.Orientation.VERTICAL, "VStack": Gtk.Orientation.VERTICAL, "HStack": Gtk.Orientation.HORIZONTAL}


def build(node, interpreter, env, handlers, next_id):
    """Walks a .satUI AST against the CURRENT program state, same as satlang.render_view, but
    returns a live Gtk.Widget instead of a JSON-able dict. Runs on every render -- there is no
    compiled-once view, a Satisfaction program's UI is only ever evaluated fresh."""
    name, arg_nodes, block = node
    css_class = CSS_CLASS.get(name, "sat-" + name.lower())
    text = interpreter.eval_expr(arg_nodes[0], env) if arg_nodes else None
    text_str = to_display_string(text) if text is not None else None

    if name == "Text":
        label = Gtk.Label(label=text_str or "")
        label.set_xalign(0)
        label.get_style_context().add_class(css_class)
        return label

    if name == "Spacer":
        filler = Gtk.Box()
        filler.set_hexpand(True)
        filler.set_vexpand(True)
        filler.get_style_context().add_class(css_class)
        return filler

    if name == "Button":
        btn = Gtk.Button(label=text_str or "")
        btn.get_style_context().add_class(css_class)
        if block is not None and block[0] == "stmts":
            handler_id = "h%d" % next_id[0]
            next_id[0] += 1
            handlers[handler_id] = (block[1], env)
            stmts, handler_env = block[1], env

            def on_click(_widget, stmts=stmts, handler_env=handler_env):
                for s in stmts:
                    interpreter.exec_stmt(s, handler_env)

            btn.connect("clicked", on_click)
        return btn

    # a container: View, VStack, HStack, or ZStack
    box = Gtk.Box(orientation=ORIENTATION.get(name, Gtk.Orientation.VERTICAL), spacing=10)
    box.get_style_context().add_class(css_class)
    if block is not None and block[0] == "views":
        for child_node in block[1]:
            child = build(child_node, interpreter, env, handlers, next_id)
            expand = child_node[0] == "Spacer"
            box.pack_start(child, expand, expand, 0)
    return box


def load_css():
    """A GTK CssProvider, not a browser stylesheet -- GTK's own CSS dialect, applied once at
    process start. See usr/share/wos/satisfaction/satgtk.css for the actual rules."""
    from gi.repository import Gdk
    provider = Gtk.CssProvider()
    try:
        provider.load_from_path("/usr/share/wos/satisfaction/satgtk.css")
    except GLib.Error as e:
        import sys
        print("satgtk: no stylesheet: %s" % e, file=sys.stderr)
        return
    Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
