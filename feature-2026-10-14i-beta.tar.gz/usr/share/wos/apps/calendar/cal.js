"use strict";
/* Calendar logic with no screen in it, so it can be tested (os/tests/calendar.test.js).
   An event is {id, title, location, notes, start, end, allDay}: start and end are milliseconds since 1970.
   An all-day event runs from midnight at the start of its first day to the end of its last day (end is exclusive). */
(function (root) {
  const DAY = 86400000;
  const midnight = d => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; };
  const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };       // DST-safe: moves calendar days, not 24 h
  const startOfWeek = d => { const x = midnight(d); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x; };      // weeks start on Monday
  const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const parseYmd = s => { const [y, m, d] = String(s).split("-").map(Number); return new Date(y, m - 1, d); };

  /* The span of days a view shows, as [from, to) Dates. Month views include the greyed days of the neighbouring months. */
  function rangeFor(view, anchor) {
    const a = midnight(anchor);
    if (view === "day") return [a, addDays(a, 1)];
    if (view === "week") { const s = startOfWeek(a); return [s, addDays(s, 7)]; }
    const first = new Date(a.getFullYear(), a.getMonth(), 1), s = startOfWeek(first);
    const last = new Date(a.getFullYear(), a.getMonth() + 1, 0), e = addDays(startOfWeek(last), 7);
    return [s, e];
  }

  const overlaps = (ev, from, to) => ev.start < to.getTime() && Math.max(ev.end, ev.start + 1) > from.getTime();
  function eventsOnDay(events, day) {
    const from = midnight(day), to = addDays(from, 1);
    return events.filter(e => overlaps(e, from, to)).sort((a, b) => (b.allDay - a.allDay) || a.start - b.start || a.end - b.end);
  }

  /* Timed events of one day placed in columns so overlapping ones sit side by side.
     Returns [{ev, top, height, col, cols}] with top/height in minutes from midnight (clipped to the day, at least 20 min tall). */
  function layoutDay(events, day) {
    const from = midnight(day).getTime(), to = addDays(from, 1).getTime();
    const items = events.filter(e => !e.allDay && overlaps(e, new Date(from), new Date(to))).map(ev => {
      const s = Math.max(ev.start, from), e = Math.min(Math.max(ev.end, s + 20 * 60000), to);
      return { ev, s, e };
    }).sort((a, b) => a.s - b.s || b.e - a.e);
    const out = []; let group = [], groupEnd = -1;
    const flush = () => { const cols = group.reduce((m, g) => Math.max(m, g.col + 1), 1); group.forEach(g => { g.cols = cols; out.push(g); }); group = []; };
    for (const it of items) {
      if (group.length && it.s >= groupEnd) { flush(); groupEnd = -1; }
      const used = new Set(group.filter(g => g.e > it.s).map(g => g.col));
      let col = 0; while (used.has(col)) col++;
      group.push({ ev: it.ev, s: it.s, e: it.e, col, cols: 1, top: (it.s - from) / 60000, height: Math.max(20, (it.e - it.s) / 60000) });
      groupEnd = Math.max(groupEnd, it.e);
    }
    flush();
    return out.map(({ ev, top, height, col, cols }) => ({ ev, top, height, col, cols }));
  }

  /* Conversions to and from W-Life's calendar API (title, description, location, start_at, end_at, all_day). */
  function fromApi(row) {
    const start = Date.parse(row.start_at), end = Date.parse(row.end_at);
    const allDay = !!row.all_day;
    return { id: String(row.id), title: row.title || "", notes: row.description || "", location: row.location || "", start, end: allDay ? midnight(addDays(new Date(end), 1)).getTime() : end, allDay, remote: true };
  }
  function toApi(ev) {
    const end = ev.allDay ? addDays(midnight(new Date(ev.end - 1)), 1).getTime() - 60000 : ev.end;     // all-day: last minute of the last day
    return { title: ev.title.trim(), description: ev.notes || "", location: ev.location || "", startAt: new Date(ev.start).toISOString(), endAt: new Date(Math.max(end, ev.start)).toISOString(), allDay: !!ev.allDay };
  }

  /* The first version of this app saved {id, title, date: "2026-10-05", time: "14:30" or "", notes}. */
  function migrateOld(list) {
    return (Array.isArray(list) ? list : []).filter(e => e && e.title && /^\d{4}-\d\d-\d\d$/.test(e.date || "")).map(e => {
      const day = parseYmd(e.date), m = /^(\d\d):(\d\d)$/.exec(e.time || "");
      if (!m) return { id: String(e.id), title: String(e.title), notes: e.notes || "", location: "", start: day.getTime(), end: addDays(day, 1).getTime(), allDay: true };
      const s = new Date(day); s.setHours(+m[1], +m[2], 0, 0);
      return { id: String(e.id), title: String(e.title), notes: e.notes || "", location: "", start: s.getTime(), end: s.getTime() + 3600000, allDay: false };
    });
  }

  const fmtTime = ms => { const d = new Date(ms); return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`; };
  function describe(ev) {
    if (ev.allDay) return "All day";
    return `${fmtTime(ev.start)} - ${fmtTime(ev.end)}`;
  }

  const api = { DAY, midnight, addDays, startOfWeek, ymd, parseYmd, rangeFor, eventsOnDay, layoutDay, fromApi, toApi, migrateOld, fmtTime, describe };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.Cal = api;
})(typeof window !== "undefined" ? window : globalThis);
