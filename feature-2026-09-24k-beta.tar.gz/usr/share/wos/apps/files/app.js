"use strict";
/* Files: places on the left, the folder on the right. Home folder only. */

boot(async info => {
  const root = $("#root");
  let places = await wos.call("fs.places");
  const first = (info.args || []).find(a => a.startsWith("/") && (a === info.home || a.startsWith(info.home + "/")));
  let clipboard = null, bin = false;
  let cwd = first || info.home, history = [cwd], at = 0, entries = [], picked = null, filter = "", view = "grid", hidden = false;
  const saved = await wos.data.get("prefs", {});
  view = saved.view || "grid"; hidden = !!saved.hidden;
  const savePrefs = () => wos.data.set("prefs", { view, hidden });

  const isImage = f => (f.mime || "").startsWith("image/") && !f.mime.includes("svg") || /\.(svg)$/i.test(f.name);
  const fileUri = p => "file://" + p.split("/").map(encodeURIComponent).join("/");
  const kindIcon = f => f.dir ? "folder" : (f.mime || "").startsWith("image/") ? "image" : (f.mime || "").startsWith("text/") ? "doc" : "file";

  /* ---- frame */
  const side = h("aside.side"); const nav = h("nav.nav");
  side.append(h("span.label", "Places"), nav);
  const back = h("button.icon-btn", { title: "Back", html: icon("back"), onclick: () => step(-1) });
  const fwd = h("button.icon-btn", { title: "Forward", html: icon("forward"), onclick: () => step(1) });
  const upb = h("button.icon-btn", { title: "Up", html: icon("up"), onclick: () => go(cwd.replace(/\/[^/]+$/, "") || info.home) });
  const crumbs = h("div.grow", { style: "display:flex;gap:4px;align-items:center;overflow:hidden;font-weight:700" });
  const searchInput = h("input.field", { placeholder: "Filter", oninput: e => { filter = e.target.value.toLowerCase(); draw(); } });
  const search = h("div.search", { style: "width:180px" }, h("span", { html: icon("search") }), searchInput);
  const viewSeg = h("div.seg", h("button", { "data-v": "grid", onclick: () => setView("grid"), title: "Icons", html: icon("grid", 16) }),
                    h("button", { "data-v": "list", onclick: () => setView("list"), title: "List", html: icon("list", 16) }));
  const newBtn = h("button.btn.small.ghost", { onclick: newFolder }, h("span", { html: icon("plus", 14) }), "New folder");
  const pasteBtn = h("button.btn.small.ghost", { onclick: paste, title: "Paste" }, "Paste");
  const bar = h("div.bar", back, fwd, upb, crumbs, search, viewSeg, pasteBtn, newBtn);
  const body = h("div.body"); const status = h("div.small.muted", { style: "padding:8px 18px;border-top:1px solid var(--line)" });
  root.append(h("div.app", side, h("div.main", bar, body, status)));

  function setView(v) { view = v; savePrefs(); draw(); }
  function step(d) { const n = at + d; if (n < 0 || n >= history.length) return; at = n; load(history[at], false); }
  function go(path) { history = history.slice(0, at + 1); history.push(path); at = history.length - 1; load(path, false); }

  async function load(path) {
    bin = false;
    try { entries = await wos.call("fs.list", { path, hidden }); } catch (e) { toast(e.message); return; }
    cwd = path; picked = null; filter = ""; searchInput.value = ""; draw();
  }

  function drawNav() {
    nav.innerHTML = "";
    places.forEach(p => nav.append(h("button" + (cwd === p.path && !bin ? ".on" : ""), { onclick: () => { bin = false; go(p.path); } }, h("span", { html: icon(p.icon) }), p.name)));
    nav.append(h("button" + (bin ? ".on" : ""), { onclick: showBin }, h("span", { html: icon("trash") }), "Bin"));
  }
  function drawCrumbs() {
    crumbs.innerHTML = "";
    const rel = cwd === info.home ? [] : cwd.slice(info.home.length + 1).split("/");
    let acc = info.home;
    crumbs.append(h("button.btn.small.ghost", { onclick: () => go(info.home) }, "Home"));
    rel.forEach(part => { acc += "/" + part; const p = acc; crumbs.append(h("span.muted", "/"), h("button.btn.small.ghost", { onclick: () => go(p) }, part)); });
  }

  function draw() {
    drawNav(); drawCrumbs();
    back.disabled = at === 0; fwd.disabled = at >= history.length - 1;
    $$("button", viewSeg).forEach(b => b.classList.toggle("on", b.dataset.v === view));
    const list = entries.filter(f => !filter || f.name.toLowerCase().includes(filter));
    body.innerHTML = "";
    if (!list.length) { body.append(h("div.empty", h("div", h("div", { html: icon("folder", 44), style: "color:var(--muted);margin-bottom:10px" }), h("p", filter ? "Nothing here matches." : "This folder is empty.")))); }
    else if (view === "grid") {
      const grid = h("div.grid");
      list.forEach(f => {
        const thumb = isImage(f) ? h("img", { src: fileUri(f.path), style: "width:100%;height:84px;object-fit:cover;border-radius:10px;background:var(--panel-2)" })
                                  : h("div", { html: icon(kindIcon(f), 40), style: "height:84px;display:grid;place-items:center;color:var(--ink-2)" });
        grid.append(h("div.tile" + (picked === f ? ".on" : ""), { onclick: () => { picked = f; draw(); }, ondblclick: () => openIt(f) },
          thumb, h("div.t", { style: "margin-top:8px;font-weight:700;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" }, f.name)));
      });
      body.append(grid);
    } else {
      const card = h("div.card"); const l = h("div.list");
      list.forEach(f => l.append(h("div.row" + (picked === f ? ".on" : ""), { onclick: () => { picked = f; draw(); }, ondblclick: () => openIt(f) },
        h("span", { html: icon(kindIcon(f), 20), style: "color:var(--ink-2)" }), h("div.grow", h("div.t", f.name)),
        h("span.small.muted", f.dir ? "" : fmtSize(f.size)), h("span.small.muted", { style: "width:120px;text-align:right" }, new Date(f.mtime * 1000).toLocaleDateString("en-GB")))));
      card.append(l); body.append(card);
    }
    status.textContent = `${list.length} item${list.length === 1 ? "" : "s"}` + (picked ? `  ·  ${picked.name}` : "");
  }

  async function openIt(f) { if (f.dir) go(f.path); else { try { await wos.call("fs.open", { path: f.path }); } catch (e) { toast(e.message); } } }
  async function paste() {
    if (!clipboard) return;
    try { await wos.call(clipboard.mode === "copy" ? "fs.copy" : "fs.move", { paths: clipboard.paths, dest: cwd }); if (clipboard.mode === "move") clipboard = null; load(cwd); toast("Done"); } catch (e) { toast(e.message); }
  }
  async function showBin() {
    bin = true; picked = null; body.innerHTML = ""; drawNav(); crumbs.innerHTML = ""; crumbs.append(h("span", { style: "font-weight:800" }, "Bin"));
    let items = []; try { items = await wos.call("fs.bin.list"); } catch (e) { items = []; }
    if (!items.length) { body.append(h("div.empty", h("div", h("div", { html: icon("trash", 44), style: "color:var(--muted);margin-bottom:10px" }), h("p", "The Bin is empty.")))); status.textContent = "0 items"; return; }
    const l = h("div.list"); items.forEach(it => l.append(h("div.row", { style: "cursor:default" }, h("span", { html: icon(it.dir ? "folder" : "file", 20), style: "color:var(--ink-2)" }),
      h("div.grow", h("div.t", it.name), h("div.s", it.orig)), h("button.btn.ghost.small", { onclick: async () => { try { await wos.call("fs.bin.restore", { id: it.id }); showBin(); } catch (e) { toast(e.message); } } }, "Put back"))));
    body.append(h("div.card", l), h("div", { style: "margin-top:12px" }, h("button.btn.danger.small", { onclick: async () => { if (!await confirmBox("Empty the Bin?", "Everything in it will be deleted for good.", "Empty Bin", true)) return; await wos.call("fs.bin.empty"); showBin(); } }, "Empty Bin")));
    status.textContent = items.length + " item" + (items.length === 1 ? "" : "s");
  }
  async function newFolder() {
    const name = await prompt2("New folder", "Untitled folder"); if (!name || !name.trim()) return;
    try { await wos.call("fs.mkdir", { parent: cwd, name: name.trim() }); load(cwd); } catch (e) { toast(e.message); }
  }
  async function rename() {
    if (!picked) return; const name = await prompt2("Rename", picked.name); if (!name || name === picked.name) return;
    try { await wos.call("fs.rename", { path: picked.path, name }); load(cwd); } catch (e) { toast(e.message); }
  }
  async function trash() {
    if (!picked) return;
    if (!await confirmBox("Move to Bin?", `“${picked.name}” will go to the Bin.`, "Move to Bin", true)) return;
    try { await wos.call("fs.trash", { path: picked.path }); load(cwd); } catch (e) { toast(e.message); }
  }
  document.addEventListener("keydown", e => {
    if (e.target.tagName === "INPUT") return;
    if (e.key === "F2") rename(); else if (e.key === "Delete") trash(); else if (e.key === "Enter" && picked) openIt(picked);
    else if (e.key === "Backspace") upb.click(); else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "h") { hidden = !hidden; savePrefs(); load(cwd); e.preventDefault(); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "n") { e.preventDefault(); newFolder(); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "c" && picked) { clipboard = { mode: "copy", paths: [picked.path] }; toast("Copied"); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "x" && picked) { clipboard = { mode: "move", paths: [picked.path] }; toast("Cut"); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v" && clipboard) { paste(); }
  });
  wos.on("theme", () => {});
  if ((info.args || []).includes("bin")) showBin(); else load(cwd);      // the desktop's Bin opens straight to the Bin
});
