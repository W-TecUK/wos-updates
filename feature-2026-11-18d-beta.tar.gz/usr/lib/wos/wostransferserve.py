"""Transfer over the network: a small, short-lived upload page the old Windows PC or Mac opens in a browser.

How it is kept safe (and what it is not):
- Off unless the person turns it on, and it stops by itself after 10 idle minutes or when Transfer closes.
- Local network only: a request from an address that is not private (home/office LAN, link-local or this computer) is refused.
  It is never meant to be reachable from the internet; do not forward a port to it.
- A random 6-digit check code, shown on this computer only. One computer can pair with it, once. Five wrong codes shut it down.
- Uploads only ever land inside the inbox folder: every path is cleaned, nothing can climb out of it, nothing is overwritten.
- It is NOT encrypted (plain http on the local network). Use it on a network you trust. Say this on screen.

Standard library only. The old computer's browser page is necessarily a web page; everything on this side is native.
"""
import hmac
import ipaddress
import os
import re
import secrets
import shutil
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

MAX_WRONG_CODES = 5
IDLE_SECONDS = 600
MAX_FILES = 500_000
MAX_NAME = 200
FREE_MARGIN = 200 * 1024 * 1024
BAD_CHARS = re.compile(r"[\x00-\x1f<>:\"|?*]")


class ServeError(Exception):
    """Message safe to show to the person."""


def clean_relative_path(raw):
    """A browser-sent path like 'Documents\\cv.docx' -> ['Documents', 'cv.docx']. Raises ValueError if it is unsafe."""
    parts = [p for p in re.split(r"[\\/]+", raw) if p not in ("", ".")]
    if not parts or len(parts) > 40:
        raise ValueError("empty or too deep")
    for p in parts:
        if p == ".." or len(p) > MAX_NAME or BAD_CHARS.search(p) or p.endswith((".", " ")):
            raise ValueError("unsafe name")
    return parts


def is_local(addr):
    try:
        ip = ipaddress.ip_address(addr.split("%")[0])
    except ValueError:
        return False
    if ip.version == 6 and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return ip.is_private or ip.is_link_local or ip.is_loopback


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Send to W-OS</title><style>
body{margin:0;background:#141414;color:#fff;font:16px/1.5 system-ui,sans-serif;display:grid;place-items:center;min-height:100vh}
main{width:min(560px,92vw);padding:32px}h1{font-size:30px;margin:0 0 8px}p{color:#a3a8b0}
input,button{font:inherit;border-radius:999px;border:0;padding:12px 22px}input{background:#2b2b2b;color:#fff;width:9em;letter-spacing:.3em;text-align:center}
button{background:#fff;color:#000;font-weight:700;cursor:pointer}button.s{background:#2b2b2b;color:#fff}
.card{background:#1f1f1f;border-radius:22px;padding:18px 22px;margin:18px 0}.bar{height:10px;background:#2b2b2b;border-radius:99px;overflow:hidden}
.bar i{display:block;height:100%;width:0;background:#FFC933}.bad{color:#ff6b6b}[hidden]{display:none}
</style></head><body><main>
<section id="a"><h1>Send to W-OS</h1><p>Type the 6-digit check code shown on the W-OS computer.</p>
<p><input id="code" inputmode="numeric" maxlength="6" autocomplete="off"> <button id="go">Connect</button></p><p id="err" class="bad"></p></section>
<section id="b" hidden><h1>Choose what to send</h1><p>Pick your Documents, Pictures, Music or Videos folders, or any other folders. Your files stay on this computer too.</p>
<div class="card"><p><button id="pickdir">Choose folders</button> <button id="pickfiles" class="s">Choose files</button></p>
<input id="dir" type="file" webkitdirectory multiple hidden><input id="files" type="file" multiple hidden></div>
<div class="card" id="prog" hidden><div class="bar"><i id="fill"></i></div><p id="txt"></p></div>
<p>This page is not encrypted. Only use it on a network you trust. Close it when you are done.</p></section>
<script>
let token="";const $=id=>document.getElementById(id);
$("go").onclick=async()=>{const r=await fetch("/api/pair",{method:"POST",body:$("code").value.trim()});
 if(r.ok){token=await r.text();$("a").hidden=true;$("b").hidden=false}else{$("err").textContent=r.status==429?"Too many wrong codes. Start again on the W-OS computer.":"That code is not right."}};
$("pickdir").onclick=()=>$("dir").click();$("pickfiles").onclick=()=>$("files").click();
async function send(list){list=[...list];let total=list.reduce((a,f)=>a+f.size,0),done=0,n=0;$("prog").hidden=false;
 for(const f of list){const p=f.webkitRelativePath||f.name;
  const r=await fetch("/api/upload?path="+encodeURIComponent(p),{method:"PUT",headers:{"X-Token":token},body:f});
  if(!r.ok){$("txt").textContent="Stopped: "+(await r.text());$("txt").className="bad";return}
  done+=f.size;n++;$("fill").style.width=(total?100*done/total:100)+"%";$("txt").textContent=n+" of "+list.length+" files sent"}
 await fetch("/api/done",{method:"POST",headers:{"X-Token":token}});$("txt").textContent="All sent. Carry on at the W-OS computer."}
$("dir").onchange=e=>send(e.target.files);$("files").onchange=e=>send(e.target.files);
</script></main></body></html>"""


class TransferServer:
    def __init__(self, inbox, code=None, idle_seconds=IDLE_SECONDS, max_bytes=None):
        self.inbox = os.path.abspath(inbox)
        self.code = code or "%06d" % secrets.randbelow(10 ** 6)
        self.idle_seconds = idle_seconds
        self.max_bytes = max_bytes
        self.token = None
        self.wrong = 0
        self.locked = False
        self.files = 0
        self.bytes = 0
        self.finished = False
        self.last_seen = time.time()
        self._lock = threading.Lock()
        self._httpd = None
        self.port = None
        self.on_change = None

    # ----- lifecycle -----
    def start(self, host="0.0.0.0", port=0):
        os.makedirs(self.inbox, exist_ok=True)
        server = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            def log_message(self, *a):
                pass
            def do_GET(self):
                server._handle(self, "GET")
            def do_POST(self):
                server._handle(self, "POST")
            def do_PUT(self):
                server._handle(self, "PUT")

        self._httpd = ThreadingHTTPServer((host, port), Handler)
        self.port = self._httpd.server_address[1]
        threading.Thread(target=self._httpd.serve_forever, daemon=True).start()
        threading.Thread(target=self._watchdog, daemon=True).start()
        return self.port

    def stop(self):
        httpd, self._httpd = self._httpd, None
        if httpd:
            threading.Thread(target=lambda: (httpd.shutdown(), httpd.server_close()), daemon=True).start()

    @property
    def running(self):
        return self._httpd is not None

    def _watchdog(self):
        while self.running:
            time.sleep(1)
            if time.time() - self.last_seen > self.idle_seconds:
                self.stop()

    def _changed(self):
        if self.on_change:
            try:
                self.on_change()
            except Exception:
                pass

    # ----- request handling -----
    def _send(self, h, status, body=b"", ctype="text/plain; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode()
        h.send_response(status)
        h.send_header("Content-Type", ctype)
        h.send_header("Content-Length", str(len(body)))
        h.send_header("Cache-Control", "no-store")
        h.send_header("X-Content-Type-Options", "nosniff")
        h.send_header("Content-Security-Policy", "default-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'")
        h.end_headers()
        h.wfile.write(body)

    def _handle(self, h, method):
        if not is_local(h.client_address[0]):
            return self._send(h, 403, "This only works on your own network.")
        self.last_seen = time.time()
        url = urlparse(h.path)
        try:
            if method == "GET" and url.path == "/":
                return self._send(h, 200, PAGE, "text/html; charset=utf-8")
            if method == "POST" and url.path == "/api/pair":
                return self._pair(h)
            token_ok = self.token is not None and hmac.compare_digest(h.headers.get("X-Token", ""), self.token)
            if not token_ok:
                return self._send(h, 401, "Not connected.")
            if method == "PUT" and url.path == "/api/upload":
                return self._upload(h, parse_qs(url.query).get("path", [""])[0])
            if method == "POST" and url.path == "/api/done":
                self.finished = True
                self._changed()
                return self._send(h, 200, "ok")
            return self._send(h, 404, "Not found.")
        except (ConnectionError, TimeoutError):
            return None

    def _pair(self, h):
        length = min(int(h.headers.get("Content-Length") or 0), 32)
        given = h.rfile.read(length).decode("ascii", "ignore")
        with self._lock:
            if self.locked or self.token is not None:
                return self._send(h, 429 if self.locked else 409, "Not available.")
            if hmac.compare_digest(given, self.code):
                self.token = secrets.token_urlsafe(24)
                token = self.token
            else:
                self.wrong += 1
                if self.wrong >= MAX_WRONG_CODES:
                    self.locked = True
                    self.stop()
                self._changed()
                return self._send(h, 429 if self.locked else 403, "Wrong code.")
        self._changed()
        return self._send(h, 200, token)

    def _free(self):
        return shutil.disk_usage(self.inbox).free - FREE_MARGIN

    def _upload(self, h, raw_path):
        try:
            parts = clean_relative_path(raw_path)
        except ValueError:
            return self._send(h, 400, "That file name cannot be used.")
        length = int(h.headers.get("Content-Length") or -1)
        if length < 0:
            return self._send(h, 411, "Length needed.")
        limit = self.max_bytes if self.max_bytes is not None else self._free()
        if self.bytes + length > limit or self.files >= MAX_FILES:
            return self._send(h, 507, "There is not enough room on this computer.")
        dest = os.path.normpath(os.path.join(self.inbox, *parts))
        if os.path.commonpath([self.inbox, dest]) != self.inbox:
            return self._send(h, 400, "That file name cannot be used.")
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if os.path.lexists(dest):
            base, ext = os.path.splitext(dest)
            n = 2
            while os.path.lexists("%s (%d)%s" % (base, n, ext)):
                n += 1
            dest = "%s (%d)%s" % (base, n, ext)
        part = dest + ".part"
        remaining = length
        with open(part, "wb") as f:
            while remaining:
                chunk = h.rfile.read(min(1 << 20, remaining))
                if not chunk:
                    break
                f.write(chunk)
                remaining -= len(chunk)
        if remaining:
            os.remove(part)
            return self._send(h, 400, "The upload was cut short.")
        os.replace(part, dest)
        self.files += 1
        self.bytes += length
        self._changed()
        return self._send(h, 200, "ok")


def lan_addresses():
    """This computer's private IPv4 addresses, best guess first. Uses only the standard library."""
    import socket
    found = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))            # no packet is sent; it just picks the LAN interface
        found.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if ip not in found and not ip.startswith("127."):
                found.append(ip)
    except OSError:
        pass
    return [ip for ip in found if is_local(ip) and not ip.startswith("127.")]
