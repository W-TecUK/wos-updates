"""MPRIS for W-OS Music, so the dock's music pill, media keys and other desktop parts can see and control it.
`player` is any object with: status ("Playing"|"Paused"|"Stopped"), metadata() -> dict of plain values, volume (0..1), position_us,
play_pause(), play(), pause(), stop(), next(), previous(), seek_us(offset), set_position_us(pos), raise_window(), quit()."""
from gi.repository import Gio, GLib

NAME = "org.mpris.MediaPlayer2.wosmusic"
PATH = "/org/mpris/MediaPlayer2"
ROOT_IFACE = "org.mpris.MediaPlayer2"
PLAYER_IFACE = "org.mpris.MediaPlayer2.Player"

XML = """
<node>
  <interface name="org.mpris.MediaPlayer2">
    <method name="Raise"/><method name="Quit"/>
    <property name="CanQuit" type="b" access="read"/><property name="CanRaise" type="b" access="read"/>
    <property name="HasTrackList" type="b" access="read"/><property name="Identity" type="s" access="read"/>
    <property name="DesktopEntry" type="s" access="read"/>
    <property name="SupportedUriSchemes" type="as" access="read"/><property name="SupportedMimeTypes" type="as" access="read"/>
  </interface>
  <interface name="org.mpris.MediaPlayer2.Player">
    <method name="Next"/><method name="Previous"/><method name="Pause"/><method name="PlayPause"/><method name="Stop"/><method name="Play"/>
    <method name="Seek"><arg type="x" direction="in"/></method>
    <method name="SetPosition"><arg type="o" direction="in"/><arg type="x" direction="in"/></method>
    <method name="OpenUri"><arg type="s" direction="in"/></method>
    <property name="PlaybackStatus" type="s" access="read"/><property name="Metadata" type="a{sv}" access="read"/>
    <property name="Volume" type="d" access="readwrite"/><property name="Position" type="x" access="read"/>
    <property name="Rate" type="d" access="read"/><property name="MinimumRate" type="d" access="read"/><property name="MaximumRate" type="d" access="read"/>
    <property name="CanGoNext" type="b" access="read"/><property name="CanGoPrevious" type="b" access="read"/>
    <property name="CanPlay" type="b" access="read"/><property name="CanPause" type="b" access="read"/>
    <property name="CanSeek" type="b" access="read"/><property name="CanControl" type="b" access="read"/>
  </interface>
</node>
"""


def metadata_variant(md):
    """md: {"path", "title", "artist", "album", "length"(seconds)} -> an a{sv} of MPRIS keys."""
    d = {"mpris:trackid": GLib.Variant("o", "/org/wos/music/track/%d" % (abs(hash(md.get("path", ""))) % 10 ** 9))}
    if md.get("title"):
        d["xesam:title"] = GLib.Variant("s", md["title"])
    if md.get("artist"):
        d["xesam:artist"] = GLib.Variant("as", [md["artist"]])
    if md.get("album"):
        d["xesam:album"] = GLib.Variant("s", md["album"])
    if md.get("length"):
        d["mpris:length"] = GLib.Variant("x", int(md["length"] * 1000000))
    if md.get("path"):
        d["xesam:url"] = GLib.Variant("s", GLib.filename_to_uri(md["path"], None))
    return d if md else {}


class Mpris:
    def __init__(self, player, bus=None):
        self.player = player
        self.bus = bus or Gio.bus_get_sync(Gio.BusType.SESSION, None)
        info = Gio.DBusNodeInfo.new_for_xml(XML)
        self.ids = []
        for iface in info.interfaces:
            self.ids.append(self.bus.register_object(PATH, iface, self._call, self._get, self._set))
        self.owner = Gio.bus_own_name_on_connection(self.bus, NAME, Gio.BusNameOwnerFlags.NONE, None, None)

    def close(self):
        for i in self.ids:
            self.bus.unregister_object(i)
        Gio.bus_unown_name(self.owner)

    # ---- properties
    def _get(self, conn, sender, path, iface, prop):
        p = self.player
        if iface == ROOT_IFACE:
            return {"CanQuit": GLib.Variant("b", True), "CanRaise": GLib.Variant("b", True), "HasTrackList": GLib.Variant("b", False),
                    "Identity": GLib.Variant("s", "Music"), "DesktopEntry": GLib.Variant("s", "wos-music"),
                    "SupportedUriSchemes": GLib.Variant("as", ["file"]),
                    "SupportedMimeTypes": GLib.Variant("as", ["audio/mpeg", "audio/flac", "audio/ogg", "audio/mp4", "audio/x-wav"])}.get(prop)
        has = bool(p.metadata())
        return {"PlaybackStatus": lambda: GLib.Variant("s", p.status),
                "Metadata": lambda: GLib.Variant("a{sv}", metadata_variant(p.metadata())),
                "Volume": lambda: GLib.Variant("d", float(p.volume)),
                "Position": lambda: GLib.Variant("x", int(p.position_us)),
                "Rate": lambda: GLib.Variant("d", 1.0), "MinimumRate": lambda: GLib.Variant("d", 1.0), "MaximumRate": lambda: GLib.Variant("d", 1.0),
                "CanGoNext": lambda: GLib.Variant("b", has), "CanGoPrevious": lambda: GLib.Variant("b", has),
                "CanPlay": lambda: GLib.Variant("b", True), "CanPause": lambda: GLib.Variant("b", has),
                "CanSeek": lambda: GLib.Variant("b", has), "CanControl": lambda: GLib.Variant("b", True)}.get(prop, lambda: None)()

    def _set(self, conn, sender, path, iface, prop, value):
        if iface == PLAYER_IFACE and prop == "Volume":
            self.player.set_volume_fraction(max(0.0, min(1.0, value.get_double())))
            return True
        return False

    # ---- methods
    def _call(self, conn, sender, path, iface, method, params, invocation):
        p = self.player
        args = params.unpack()
        if iface == ROOT_IFACE:
            {"Raise": p.raise_window, "Quit": p.quit}.get(method, lambda: None)()
        else:
            if method == "Seek":
                p.seek_us(args[0])
            elif method == "SetPosition":
                p.set_position_us(args[1])
            elif method == "OpenUri":
                pass
            else:
                {"Next": p.next, "Previous": p.previous, "Pause": p.pause, "PlayPause": p.play_pause, "Stop": p.stop, "Play": p.play}.get(method, lambda: None)()
        invocation.return_value(None)

    def changed(self, *names):
        """Tell listeners that these Player properties changed."""
        changed = {}
        for n in names:
            v = self._get(None, None, PATH, PLAYER_IFACE, n)
            if v is not None:
                changed[n] = v
        try:
            self.bus.emit_signal(None, PATH, "org.freedesktop.DBus.Properties", "PropertiesChanged",
                                 GLib.Variant("(sa{sv}as)", (PLAYER_IFACE, changed, [])))
        except GLib.Error:
            pass
