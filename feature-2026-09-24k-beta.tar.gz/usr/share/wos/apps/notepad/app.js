"use strict";
/* Notepad: a list of notes on the left, the note you are writing on the right. Saves as you type. */

boot(async () => {
  const root = $("#root");
  let notes = await wos.data.get("notes", null);
  if (!notes) {
    notes = [{ id: uid(), title: "Welcome to Notepad", body: "Write anything. It saves as you type.\n\nPin a note to keep it at the top.", updated: Date.now(), pinned: true }];
    await wos.data.set("notes", notes);
  }
  let current = notes[0].id, query = "";
  const save = debounce(() => wos.data.set("notes", notes), 300);
  const get = id => notes.find(n => n.id === id);

  const list = h("div.list"); const listWrap = h("div.body.pad0", list);
  const search = h("input.field", { placeholder: "Search", oninput: e => { query = e.target.value.toLowerCase(); drawList(); } });
  const addBtn = h("button.btn.small", { onclick: add }, h("span", { html: icon("plus", 14) }), "New");
  const side = h("aside.side", { style: "display:flex;flex-direction:column;padding:12px;gap:10px" },
    h("div", { style: "display:flex;gap:8px;align-items:center" }, h("div.search", { style: "flex:1" }, h("span", { html: icon("search") }), search), addBtn),
    h("div.card", { style: "flex:1;overflow:auto" }, list));
  const title = h("input.field", { placeholder: "Title", style: "border:0;background:none;font-size:22px;font-weight:800;padding:0;height:auto", oninput: e => edit("title", e.target.value) });
  const text = h("textarea.field", { placeholder: "Start writing…", style: "flex:1;border:0;background:none;font-size:15px;line-height:1.65;padding:0", oninput: e => edit("body", e.target.value) });
  const meta = h("div.small.muted"); const count = h("div.small.muted");
  const pin = h("button.icon-btn", { title: "Pin", onclick: () => { const n = get(current); n.pinned = !n.pinned; save(); draw(); } });
  const del = h("button.icon-btn", { title: "Delete note", html: icon("trash"), onclick: remove });
  const bar = h("div.bar", meta, h("div.grow"), count, pin, del);
  const editor = h("div", { style: "display:flex;flex-direction:column;flex:1;padding:22px 30px;gap:12px;min-height:0" }, title, text);
  root.append(h("div.app", side, h("div.main", bar, editor)));

  function edit(field, value) { const n = get(current); n[field] = value; n.updated = Date.now(); save(); drawList(); stats(); }
  function add() { const n = { id: uid(), title: "", body: "", updated: Date.now(), pinned: false }; notes.unshift(n); current = n.id; save(); draw(); title.focus(); }
  async function remove() {
    const n = get(current); if (!n) return;
    if (!await confirmBox("Delete this note?", `“${n.title || "Untitled"}” will be deleted for good.`, "Delete", true)) return;
    notes = notes.filter(x => x.id !== n.id); if (!notes.length) notes.push({ id: uid(), title: "", body: "", updated: Date.now(), pinned: false });
    current = notes[0].id; save(); draw();
  }
  function stats() { const n = get(current); const words = (n.body.trim().match(/\S+/g) || []).length; count.textContent = `${words} word${words === 1 ? "" : "s"}`; meta.textContent = "Edited " + new Date(n.updated).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }); }
  function drawList() {
    list.innerHTML = "";
    const shown = [...notes].filter(n => !query || (n.title + " " + n.body).toLowerCase().includes(query)).sort((a, b) => (b.pinned - a.pinned) || b.updated - a.updated);
    if (!shown.length) list.append(h("div.row.muted", "No notes"));
    shown.forEach(n => list.append(h("button.row" + (n.id === current ? ".on" : ""), { onclick: () => { current = n.id; draw(); } },
      h("div.grow", h("div.t", (n.pinned ? "★ " : "") + (n.title || "Untitled")), h("div.s", (n.body.split("\n")[0] || "No text").slice(0, 60))))));
  }
  function draw() {
    const n = get(current);
    title.value = n.title; text.value = n.body; pin.innerHTML = icon("star"); pin.style.color = n.pinned ? "#ff9f0a" : "";
    drawList(); stats();
  }
  document.addEventListener("keydown", e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "n") { e.preventDefault(); add(); } });
  draw();
});
