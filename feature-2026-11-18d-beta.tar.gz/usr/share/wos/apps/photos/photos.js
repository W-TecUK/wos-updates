"use strict";
/* Photos logic with no screen in it, so it can be tested (os/tests/photos.test.js).
   A photo is {name, path, uri, mtime (seconds), size (bytes, optional)}. */
(function (root) {
  const parentOf = p => p.replace(/\/[^/]+$/, "") || "/";
  const baseOf = p => p.split("/").filter(Boolean).pop() || p;

  /* Newest first, grouped by month: [{label, key, items}]. */
  function byMonth(photos, locale) {
    const out = []; let cur = null;
    [...photos].sort((a, b) => b.mtime - a.mtime).forEach(p => {
      const d = new Date(p.mtime * 1000), key = d.getFullYear() * 100 + d.getMonth();
      if (!cur || cur.key !== key) { cur = { key, label: d.toLocaleDateString(locale || "en-GB", { month: "long", year: "numeric" }), items: [] }; out.push(cur); }
      cur.items.push(p);
    });
    return out;
  }

  /* Albums the person has without doing anything: one per folder that holds pictures (named by the folder, with its parent
     when two folders share a name), plus Screenshots. Largest first. */
  function folderAlbums(photos, home) {
    const by = new Map();
    photos.forEach(p => { const f = parentOf(p.path); if (!by.has(f)) by.set(f, []); by.get(f).push(p); });
    const names = {}; by.forEach((_, f) => { const n = baseOf(f); names[n] = (names[n] || 0) + 1; });
    const albums = [...by.entries()].map(([folder, items]) => {
      let name = baseOf(folder);
      if (folder === home) name = "Home folder";
      else if (names[name] > 1) name = baseOf(parentOf(folder)) + " / " + name;
      return { id: "dir:" + folder, name, items: items.sort((a, b) => b.mtime - a.mtime), kind: "folder" };
    });
    const shots = photos.filter(p => /screenshot/i.test(p.name));
    if (shots.length && !albums.some(a => a.name.toLowerCase() === "screenshots")) albums.push({ id: "shots", name: "Screenshots", items: shots.sort((a, b) => b.mtime - a.mtime), kind: "smart" });
    return albums.sort((a, b) => b.items.length - a.items.length || a.name.localeCompare(b.name));
  }

  /* Pictures in the person's own albums ({id, name, paths}); missing files are dropped quietly. */
  function customAlbum(album, photos) {
    const want = new Set(album.paths); const have = photos.filter(p => want.has(p.path));
    return { id: album.id, name: album.name, items: have.sort((a, b) => b.mtime - a.mtime), kind: "custom" };
  }

  /* A centred crop of w x h at a given aspect ratio (0 = keep as is). Returns {x, y, w, h} in whole pixels. */
  function cropRect(w, h, ratio) {
    if (!ratio || w <= 0 || h <= 0) return { x: 0, y: 0, w, h };
    let cw = w, ch = Math.round(w / ratio);
    if (ch > h) { ch = h; cw = Math.round(h * ratio); }
    return { x: Math.floor((w - cw) / 2), y: Math.floor((h - ch) / 2), w: cw, h: ch };
  }

  /* CSS/canvas filter string for the edit sliders (each -100..100, 0 = unchanged) and a named look. */
  const LOOKS = { none: "", mono: "grayscale(1) contrast(1.05)", warm: "sepia(.25) saturate(1.2) hue-rotate(-8deg)", cool: "saturate(1.05) hue-rotate(12deg) brightness(1.02)", vivid: "saturate(1.45) contrast(1.08)", fade: "contrast(.88) brightness(1.08) saturate(.85)" };
  function filterString(adj, look) {
    const a = adj || {}, c = v => Math.max(-100, Math.min(100, +v || 0));
    const parts = [];
    if (c(a.brightness)) parts.push(`brightness(${(1 + c(a.brightness) / 100).toFixed(2)})`);
    if (c(a.contrast)) parts.push(`contrast(${(1 + c(a.contrast) / 100).toFixed(2)})`);
    if (c(a.saturation)) parts.push(`saturate(${(1 + c(a.saturation) / 100).toFixed(2)})`);
    if (LOOKS[look]) parts.push(LOOKS[look]);
    return parts.join(" ") || "none";
  }

  /* Output size after rotating by quarter turns. */
  function rotatedSize(w, h, quarters) { return (((quarters % 4) + 4) % 4) % 2 ? { w: h, h: w } : { w, h }; }

  const fmtBytes = n => n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : n >= 1024 ? Math.round(n / 1024) + " KB" : n + " bytes";
  /* A name for the edited copy: "holiday.jpg" -> "holiday (edited).jpg"; picks (edited 2) etc. if taken. */
  function editedName(name, taken) {
    const dot = name.lastIndexOf("."), stem = dot > 0 ? name.slice(0, dot) : name, ext = dot > 0 ? name.slice(dot) : "";
    const have = new Set((taken || []).map(t => t.toLowerCase()));
    let out = `${stem} (edited)${ext}`, n = 2;
    while (have.has(out.toLowerCase())) out = `${stem} (edited ${n++})${ext}`;
    return out;
  }


  /* The edit itself, on raw RGBA pixels, so the preview and the saved copy are the same picture. adj: brightness, contrast and
     saturation from -100 to 100; look: one of LOOKS. Changes data in place and returns it. */
  const LOOK_PARAMS = { none: [0, 0, 0, 1, 1, 1], mono: [0.0, 0.05, -1, 1, 1, 1], warm: [0.0, 0.0, 0.2, 1.08, 1.0, 0.9], cool: [0.02, 0.0, 0.05, 0.92, 1.0, 1.08], vivid: [0.0, 0.08, 0.45, 1, 1, 1], fade: [0.08, -0.12, -0.15, 1, 1, 1] };
  function adjustPixels(data, adj, look) {
    const a = adj || {}, cl = v => Math.max(-100, Math.min(100, +v || 0)) / 100;
    const L = LOOK_PARAMS[look] || LOOK_PARAMS.none;
    const bright = cl(a.brightness) + L[0], contrast = 1 + cl(a.contrast) + L[1], sat = Math.max(0, 1 + cl(a.saturation) + L[2]);
    const mr = L[3], mg = L[4], mb = L[5];
    if (!bright && contrast === 1 && sat === 1 && mr === 1 && mg === 1 && mb === 1) return data;
    const clamp = v => v < 0 ? 0 : v > 255 ? 255 : v;
    for (let i = 0; i < data.length; i += 4) {
      let r = data[i] * mr, g = data[i + 1] * mg, b = data[i + 2] * mb;
      const gray = 0.299 * r + 0.587 * g + 0.114 * b;
      r = gray + (r - gray) * sat; g = gray + (g - gray) * sat; b = gray + (b - gray) * sat;
      r = (r - 128) * contrast + 128 + bright * 255; g = (g - 128) * contrast + 128 + bright * 255; b = (b - 128) * contrast + 128 + bright * 255;
      data[i] = clamp(r); data[i + 1] = clamp(g); data[i + 2] = clamp(b);
    }
    return data;
  }

  const api = { adjustPixels, byMonth, folderAlbums, customAlbum, cropRect, filterString, LOOKS, rotatedSize, fmtBytes, editedName, parentOf, baseOf };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.PhotoLogic = api;
})(typeof window !== "undefined" ? window : globalThis);
