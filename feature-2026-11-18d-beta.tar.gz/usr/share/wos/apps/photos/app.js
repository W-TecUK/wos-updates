"use strict";
/* Photos: your pictures by month, albums (a folder is an album, and you can make your own), favourites, a viewer with a
   slideshow and an editor that always saves a copy and never touches the original. The logic is in photos.js (tested). */

boot(async info => {
  const root = $("#root");
  const L = window.PhotoLogic;
  const errText = e => (e && e.message) || "Something went wrong";
  let photos = [], faves = new Set(await wos.data.get("faves", [])), custom = (await wos.data.get("albums", [])) || [];
  let current = { kind: "all" }, selecting = false, picked = new Set();
  const saveFaves = () => wos.data.set("faves", [...faves]), saveAlbums = () => wos.data.set("albums", custom);

  const side = h("aside.side"), body = h("div.body"), count = h("span.small.muted"), title = h("h1");
  const selectBtn = h("button.btn.small.ghost", { onclick: () => { selecting = !selecting; picked.clear(); draw(); } }, "Select");
  const playBtn = h("button.btn.small.ghost", { onclick: () => { const l = visible(); if (l.length) open(l, 0, true); } }, h("span", { html: icon("refresh", 14) }), "Slideshow");
  const selBar = h("div", { style: "display:none;padding:8px 18px;background:var(--sel);gap:10px;align-items:center" });
  const bar = h("div.bar", title, count, h("div.grow"), playBtn, selectBtn, h("button.icon-btn", { title: "Look for new pictures", html: icon("refresh"), onclick: load }));
  root.append(h("div.app", side, h("div.main", bar, selBar, body)));

  // ---------- what is shown ----------
  const folders = () => L.folderAlbums(photos, info.home);
  const customs = () => custom.map(a => L.customAlbum(a, photos));
  function visible() {
    if (current.kind === "faves") return photos.filter(p => faves.has(p.path)).sort((a, b) => b.mtime - a.mtime);
    if (current.kind === "album") { const a = [...folders(), ...customs()].find(x => x.id === current.id); return a ? a.items : []; }
    return [...photos].sort((a, b) => b.mtime - a.mtime);
  }
  function drawSide() {
    side.innerHTML = "";
    const item = (label, ic, cur, n, onclick, extra) => h("button" + (cur ? ".on" : ""), { onclick }, h("span", { html: icon(ic) }), h("span", { style: "flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" }, label), n != null ? h("span.small", { style: "opacity:.7" }, n) : null, extra || null);
    const isCur = (k, id) => current.kind === k && (id === undefined || current.id === id);
    const go = (kind, id) => () => { current = { kind, id }; selecting = false; picked.clear(); draw(); };
    side.append(h("div.side-title", "Photos"), h("div.label", { style: "margin:6px 10px" }, "Library"),
      h("nav.nav", item("All photos", "image", isCur("all"), photos.length, go("all")), item("Favourites", "star", isCur("faves"), faves.size ? [...faves].filter(f => photos.some(p => p.path === f)).length : 0, go("faves"))));
    const own = customs();
    side.append(h("div", { style: "display:flex;align-items:center;margin:14px 10px 6px" }, h("span.label", { style: "flex:1;margin:0" }, "My albums"), h("button.icon-btn", { style: "width:24px;height:24px", title: "New album", html: icon("plus", 14), onclick: () => newAlbum() })));
    side.append(h("nav.nav", ...(own.length ? own.map(a => item(a.name, "folder", isCur("album", a.id), a.items.length, go("album", a.id))) : [h("div.small.muted", { style: "padding:4px 10px" }, "None yet")])));
    const fo = folders();
    if (fo.length) side.append(h("div.label", { style: "margin:14px 10px 6px" }, "Folders"), h("nav.nav", ...fo.slice(0, 14).map(a => item(a.name, a.kind === "smart" ? "eye" : "folder", isCur("album", a.id), a.items.length, go("album", a.id)))));
  }
  function drawHeader(list) {
    const album = current.kind === "album" ? [...folders(), ...customs()].find(x => x.id === current.id) : null;
    title.textContent = current.kind === "faves" ? "Favourites" : album ? album.name : "All photos";
    count.textContent = `${list.length} picture${list.length === 1 ? "" : "s"}`;
    selectBtn.textContent = selecting ? "Done" : "Select";
    playBtn.style.display = list.length ? "" : "none";
    selBar.style.display = selecting ? "flex" : "none"; selBar.innerHTML = "";
    if (selecting) {
      selBar.append(h("b", picked.size ? `${picked.size} selected` : "Click pictures to select them"), h("div", { style: "flex:1" }),
        h("button.btn.small.ghost", { disabled: !picked.size, onclick: addToAlbum }, "Add to album…"), h("button.btn.small.danger", { disabled: !picked.size, onclick: binPicked }, "Move to Bin"));
    }
    if (album && album.kind === "custom") selBar.style.display = selecting ? "flex" : "none";
  }
  function draw() {
    const list = visible(); drawSide(); drawHeader(list); body.innerHTML = "";
    if (!list.length) {
      body.append(h("div.empty", h("div", h("div", { html: icon(current.kind === "faves" ? "star" : "image", 44), style: "color:var(--muted);margin-bottom:10px" }),
        h("p", current.kind === "faves" ? "Star a picture in the viewer and it shows up here." : current.kind === "album" ? "There is nothing in this album yet." : "No pictures yet. Put some in your Pictures folder, or take a screenshot."),
        h("button.btn", { onclick: () => wos.call("sys.launch", { id: "wos-files.desktop" }) }, "Open Files"))));
      return;
    }
    L.byMonth(list).forEach(group => {
      body.append(h("div.label", { style: "margin:18px 2px 10px" }, group.label));
      const grid = h("div.grid", { style: "grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:6px" });
      group.items.forEach(p => grid.append(h("div", { style: "position:relative;aspect-ratio:1;border-radius:14px;overflow:hidden;background:var(--panel-2);cursor:pointer" + (picked.has(p.path) ? ";outline:3px solid var(--accent);outline-offset:-3px" : ""),
        onclick: () => { if (selecting) { picked.has(p.path) ? picked.delete(p.path) : picked.add(p.path); draw(); } else open(list, list.indexOf(p)); } },
        h("img", { src: p.uri, loading: "lazy", style: "width:100%;height:100%;object-fit:cover" }),
        faves.has(p.path) ? h("span", { html: icon("star", 14), style: "position:absolute;bottom:8px;left:8px;color:#ff9f0a;filter:drop-shadow(0 1px 2px rgba(0,0,0,.5))" }) : null,
        selecting ? h("span", { style: "position:absolute;top:8px;right:8px;width:22px;height:22px;border-radius:50%;display:grid;place-items:center;" + (picked.has(p.path) ? "background:var(--accent);color:#fff" : "background:rgba(0,0,0,.35);border:2px solid #fff"), html: picked.has(p.path) ? icon("check", 14) : "" }) : null)));
      body.append(grid);
    });
  }

  async function load() { body.innerHTML = ""; body.append(h("div.empty", "Looking for your pictures…")); try { photos = await wos.call("photos.list"); } catch (e) { toast(errText(e)); photos = []; } draw(); }

  // ---------- albums and bin ----------
  function newAlbum(then) {
    const name = h("input.field", { placeholder: "Album name", maxlength: 40 }); const done = () => back.remove();
    const make = () => { const n = name.value.trim(); if (!n) return; const a = { id: uid(), name: n, paths: [] }; custom.push(a); saveAlbums(); done(); drawSide(); if (then) then(a); };
    name.addEventListener("keydown", e => { if (e.key === "Enter") make(); });
    const back = h("div.modal-back", h("div.modal", h("h2", "New album"), h("div.form-row", name), h("div.actions", h("button.btn.ghost", { onclick: done }, "Cancel"), h("button.btn", { onclick: make }, "Create"))));
    document.body.append(back); name.focus();
  }
  function addToAlbum(e) {
    const items = [...custom.map(a => ({ label: a.name, icon: "folder", onclick: () => put(a) })), custom.length ? "-" : null, { label: "New album…", icon: "plus", onclick: () => newAlbum(put) }].filter(Boolean);
    const r = e.currentTarget.getBoundingClientRect(); contextMenu(items, r.left, r.bottom + 4);
    function put(a) { picked.forEach(p => { if (!a.paths.includes(p)) a.paths.push(p); }); saveAlbums(); toast(`Added to ${a.name}`); selecting = false; picked.clear(); draw(); }
  }
  async function binPicked() {
    const n = picked.size; if (!await confirmBox(`Move ${n} ${n === 1 ? "picture" : "pictures"} to the Bin?`, "You can bring them back from the Bin in Files.", "Move to Bin", true)) return;
    try { await wos.call("fs.trash", { paths: [...picked] }); photos = photos.filter(p => !picked.has(p.path)); picked.clear(); selecting = false; draw(); toast("Moved to the Bin"); } catch (e) { toast(errText(e)); }
  }

  // ---------- viewer, slideshow and editor ----------
  function open(list, start, slideshow) {
    let at = start, zoom = 1, timer = null, editing = null, info_ = false;
    const stage = h("div", { style: "flex:1;min-height:0;display:flex;align-items:center;justify-content:center;overflow:auto;position:relative" });
    const img = h("img", { style: "max-width:100%;max-height:100%;object-fit:contain" });
    const canvas = h("canvas", { style: "max-width:100%;max-height:100%;display:none" });
    const name = h("span", { style: "color:#fff;font-weight:700" }), meta = h("div", { style: "display:none;position:absolute;left:14px;bottom:14px;padding:12px 16px;border-radius:14px;background:rgba(0,0,0,.65);color:#fff;font-size:13px;line-height:1.6" });
    const panel = h("div", { style: "display:none;width:280px;background:var(--panel);color:var(--ink);padding:16px;overflow:auto;flex:none" });
    const ibtn = (ic, t, f) => h("button.icon-btn", { style: "color:#fff", title: t, html: icon(ic), onclick: f });
    const star = ibtn("star", "Favourite", () => { const p = list[at]; faves.has(p.path) ? faves.delete(p.path) : faves.add(p.path); saveFaves(); show(); });
    const playing = ibtn("refresh", "Slideshow", () => toggle());
    const view = h("div", { style: "position:fixed;inset:0;background:#000;z-index:30;display:flex;flex-direction:column" },
      h("div", { style: "display:flex;align-items:center;gap:6px;padding:10px 14px" }, ibtn("x", "Close", close), name, h("div", { style: "flex:1" }), playing, ibtn("info", "Info", () => { info_ = !info_; show(); }),
        ibtn("zoomout", "Zoom out", () => { zoom = Math.max(.4, zoom - .25); fit(); }), ibtn("zoomin", "Zoom in", () => { zoom = Math.min(4, zoom + .25); fit(); }), star, ibtn("edit", "Edit", () => startEdit()),
        ibtn("trash", "Move to Bin", async () => {
          const p = list[at]; if (!await confirmBox("Move to Bin?", `“${p.name}” will go to the Bin.`, "Move to Bin", true)) return;
          try { await wos.call("fs.trash", { paths: [p.path] }); photos = photos.filter(x => x.path !== p.path); list.splice(at, 1); if (!list.length) return close(); at = Math.min(at, list.length - 1); show(); } catch (e) { toast(errText(e)); } })),
      h("div", { style: "flex:1;min-height:0;display:flex" }, h("div", { style: "flex:1;min-width:0;display:flex;flex-direction:column;position:relative" }, stage, meta), panel));
    stage.append(img, canvas,
      h("button.icon-btn", { style: "position:absolute;left:10px;color:#fff;background:rgba(255,255,255,.12)", html: icon("back"), onclick: () => step(-1) }),
      h("button.icon-btn", { style: "position:absolute;right:10px;color:#fff;background:rgba(255,255,255,.12)", html: icon("forward"), onclick: () => step(1) }));
    function fit() { img.style.transform = `scale(${zoom})`; }
    function show() {
      const p = list[at]; if (!p) return; editing = null; panel.style.display = "none"; canvas.style.display = "none"; img.style.display = "";
      img.src = p.uri; name.textContent = `${p.name}  ·  ${at + 1} / ${list.length}`; star.style.color = faves.has(p.path) ? "#ff9f0a" : "#fff"; zoom = 1; fit();
      meta.style.display = info_ ? "block" : "none";
      meta.innerHTML = ""; meta.append(h("div", p.name), h("div", p.path), h("div", [p.size ? L.fmtBytes(p.size) : null, new Date(p.mtime * 1000).toLocaleString("en-GB")].filter(Boolean).join("  ·  ")));
      img.onload = () => { if (info_) meta.append(h("div", `${img.naturalWidth} × ${img.naturalHeight} pixels`)); };
    }
    function step(d) { at = (at + d + list.length) % list.length; show(); }
    function toggle() { if (timer) { clearInterval(timer); timer = null; playing.style.color = "#fff"; } else { timer = setInterval(() => step(1), 4000); playing.style.color = "#0a84ff"; toast("Slideshow: Esc to stop"); } }
    function close() { clearInterval(timer); view.remove(); document.removeEventListener("keydown", keys); draw(); }
    const keys = e => { if (e.key === "Escape") { if (timer) toggle(); else if (editing) show(); else close(); } else if (editing) return; else if (e.key === "ArrowLeft") step(-1); else if (e.key === "ArrowRight") step(1); else if (e.key === " ") { e.preventDefault(); toggle(); } };

    // ----- editor -----
    function startEdit() {
      const p = list[at]; if (timer) toggle();
      const st = editing = { adj: { brightness: 0, contrast: 0, saturation: 0 }, look: "none", quarters: 0, flip: false, ratio: 0, src: new Image() };
      st.src.onload = () => { panel.style.display = "block"; img.style.display = "none"; canvas.style.display = ""; paint(); };
      st.src.onerror = () => { toast("Could not open that picture for editing"); show(); };
      st.src.src = p.uri;
      const sliders = ["brightness", "contrast", "saturation"].map(k => h("div", { style: "margin:10px 0" }, h("div.small", { style: "font-weight:700;text-transform:capitalize;margin-bottom:4px" }, k),
        slider({ min: -100, max: 100, value: 0, onInput: v => { st.adj[k] = v; schedule(); } })));
      const looks = h("div", { style: "display:flex;flex-wrap:wrap;gap:6px" });
      const paintLooks = () => { looks.innerHTML = ""; Object.keys(L.LOOKS).forEach(k => looks.append(h("button.btn.small" + (st.look === k ? "" : ".ghost"), { onclick: () => { st.look = k; paintLooks(); schedule(); } }, k === "none" ? "Original" : k[0].toUpperCase() + k.slice(1)))); };
      const ratios = h("div", { style: "display:flex;flex-wrap:wrap;gap:6px" });
      const paintRatios = () => { ratios.innerHTML = ""; [["Original", 0], ["Square", 1], ["4:3", 4 / 3], ["3:2", 3 / 2], ["16:9", 16 / 9]].forEach(([l, r]) => ratios.append(h("button.btn.small" + (Math.abs(st.ratio - r) < 1e-6 ? "" : ".ghost"), { onclick: () => { st.ratio = r; paintRatios(); schedule(); } }, l))); };
      let queued = false; const schedule = () => { if (!queued) { queued = true; requestAnimationFrame(() => { queued = false; paint(); }); } };
      function render(maxSide) {
        const sw = st.src.naturalWidth, sh = st.src.naturalHeight, scale = Math.min(1, maxSide / Math.max(sw, sh));
        const rw = L.rotatedSize(sw, sh, st.quarters), c1 = document.createElement("canvas");
        c1.width = Math.max(1, Math.round(rw.w * scale)); c1.height = Math.max(1, Math.round(rw.h * scale));
        const x = c1.getContext("2d"); x.translate(c1.width / 2, c1.height / 2); x.rotate(st.quarters * Math.PI / 2); if (st.flip) x.scale(-1, 1);
        x.drawImage(st.src, -sw * scale / 2, -sh * scale / 2, sw * scale, sh * scale);
        const r = L.cropRect(c1.width, c1.height, st.ratio), out = document.createElement("canvas"); out.width = r.w; out.height = r.h;
        const ox = out.getContext("2d"); ox.drawImage(c1, r.x, r.y, r.w, r.h, 0, 0, r.w, r.h);
        const data = ox.getImageData(0, 0, r.w, r.h); L.adjustPixels(data.data, st.adj, st.look); ox.putImageData(data, 0, 0);
        return out;
      }
      function paint() { const out = render(1400); canvas.width = out.width; canvas.height = out.height; canvas.getContext("2d").drawImage(out, 0, 0); }
      const reset = () => { st.adj = { brightness: 0, contrast: 0, saturation: 0 }; st.look = "none"; st.quarters = 0; st.flip = false; st.ratio = 0; startEdit(); };
      paintLooks(); paintRatios();
      const save = h("button.btn", { onclick: async () => {
        save.disabled = true; save.textContent = "Saving…";
        try {
          const jpeg = /\.jpe?g$/i.test(p.name), out = render(100000);
          const data = out.toDataURL(jpeg ? "image/jpeg" : "image/png", 0.92);
          const saved = await wos.call("photos.save_edit", { path: p.path, data });
          toast("Saved a copy: " + saved.split("/").pop()); await load0(); const i = list.findIndex(x => x.path === saved); if (i >= 0) at = i; show();
        } catch (e) { toast(errText(e)); save.disabled = false; save.textContent = "Save a copy"; }
      } }, "Save a copy");
      panel.innerHTML = ""; panel.append(h("h2", { style: "margin:0 0 4px;font-size:18px" }, "Edit"), h("p.small.muted", { style: "margin:0 0 12px" }, "Your original is never changed. Saving makes a copy."),
        h("div.label", "Look"), looks, h("div.label", { style: "margin-top:14px" }, "Adjust"), ...sliders,
        h("div.label", { style: "margin-top:6px" }, "Rotate and flip"), h("div", { style: "display:flex;gap:6px;margin:6px 0 12px" },
          h("button.btn.small.ghost", { onclick: () => { st.quarters = (st.quarters + 3) % 4; schedule(); } }, "Left"), h("button.btn.small.ghost", { onclick: () => { st.quarters = (st.quarters + 1) % 4; schedule(); } }, "Right"), h("button.btn.small.ghost", { onclick: () => { st.flip = !st.flip; schedule(); } }, "Flip")),
        h("div.label", "Crop"), ratios, h("div", { style: "display:flex;gap:8px;margin-top:20px;flex-wrap:wrap" }, h("button.btn.ghost", { onclick: show }, "Cancel"), h("button.btn.ghost", { onclick: reset }, "Reset"), save));
    }
    async function load0() { try { photos = await wos.call("photos.list"); const keep = list.map(x => x.path); list.length = 0; (current.kind === "all" ? photos.slice().sort((a, b) => b.mtime - a.mtime) : visible()).forEach(x => list.push(x)); void keep; } catch (e) { /* keep what we have */ } }
    document.addEventListener("keydown", keys); document.body.append(view); show(); if (slideshow) toggle();
  }

  await load();
  // Opened with a picture (double-click one in Files): show it straight away, with its neighbours when it is one of the home folder's.
  const target = (info.args || []).find(a => a.startsWith("/") && /\.(jpe?g|png|gif|webp|bmp|svg)$/i.test(a));
  if (target) {
    const list = visible(), i = list.findIndex(p => p.path === target);
    if (i >= 0) open(list, i);
    else open([{ name: target.split("/").pop(), path: target, uri: "file://" + target.split("/").map(encodeURIComponent).join("/"), mtime: 0 }], 0);
  }
});
