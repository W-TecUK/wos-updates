"use strict";
/* Files: places on the left, the folder on the right. Select several things (Ctrl/Shift-click, Ctrl+A),
   right-click for the menu, drag onto a folder or a place to move (hold Ctrl to copy), search inside
   folders, zip and unzip. Home folder and plugged-in drives only. */

boot(async info => {
  const root = $("#root");
  let places = await wos.call("fs.places");
  const first = (info.args || []).find(a => a.startsWith("/") && (a === info.home || a.startsWith(info.home + "/")));
  let clipboard = null, bin = false, results = null, searchToken = 0, searchTimer = null, dragPaths = null;
  let cwd = first || info.home, history = [cwd], at = 0, entries = [], shown = [], filter = "", view = "grid", hidden = false;
  let sel = new Map(), picked = null, anchor = null;
  const els = new Map();
  const saved = await wos.data.get("prefs", {});
  view = saved.view || "grid"; hidden = !!saved.hidden;
  const savePrefs = () => wos.data.set("prefs", { view, hidden });

  const isImage = f => (f.mime || "").startsWith("image/") && !f.mime.includes("svg") || /\.(svg)$/i.test(f.name);
  const isArchive = f => !f.dir && /\.(zip|tar|tar\.gz|tgz|tar\.bz2|tbz2|tar\.xz|txz)$/i.test(f.name);
  const fileUri = p => "file://" + p.split("/").map(encodeURIComponent).join("/");
  const kindIcon = f => f.dir ? "folder" : (f.mime || "").startsWith("image/") ? "image" : (f.mime || "").startsWith("text/") ? "doc" : "file";
  const selected = () => [...sel.values()];
  const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
  const dirname = p => p.replace(/\/[^/]+$/, "") || "/";

  /* ---- frame */
  const side = h("aside.side"); const nav = h("nav.nav");
  side.append(h("span.label", "Places"), nav);
  const back = h("button.icon-btn", { title: "Back", html: icon("back"), onclick: () => step(-1) });
  const fwd = h("button.icon-btn", { title: "Forward", html: icon("forward"), onclick: () => step(1) });
  const upb = h("button.icon-btn", { title: "Up", html: icon("up"), onclick: () => go(cwd.replace(/\/[^/]+$/, "") || info.home) });
  const crumbs = h("div.grow", { style: "display:flex;gap:4px;align-items:center;overflow:hidden;font-weight:700" });
  const searchInput = h("input.field", { placeholder: "Search", oninput: e => { filter = e.target.value.trim(); runSearch(); } });
  const search = h("div.search", { style: "width:200px" }, h("span", { html: icon("search") }), searchInput);
  const viewSeg = h("div.seg", h("button", { "data-v": "grid", onclick: () => setView("grid"), title: "Icons", html: icon("grid", 16) }),
                    h("button", { "data-v": "list", onclick: () => setView("list"), title: "List", html: icon("list", 16) }));
  const newBtn = h("button.btn.small.ghost", { onclick: newFolder }, h("span", { html: icon("plus", 14) }), "New folder");
  const pasteBtn = h("button.btn.small.ghost", { onclick: paste, title: "Paste" }, "Paste");
  const infoBtn = h("button.icon-btn", { title: "Get Info", html: icon("info"), onclick: getInfo });
  const bar = h("div.bar", back, fwd, upb, crumbs, search, viewSeg, infoBtn, pasteBtn, newBtn);
  const body = h("div.body"); const status = h("div.small.muted", { style: "padding:8px 18px;border-top:1px solid var(--line)" });
  root.append(h("div.app", side, h("div.main", bar, body, status)));

  function setView(v) { view = v; savePrefs(); draw(); }
  function step(d) { const n = at + d; if (n < 0 || n >= history.length) return; at = n; load(history[at], false); }
  function go(path) { history = history.slice(0, at + 1); history.push(path); at = history.length - 1; load(path, false); }

  async function load(path) {
    bin = false; results = null; filter = ""; searchInput.value = ""; searchToken++;
    try { entries = await wos.call("fs.list", { path, hidden }); } catch (e) { toast(e.message); return; }
    cwd = path; setSel([]); draw();
  }

  /* ---- selection */
  function setSel(list, primary) { sel = new Map(list.map(f => [f.path, f])); picked = primary || list[list.length - 1] || null; anchor = picked; }
  function paintSel() {
    els.forEach((el, p) => el.classList.toggle("on", sel.has(p)));
    infoBtn.disabled = !picked;
    updateStatus();
  }
  function updateStatus() {
    if (bin) return;
    const n = shown.length, s = sel.size;
    status.textContent = (results ? plural(n, "result") : plural(n, "item")) + (s > 1 ? `  ·  ${s} selected` : s === 1 ? `  ·  ${picked.name}` : "");
  }
  function clickItem(e, f) {
    e.stopPropagation();
    if (e.ctrlKey || e.metaKey) { if (sel.has(f.path)) sel.delete(f.path); else sel.set(f.path, f); picked = sel.size ? f : null; anchor = f; }
    else if (e.shiftKey && anchor) {
      const a = shown.findIndex(x => x.path === anchor.path), b = shown.findIndex(x => x.path === f.path);
      if (a >= 0 && b >= 0) { sel = new Map(shown.slice(Math.min(a, b), Math.max(a, b) + 1).map(x => [x.path, x])); picked = f; }
    } else setSel([f], f);
    paintSel();
  }

  /* ---- drag and drop: move onto a folder, a place or a breadcrumb; hold Ctrl to copy */
  function dropTarget(el, dest) {
    el.addEventListener("dragover", e => { if (!dragPaths || dragPaths.includes(dest)) return; e.preventDefault(); e.dataTransfer.dropEffect = e.ctrlKey ? "copy" : "move"; el.classList.add("drop-target"); });
    el.addEventListener("dragleave", () => el.classList.remove("drop-target"));
    el.addEventListener("drop", e => { e.preventDefault(); e.stopPropagation(); el.classList.remove("drop-target"); if (dragPaths) dropOn(dragPaths, dest, e.ctrlKey); });
  }
  async function dropOn(paths, dest, copy) {
    paths = paths.filter(p => p !== dest && !dest.startsWith(p + "/") && (copy || dirname(p) !== dest));
    dragPaths = null;
    if (!paths.length) return;
    try { await wos.call(copy ? "fs.copy" : "fs.move", { paths, dest }); toast((copy ? "Copied " : "Moved ") + plural(paths.length, "item")); load(cwd); } catch (e) { toast(e.message); }
  }
  function makeItem(el, f) {
    el.draggable = true; els.set(f.path, el);
    el.addEventListener("click", e => clickItem(e, f));
    el.addEventListener("dblclick", () => openIt(f));
    el.addEventListener("contextmenu", e => { e.preventDefault(); e.stopPropagation(); if (!sel.has(f.path)) { setSel([f], f); paintSel(); } itemMenu(e.clientX, e.clientY); });
    el.addEventListener("dragstart", e => {
      if (!sel.has(f.path)) { setSel([f], f); paintSel(); }
      dragPaths = selected().map(x => x.path);
      e.dataTransfer.setData("text/plain", dragPaths.join("\n")); e.dataTransfer.effectAllowed = "copyMove";
    });
    el.addEventListener("dragend", () => { dragPaths = null; $$(".drop-target").forEach(x => x.classList.remove("drop-target")); });
    if (f.dir) dropTarget(el, f.path);
    return el;
  }

  /* ---- search: type 2+ letters to search this folder and everything inside it */
  function runSearch() {
    clearTimeout(searchTimer); searchToken++;
    if (filter.length < 2) { results = null; draw(); return; }
    const token = searchToken;
    draw();                                           // instant: filter what is already showing
    searchTimer = setTimeout(async () => {
      status.textContent = "Searching…";
      try { const found = await wos.call("fs.search", { path: cwd, query: filter, hidden }); if (token !== searchToken) return; results = found; draw(); }
      catch (e) { if (token === searchToken) toast(e.message); }
    }, 250);
  }

  function drawNav() {
    nav.innerHTML = "";
    places.forEach(p => {
      const b = h("button" + (cwd === p.path && !bin ? ".on" : ""), { onclick: () => { bin = false; go(p.path); } }, h("span", { html: icon(p.icon) }), p.name,
        p.removable ? h("span.icon-btn", { style: "width:22px;height:22px;margin-left:auto", title: "Eject", onclick: async e => {
          e.stopPropagation();
          try { await wos.call("fs.eject", { path: p.path }); if (cwd === p.path || cwd.startsWith(p.path + "/")) go(info.home); }
          catch (er) { toast(er.message); }
        }, html: icon("x", 12) }) : null);
      dropTarget(b, p.path);
      nav.append(b);
    });
    nav.append(h("button" + (bin ? ".on" : ""), { onclick: showBin }, h("span", { html: icon("trash") }), "Bin"));
  }
  function drawCrumbs() {
    crumbs.innerHTML = "";
    if (results) { crumbs.append(h("span", { style: "font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" }, `Results for “${filter}”`)); return; }
    const rel = cwd === info.home ? [] : cwd.startsWith(info.home + "/") ? cwd.slice(info.home.length + 1).split("/") : [];
    let acc = info.home;
    const homeBtn = h("button.btn.small.ghost", { onclick: () => go(info.home) }, cwd === info.home || cwd.startsWith(info.home + "/") ? "Home" : cwd.split("/").pop() || "/");
    dropTarget(homeBtn, info.home);
    crumbs.append(homeBtn);
    rel.forEach(part => { acc += "/" + part; const p = acc; const b = h("button.btn.small.ghost", { onclick: () => go(p) }, part); dropTarget(b, p); crumbs.append(h("span.muted", "/"), b); });
  }

  function draw() {
    drawNav(); drawCrumbs(); els.clear();
    back.disabled = at === 0; fwd.disabled = at >= history.length - 1;
    pasteBtn.style.display = clipboard ? "" : "none";
    $$("button", viewSeg).forEach(b => b.classList.toggle("on", b.dataset.v === view));
    const lc = filter.toLowerCase();
    shown = results && filter.length >= 2 ? results : entries.filter(f => !lc || f.name.toLowerCase().includes(lc));
    const mode = results ? "list" : view;
    body.innerHTML = "";
    body.oncontextmenu = e => { e.preventDefault(); if (!results) { setSel([]); paintSel(); blankMenu(e.clientX, e.clientY); } };
    body.onclick = () => { setSel([]); paintSel(); };
    if (!shown.length) { body.append(h("div.empty", h("div", h("div", { html: icon(results || filter ? "search" : "folder", 44), style: "color:var(--muted);margin-bottom:10px" }),
      h("p", filter ? (results === null && filter.length >= 2 ? "Searching…" : "Nothing here matches.") : "This folder is empty.")))); }
    else if (mode === "grid") {
      const grid = h("div.grid");
      shown.forEach(f => {
        const thumb = isImage(f) ? h("img", { src: fileUri(f.path), draggable: false, style: "width:100%;height:84px;object-fit:cover;border-radius:10px;background:var(--panel-2)" })
                                  : h("div", { html: icon(kindIcon(f), 40), style: "height:84px;display:grid;place-items:center;color:var(--ink-2)" });
        grid.append(makeItem(h("div.tile" + (sel.has(f.path) ? ".on" : ""), { title: f.name },
          thumb, h("div.t", { style: "margin-top:8px;font-weight:700;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" }, f.name)), f));
      });
      body.append(grid);
    } else {
      const card = h("div.card"); const l = h("div.list");
      shown.forEach(f => l.append(makeItem(h("div.row" + (sel.has(f.path) ? ".on" : ""), { title: f.path },
        h("span", { html: icon(kindIcon(f), 20), style: "color:var(--ink-2)" }),
        h("div.grow", h("div.t", f.name), results ? h("div.s", dirname(f.path).replace(info.home, "~")) : null),
        h("span.small.muted", f.dir ? "" : fmtSize(f.size)), h("span.small.muted", { style: "width:120px;text-align:right" }, new Date(f.mtime * 1000).toLocaleDateString("en-GB"))), f)));
      card.append(l); body.append(card);
    }
    infoBtn.disabled = !picked;
    updateStatus();
  }

  /* ---- menus */
  function itemMenu(x, y) {
    const items = selected(), one = items.length === 1 ? items[0] : null;
    contextMenu([
      { label: one && isArchive(one) ? "Unpack" : "Open", icon: "folder", hint: "Enter", onclick: () => openSel() },
      one && !one.dir ? { label: "Open with…", onclick: () => openWith(one) } : null,
      "-",
      { label: "Cut", hint: "Ctrl+X", onclick: () => setClip("move") },
      { label: "Copy", hint: "Ctrl+C", onclick: () => setClip("copy") },
      { label: "Rename", icon: "edit", hint: "F2", disabled: !one, onclick: rename },
      "-",
      { label: items.length > 1 ? `Compress ${items.length} items` : "Compress", onclick: compress },
      one && isArchive(one) ? { label: "Unpack here", onclick: () => extractIt(one) } : null,
      { label: "Get Info", icon: "info", disabled: !one, onclick: getInfo },
      "-",
      { label: "Move to Bin", icon: "trash", danger: true, hint: "Del", onclick: trashSel },
    ], x, y);
  }
  function blankMenu(x, y) {
    contextMenu([
      { label: "New folder", icon: "plus", hint: "Ctrl+N", onclick: newFolder },
      { label: "New text file", onclick: newFile },
      "-",
      { label: "Paste", hint: "Ctrl+V", disabled: !clipboard, onclick: paste },
      "-",
      { label: hidden ? "Hide hidden files" : "Show hidden files", hint: "Ctrl+H", onclick: toggleHidden },
      { label: "Refresh", onclick: () => load(cwd) },
    ], x, y);
  }
  function toggleHidden() { hidden = !hidden; savePrefs(); load(cwd); }
  function setClip(mode) { if (!sel.size) return; clipboard = { mode, paths: selected().map(f => f.path) }; pasteBtn.style.display = ""; toast((mode === "copy" ? "Copied " : "Cut ") + plural(sel.size, "item")); }

  /* ---- actions */
  async function openIt(f) {
    if (f.dir) go(f.path);
    else if (isArchive(f)) extractIt(f);
    else { try { await wos.call("fs.open", { path: f.path }); } catch (e) { toast(e.message); } }
  }
  function openSel() { const items = selected(); const dir = items.find(f => f.dir); if (dir) openIt(dir); else items.forEach(openIt); }
  async function paste() {
    if (!clipboard || bin) return;
    try {
      await wos.call(clipboard.mode === "copy" ? "fs.copy" : "fs.move", { paths: clipboard.paths, dest: cwd });
      if (clipboard.mode === "move") clipboard = null;
      load(cwd); toast("Done");
    } catch (e) { toast(e.message); }
  }
  async function trashSel() {
    const items = selected(); if (!items.length) return;
    try { await wos.call("fs.trash", { paths: items.map(f => f.path) }); toast(items.length === 1 ? "Moved to the Bin" : `Moved ${items.length} items to the Bin`); load(cwd); } catch (e) { toast(e.message); }
  }
  async function compress() {
    const items = selected(); if (!items.length) return;
    toast("Compressing…");
    try { await wos.call("fs.compress", { paths: items.map(f => f.path) }); toast("Compressed"); load(cwd); } catch (e) { toast(e.message); }
  }
  async function extractIt(f) {
    toast("Unpacking…");
    try { await wos.call("fs.extract", { path: f.path }); toast("Unpacked"); load(cwd); } catch (e) { toast(e.message); }
  }
  async function newFolder() {
    if (bin) return;
    const name = await prompt2("New folder", "Untitled folder"); if (!name || !name.trim()) return;
    try { await wos.call("fs.mkdir", { parent: cwd, name: name.trim() }); load(cwd); } catch (e) { toast(e.message); }
  }
  async function newFile() {
    if (bin) return;
    try { await wos.call("fs.new_file", { parent: cwd, name: "Untitled.txt" }); load(cwd); } catch (e) { toast(e.message); }
  }
  async function rename() {
    if (sel.size !== 1) return; const f = picked;
    const name = await prompt2("Rename", f.name); if (!name || name === f.name) return;
    try { await wos.call("fs.rename", { path: f.path, name }); load(cwd); } catch (e) { toast(e.message); }
  }
  async function openWith(f) {
    let apps = []; try { apps = await wos.call("fs.apps_for", { path: f.path }); } catch (e) { toast(e.message); return; }
    if (!apps.length) { toast("No app on this computer can open that"); return; }
    const done = () => back.remove();
    const list = h("div.list", apps.map(a => h("button.row", { onclick: async () => { done(); try { await wos.call("fs.open_with", { path: f.path, id: a.id }); } catch (e) { toast(e.message); } } },
      h("div.grow", h("div.t", a.name), a.default ? h("div.s", "Default") : null))));
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) done(); } },
      h("div.modal", h("h2", `Open “${f.name}” with`), h("div.card", { style: "max-height:50vh;overflow:auto" }, list),
        h("div.actions", h("button.btn.ghost", { onclick: done }, "Cancel"))));
    document.body.append(back);
  }
  async function showBin() {
    bin = true; results = null; setSel([]); body.innerHTML = ""; body.oncontextmenu = null; body.onclick = null; drawNav(); crumbs.innerHTML = ""; crumbs.append(h("span", { style: "font-weight:800" }, "Bin"));
    infoBtn.disabled = true; pasteBtn.style.display = "none";
    let items = []; try { items = await wos.call("fs.bin.list"); } catch (e) { items = []; }
    if (!items.length) { body.append(h("div.empty", h("div", h("div", { html: icon("trash", 44), style: "color:var(--muted);margin-bottom:10px" }), h("p", "The Bin is empty.")))); status.textContent = "0 items"; return; }
    const l = h("div.list"); items.forEach(it => l.append(h("div.row", { style: "cursor:default" }, h("span", { html: icon(it.dir ? "folder" : "file", 20), style: "color:var(--ink-2)" }),
      h("div.grow", h("div.t", it.name), h("div.s", it.orig)), h("button.btn.ghost.small", { onclick: async () => { try { await wos.call("fs.bin.restore", { id: it.id }); showBin(); } catch (e) { toast(e.message); } } }, "Put back"))));
    body.append(h("div.card", l), h("div", { style: "margin-top:12px" }, h("button.btn.danger.small", { onclick: async () => { if (!await confirmBox("Empty the Bin?", "Everything in it will be deleted for good.", "Empty Bin", true)) return; await wos.call("fs.bin.empty"); showBin(); } }, "Empty Bin")));
    status.textContent = plural(items.length, "item");
  }

  /* Quick Look, macOS's own name for exactly this: Space previews the selected file without
     opening a whole app for it. Images render directly; text-ish files show their content;
     anything else falls back to a big icon and its name/size, same as macOS does for a file
     type it has no real preview for. */
  let qlOpen = false;
  async function quickLook() {
    // Guards against the outer keydown listener below (registered first, so it runs first):
    // pressing Space to close this re-fires that same listener, which still sees `picked` set
    // and would call quickLook() again right as onKey closes it -- net effect "replace", not
    // "close". Without this guard, that's exactly what happens.
    if (!picked || qlOpen) return;
    qlOpen = true;
    const f = picked;
    const close = () => { qlOpen = false; back.remove(); document.removeEventListener("keydown", onKey); };
    const onKey = e => { if (e.key === "Escape" || e.key === " ") { e.preventDefault(); close(); } };
    const content = h("div", { style: "flex:1;overflow:auto;display:grid;place-items:center;padding:24px;min-height:160px" });
    const box = h("div.card", { style: "width:min(720px,86vw);max-height:80vh;display:flex;flex-direction:column;overflow:hidden;padding:0" },
      h("div.bar", h("div.grow", h("div.t", f.name)), h("button.icon-btn", { title: "Close", onclick: close, html: icon("x") })), content);
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) close(); } }, box);
    document.addEventListener("keydown", onKey);
    document.body.append(back);
    if (isImage(f)) {
      content.append(h("img", { src: fileUri(f.path), style: "max-width:100%;max-height:70vh;border-radius:10px;object-fit:contain" }));
    } else if (!f.dir && ((f.mime || "").startsWith("text/") || /\.(txt|md|json|ya?ml|js|ts|py|css|html?|xml|csv|log|sh|ini|conf)$/i.test(f.name))) {
      content.style.display = "block"; content.style.textAlign = "left";
      try {
        const text = await wos.call("fs.read_text", { path: f.path, limit: 200000 });
        content.append(h("pre", { style: "white-space:pre-wrap;font-family:monospace;font-size:12.5px;margin:0;user-select:text" }, text));
      } catch (e) { content.append(h("p.muted", "Couldn't read this file.")); }
    } else {
      content.append(h("div", { style: "text-align:center" }, h("div", { html: icon(kindIcon(f), 64), style: "color:var(--muted);margin-bottom:12px" }),
        h("div.t", f.name), f.dir ? null : h("div.s.muted", fmtSize(f.size))));
    }
  }
  // Get Info (a toolbar button, not just a shortcut -- Cmd+I is the natural key but everything
  // else in this app already has a mouse path too, so this shouldn't be keyboard-only).
  let giOpen = false;
  function getInfo() {
    if (!picked || giOpen) return;
    giOpen = true;
    const f = picked;
    const close = () => { giOpen = false; back.remove(); document.removeEventListener("keydown", onKey); };
    const onKey = e => { if (e.key === "Escape") { e.preventDefault(); close(); } };
    const row = (label, value) => h("div.row", { style: "cursor:default;min-height:40px" },
      h("span.muted", { style: "width:90px;flex:none" }, label),
      h("span", { style: "user-select:text;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" }, value));
    const box = h("div.card", { style: "width:min(420px,86vw);padding:0;overflow:hidden" },
      h("div.bar", h("div.grow", h("div.t", f.name)), h("button.icon-btn", { title: "Close", onclick: close, html: icon("x") })),
      h("div", { style: "padding:6px 16px 16px" },
        row("Kind", f.dir ? "Folder" : (f.mime || "Unknown")),
        f.dir ? null : row("Size", fmtSize(f.size)),
        row("Modified", new Date(f.mtime * 1000).toLocaleString("en-GB")),
        row("Location", f.path)));
    const back = h("div.modal-back", { onclick: e => { if (e.target === back) close(); } }, box);
    document.addEventListener("keydown", onKey);
    document.body.append(back);
  }

  /* ---- keyboard */
  function moveSel(delta) {
    if (!shown.length) return;
    const idx = picked ? shown.findIndex(f => f.path === picked.path) : -1;
    const n = Math.max(0, Math.min(shown.length - 1, idx < 0 ? 0 : idx + delta));
    const f = shown[n]; setSel([f], f); paintSel();
    const el = els.get(f.path); if (el) el.scrollIntoView({ block: "nearest" });
  }
  function columns() {
    const tiles = $$(".grid > .tile", body); if (!tiles.length) return 1;
    let c = 0; while (c < tiles.length && tiles[c].offsetTop === tiles[0].offsetTop) c++;
    return c || 1;
  }
  document.addEventListener("keydown", e => {
    if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA" || qlOpen || giOpen || document.querySelector(".modal-back")) return;
    const mod = e.ctrlKey || e.metaKey, key = e.key.toLowerCase();
    if (bin) return;
    if (e.key === "F2") rename(); else if (e.key === "Delete") trashSel(); else if (e.key === "Enter" && sel.size) openSel();
    else if (mod && key === "i" && picked) { e.preventDefault(); getInfo(); }
    else if (e.key === " " && picked) { e.preventDefault(); quickLook(); }
    else if (e.key === "Backspace") upb.click(); else if (mod && key === "h") { e.preventDefault(); toggleHidden(); }
    else if (mod && key === "n") { e.preventDefault(); newFolder(); }
    else if (mod && key === "a") { e.preventDefault(); setSel(shown.slice()); paintSel(); }
    else if (mod && key === "f") { e.preventDefault(); searchInput.focus(); }
    else if (mod && key === "c" && sel.size) setClip("copy");
    else if (mod && key === "x" && sel.size) setClip("move");
    else if (mod && key === "v" && clipboard) paste();
    else if (e.key === "Escape") { if (sel.size) { setSel([]); paintSel(); } }
    else if (e.key === "ArrowRight") { e.preventDefault(); moveSel(1); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); moveSel(-1); }
    else if (e.key === "ArrowDown") { e.preventDefault(); moveSel(view === "grid" && !results ? columns() : 1); }
    else if (e.key === "ArrowUp") { e.preventDefault(); moveSel(view === "grid" && !results ? -columns() : -1); }
  });
  wos.on("theme", () => {});
  // A USB drive plugged in (or pulled out) while this window is already open, pushed live --
  // previously needed a reopen of Files to show up or disappear at all.
  wos.on("places", m => { places = m.places; drawNav(); });
  if ((info.args || []).includes("bin")) showBin(); else load(cwd);      // the desktop's Bin opens straight to the Bin
});
