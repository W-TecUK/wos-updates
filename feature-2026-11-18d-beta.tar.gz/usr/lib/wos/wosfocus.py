"""A schedule for Do Not Disturb ("Focus"): quiet hours such as 22:00 to 07:00. Pure functions, tested anywhere.

The shell checks the clock every half minute. It only changes Do Not Disturb when the schedule crosses a boundary, so the person
can still switch it on or off by hand in between and the schedule never fights them.
"""
import re

TIME_RE = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")


def clean(raw):
    raw = raw if isinstance(raw, dict) else {}
    start, end = str(raw.get("from", "22:00")), str(raw.get("to", "07:00"))
    return {"on": bool(raw.get("on")), "from": start if TIME_RE.match(start) else "22:00", "to": end if TIME_RE.match(end) else "07:00"}


def minutes(text):
    h, m = text.split(":")
    return int(h) * 60 + int(m)


def in_window(cfg, now_minutes):
    """Is `now_minutes` (minutes since midnight) inside the quiet hours? Handles windows that run past midnight."""
    c = clean(cfg)
    if not c["on"]:
        return False
    a, b = minutes(c["from"]), minutes(c["to"])
    if a == b:
        return False                       # an empty window, not an all-day one
    return a <= now_minutes < b if a < b else (now_minutes >= a or now_minutes < b)


def transition(was_inside, inside):
    """What to do with Do Not Disturb: 'on' when quiet hours start, 'off' when they end, None otherwise (including the first check)."""
    if was_inside is None or was_inside == inside:
        return None
    return "on" if inside else "off"
