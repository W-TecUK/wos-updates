"use strict";
/* App Store: discover apps, see what is installed, check for updates.
   The catalogue below is a placeholder list until the App Store service exists; installing is not
   wired up yet, so "Get" says so instead of pretending. */

boot(async info => {
  const root = $("#root");
  let tab = "discover", installed = [], catalogue = [], busy = new Set();
  const load = async () => { try { installed = await wos.call("sys.apps"); } catch (e) { installed = []; } try { catalogue = await wos.call("store.catalogue"); } catch (e) { catalogue = []; } };
  await load();
  const has = c => c.installed;
  const appIcon = c => c.icon
    ? h("img", { src: "../../store/icons/" + c.icon + ".svg", width: 52, height: 52, style: "border-radius:14px;flex:none;display:block" })
    : h("div", { style: "width:52px;height:52px;border-radius:14px;background:var(--panel-2);display:grid;place-items:center;flex:none", html: icon(c.glyph || "grid", 26) });
  const badge = c => c.kind === "web" ? "Web app" : c.kind === "flatpak" ? "App" : "";

  const nav = h("nav.nav"); const body = h("div.body");
  const side = h("aside.side", h("span.label", { style: "margin-top:0" }, "App Store"), nav);
  root.append(h("div.app", side, h("div.main", body)));

  function drawNav() {
    nav.innerHTML = "";
    [["discover", "Discover", "bag"], ["installed", "Installed", "grid"], ["updates", "Updates", "refresh"]].forEach(([k, l, i]) =>
      nav.append(h("button" + (tab === k ? ".on" : ""), { onclick: () => { tab = k; draw(); } }, h("span", { html: icon(i) }), l)));
  }
  const getBtn = c => {
    if (busy.has(c.package || c.id)) return h("span.chip", c.kind === "flatpak" ? "Installing…" : "Working…");
    if (c.installed) return h("button.btn.ghost.small", { onclick: () => act(c, "store.remove", "Removed") }, "Remove");
    return h("button.btn.small", { onclick: () => act(c, "store.install", "Installed") }, "Get");
  };
  async function act(c, method, done) {
    busy.add(c.package || c.id); draw();
    try { await wos.call(method, c.kind === "web" || c.kind === "flatpak" ? { id: c.id } : { package: c.package }); toast(c.name + ": " + done); } catch (e) { toast(e.message); }
    busy.delete(c.package || c.id); await load(); draw();
  }

  function draw() {
    drawNav(); body.innerHTML = "";
    if (tab === "discover") {
      body.append(h("h1.dots", { style: "font-size:40px;margin:4px 0 4px" }, "Discover"), h("p.muted", { style: "margin:0 0 20px" }, "Apps picked for W-OS."));
      const order = ["Music", "Microsoft", "Developer", "Work", "Internet", "Video", "Creative", "Security"];
      const rank = c => { const i = order.indexOf(c); return i < 0 ? 99 : i; };
      const cats = [...new Set(catalogue.map(c => c.cat))].sort((x, y) => rank(x) - rank(y) || x.localeCompare(y));
      cats.forEach(cat => {
        body.append(h("div.label", { style: "margin:18px 0 10px" }, cat));
        const grid = h("div.grid", { style: "grid-template-columns:repeat(auto-fill,minmax(250px,1fr))" });
        catalogue.filter(c => c.cat === cat).forEach(c => grid.append(h("div.card.pad", { style: "display:flex;gap:14px;align-items:center" },
          appIcon(c),
          h("div", { style: "flex:1;min-width:0" }, h("div", { style: "font-weight:800" }, c.name), h("div.small.muted", c.blurb), h("div.small.muted", { style: "opacity:.7" }, [c.by, badge(c)].filter(Boolean).join("  ·  ")),
            c.note && !c.installed ? h("div.small.muted", { style: "opacity:.7" }, c.note) : ""), getBtn(c))));
        body.append(grid);
      });
    } else if (tab === "installed") {
      body.append(h("h1", { style: "margin:4px 0 16px" }, "Installed"), h("div.card", h("div.list", installed.map(a => h("div.row", { style: "cursor:default" },
        h("div.grow", h("div.t", a.name), h("div.s", a.description || "")), h("button.btn.ghost.small", { onclick: () => wos.call("sys.launch", { id: a.id }) }, "Open"))))));
    } else {
      body.append(h("h1", { style: "margin:4px 0 16px" }, "Updates"), h("div.card.pad", { style: "display:flex;align-items:center;gap:14px" },
        h("span", { html: icon("check", 26), style: "color:var(--ok)" }), h("div", { style: "flex:1" }, h("div", { style: "font-weight:800" }, "W-OS is up to date"), h("div.small.muted", `Version ${info.version}`)),
        h("button.btn.ghost.small", { onclick: async () => { toast("Checking…"); try { await wos.call("store.refresh"); toast("Up to date"); } catch (e) { toast(e.message); } } }, "Check now")));
    }
  }
  draw();
});
